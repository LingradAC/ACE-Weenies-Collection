DELETE FROM `landblock_instance` WHERE `landblock` = 0x01A8;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701A8007,   278, 0x01A8011D, 25.245, -80, -6, -0.707107, 0, 0, -0.707107, False, '2005-02-09 10:00:00'); /* Door */
/* @teleloc 0x01A8011D [25.245001 -80.000000 -6.000000] -0.707107 0.000000 0.000000 -0.707107 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701A8016,   153, 0x01A80147, 30, -10, 0, 0.707107, 0, 0, -0.707107, False, '2005-02-09 10:00:00'); /* Fountain */
/* @teleloc 0x01A80147 [30.000000 -10.000000 0.000000] 0.707107 0.000000 0.000000 -0.707107 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701A8035,  1289, 0x01A80180, 64.75, -80, 0, 0.707107, 0, 0, -0.707107, False, '2005-02-09 10:00:00'); /* Door */
/* @teleloc 0x01A80180 [64.750000 -80.000000 0.000000] 0.707107 0.000000 0.000000 -0.707107 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701A8036, 801836, 0x01A8014E, 27.7343, -50.0524, 0.055, 0.749728, 0, 0, 0.661747, False, '2023-01-04 18:29:24');
/* @teleloc 0x01A8014E [27.734301 -50.052399 0.055000] 0.749728 0.000000 0.000000 0.661747 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701A8037, 801836, 0x01A8015E, 41.8108, -50.223, 0.055, -0.0889407, 0, 0, -0.996037, False, '2023-01-04 18:29:40');
/* @teleloc 0x01A8015E [41.810799 -50.223000 0.055000] -0.088941 0.000000 0.000000 -0.996037 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701A8038, 801836, 0x01A8015F, 41.7663, -60.5843, 0.055, 0.0329504, 0, 0, -0.999457, False, '2023-01-04 18:29:43');
/* @teleloc 0x01A8015F [41.766300 -60.584301 0.055000] 0.032950 0.000000 0.000000 -0.999457 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701A8039, 801836, 0x01A80160, 42.206, -69.9562, 0.055, 0.606173, 0, 0, -0.795333, False, '2023-01-04 18:29:46');
/* @teleloc 0x01A80160 [42.206001 -69.956200 0.055000] 0.606173 0.000000 0.000000 -0.795333 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701A803A, 801836, 0x01A80161, 41.212, -78.1023, 0.055, -0.00323842, 0, 0, -0.999995, False, '2023-01-04 18:29:49');
/* @teleloc 0x01A80161 [41.212002 -78.102303 0.055000] -0.003238 0.000000 0.000000 -0.999995 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701A803B, 801836, 0x01A80151, 27.1069, -80.2711, 0.055, -0.723612, 0, 0, -0.690207, False, '2023-01-04 18:29:53');
/* @teleloc 0x01A80151 [27.106899 -80.271103 0.055000] -0.723612 0.000000 0.000000 -0.690207 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701A803C, 801836, 0x01A80150, 27.4327, -69.9952, 0.055, -0.999548, 0, 0, -0.0300533, False, '2023-01-04 18:29:56');
/* @teleloc 0x01A80150 [27.432699 -69.995201 0.055000] -0.999548 0.000000 0.000000 -0.030053 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701A803D, 801836, 0x01A8014F, 26.6755, -61.3249, 0.055, -0.999849, 0, 0, -0.0173697, False, '2023-01-04 18:29:59');
/* @teleloc 0x01A8014F [26.675501 -61.324902 0.055000] -0.999849 0.000000 0.000000 -0.017370 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701A803E, 801836, 0x01A8015E, 35.2189, -49.5347, 0.055, 0.0601171, 0, 0, 0.998191, False, '2023-01-04 18:30:02');
/* @teleloc 0x01A8015E [35.218899 -49.534698 0.055000] 0.060117 0.000000 0.000000 0.998191 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701A803F, 801836, 0x01A8015F, 36.6467, -62.791, 0.055, 0.76146, 0, 0, 0.648212, False, '2023-01-04 18:30:09');
/* @teleloc 0x01A8015F [36.646702 -62.791000 0.055000] 0.761460 0.000000 0.000000 0.648212 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701A8040, 801836, 0x01A80150, 34.9454, -71.6911, 0.055, 0.694957, 0, 0, 0.719052, False, '2023-01-04 18:30:17');
/* @teleloc 0x01A80150 [34.945400 -71.691101 0.055000] 0.694957 0.000000 0.000000 0.719052 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701A8041, 801836, 0x01A80161, 36.1656, -78.9402, 0.055, 0.0289884, 0, 0, 0.99958, False, '2023-01-04 18:30:21');
/* @teleloc 0x01A80161 [36.165600 -78.940201 0.055000] 0.028988 0.000000 0.000000 0.999580 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701A8042, 801836, 0x01A801AD, 49.536, -79.9215, 6.055, 0.997632, 0, 0, 0.0687743, False, '2023-01-04 18:31:30');
/* @teleloc 0x01A801AD [49.535999 -79.921501 6.055000] 0.997632 0.000000 0.000000 0.068774 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701A8043, 801836, 0x01A801AC, 50.7913, -67.9394, 6.055, 0.995035, 0, 0, 0.0995307, False, '2023-01-04 18:31:38');
/* @teleloc 0x01A801AC [50.791302 -67.939400 6.055000] 0.995035 0.000000 0.000000 0.099531 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701A8044, 801836, 0x01A801AA, 50.7733, -49.599, 6.055, 0.999961, 0, 0, -0.00888518, False, '2023-01-04 18:31:40');
/* @teleloc 0x01A801AA [50.773300 -49.598999 6.055000] 0.999961 0.000000 0.000000 -0.008885 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701A8045, 801836, 0x01A80198, 20.71, -50.3361, 6.055, -0.05257, 0, 0, 0.998617, False, '2023-01-04 18:31:48');
/* @teleloc 0x01A80198 [20.709999 -50.336102 6.055000] -0.052570 0.000000 0.000000 0.998617 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701A8046, 801836, 0x01A80199, 20.5701, -60.7687, 6.055, -0.0408292, 0, 0, 0.999166, False, '2023-01-04 18:31:49');
/* @teleloc 0x01A80199 [20.570101 -60.768700 6.055000] -0.040829 0.000000 0.000000 0.999166 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701A8047, 801836, 0x01A8019B, 20.8876, -78.4157, 6.055, 0.0179269, 0, 0, 0.999839, False, '2023-01-04 18:31:51');
/* @teleloc 0x01A8019B [20.887600 -78.415703 6.055000] 0.017927 0.000000 0.000000 0.999839 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701A8048, 801825, 0x01A80151, 34.9096, -80.283, 0.055, -0.999977, 0, 0, -0.00682392, False, '2023-02-20 04:50:23'); /* SandTuskerGen */
/* @teleloc 0x01A80151 [34.909599 -80.282997 0.055000] -0.999977 0.000000 0.000000 -0.006824 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701A8049, 801825, 0x01A80150, 34.9595, -74.1178, 0.055, -0.999977, 0, 0, -0.00682392, False, '2023-02-20 04:50:29'); /* SandTuskerGen */
/* @teleloc 0x01A80150 [34.959499 -74.117798 0.055000] -0.999977 0.000000 0.000000 -0.006824 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701A804A, 801825, 0x01A80150, 34.889, -68.952, 0.055, -0.999977, 0, 0, -0.00682392, False, '2023-02-20 04:50:31'); /* SandTuskerGen */
/* @teleloc 0x01A80150 [34.889000 -68.952003 0.055000] -0.999977 0.000000 0.000000 -0.006824 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701A804B, 801825, 0x01A8015F, 35.0789, -60.4941, 0.055, -0.999977, 0, 0, -0.00682392, False, '2023-02-20 04:50:32'); /* SandTuskerGen */
/* @teleloc 0x01A8015F [35.078899 -60.494099 0.055000] -0.999977 0.000000 0.000000 -0.006824 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701A804C, 801825, 0x01A8014E, 34.9795, -53.2067, 0.055, -0.999977, 0, 0, -0.00682392, False, '2023-02-20 04:50:33'); /* SandTuskerGen */
/* @teleloc 0x01A8014E [34.979500 -53.206699 0.055000] -0.999977 0.000000 0.000000 -0.006824 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701A804D, 801825, 0x01A8014E, 34.9164, -48.5857, 0.055, -0.999977, 0, 0, -0.00682392, False, '2023-02-20 04:50:35'); /* SandTuskerGen */
/* @teleloc 0x01A8014E [34.916401 -48.585701 0.055000] -0.999977 0.000000 0.000000 -0.006824 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701A804E, 801825, 0x01A801AD, 51.2343, -82.8811, 6.055, -0.999986, 0, 0, 0.00524138, False, '2023-02-20 04:51:06'); /* SandTuskerGen */
/* @teleloc 0x01A801AD [51.234299 -82.881104 6.055000] -0.999986 0.000000 0.000000 0.005241 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701A804F, 801825, 0x01A801AC, 50.555, -72.7278, 6.055, -0.996851, 0, 0, -0.0792939, False, '2023-02-20 04:51:11'); /* SandTuskerGen */
/* @teleloc 0x01A801AC [50.555000 -72.727798 6.055000] -0.996851 0.000000 0.000000 -0.079294 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701A8050, 801825, 0x01A801AB, 50.1929, -62.1481, 6.055, -0.997473, 0, 0, 0.0710397, False, '2023-02-20 04:51:17'); /* SandTuskerGen */
/* @teleloc 0x01A801AB [50.192902 -62.148102 6.055000] -0.997473 0.000000 0.000000 0.071040 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701A8051, 801825, 0x01A801AA, 50.4146, -49.9357, 6.055, -0.99255, 0, 0, -0.121839, False, '2023-02-20 04:51:19'); /* SandTuskerGen */
/* @teleloc 0x01A801AA [50.414600 -49.935699 6.055000] -0.992550 0.000000 0.000000 -0.121839 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701A8052, 801825, 0x01A80198, 20.9295, -47.6911, 6.055, -0.0831555, 0, 0, -0.996537, False, '2023-02-20 04:51:25'); /* SandTuskerGen */
/* @teleloc 0x01A80198 [20.929501 -47.691101 6.055000] -0.083155 0.000000 0.000000 -0.996537 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701A8053, 801825, 0x01A80199, 20.4201, -57.0655, 6.055, -0.0673425, 0, 0, -0.99773, False, '2023-02-20 04:51:27'); /* SandTuskerGen */
/* @teleloc 0x01A80199 [20.420099 -57.065498 6.055000] -0.067342 0.000000 0.000000 -0.997730 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701A8054, 801825, 0x01A8019A, 20.0414, -66.7096, 6.055, -0.016916, 0, 0, -0.999857, False, '2023-02-20 04:51:28'); /* SandTuskerGen */
/* @teleloc 0x01A8019A [20.041401 -66.709602 6.055000] -0.016916 0.000000 0.000000 -0.999857 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701A8055, 801825, 0x01A8019B, 19.0479, -78.5345, 6.055, 0.114074, 0, 0, -0.993472, False, '2023-02-20 04:51:30'); /* SandTuskerGen */
/* @teleloc 0x01A8019B [19.047899 -78.534500 6.055000] 0.114074 0.000000 0.000000 -0.993472 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701A8056, 803040, 0x01A80130, 15.6664, -24.4081, 0.055, -0.439832, 0, 0, -0.89808, False, '2023-10-30 05:08:22');
/* @teleloc 0x01A80130 [15.666400 -24.408100 0.055000] -0.439832 0.000000 0.000000 -0.898080 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701A8057, 803040, 0x01A80160, 37.30576, -67.15202, 0.054999996, 0.2814165, 0, 0, -0.9595857, False, '2023-10-30 05:08:40');
/* @teleloc 0x01A80160 [37.305759 -67.152023 0.055000] 0.281417 0.000000 0.000000 -0.959586 */
