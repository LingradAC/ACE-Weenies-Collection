DELETE FROM `event` WHERE `name` = 'BossRaid1';

INSERT INTO `event` (`name`, `start_Time`, `end_Time`, `state`, `last_Modified`)
VALUES ('BossRaid1', -1, -1, 3, '2020-05-24 00:00:00');