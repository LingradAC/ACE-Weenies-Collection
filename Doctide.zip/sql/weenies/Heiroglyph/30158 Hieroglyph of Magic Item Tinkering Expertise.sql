DELETE FROM `weenie` WHERE `class_Id` = 30158;

INSERT INTO `weenie` (`class_Id`, `class_Name`, `type`, `last_Modified`)
VALUES (30158, 'gemrareeternalmagicitemtinkering', 38, '2021-11-17 16:56:08') /* Gem */;

INSERT INTO `weenie_properties_int` (`object_Id`, `type`, `value`)
VALUES (30158,   1,       2048) /* ItemType - Gem */
     , (30158,   3,         39) /* PaletteTemplate - Black */
     , (30158,   5,          5) /* EncumbranceVal */
     , (30158,   8,          5) /* Mass */
     , (30158,  16,          524296) /* ItemUseable - SourceContainedTargetContained */
     , (30158,  17,        105) /* RareId */
     , (30158,  18,          1) /* UiEffects - Magical */
     , (30158,  19,          0) /* Value */
     , (30158,  33,         -1) /* Bonded - Slippery */
     , (30158,  93,       1044) /* PhysicsState - Ethereal, IgnoreCollisions, Gravity */
     , (30158,  94,         35215) /* TargetType - Vestements */
     , (30158, 150,        103) /* HookPlacement - Hook */
     , (30158, 151,         11) /* HookType - Floor, Wall, Yard */;

INSERT INTO `weenie_properties_bool` (`object_Id`, `type`, `value`)
VALUES (30158,  22, True ) /* Inscribable */;

INSERT INTO `weenie_properties_string` (`object_Id`, `type`, `value`)
VALUES (30158,   1, 'Hieroglyph of Magic Item Tinkering Expertise') /* Name */
     , (30158,  16, 'Use this gem to add Legendary Magic Item Tinkering Expertise. This gem will be destroyed upon use.') /* LongDesc */;

INSERT INTO `weenie_properties_d_i_d` (`object_Id`, `type`, `value`)
VALUES (30158,   1, 0x020009A7) /* Setup */
     , (30158,   3, 0x20000014) /* SoundTable */
     , (30158,   6, 0x040001FA) /* PaletteBase */
     , (30158,   7, 0x1000010B) /* ClothingBase */
     , (30158,   8, 0x06005B22) /* Icon */
     , (30158,  22, 0x3400002B) /* PhysicsEffectTable */
     , (30158,  50, 0x06005B50) /* IconOverlay */
     , (30158,  52, 0x06005B0C) /* IconUnderlay */;
