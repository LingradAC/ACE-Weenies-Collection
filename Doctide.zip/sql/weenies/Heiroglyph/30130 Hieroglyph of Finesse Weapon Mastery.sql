DELETE FROM `weenie` WHERE `class_Id` = 30130;

INSERT INTO `weenie` (`class_Id`, `class_Name`, `type`, `last_Modified`)
VALUES (30130, 'gemrareeternaldagger', 38, '2021-11-17 16:56:08') /* Gem */;

INSERT INTO `weenie_properties_int` (`object_Id`, `type`, `value`)
VALUES (30130,   1,       2048) /* ItemType - Gem */
     , (30130,   3,         39) /* PaletteTemplate - Black */
     , (30130,   5,          5) /* EncumbranceVal */
     , (30130,   8,          5) /* Mass */
     , (30130,  16,          524296) /* ItemUseable - SourceContainedTargetContained */
     , (30130,  17,         93) /* RareId */
     , (30130,  18,          1) /* UiEffects - Magical */
     , (30130,  19,          0) /* Value */
     , (30130,  33,         -1) /* Bonded - Slippery */
     , (30130,  93,       1044) /* PhysicsState - Ethereal, IgnoreCollisions, Gravity */
     , (30130,  94,        35215) /* TargetType - Vestements */
     , (30130, 109,          0) /* ItemDifficulty */
     , (30130, 150,        103) /* HookPlacement - Hook */
     , (30130, 151,         11) /* HookType - Floor, Wall, Yard */;

INSERT INTO `weenie_properties_bool` (`object_Id`, `type`, `value`)
VALUES (30130,  22, True ) /* Inscribable */;

INSERT INTO `weenie_properties_string` (`object_Id`, `type`, `value`)
VALUES (30130,   1, 'Hieroglyph of Finesse Weapon Mastery') /* Name */
     , (30130,  16, 'Use this gem to add Legendary Finesse Weapons. This gem will be destroyed upon use.') /* LongDesc */;

INSERT INTO `weenie_properties_d_i_d` (`object_Id`, `type`, `value`)
VALUES (30130,   1, 0x020009A7) /* Setup */
     , (30130,   3, 0x20000014) /* SoundTable */
     , (30130,   6, 0x040001FA) /* PaletteBase */
     , (30130,   7, 0x1000010B) /* ClothingBase */
     , (30130,   8, 0x06005B22) /* Icon */
     , (30130,  22, 0x3400002B) /* PhysicsEffectTable */
     , (30130,  50, 0x06005B34) /* IconOverlay */
     , (30130,  52, 0x06005B0C) /* IconUnderlay */;
