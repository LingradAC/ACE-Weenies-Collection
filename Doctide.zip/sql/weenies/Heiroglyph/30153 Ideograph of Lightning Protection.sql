DELETE FROM `weenie` WHERE `class_Id` = 30153;

INSERT INTO `weenie` (`class_Id`, `class_Name`, `type`, `last_Modified`)
VALUES (30153, 'gemrareeternallightningprotection', 38, '2021-11-17 16:56:08') /* Gem */;

INSERT INTO `weenie_properties_int` (`object_Id`, `type`, `value`)
VALUES (30153,   1,       2048) /* ItemType - Gem */
     , (30153,   3,         39) /* PaletteTemplate - Black */
     , (30153,   5,          5) /* EncumbranceVal */
     , (30153,   8,          5) /* Mass */
     , (30153,  16,          524296) /* ItemUseable - SourceContainedTargetContained */
     , (30153,  17,        127) /* RareId */
     , (30153,  18,          1) /* UiEffects - Magical */
     , (30153,  19,          0) /* Value */
     , (30153,  33,         -1) /* Bonded - Slippery */
     , (30153,  92,         -1) /* Structure */
     , (30153,  93,       1044) /* PhysicsState - Ethereal, IgnoreCollisions, Gravity */
     , (30153,  94,         35215) /* TargetType - Vestements */
     , (30153, 150,        103) /* HookPlacement - Hook */
     , (30153, 151,         11) /* HookType - Floor, Wall, Yard */;

INSERT INTO `weenie_properties_bool` (`object_Id`, `type`, `value`)
VALUES (30153,  22, True ) /* Inscribable */;

INSERT INTO `weenie_properties_string` (`object_Id`, `type`, `value`)
VALUES (30153,   1, 'Ideograph of Lightning Protection') /* Name */
     , (30153,  16, 'Use this gem add Legendary Storm Ward. This gem will be destroyed upon use.') /* LongDesc */;

INSERT INTO `weenie_properties_d_i_d` (`object_Id`, `type`, `value`)
VALUES (30153,   1, 0x020009A7) /* Setup */
     , (30153,   3, 0x20000014) /* SoundTable */
     , (30153,   6, 0x040001FA) /* PaletteBase */
     , (30153,   7, 0x1000010B) /* ClothingBase */
     , (30153,   8, 0x06005B20) /* Icon */
     , (30153,  22, 0x3400002B) /* PhysicsEffectTable */
     , (30153,  50, 0x06005B4B) /* IconOverlay */
     , (30153,  52, 0x06005B0C) /* IconUnderlay */;
