DELETE FROM `landblock_instance` WHERE `landblock` = 0x7D64;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x77D64000,   145, 0x7D64010D, 78.125, 113.075, 12, 0.707107, 0, 0, -0.707107, False, '2022-12-04 19:04:52'); /* Coffer */
/* @teleloc 0x7D64010D [78.125000 113.074997 12.000000] 0.707107 0.000000 0.000000 -0.707107 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x77D64001,  1148, 0x7D640000, 84, 111.99, 12, 1, 0, 0, 0, False, '2022-12-04 19:04:52'); /* Door */
/* @teleloc 0x7D640000 [84.000000 111.989998 12.000000] 1.000000 0.000000 0.000000 0.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x77D64002,  1148, 0x7D640000, 84, 119.51, 12, 0, 0, 0, -1, False, '2022-12-04 19:04:52'); /* Door */
/* @teleloc 0x7D640000 [84.000000 119.510002 12.000000] 0.000000 0.000000 0.000000 -1.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x77D64003,  1148, 0x7D640000, 91.75, 101.99, 12, 1, 0, 0, 0, False, '2022-12-04 19:04:52'); /* Door */
/* @teleloc 0x7D640000 [91.750000 101.989998 12.000000] 1.000000 0.000000 0.000000 0.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x77D64004,  1148, 0x7D640111, 88, 125.51, 12, 0, 0, 0, 1, False, '2022-12-04 19:04:52'); /* Door */
/* @teleloc 0x7D640111 [88.000000 125.510002 12.000000] 0.000000 0.000000 0.000000 1.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x77D64005,  1148, 0x7D640000, 80, 131.51, 12, 0, 0, 0, 1, False, '2022-12-04 19:04:52'); /* Door */
/* @teleloc 0x7D640000 [80.000000 131.509995 12.000000] 0.000000 0.000000 0.000000 1.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x77D64006,  1148, 0x7D640000, 82.99, 137, 12, 0.707107, 0, 0, -0.707107, False, '2022-12-04 19:04:52'); /* Door */
/* @teleloc 0x7D640000 [82.989998 137.000000 12.000000] 0.707107 0.000000 0.000000 -0.707107 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x77D64007,  1148, 0x7D64013E, 92.21, 64, 12, 0.707107, 0, 0, -0.707107, False, '2022-12-04 19:04:52'); /* Door */
/* @teleloc 0x7D64013E [92.209999 64.000000 12.000000] 0.707107 0.000000 0.000000 -0.707107 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x77D64008,  1148, 0x7D640000, 86.21, 56, 12, 0.707107, 0, 0, -0.707107, False, '2022-12-04 19:04:52'); /* Door */
/* @teleloc 0x7D640000 [86.209999 56.000000 12.000000] 0.707107 0.000000 0.000000 -0.707107 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x77D64009,  1148, 0x7D640000, 80.72, 58.99, 12, -1, 0, 0, 0, False, '2022-12-04 19:04:52'); /* Door */
/* @teleloc 0x7D640000 [80.720001 58.990002 12.000000] -1.000000 0.000000 0.000000 0.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x77D6400A,   794, 0x7D640000, 185.66, 3.85551, 15.7208, 0.99225, 0, 0, 0.124257, False, '2022-12-04 19:04:52'); /* Apple Generator */
/* @teleloc 0x7D640000 [185.660004 3.855510 15.720800] 0.992250 0.000000 0.000000 0.124257 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x77D6400B,  1040, 0x7D640114, 78.72, 124.52, 12.01, 1, 0, 0, 0, False, '2022-12-04 19:04:52'); /* Nuya bint Mulud the Grocer */
/* @teleloc 0x7D640114 [78.720001 124.519997 12.010000] 1.000000 0.000000 0.000000 0.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x77D6400C,  1047, 0x7D64010E, 88.6799, 138.12, 12.005, 0.551937, 0, 0, 0.833886, False, '2022-12-04 19:04:52'); /* Arlad ibn Mulud the Tailor */
/* @teleloc 0x7D64010E [88.679901 138.119995 12.005000] 0.551937 0.000000 0.000000 0.833886 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x77D6400D,  1041, 0x7D640000, 85.92, 138.564, 15.605, -0.626604, 0, 0, 0.779337, False, '2022-12-04 19:04:52'); /* Mulud al-Iyar the Healer */
/* @teleloc 0x7D640000 [85.919998 138.563995 15.605000] -0.626604 0.000000 0.000000 0.779337 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x77D6400E,  1038, 0x7D640100, 87.8479, 111.782, 12.005, 0.551937, 0, 0, 0.833886, False, '2022-12-04 19:04:52'); /* Buray ibn Tamsa the Blacksmith */
/* @teleloc 0x7D640100 [87.847900 111.781998 12.005000] 0.551937 0.000000 0.000000 0.833886 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x77D6400F,  1039, 0x7D640100, 86.1409, 115.885, 12.005, -0.658594, 0, 0, -0.752498, False, '2022-12-04 19:04:52'); /* Ladim al-Faji the Bowyer */
/* @teleloc 0x7D640100 [86.140900 115.885002 12.005000] -0.658594 0.000000 0.000000 -0.752498 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x77D64010,  1045, 0x7D64012D, 86.1599, 89.98, 12.01, -0.278991, 0, 0, -0.960294, False, '2022-12-04 19:04:52'); /* Rahira bint Hisan the Shopkeeper */
/* @teleloc 0x7D64012D [86.159897 89.980003 12.010000] -0.278991 0.000000 0.000000 -0.960294 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x77D64011,  1044, 0x7D640137, 91.48, 84.84, 12.01, -0.594823, 0, 0, -0.803857, False, '2022-12-04 19:04:52'); /* Wasifa al-Kani the Scribe */
/* @teleloc 0x7D640137 [91.480003 84.839996 12.010000] -0.594823 0.000000 0.000000 -0.803857 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x77D64012,  1042, 0x7D64012F, 85.9199, 78.02, 12.01, -0.995396, 0, 0, -0.095846, False, '2022-12-04 19:04:52'); /* Tariqana bint Hin the Jeweler */
/* @teleloc 0x7D64012F [85.919899 78.019997 12.010000] -0.995396 0.000000 0.000000 -0.095846 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x77D64013,  1034, 0x7D640141, 93.2, 55.56, 12.005, -0.735506, 0, 0, -0.677518, False, '2022-12-04 19:04:52'); /* Barkeep Jubal al-Baljad */
/* @teleloc 0x7D640141 [93.199997 55.560001 12.005000] -0.735506 0.000000 0.000000 -0.677518 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x77D64014,  1076, 0x7D640000, 75.5867, 59.3967, 15.5505, 0, 0, 0, -1, False, '2022-12-04 19:04:52'); /* The Cerulean Cove */
/* @teleloc 0x7D640000 [75.586700 59.396702 15.550500] 0.000000 0.000000 0.000000 -1.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x77D64015,  1071, 0x7D640000, 86.3637, 111.273, 15.8309, 0.913012, 0, 0, -0.407932, False, '2022-12-04 19:04:52'); /* The Eagle's Blade */
/* @teleloc 0x7D640000 [86.363701 111.273003 15.830900] 0.913012 0.000000 0.000000 -0.407932 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x77D64016,  1073, 0x7D640000, 72.3694, 131.351, 15.3761, 0, 0, 0, -1, False, '2022-12-04 19:04:52'); /* Nuya's Necessities */
/* @teleloc 0x7D640000 [72.369400 131.350998 15.376100] 0.000000 0.000000 0.000000 -1.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x77D64017,  2307, 0x7D64012E, 86.9758, 91.882, 15.205, 0.001857, 0, 0, -0.999998, False, '2022-12-04 19:04:52'); /* Archmage Inyamkaya bint Ruz */
/* @teleloc 0x7D64012E [86.975800 91.882004 15.205000] 0.001857 0.000000 0.000000 -0.999998 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x77D64018,  4770, 0x7D64013B, 79.5236, 64.6462, 12.005, -0.196667, 0, 0, 0.98047, False, '2022-12-04 19:04:52'); /* Collector Gharundim Gen */
/* @teleloc 0x7D64013B [79.523598 64.646202 12.005000] -0.196667 0.000000 0.000000 0.980470 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x77D64019,  5365, 0x7D640000, 85.0516, 65.2689, 20.805, 0.788997, 0, 0, 0.614397,  True, '2022-12-04 19:04:52'); /* Akyafi ibn Sumwar */
/* @teleloc 0x7D640000 [85.051598 65.268898 20.805000] 0.788997 0.000000 0.000000 0.614397 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x77D6401A,  1154, 0x7D640000, 86.9412, 66.5654, 20.805, 0.669975, 0, 0, 0.742384, False, '2022-12-04 19:04:52'); /* Linkable Monster Generator */
/* @teleloc 0x7D640000 [86.941200 66.565399 20.805000] 0.669975 0.000000 0.000000 0.742384 */

INSERT INTO `landblock_instance_link` (`parent_GUID`, `child_GUID`, `last_Modified`)
VALUES (0x77D6401A, 0x77D64019, '2022-12-04 19:04:52') /* Akyafi ibn Sumwar (5365) */
     , (0x77D6401A, 0x77D64022, '2022-12-04 19:04:52') /* Agent of the Arcanum (12050) */
     , (0x77D6401A, 0x77D6403D, '2022-12-04 19:04:52') /* Small Creepy Statue (25992) */
     , (0x77D6401A, 0x77D64043, '2022-12-04 19:04:52') /* Apprentice Alchemist (27741) */
     , (0x77D6401A, 0x77D6404D, '2022-12-04 19:04:52') /* Mara al-Luq (5179) */
     , (0x77D6401A, 0x77D6404E, '2022-12-04 19:04:52') /* Ma'yad ibn Ibsar (5366) */
     , (0x77D6401A, 0x77D64073, '2022-12-04 19:04:52') /* Arcanum Refurbisher (32085) */
     , (0x77D6401A, 0x77D64074, '2022-12-04 19:04:52') /* Tailor's Apprentice (42737) */;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x77D6401B,  8377, 0x7D640140, 91.3656, 58.5145, 12.9546, 0.707107, 0, 0, -0.707107, False, '2022-12-04 19:04:52'); /* Beer Keg */
/* @teleloc 0x7D640140 [91.365601 58.514500 12.954600] 0.707107 0.000000 0.000000 -0.707107 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x77D6401C,   165, 0x7D640000, 60.72, 54.84, 12.05, 1, 0, 0, 0, False, '2022-12-04 19:04:52'); /* Pool */
/* @teleloc 0x7D640000 [60.720001 54.840000 12.050000] 1.000000 0.000000 0.000000 0.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x77D6401D,   165, 0x7D640000, 60.72, 102.36, 12.05, 1, 0, 0, 0, False, '2022-12-04 19:04:52'); /* Pool */
/* @teleloc 0x7D640000 [60.720001 102.360001 12.050000] 1.000000 0.000000 0.000000 0.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x77D6401E,  9424, 0x7D640000, 78.3869, 51.5654, 12.01, -0.734439, 0, 0, -0.678675, False, '2022-12-04 19:04:52'); /* Drawohan the Gem Seller */
/* @teleloc 0x7D640000 [78.386902 51.565399 12.010000] -0.734439 0.000000 0.000000 -0.678675 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x77D64021,   412, 0x7D64014A, 81.3816, 30.7557, 12, 0.707107, 0, 0, -0.707107, False, '2022-12-04 19:04:52'); /* Door */
/* @teleloc 0x7D64014A [81.381599 30.755699 12.000000] 0.707107 0.000000 0.000000 -0.707107 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x77D64022, 12050, 0x7D64014C, 88.4002, 38.4678, 12.005, 0.125633, 0, 0, -0.992077,  True, '2022-12-04 19:04:52'); /* Agent of the Arcanum */
/* @teleloc 0x7D64014C [88.400200 38.467800 12.005000] 0.125633 0.000000 0.000000 -0.992077 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x77D64024, 12304, 0x7D640000, 80.08, 35.413, 12.005, 0.39265, 0, 0, -0.919688, False, '2022-12-04 19:04:52'); /* Agent of the Arcanum  */
/* @teleloc 0x7D640000 [80.080002 35.412998 12.005000] 0.392650 0.000000 0.000000 -0.919688 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x77D64026,  7923, 0x7D640000, 60.4073, 94.7986, 12.005, 0.753985, 0, 0, 0.656892, False, '2022-12-04 19:04:52'); /* Linkable Monster Generator ( 3 Min.) */
/* @teleloc 0x7D640000 [60.407299 94.798599 12.005000] 0.753985 0.000000 0.000000 0.656892 */

INSERT INTO `landblock_instance_link` (`parent_GUID`, `child_GUID`, `last_Modified`)
VALUES (0x77D64026, 0x77D6404F, '2022-12-04 19:04:52') /* Salvaging Forge (30461) */
     , (0x77D64026, 0x77D64050, '2022-12-04 19:04:52') /* Alchemy Forge (30465) */
     , (0x77D64026, 0x77D64051, '2022-12-04 19:04:52') /* Cooking Forge (30466) */
     , (0x77D64026, 0x77D64052, '2022-12-04 19:04:52') /* Fletching Forge (30467) */
     , (0x77D64026, 0x77D64053, '2022-12-04 19:04:52') /* Lockpick Forge (30460) */;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x77D6402A, 14930, 0x7D64014C, 91.4248, 35.7012, 12.005, -0.729114, 0, 0, -0.684392, False, '2022-12-04 19:04:52'); /* Wedding Planner */
/* @teleloc 0x7D64014C [91.424797 35.701199 12.005000] -0.729114 0.000000 0.000000 -0.684392 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x77D6402D, 16919, 0x7D640000, 59.839, 79.4061, 12, 0, 0, 0, -1, False, '2022-12-04 19:04:52'); /* Pedestal Weak Spot */
/* @teleloc 0x7D640000 [59.839001 79.406097 12.000000] 0.000000 0.000000 0.000000 -1.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x77D64030, 19457, 0x7D640000, 60.4462, 83.5872, 18.9739, 0.71897, 0, 0, -0.695041, False, '2022-12-04 19:04:52'); /* Fireworks Generator */
/* @teleloc 0x7D640000 [60.446201 83.587196 18.973900] 0.718970 0.000000 0.000000 -0.695041 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x77D64033, 19196, 0x7D640000, 59.9142, 83.5841, 18.839, 0.699647, 0, 0, -0.714488, False, '2022-12-04 19:04:52'); /* Nullified Statue of a Drudge */
/* @teleloc 0x7D640000 [59.914200 83.584099 18.839001] 0.699647 0.000000 0.000000 -0.714488 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x77D64034, 19717, 0x7D640150, 59.9385, 97.8042, 6.805, -0.999485, 0, 0, 0.032073, False, '2022-12-04 19:04:52'); /* Mannikin Foundry Portal */
/* @teleloc 0x7D640150 [59.938499 97.804199 6.805000] -0.999485 0.000000 0.000000 0.032073 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x77D64035, 20215, 0x7D640164, 148.328, 109.418, 16.005, 0.702778, 0, 0, -0.71141, False, '2022-12-04 19:04:52'); /* Apprentice Scrivener of Item and War Magic */
/* @teleloc 0x7D640164 [148.328003 109.417999 16.004999] 0.702778 0.000000 0.000000 -0.711410 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x77D64036, 20217, 0x7D64016E, 155.045, 116.419, 16.005, -0.128535, 0, 0, -0.991705, False, '2022-12-04 19:04:52'); /* Apprentice Scrivener of Life Magic */
/* @teleloc 0x7D64016E [155.044998 116.418999 16.004999] -0.128535 0.000000 0.000000 -0.991705 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x77D64037, 20205, 0x7D640166, 161.559, 109.528, 16.005, -0.797963, 0, 0, -0.602706, False, '2022-12-04 19:04:52'); /* Apprentice Scrivener of Creature Magic */
/* @teleloc 0x7D640166 [161.559006 109.528000 16.004999] -0.797963 0.000000 0.000000 -0.602706 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x77D64038, 20206, 0x7D640165, 147.116, 108.396, 19.205, -0.691081, 0, 0, 0.722777, False, '2022-12-04 19:04:52'); /* Apprentice Scrivener of Creature Magic */
/* @teleloc 0x7D640165 [147.115997 108.396004 19.205000] -0.691081 0.000000 0.000000 0.722777 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x77D64039, 20218, 0x7D640171, 156.358, 118.182, 19.205, -0.487067, 0, 0, -0.873365, False, '2022-12-04 19:04:52'); /* Apprentice Scrivener of Life Magic */
/* @teleloc 0x7D640171 [156.358002 118.181999 19.205000] -0.487067 0.000000 0.000000 -0.873365 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x77D6403A, 20216, 0x7D640167, 162.948, 110.601, 19.205, 0.685224, 0, 0, 0.728333, False, '2022-12-04 19:04:52'); /* Apprentice Scrivener of Item and War Magic */
/* @teleloc 0x7D640167 [162.947998 110.600998 19.205000] 0.685224 0.000000 0.000000 0.728333 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x77D6403C, 23631, 0x7D640000, 77.6848, 81.0209, 75.8893, 0.053052, 0, 0, -0.998592, False, '2022-12-04 19:04:52'); /* April 2003 Raining Mad Cows Gen */
/* @teleloc 0x7D640000 [77.684799 81.020897 75.889297] 0.053052 0.000000 0.000000 -0.998592 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x77D6403D, 25992, 0x7D640000, 62.3025, 173.546, 12.005, -0.997083, 0, 0, -0.076326,  True, '2022-12-04 19:04:52'); /* Small Creepy Statue */
/* @teleloc 0x7D640000 [62.302502 173.546005 12.005000] -0.997083 0.000000 0.000000 -0.076326 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x77D64040,   509, 0x7D640000, 37.7105, 105.788, 12.005, 0.660946, 0, 0, -0.750434, False, '2022-12-04 19:04:52'); /* Life Stone */
/* @teleloc 0x7D640000 [37.710499 105.788002 12.005000] 0.660946 0.000000 0.000000 -0.750434 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x77D64041,  6111, 0x7D640173, 35.3787, 35.4762, 14.005, 0.698606, 0, 0, 0.715506, False, '2022-12-04 19:04:52'); /* Yaraq Meeting Hall Portal */
/* @teleloc 0x7D640173 [35.378700 35.476200 14.005000] 0.698606 0.000000 0.000000 0.715506 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x77D64042, 27547, 0x7D640000, 54.1621, 33.492, 12.005, 0.747357, 0, 0, 0.664422, False, '2022-12-04 19:04:52'); /* Bind Stone */
/* @teleloc 0x7D640000 [54.162102 33.492001 12.005000] 0.747357 0.000000 0.000000 0.664422 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x77D64043, 27741, 0x7D640000, 90.5631, 90.5797, 12.005, 0.938614, 0, 0, -0.344968,  True, '2022-12-04 19:04:52'); /* Apprentice Alchemist */
/* @teleloc 0x7D640000 [90.563103 90.579697 12.005000] 0.938614 0.000000 0.000000 -0.344968 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x77D6404B, 11954, 0x7D640000, 35.2509, 61.7802, 12.5, 0.810548, 0, 0, -0.585672, False, '2022-12-04 19:04:52'); /* Destroyed Portal to Greenspire */
/* @teleloc 0x7D640000 [35.250900 61.780201 12.500000] 0.810548 0.000000 0.000000 -0.585672 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x77D6404D,  5179, 0x7D64013E, 85.6987, 66.45, 12.005, -0.10452, 0, 0, 0.994523,  True, '2022-12-04 19:04:52'); /* Mara al-Luq */
/* @teleloc 0x7D64013E [85.698700 66.449997 12.005000] -0.104520 0.000000 0.000000 0.994523 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x77D6404E,  5366, 0x7D64013E, 89.9014, 62.067, 12.005, -0.760963, 0, 0, -0.648796,  True, '2022-12-04 19:04:52'); /* Ma'yad ibn Ibsar */
/* @teleloc 0x7D64013E [89.901398 62.067001 12.005000] -0.760963 0.000000 0.000000 -0.648796 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x77D6404F, 30461, 0x7D640000, 60.374, 116.128, 12.005, 0.707107, 0, 0, -0.707107,  True, '2022-12-04 19:04:52'); /* Salvaging Forge */
/* @teleloc 0x7D640000 [60.374001 116.127998 12.005000] 0.707107 0.000000 0.000000 -0.707107 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x77D64050, 30465, 0x7D640000, 100.928, 84.661, 12.005, 1, 0, 0, 0,  True, '2022-12-04 19:04:52'); /* Alchemy Forge */
/* @teleloc 0x7D640000 [100.928001 84.661003 12.005000] 1.000000 0.000000 0.000000 0.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x77D64051, 30466, 0x7D640000, 85.618, 148.353, 12, -0.707107, 0, 0, -0.707107,  True, '2022-12-04 19:04:52'); /* Cooking Forge */
/* @teleloc 0x7D640000 [85.617996 148.352997 12.000000] -0.707107 0.000000 0.000000 -0.707107 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x77D64052, 30467, 0x7D640000, 95.7726, 113.577, 12.005, -0.707107, 0, 0, -0.707107,  True, '2022-12-04 19:04:52'); /* Fletching Forge */
/* @teleloc 0x7D640000 [95.772598 113.577003 12.005000] -0.707107 0.000000 0.000000 -0.707107 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x77D64053, 30460, 0x7D640000, 95.7718, 132.065, 12.005, -0.707107, 0, 0, -0.707107,  True, '2022-12-04 19:04:52'); /* Lockpick Forge */
/* @teleloc 0x7D640000 [95.771797 132.065002 12.005000] -0.707107 0.000000 0.000000 -0.707107 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x77D6405D,  3953, 0x7D640000, 74.9746, 103.29, 12.005, 0.342535, 0, 0, 0.939505, False, '2022-12-04 19:04:52'); /* Linkable Monster Gen (30 min.) */
/* @teleloc 0x7D640000 [74.974602 103.290001 12.005000] 0.342535 0.000000 0.000000 0.939505 */

INSERT INTO `landblock_instance_link` (`parent_GUID`, `child_GUID`, `last_Modified`)
VALUES (0x77D6405D, 0x77D6405C, '2022-12-04 19:04:52');

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x77D6405E,  1154, 0x7D640015, 64.5098, 102.84, 12.005, 0.645592, 0, 0, 0.763682, False, '2022-12-04 19:04:52'); /* Linkable Monster Generator */
/* @teleloc 0x7D640015 [64.509804 102.839996 12.005000] 0.645592 0.000000 0.000000 0.763682 */

INSERT INTO `landblock_instance_link` (`parent_GUID`, `child_GUID`, `last_Modified`)
VALUES (0x77D6405E, 0x77D64060, '2022-12-04 19:04:52') /* Ghaziyah (44896) */
     , (0x77D6405E, 0x77D64061, '2022-12-04 19:04:52') /* Pathwarden Qanara bint Qolosh (33616) */
     , (0x77D6405E, 0x77D64062, '2022-12-04 19:04:52') /* A'shadieeyah (44892) */
     , (0x77D6405E, 0x77D6406B, '2022-12-04 19:04:52') /* Nawaf (42721) */;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x77D6405F, 650028, 0x7D640015, 61, 105, 12, 0.707107, 0, 0, -0.707107, False, '2022-12-04 19:04:52'); /* Gharu'ndim Pathwarden Chest */
/* @teleloc 0x7D640015 [61.000000 105.000000 12.000000] 0.707107 0.000000 0.000000 -0.707107 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x77D64060, 44896, 0x7D64000D, 39.203, 102.204, 12.005, -0.827734, 0, 0, -0.561121,  True, '2022-12-04 19:04:52'); /* Ghaziyah */
/* @teleloc 0x7D64000D [39.202999 102.204002 12.005000] -0.827734 0.000000 0.000000 -0.561121 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x77D64061, 33616, 0x7D640015, 58, 106, 12.005, -0.707107, 0, 0, -0.707107,  True, '2022-12-04 19:04:52'); /* Pathwarden Qanara bint Qolosh */
/* @teleloc 0x7D640015 [58.000000 106.000000 12.005000] -0.707107 0.000000 0.000000 -0.707107 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x77D64062, 44892, 0x7D640140, 91.2228, 53.6365, 12.005, 0.930453, 0, 0, 0.366411,  True, '2022-12-04 19:04:52'); /* A'shadieeyah */
/* @teleloc 0x7D640140 [91.222801 53.636501 12.005000] 0.930453 0.000000 0.000000 0.366411 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x77D64063, 42429, 0x7D64010E, 84.4232, 139.606, 12.005, 0.199237, 0, 0, -0.979951, False, '2022-12-04 19:04:52'); /* Iqbal */
/* @teleloc 0x7D64010E [84.423203 139.606003 12.005000] 0.199237 0.000000 0.000000 -0.979951 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x77D64064, 49517, 0x7D64012E, 85.3193, 89.8775, 15.2058, 0.999736, 0, 0, -0.02298, False, '2022-12-04 19:04:52'); /* Iaret */
/* @teleloc 0x7D64012E [85.319298 89.877502 15.205800] 0.999736 0.000000 0.000000 -0.022980 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x77D6406A, 43066, 0x7D640025, 102.999, 106.787, 12.198, 0.072717, 0, 0, 0.997353, False, '2022-12-04 19:04:52'); /* Portal to Town Network */
/* @teleloc 0x7D640025 [102.999001 106.787003 12.198000] 0.072717 0.000000 0.000000 0.997353 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x77D6406B, 42721, 0x7D64010E, 91.5019, 136.84, 12.005, -0.948897, 0, 0, 0.315586,  True, '2022-12-04 19:04:52'); /* Nawaf */
/* @teleloc 0x7D64010E [91.501900 136.839996 12.005000] -0.948897 0.000000 0.000000 0.315586 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x77D6406C, 43354, 0x7D640035, 148.71, 114.43, 16.005, -0.836033, 0, 0, -0.548679, False, '2022-12-04 19:04:52'); /* Scrivener of Void Magic */
/* @teleloc 0x7D640035 [148.710007 114.430000 16.004999] -0.836033 0.000000 0.000000 -0.548679 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x77D6406E, 80022, 0x7D64000D, 30.1476, 111.945, 11.1885, 0.102548, 0, 0, -0.994728, False, '2022-12-04 19:04:52'); /* Pumpkin Buffer Generator */
/* @teleloc 0x7D64000D [30.147600 111.945000 11.188500] 0.102548 0.000000 0.000000 -0.994728 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x77D6406F, 32836, 0x7D64001D, 86.6364, 105.347, 12.005, -0.675014, 0, 0, -0.737805, False, '2022-12-04 19:04:52'); /* Bhravarn ibn Salizim */
/* @teleloc 0x7D64001D [86.636398 105.347000 12.005000] -0.675014 0.000000 0.000000 -0.737805 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x77D64070, 44189, 0x7D64001B, 81.8409, 63.649, 15.605, -0.996757, 0, 0, -0.080476, False, '2022-12-04 19:04:52'); /* Contract Broker */
/* @teleloc 0x7D64001B [81.840897 63.648998 15.605000] -0.996757 0.000000 0.000000 -0.080476 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x77D64071, 44207, 0x7D64001B, 78.7634, 64.2902, 15.605, 0.977384, 0, 0, -0.211471, False, '2022-12-04 19:04:52'); /* Abd-al-Matin Basshir */
/* @teleloc 0x7D64001B [78.763397 64.290199 15.605000] 0.977384 0.000000 0.000000 -0.211471 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x77D64072, 87818, 0x7D64014E, 87.8971, 37.7208, 8.056, -0.175269, 0, 0, 0.984521, False, '2022-12-04 19:04:52'); /* Kim Event Gen */
/* @teleloc 0x7D64014E [87.897102 37.720798 8.056000] -0.175269 0.000000 0.000000 0.984521 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x77D64073, 32085, 0x7D64014C, 91.2676, 38.6012, 12.005, -0.174972, 0, 0, -0.984573,  True, '2022-12-04 19:04:52'); /* Arcanum Refurbisher */
/* @teleloc 0x7D64014C [91.267601 38.601200 12.005000] -0.174972 0.000000 0.000000 -0.984573 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x77D64074, 42737, 0x7D64010E, 86.6307, 139.512, 12.005, 0.170397, 0, 0, 0.985376,  True, '2022-12-04 19:04:52'); /* Tailor's Apprentice */
/* @teleloc 0x7D64010E [86.630699 139.511993 12.005000] 0.170397 0.000000 0.000000 0.985376 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x77D64075, 37518, 0x7D640018, 66.1992, 183.29, 12.005, 0.999911, 0, 0, -0.013339, False, '2022-12-04 19:04:52'); /* Royal Guard */
/* @teleloc 0x7D640018 [66.199203 183.289993 12.005000] 0.999911 0.000000 0.000000 -0.013339 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x77D64076, 37518, 0x7D64002C, 140.955, 87.8733, 15.4975, 0.759906, 0, 0, -0.650033, False, '2022-12-04 19:04:52'); /* Royal Guard */
/* @teleloc 0x7D64002C [140.955002 87.873299 15.497500] 0.759906 0.000000 0.000000 -0.650033 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x77D64077, 37518, 0x7D640019, 83.6504, 4.37371, 12.005, 0.321405, 0, 0, -0.946942, False, '2022-12-04 19:04:52'); /* Royal Guard */
/* @teleloc 0x7D640019 [83.650398 4.373710 12.005000] 0.321405 0.000000 0.000000 -0.946942 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x77D64078, 650003, 0x7D640015, 60.8026, 102.338, 12, 0.698973, 0, 0, 0.715148, False, '2023-11-07 02:16:03'); /* Buff Stone */
/* @teleloc 0x7D640015 [60.802601 102.337997 12.000000] 0.698973 0.000000 0.000000 0.715148 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x77D64079, 650010, 0x7D640014, 56.17012, 92.68338, 12.005, 0.710234, 0, 0, 0.703966, False, '2023-11-10 11:11:12'); /* Server Crier */
/* @teleloc 0x7D640014 [56.170120 92.683380 12.005000] 0.710234 0.000000 0.000000 0.703966 */
