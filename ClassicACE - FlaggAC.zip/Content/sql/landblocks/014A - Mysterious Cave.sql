DELETE FROM `landblock_instance` WHERE `landblock` = 0x014A;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7014A002,  2609, 0x014A011A, 40, -50, -6, 1, 0, 0, 0,  True, '2005-02-09 10:00:00'); /* Lever(2609/leverbigswitch) */
/* @teleloc 0x014A011A [40.000000 -50.000000 -6.000000] 1.000000 0.000000 0.000000 0.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7014A00A,  5512, 0x014A0147, 10, -60, 0, 1, 0, 0, 0, False, '2005-02-09 10:00:00'); /* Surface Portal(5512/portalgolemminesexit) */
/* @teleloc 0x014A0147 [10.000000 -60.000000 0.000000] 1.000000 0.000000 0.000000 0.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7014A00C,  2180, 0x014A0153, 35.2482, -60.0104, 0.02675, 0.707107, 0, 0, -0.707107, False, '2005-02-09 10:00:00'); /* Door(2180/doordungeonactivated) */
/* @teleloc 0x014A0153 [35.248199 -60.010399 0.026750] 0.707107 0.000000 0.000000 -0.707107 */

INSERT INTO `landblock_instance_link` (`parent_GUID`, `child_GUID`, `last_Modified`)
VALUES (0x7014A00C, 0x7014A002, '2005-02-09 10:00:00')/* Lever (2609/leverbigswitch) */;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7014A00D,   197, 0x014A0100, 11.8759, -0.876738, -5.99, 0.197234, 0, 0, -0.980356,  True, '2005-02-09 10:00:00'); /* Iron Golem(197/golemiron) - Level: 20 - T2_Magic - Random Loot: Tier 2 - DeathTreasureType: 463(T2_Magic) - Generates - Iron Heart(3672/golemheartiron) / Pyreal Mote(6353/pyrealmote) */
/* @teleloc 0x014A0100 [11.875900 -0.876738 -5.990000] 0.197234 0.000000 0.000000 -0.980356 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7014A00E,  1608, 0x014A0103, 9.28614, -19.9964, -5.995, 0.468528, 0, 0, -0.883449,  True, '2005-02-09 10:00:00'); /* Drudge Lurker(1608/drudgelurker) - Level: 24 - T2_General - Random Loot: Tier 2 - DeathTreasureType: 451(T2_General) - Generates - Brown Beans(7825/cacaobeans) / Ruined Amulet of the Atlatl(15760/amuletruinedatlatl) / Drudge Fight(27390/gemquestfightdrudge) */
/* @teleloc 0x014A0103 [9.286140 -19.996401 -5.995000] 0.468528 0.000000 0.000000 -0.883449 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7014A00F,  1608, 0x014A0103, 11.5591, -18.756, -5.995, 0.186876, 0, 0, 0.982383,  True, '2005-02-09 10:00:00'); /* Drudge Lurker(1608/drudgelurker) - Level: 24 - T2_General - Random Loot: Tier 2 - DeathTreasureType: 451(T2_General) - Generates - Brown Beans(7825/cacaobeans) / Ruined Amulet of the Atlatl(15760/amuletruinedatlatl) / Drudge Fight(27390/gemquestfightdrudge) */
/* @teleloc 0x014A0103 [11.559100 -18.756001 -5.995000] 0.186876 0.000000 0.000000 0.982383 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7014A010,   197, 0x014A0108, 18.307, -2.07242, -5.99, -0.483152, 0, 0, -0.875537,  True, '2005-02-09 10:00:00'); /* Iron Golem(197/golemiron) - Level: 20 - T2_Magic - Random Loot: Tier 2 - DeathTreasureType: 463(T2_Magic) - Generates - Iron Heart(3672/golemheartiron) / Pyreal Mote(6353/pyrealmote) */
/* @teleloc 0x014A0108 [18.306999 -2.072420 -5.990000] -0.483152 0.000000 0.000000 -0.875537 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7014A011,   195, 0x014A010C, 34.4693, 0.460433, -5.945, 0.439177, 0, 0, 0.898401,  True, '2005-02-09 10:00:00'); /* Granite Golem(195/golemgranite) - Level: 17 - T2_Magic - Random Loot: Tier 2 - DeathTreasureType: 463(T2_Magic) - Generates - Granite Heart(3671/golemheartgranite) / Pyreal Mote(6353/pyrealmote) */
/* @teleloc 0x014A010C [34.469299 0.460433 -5.945000] 0.439177 0.000000 0.000000 0.898401 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7014A012,  1608, 0x014A010F, 31.0922, -18.2032, -5.995, -0.834134, 0, 0, 0.551562,  True, '2005-02-09 10:00:00'); /* Drudge Lurker(1608/drudgelurker) - Level: 24 - T2_General - Random Loot: Tier 2 - DeathTreasureType: 451(T2_General) - Generates - Brown Beans(7825/cacaobeans) / Ruined Amulet of the Atlatl(15760/amuletruinedatlatl) / Drudge Fight(27390/gemquestfightdrudge) */
/* @teleloc 0x014A010F [31.092199 -18.203199 -5.995000] -0.834134 0.000000 0.000000 0.551562 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7014A013,  1609, 0x014A010F, 34.2515, -19.2244, -5.995, 0.972599, 0, 0, 0.232488,  True, '2005-02-09 10:00:00'); /* Drudge Stalker(1609/drudgestalker) - Level: 27 - T2_General - Random Loot: Tier 2 - DeathTreasureType: 451(T2_General) - Generates - Brown Beans(7825/cacaobeans) / Ruined Amulet of the Sword(15771/amuletruinedsword) / Drudge Fight(27390/gemquestfightdrudge) / Drudge Head(8145/drudgehead) */
/* @teleloc 0x014A010F [34.251499 -19.224400 -5.995000] 0.972599 0.000000 0.000000 0.232488 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7014A014,   194, 0x014A0113, 40.8511, -24.9693, -5.99, 0.98738, 0, 0, 0.158371,  True, '2005-02-09 10:00:00'); /* Copper Golem(194/golemcopper) - Level: 19 - T2_Magic - Random Loot: Tier 2 - DeathTreasureType: 463(T2_Magic) - Generates - Copper Heart(3670/golemheartcopper) / Pyreal Mote(6353/pyrealmote) */
/* @teleloc 0x014A0113 [40.851101 -24.969299 -5.990000] 0.987380 0.000000 0.000000 0.158371 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7014A015,   194, 0x014A0118, 39.8915, -43.0909, -5.99, -0.999917, 0, 0, 0.012908,  True, '2005-02-09 10:00:00'); /* Copper Golem(194/golemcopper) - Level: 19 - T2_Magic - Random Loot: Tier 2 - DeathTreasureType: 463(T2_Magic) - Generates - Copper Heart(3670/golemheartcopper) / Pyreal Mote(6353/pyrealmote) */
/* @teleloc 0x014A0118 [39.891499 -43.090900 -5.990000] -0.999917 0.000000 0.000000 0.012908 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7014A016,  1609, 0x014A011A, 36.7253, -52.3383, -5.995, 0.98528, 0, 0, -0.170946,  True, '2005-02-09 10:00:00'); /* Drudge Stalker(1609/drudgestalker) - Level: 27 - T2_General - Random Loot: Tier 2 - DeathTreasureType: 451(T2_General) - Generates - Brown Beans(7825/cacaobeans) / Ruined Amulet of the Sword(15771/amuletruinedsword) / Drudge Fight(27390/gemquestfightdrudge) / Drudge Head(8145/drudgehead) */
/* @teleloc 0x014A011A [36.725300 -52.338299 -5.995000] 0.985280 0.000000 0.000000 -0.170946 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7014A017,  1609, 0x014A011A, 42.753, -51.2884, -5.995, 0.992826, 0, 0, 0.119566,  True, '2005-02-09 10:00:00'); /* Drudge Stalker(1609/drudgestalker) - Level: 27 - T2_General - Random Loot: Tier 2 - DeathTreasureType: 451(T2_General) - Generates - Brown Beans(7825/cacaobeans) / Ruined Amulet of the Sword(15771/amuletruinedsword) / Drudge Fight(27390/gemquestfightdrudge) / Drudge Head(8145/drudgehead) */
/* @teleloc 0x014A011A [42.752998 -51.288399 -5.995000] 0.992826 0.000000 0.000000 0.119566 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7014A018,   195, 0x014A011D, 50.4061, -0.146862, -5.989, 0.715885, 0, 0, 0.698218,  True, '2005-02-09 10:00:00'); /* Granite Golem(195/golemgranite) - Level: 17 - T2_Magic - Random Loot: Tier 2 - DeathTreasureType: 463(T2_Magic) - Generates - Granite Heart(3671/golemheartgranite) / Pyreal Mote(6353/pyrealmote) */
/* @teleloc 0x014A011D [50.406101 -0.146862 -5.989000] 0.715885 0.000000 0.000000 0.698218 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7014A019,  6645, 0x014A011F, 54.316, -38.3942, -5.99, -0.917357, 0, 0, 0.398066,  True, '2005-02-09 10:00:00'); /* Unstable Magma Golem(6645/golemunstablemagma) - Level: 23 - T2_Magic - Random Loot: Tier 2 - DeathTreasureType: 463(T2_Magic) - Generates - Black Rock(3686/rockblack) / Pyreal Mote(6353/pyrealmote) */
/* @teleloc 0x014A011F [54.316002 -38.394199 -5.990000] -0.917357 0.000000 0.000000 0.398066 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7014A01A,   194, 0x014A0123, 45.4811, -60.1847, -5.989, -0.538404, 0, 0, -0.842687,  True, '2005-02-09 10:00:00'); /* Copper Golem(194/golemcopper) - Level: 19 - T2_Magic - Random Loot: Tier 2 - DeathTreasureType: 463(T2_Magic) - Generates - Copper Heart(3670/golemheartcopper) / Pyreal Mote(6353/pyrealmote) */
/* @teleloc 0x014A0123 [45.481098 -60.184700 -5.989000] -0.538404 0.000000 0.000000 -0.842687 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7014A01B,  1625, 0x014A0129, 59.0202, -17.5476, -5.988, 0.995547, 0, 0, -0.094264,  True, '2005-02-09 10:00:00'); /* Mountain Rat(1625/ratmountain) - Level: 16 - T1_Warrior - Random Loot: Tier 1 - DeathTreasureType: 459(T1_Warrior) - Generates - Hot Pepper(5794/hotpepper) */
/* @teleloc 0x014A0129 [59.020199 -17.547600 -5.988000] 0.995547 0.000000 0.000000 -0.094264 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7014A01C,  1625, 0x014A0129, 61.429, -23.1519, -5.988, -0.996538, 0, 0, 0.083143,  True, '2005-02-09 10:00:00'); /* Mountain Rat(1625/ratmountain) - Level: 16 - T1_Warrior - Random Loot: Tier 1 - DeathTreasureType: 459(T1_Warrior) - Generates - Hot Pepper(5794/hotpepper) */
/* @teleloc 0x014A0129 [61.429001 -23.151899 -5.988000] -0.996538 0.000000 0.000000 0.083143 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7014A01D,   194, 0x014A012F, 57.4792, -59.0929, -5.945, 0.679299, 0, 0, 0.733861,  True, '2005-02-09 10:00:00'); /* Copper Golem(194/golemcopper) - Level: 19 - T2_Magic - Random Loot: Tier 2 - DeathTreasureType: 463(T2_Magic) - Generates - Copper Heart(3670/golemheartcopper) / Pyreal Mote(6353/pyrealmote) */
/* @teleloc 0x014A012F [57.479198 -59.092899 -5.945000] 0.679299 0.000000 0.000000 0.733861 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7014A01E,  6645, 0x014A0132, 72.4126, -11.5836, -5.99, 0.121946, 0, 0, -0.992537,  True, '2005-02-09 10:00:00'); /* Unstable Magma Golem(6645/golemunstablemagma) - Level: 23 - T2_Magic - Random Loot: Tier 2 - DeathTreasureType: 463(T2_Magic) - Generates - Black Rock(3686/rockblack) / Pyreal Mote(6353/pyrealmote) */
/* @teleloc 0x014A0132 [72.412598 -11.583600 -5.990000] 0.121946 0.000000 0.000000 -0.992537 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7014A01F,  6645, 0x014A0135, 67.9131, -38.4882, -5.99, -0.976397, 0, 0, -0.215982,  True, '2005-02-09 10:00:00'); /* Unstable Magma Golem(6645/golemunstablemagma) - Level: 23 - T2_Magic - Random Loot: Tier 2 - DeathTreasureType: 463(T2_Magic) - Generates - Black Rock(3686/rockblack) / Pyreal Mote(6353/pyrealmote) */
/* @teleloc 0x014A0135 [67.913101 -38.488201 -5.990000] -0.976397 0.000000 0.000000 -0.215982 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7014A020,  6645, 0x014A0138, 76.6125, -21.2307, -5.989, -0.585399, 0, 0, -0.810745,  True, '2005-02-09 10:00:00'); /* Unstable Magma Golem(6645/golemunstablemagma) - Level: 23 - T2_Magic - Random Loot: Tier 2 - DeathTreasureType: 463(T2_Magic) - Generates - Black Rock(3686/rockblack) / Pyreal Mote(6353/pyrealmote) */
/* @teleloc 0x014A0138 [76.612503 -21.230700 -5.989000] -0.585399 0.000000 0.000000 -0.810745 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7014A021, 14521, 0x014A013C, 107.87, -19.9044, -5.99, -0.723377, 0, 0, -0.690454,  True, '2005-02-09 10:00:00'); /* Glacial Golem(14521/golemglacial) - Level: 23 - T2_Magic - Random Loot: Tier 2 - DeathTreasureType: 463(T2_Magic) - Generates - Pyreal Mote(6353/pyrealmote) / Glacial Golem Heart(23201/golemheartglacial) */
/* @teleloc 0x014A013C [107.870003 -19.904400 -5.990000] -0.723377 0.000000 0.000000 -0.690454 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7014A022,  1924, 0x014A013F, 118.959, -21.459, -5.995, -0.540434, 0, 0, -0.841387, False, '2005-02-09 10:00:00'); /* Chest(1924/chestmagiclow) - Content - Random Loot: Tier 2 - DeathTreasureType: 463(T2_Magic) */
/* @teleloc 0x014A013F [118.959000 -21.459000 -5.995000] -0.540434 0.000000 0.000000 -0.841387 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7014A023, 14521, 0x014A013F, 117.675, -22.7814, -5.99, -0.594848, 0, 0, -0.803838,  True, '2005-02-09 10:00:00'); /* Glacial Golem(14521/golemglacial) - Level: 23 - T2_Magic - Random Loot: Tier 2 - DeathTreasureType: 463(T2_Magic) - Generates - Pyreal Mote(6353/pyrealmote) / Glacial Golem Heart(23201/golemheartglacial) */
/* @teleloc 0x014A013F [117.675003 -22.781401 -5.990000] -0.594848 0.000000 0.000000 -0.803838 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7014A024, 24670, 0x014A0140, 118.808, -28.4008, -5.995, 0.335068, 0, 0, -0.942194, False, '2005-02-09 10:00:00'); /* Runed Chest(24670/chestquestlockedlowpoie) - Locked(100/nokey) - Content - Random Loot: Tier 2 - DeathTreasureType: 410(T2_RunedChest) */
/* @teleloc 0x014A0140 [118.807999 -28.400801 -5.995000] 0.335068 0.000000 0.000000 -0.942194 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7014A025, 14521, 0x014A0140, 116.904, -27.3257, -5.99, -0.921907, 0, 0, -0.387412,  True, '2005-02-09 10:00:00'); /* Glacial Golem(14521/golemglacial) - Level: 23 - T2_Magic - Random Loot: Tier 2 - DeathTreasureType: 463(T2_Magic) - Generates - Pyreal Mote(6353/pyrealmote) / Glacial Golem Heart(23201/golemheartglacial) */
/* @teleloc 0x014A0140 [116.903999 -27.325701 -5.990000] -0.921907 0.000000 0.000000 -0.387412 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7014A026,  7924, 0x014A0141, 2.6704, -53.6681, 0.005, -0.710557, 0, 0, 0.703639, False, '2005-02-09 10:00:00'); /* Linkable Monster Generator ( 5 Min.)(7924/linkmonstergen5minutes) - Generates - Place Holder Object(3666/placeholder) */
/* @teleloc 0x014A0141 [2.670400 -53.668098 0.005000] -0.710557 0.000000 0.000000 0.703639 */

INSERT INTO `landblock_instance_link` (`parent_GUID`, `child_GUID`, `last_Modified`)
VALUES (0x7014A026, 0x7014A00D, '2005-02-09 10:00:00')/* Iron Golem (197/golemiron) - Level: 20 T2_Magic - Random Loot: Tier 2 - DeathTreasureType: 463(T2_Magic) - Generates - Iron Heart(3672/golemheartiron) / Pyreal Mote(6353/pyrealmote) */
     , (0x7014A026, 0x7014A00E, '2005-02-09 10:00:00')/* Drudge Lurker (1608/drudgelurker) - Level: 24 T2_General - Random Loot: Tier 2 - DeathTreasureType: 451(T2_General) - Generates - Brown Beans(7825/cacaobeans) / Ruined Amulet of the Atlatl(15760/amuletruinedatlatl) / Drudge Fight(27390/gemquestfightdrudge) */
     , (0x7014A026, 0x7014A00F, '2005-02-09 10:00:00')/* Drudge Lurker (1608/drudgelurker) - Level: 24 T2_General - Random Loot: Tier 2 - DeathTreasureType: 451(T2_General) - Generates - Brown Beans(7825/cacaobeans) / Ruined Amulet of the Atlatl(15760/amuletruinedatlatl) / Drudge Fight(27390/gemquestfightdrudge) */
     , (0x7014A026, 0x7014A010, '2005-02-09 10:00:00')/* Iron Golem (197/golemiron) - Level: 20 T2_Magic - Random Loot: Tier 2 - DeathTreasureType: 463(T2_Magic) - Generates - Iron Heart(3672/golemheartiron) / Pyreal Mote(6353/pyrealmote) */
     , (0x7014A026, 0x7014A011, '2005-02-09 10:00:00')/* Granite Golem (195/golemgranite) - Level: 17 T2_Magic - Random Loot: Tier 2 - DeathTreasureType: 463(T2_Magic) - Generates - Granite Heart(3671/golemheartgranite) / Pyreal Mote(6353/pyrealmote) */
     , (0x7014A026, 0x7014A012, '2005-02-09 10:00:00')/* Drudge Lurker (1608/drudgelurker) - Level: 24 T2_General - Random Loot: Tier 2 - DeathTreasureType: 451(T2_General) - Generates - Brown Beans(7825/cacaobeans) / Ruined Amulet of the Atlatl(15760/amuletruinedatlatl) / Drudge Fight(27390/gemquestfightdrudge) */
     , (0x7014A026, 0x7014A013, '2005-02-09 10:00:00')/* Drudge Stalker (1609/drudgestalker) - Level: 27 T2_General - Random Loot: Tier 2 - DeathTreasureType: 451(T2_General) - Generates - Brown Beans(7825/cacaobeans) / Ruined Amulet of the Sword(15771/amuletruinedsword) / Drudge Fight(27390/gemquestfightdrudge) / Drudge Head(8145/drudgehead) */
     , (0x7014A026, 0x7014A014, '2005-02-09 10:00:00')/* Copper Golem (194/golemcopper) - Level: 19 T2_Magic - Random Loot: Tier 2 - DeathTreasureType: 463(T2_Magic) - Generates - Copper Heart(3670/golemheartcopper) / Pyreal Mote(6353/pyrealmote) */
     , (0x7014A026, 0x7014A015, '2005-02-09 10:00:00')/* Copper Golem (194/golemcopper) - Level: 19 T2_Magic - Random Loot: Tier 2 - DeathTreasureType: 463(T2_Magic) - Generates - Copper Heart(3670/golemheartcopper) / Pyreal Mote(6353/pyrealmote) */
     , (0x7014A026, 0x7014A016, '2005-02-09 10:00:00')/* Drudge Stalker (1609/drudgestalker) - Level: 27 T2_General - Random Loot: Tier 2 - DeathTreasureType: 451(T2_General) - Generates - Brown Beans(7825/cacaobeans) / Ruined Amulet of the Sword(15771/amuletruinedsword) / Drudge Fight(27390/gemquestfightdrudge) / Drudge Head(8145/drudgehead) */
     , (0x7014A026, 0x7014A017, '2005-02-09 10:00:00')/* Drudge Stalker (1609/drudgestalker) - Level: 27 T2_General - Random Loot: Tier 2 - DeathTreasureType: 451(T2_General) - Generates - Brown Beans(7825/cacaobeans) / Ruined Amulet of the Sword(15771/amuletruinedsword) / Drudge Fight(27390/gemquestfightdrudge) / Drudge Head(8145/drudgehead) */
     , (0x7014A026, 0x7014A018, '2005-02-09 10:00:00')/* Granite Golem (195/golemgranite) - Level: 17 T2_Magic - Random Loot: Tier 2 - DeathTreasureType: 463(T2_Magic) - Generates - Granite Heart(3671/golemheartgranite) / Pyreal Mote(6353/pyrealmote) */
     , (0x7014A026, 0x7014A019, '2005-02-09 10:00:00')/* Unstable Magma Golem (6645/golemunstablemagma) - Level: 23 T2_Magic - Random Loot: Tier 2 - DeathTreasureType: 463(T2_Magic) - Generates - Black Rock(3686/rockblack) / Pyreal Mote(6353/pyrealmote) */
     , (0x7014A026, 0x7014A01A, '2005-02-09 10:00:00')/* Copper Golem (194/golemcopper) - Level: 19 T2_Magic - Random Loot: Tier 2 - DeathTreasureType: 463(T2_Magic) - Generates - Copper Heart(3670/golemheartcopper) / Pyreal Mote(6353/pyrealmote) */
     , (0x7014A026, 0x7014A01B, '2005-02-09 10:00:00')/* Mountain Rat (1625/ratmountain) - Level: 16 T1_Warrior - Random Loot: Tier 1 - DeathTreasureType: 459(T1_Warrior) - Generates - Hot Pepper(5794/hotpepper) */
     , (0x7014A026, 0x7014A01C, '2005-02-09 10:00:00')/* Mountain Rat (1625/ratmountain) - Level: 16 T1_Warrior - Random Loot: Tier 1 - DeathTreasureType: 459(T1_Warrior) - Generates - Hot Pepper(5794/hotpepper) */
     , (0x7014A026, 0x7014A01D, '2005-02-09 10:00:00')/* Copper Golem (194/golemcopper) - Level: 19 T2_Magic - Random Loot: Tier 2 - DeathTreasureType: 463(T2_Magic) - Generates - Copper Heart(3670/golemheartcopper) / Pyreal Mote(6353/pyrealmote) */
     , (0x7014A026, 0x7014A01E, '2005-02-09 10:00:00')/* Unstable Magma Golem (6645/golemunstablemagma) - Level: 23 T2_Magic - Random Loot: Tier 2 - DeathTreasureType: 463(T2_Magic) - Generates - Black Rock(3686/rockblack) / Pyreal Mote(6353/pyrealmote) */
     , (0x7014A026, 0x7014A01F, '2005-02-09 10:00:00')/* Unstable Magma Golem (6645/golemunstablemagma) - Level: 23 T2_Magic - Random Loot: Tier 2 - DeathTreasureType: 463(T2_Magic) - Generates - Black Rock(3686/rockblack) / Pyreal Mote(6353/pyrealmote) */
     , (0x7014A026, 0x7014A020, '2005-02-09 10:00:00')/* Unstable Magma Golem (6645/golemunstablemagma) - Level: 23 T2_Magic - Random Loot: Tier 2 - DeathTreasureType: 463(T2_Magic) - Generates - Black Rock(3686/rockblack) / Pyreal Mote(6353/pyrealmote) */
     , (0x7014A026, 0x7014A021, '2005-02-09 10:00:00')/* Glacial Golem (14521/golemglacial) - Level: 23 T2_Magic - Random Loot: Tier 2 - DeathTreasureType: 463(T2_Magic) - Generates - Pyreal Mote(6353/pyrealmote) / Glacial Golem Heart(23201/golemheartglacial) */
     , (0x7014A026, 0x7014A023, '2005-02-09 10:00:00')/* Glacial Golem (14521/golemglacial) - Level: 23 T2_Magic - Random Loot: Tier 2 - DeathTreasureType: 463(T2_Magic) - Generates - Pyreal Mote(6353/pyrealmote) / Glacial Golem Heart(23201/golemheartglacial) */
     , (0x7014A026, 0x7014A025, '2005-02-09 10:00:00')/* Glacial Golem (14521/golemglacial) - Level: 23 T2_Magic - Random Loot: Tier 2 - DeathTreasureType: 463(T2_Magic) - Generates - Pyreal Mote(6353/pyrealmote) / Glacial Golem Heart(23201/golemheartglacial) */
     , (0x7014A026, 0x7014A027, '2005-02-09 10:00:00')/* Granite Golem (195/golemgranite) - Level: 17 T2_Magic - Random Loot: Tier 2 - DeathTreasureType: 463(T2_Magic) - Generates - Granite Heart(3671/golemheartgranite) / Pyreal Mote(6353/pyrealmote) */
     , (0x7014A026, 0x7014A028, '2005-02-09 10:00:00')/* Granite Golem (195/golemgranite) - Level: 17 T2_Magic - Random Loot: Tier 2 - DeathTreasureType: 463(T2_Magic) - Generates - Granite Heart(3671/golemheartgranite) / Pyreal Mote(6353/pyrealmote) */;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7014A027,   195, 0x014A0150, 30.9015, -62.2067, 0.011, -0.829892, 0, 0, -0.557924,  True, '2005-02-09 10:00:00'); /* Granite Golem(195/golemgranite) - Level: 17 - T2_Magic - Random Loot: Tier 2 - DeathTreasureType: 463(T2_Magic) - Generates - Granite Heart(3671/golemheartgranite) / Pyreal Mote(6353/pyrealmote) */
/* @teleloc 0x014A0150 [30.901501 -62.206699 0.011000] -0.829892 0.000000 0.000000 -0.557924 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7014A028,   195, 0x014A0150, 30.7857, -57.2982, 0.011, -0.631092, 0, 0, -0.775708,  True, '2005-02-09 10:00:00'); /* Granite Golem(195/golemgranite) - Level: 17 - T2_Magic - Random Loot: Tier 2 - DeathTreasureType: 463(T2_Magic) - Generates - Granite Heart(3671/golemheartgranite) / Pyreal Mote(6353/pyrealmote) */
/* @teleloc 0x014A0150 [30.785700 -57.298199 0.011000] -0.631092 0.000000 0.000000 -0.775708 */
