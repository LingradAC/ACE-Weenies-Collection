DELETE FROM `weenie` WHERE `class_Id` = 2024;

INSERT INTO `weenie` (`class_Id`, `class_Name`, `type`, `last_Modified`)
VALUES (2024, 'bowlilitha', 3, '2019-05-27 08:24:50') /* MissileLauncher */;

INSERT INTO `weenie_properties_int` (`object_Id`, `type`, `value`)
VALUES (2024,   1,        256) /* ItemType - MissileWeapon */
     , (2024,   3,          2) /* PaletteTemplate - Blue */
     , (2024,   5,        350) /* EncumbranceVal */
     , (2024,   9,    4194304) /* ValidLocations - MissileWeapon */
     , (2024,  16,          1) /* ItemUseable - No */
     , (2024,  19,        875) /* Value */
     , (2024,  33,          1) /* Bonded - Bonded */
     , (2024,  44,          4) /* Damage */
     , (2024,  46,         16) /* DefaultCombatStyle - Bow */
     , (2024,  48,          2) /* WeaponSkill - Bow */
     , (2024,  49,         40) /* WeaponTime */
     , (2024,  50,          1) /* AmmoType - Arrow */
     , (2024,  51,          2) /* CombatUse - Missile */
     , (2024,  52,          2) /* ParentLocation - LeftHand */
     , (2024,  53,          3) /* PlacementPosition - LeftHand */
     , (2024,  60,        280) /* WeaponRange */
     , (2024,  93,       1044) /* PhysicsState - Ethereal, IgnoreCollisions, Gravity */
     , (2024, 106,        150) /* ItemSpellcraft */
     , (2024, 107,        400) /* ItemCurMana */
     , (2024, 108,        400) /* ItemMaxMana */
     , (2024, 109,         45) /* ItemDifficulty */
     , (2024, 114,          1) /* Attuned - Attuned */
     , (2024, 150,        103) /* HookPlacement - Hook */
     , (2024, 151,          2) /* HookType - Wall */;

INSERT INTO `weenie_properties_bool` (`object_Id`, `type`, `value`)
VALUES (2024,  11, True ) /* IgnoreCollisions */
     , (2024,  13, True ) /* Ethereal */
     , (2024,  14, True ) /* GravityStatus */
     , (2024,  19, True ) /* Attackable */
     , (2024,  22, True ) /* Inscribable */
     , (2024,  23, True ) /* DestroyOnSell */
     , (2024,  99, True ) /* Ivoryable */;

INSERT INTO `weenie_properties_float` (`object_Id`, `type`, `value`)
VALUES (2024,   5,  -0.033) /* ManaRate */
     , (2024,  21,       0) /* WeaponLength */
     , (2024,  22,       0) /* DamageVariance */
     , (2024,  26,    27.5) /* MaximumVelocity */
     , (2024,  29,    1.08) /* WeaponDefense */
     , (2024,  62,       1) /* WeaponOffense */
     , (2024,  63,     2.1) /* DamageMod */
     , (2024, 147,    0.25) /* CriticalFrequency */;

INSERT INTO `weenie_properties_string` (`object_Id`, `type`, `value`)
VALUES (2024,   1, 'Lilitha''s Bow') /* Name */
     , (2024,  33, 'pickup_mutated_bowlilitha') /* Quest string */;

INSERT INTO `weenie_properties_d_i_d` (`object_Id`, `type`, `value`)
VALUES (2024,   1, 0x02000129) /* Setup */
     , (2024,   3, 0x20000014) /* SoundTable */
     , (2024,   6, 0x04000BEF) /* PaletteBase */
     , (2024,   7, 0x10000130) /* ClothingBase */
     , (2024,   8, 0x060010BF) /* Icon */
     , (2024,  22, 0x3400002B) /* PhysicsEffectTable */;

INSERT INTO `weenie_properties_spell_book` (`object_Id`, `spell`, `probability`)
VALUES (2024,  1602,      2)  /* Defender III */
     , (2024,  1613,      2)  /* Blood Drinker III */;
