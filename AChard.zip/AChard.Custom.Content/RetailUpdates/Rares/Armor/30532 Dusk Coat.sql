DELETE FROM `weenie` WHERE `class_Id` = 30532;

INSERT INTO `weenie` (`class_Id`, `class_Name`, `type`, `last_Modified`)
VALUES (30532, 'coatraredusk', 2, '2021-11-17 16:56:08') /* Clothing */;

INSERT INTO `weenie_properties_int` (`object_Id`, `type`, `value`)
VALUES (30532,   1,          2) /* ItemType - Armor */
     , (30532,   3,          1) /* PaletteTemplate - AquaBlue */
     , (30532,   4,      15360) /* ClothingPriority - OuterwearChest, OuterwearAbdomen, OuterwearUpperArms, OuterwearLowerArms */
     , (30532,   5,        800) /* EncumbranceVal */
     , (30532,   9,       7680) /* ValidLocations - ChestArmor, AbdomenArmor, UpperArmArmor, LowerArmArmor */
     , (30532,  16,          1) /* ItemUseable - No */
     , (30532,  17,        266) /* RareId */
     , (30532,  19,      50000) /* Value */
     , (30532,  27,          4) /* ArmorType - StuddedLeather */
     , (30532,  28,        500) /* ArmorLevel */
     , (30532,  93,       1044) /* PhysicsState - Ethereal, IgnoreCollisions, Gravity */
     , (30532, 106,        350) /* ItemSpellcraft */
     , (30532, 107,       2000) /* ItemCurMana */
     , (30532, 108,       2000) /* ItemMaxMana */
     , (30532, 151,          2) /* HookType - Wall */
     , (30532, 265,         40) /* EquipmentSetId - RareDamageResistance */
     , (30532, 319,         50) /* ItemMaxLevel */
     , (30532, 320,          1) /* ItemXpStyle - Fixed */;

INSERT INTO `weenie_properties_int64` (`object_Id`, `type`, `value`)
VALUES (30532,   4,          0) /* ItemTotalXp */
     , (30532,   5, 2000000000) /* ItemBaseXp */;

INSERT INTO `weenie_properties_bool` (`object_Id`, `type`, `value`)
VALUES (30532,  11, True ) /* IgnoreCollisions */
     , (30532,  13, True ) /* Ethereal */
     , (30532,  14, True ) /* GravityStatus */
     , (30532,  19, True ) /* Attackable */
     , (30532,  22, True ) /* Inscribable */
     , (30532,  69, False) /* IsSellable */;

INSERT INTO `weenie_properties_float` (`object_Id`, `type`, `value`)
VALUES (30532,   5,  -0.033) /* ManaRate */
     , (30532,  13,     1.1) /* ArmorModVsSlash */
     , (30532,  14,     1.1) /* ArmorModVsPierce */
     , (30532,  15,     1.2) /* ArmorModVsBludgeon */
     , (30532,  16,     1.1) /* ArmorModVsCold */
     , (30532,  17,     1.2) /* ArmorModVsFire */
     , (30532,  18,     1.3) /* ArmorModVsAcid */
     , (30532,  19,       1) /* ArmorModVsElectric */
     , (30532, 165,       1) /* ArmorModVsNether */;

INSERT INTO `weenie_properties_string` (`object_Id`, `type`, `value`)
VALUES (30532,   1, 'Dusk Coat') /* Name */
     , (30532,  16, 'It is said that every great craftsman has a moment of inspiration. If only for a short period of time, they are possessed by a divine spirit, and they are able to create an object of such beauty and quality that they can never in their lifetime hope to surpass. This coat, along with the Dusk Leggings, is Leyrale Shalorn''s master work. The great tailor hung up his needle and thread after finishing the set, sold them to a wealthy nobleman and retired to a life of fishing.') /* LongDesc */;

INSERT INTO `weenie_properties_d_i_d` (`object_Id`, `type`, `value`)
VALUES (30532,   1, 0x02001395) /* Setup */
     , (30532,   3, 0x20000014) /* SoundTable */
     , (30532,   6, 0x04000BEF) /* PaletteBase */
     , (30532,   7, 0x100005FC) /* ClothingBase */
     , (30532,   8, 0x06005C39) /* Icon */
     , (30532,  22, 0x3400002B) /* PhysicsEffectTable */
     , (30532,  52, 0x06005B0C) /* IconUnderlay */;

INSERT INTO `weenie_properties_spell_book` (`object_Id`, `spell`, `probability`)
VALUES (30532,  6107,      2)  /* Legendary Strength */
     , (30532,  6104,      2)  /* Legendary Endurance */
     , (30532,  4407,      2)  /* Incantation of Impenetrability */
     , (30532,  6051,      2)  /* Legendary Fealty */
     , (30532,  6102,      2)  /* Legendary Armor */;

-- Ftuoil Xelrash - 11-16-2025
-- https://github.com/FtuoilXelrash/AChard.Custom.Content
