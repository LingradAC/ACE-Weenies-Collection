DELETE FROM `landblock_instance` WHERE `landblock` = 0x9058;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x79058000,  1148, 0x90580000, 115.51, 138.25, 6, 0.707107, 0, 0, 0.707107, False, '2005-02-09 10:00:00'); /* Door */
/* @teleloc 0x90580000 [115.510002 138.250000 6.000000] 0.707107 0.000000 0.000000 0.707107 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x79058001,  1148, 0x90580000, 105.51, 130.5, 6, 0.707107, 0, 0, 0.707107, False, '2005-02-09 10:00:00'); /* Door */
/* @teleloc 0x90580000 [105.510002 130.500000 6.000000] 0.707107 0.000000 0.000000 0.707107 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x79058002,  1148, 0x90580000, 97.985, 130.5, 6, 0.707107, 0, 0, -0.707107, False, '2005-02-09 10:00:00'); /* Door */
/* @teleloc 0x90580000 [97.985001 130.500000 6.000000] 0.707107 0.000000 0.000000 -0.707107 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x79058003,  1148, 0x90580130, 52.01, 56.5, 0, 0.707107, 0, 0, 0.707107, False, '2005-02-09 10:00:00'); /* Door */
/* @teleloc 0x90580130 [52.009998 56.500000 0.000000] 0.707107 0.000000 0.000000 0.707107 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x79058004,  1148, 0x90580000, 58.01, 64.5, 0, 0.707107, 0, 0, 0.707107, False, '2005-02-09 10:00:00'); /* Door */
/* @teleloc 0x90580000 [58.009998 64.500000 0.000000] 0.707107 0.000000 0.000000 0.707107 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x79058005,  1148, 0x90580000, 63.5, 61.51, 0, -4.37114E-08, 0, 0, -1, False, '2005-02-09 10:00:00'); /* Door */
/* @teleloc 0x90580000 [63.500000 61.509998 0.000000] -0.000000 0.000000 0.000000 -1.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x79058006,  4640, 0x90580000, 184.416, 121.98, 3.9375, 1, 0, 0, 0, False, '2005-02-09 10:00:00'); /* Sidzika's Supplies */
/* @teleloc 0x90580000 [184.416000 121.980003 3.937500] 1.000000 0.000000 0.000000 0.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x79058007,  4681, 0x9058011B, 179.746, 138, 0.024, -4.37114E-08, 0, 0, -1, False, '2005-02-09 10:00:00'); /* Sidzika the Grocer */
/* @teleloc 0x9058011B [179.746002 138.000000 0.024000] -0.000000 0.000000 0.000000 -1.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x79058008,  4686, 0x90580111, 173.852, 132.299, 0.005, 0.755999, 0, 0, -0.654573, False, '2005-02-09 10:00:00'); /* Tailor Najsun */
/* @teleloc 0x90580111 [173.852005 132.298996 0.005000] 0.755999 0.000000 0.000000 -0.654573 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x79058009,  4684, 0x90580113, 185.989, 131.855, 0.024, -0.823199, 0, 0, -0.567753, False, '2005-02-09 10:00:00'); /* Bashkiya the Scribe */
/* @teleloc 0x90580113 [185.988998 131.854996 0.024000] -0.823199 0.000000 0.000000 -0.567753 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7905800A,  4677, 0x90580114, 188.124, 132.778, 3.205, -0.461937, 0, 0, -0.886913, False, '2005-02-09 10:00:00'); /* Archmage Jiz ibn Ijfai */
/* @teleloc 0x90580114 [188.123993 132.778000 3.205000] -0.461937 0.000000 0.000000 -0.886913 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7905800B,  4643, 0x90580000, 67.0511, 62.6296, 3.48313, -0.707107, 0, 0, -0.707107, False, '2005-02-09 10:00:00'); /* House of Treasure */
/* @teleloc 0x90580000 [67.051102 62.629601 3.483130] -0.707107 0.000000 0.000000 -0.707107 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7905800C,  4683, 0x90580133, 50.9855, 65.1891, 0.005, -0.805439, 0, 0, 0.592679, False, '2005-02-09 10:00:00'); /* Hinnabqiq the Jeweler */
/* @teleloc 0x90580133 [50.985500 65.189102 0.005000] -0.805439 0.000000 0.000000 0.592679 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7905800D,  4679, 0x9058011F, 105.95, 134.187, 6.005, 0.485839, 0, 0, -0.874048, False, '2005-02-09 10:00:00'); /* Smith Dah bint Nas */
/* @teleloc 0x9058011F [105.949997 134.186996 6.005000] 0.485839 0.000000 0.000000 -0.874048 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7905800E,  3918, 0x90580120, 111.103, 139.002, 5.205, -0.511058, 0, 0, 0.859546,  True, '2005-02-09 10:00:00'); /* Collector */
/* @teleloc 0x90580120 [111.102997 139.001999 5.205000] -0.511058 0.000000 0.000000 0.859546 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7905800F,  4639, 0x90580000, 106.632, 131.355, 9.55, 0.999001, 0, 0, 0.0446969, False, '2005-02-09 10:00:00'); /* Armaments of Truth */
/* @teleloc 0x90580000 [106.632004 131.354996 9.550000] 0.999001 0.000000 0.000000 0.044697 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x79058010,  4680, 0x9058011F, 102.169, 132.734, 6.005, -0.190304, 0, 0, -0.981725, False, '2005-02-09 10:00:00'); /* Muta al-Mai the Bowyer */
/* @teleloc 0x9058011F [102.168999 132.733994 6.005000] -0.190304 0.000000 0.000000 -0.981725 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x79058011,  4642, 0x90580000, 118.373, 67.4096, 2.97525, -4.37114E-08, 0, 0, -1, False, '2005-02-09 10:00:00'); /* House of Peace */
/* @teleloc 0x90580000 [118.373001 67.409599 2.975250] -0.000000 0.000000 0.000000 -1.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x79058012,  4682, 0x9058013C, 123.198, 66.7438, -0.171487, -0.998494, 0, 0, -0.0548554, False, '2005-02-09 10:00:00'); /* Healer Sunwi */
/* @teleloc 0x9058013C [123.197998 66.743797 -0.171487] -0.998494 0.000000 0.000000 -0.054855 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x79058013,  5152, 0x90580130, 54.5396, 54.4963, 0.00500001, 0.879826, 0, 0, -0.475296,  True, '2005-02-09 10:00:00'); /* Jilsaya bint Dah */
/* @teleloc 0x90580130 [54.539600 54.496300 0.005000] 0.879826 0.000000 0.000000 -0.475296 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x79058015,  4645, 0x90580000, 35.2427, 160.153, 5.34729, 0.997699, 0, 0, 0.0678047, False, '2005-02-09 10:00:00'); /* Al-Arqas */
/* @teleloc 0x90580000 [35.242699 160.153000 5.347290] 0.997699 0.000000 0.000000 0.067805 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x79058016,  4645, 0x90580000, 92.568, 86.7431, -0.095, 0.125157, 0, 0, -0.992137, False, '2005-02-09 10:00:00'); /* Al-Arqas */
/* @teleloc 0x90580000 [92.568001 86.743103 -0.095000] 0.125157 0.000000 0.000000 -0.992137 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x79058018,  7923, 0x90580000, 131.905, 91.745, 0.005, -0.675204, 0, 0, -0.737631, False, '2005-02-09 10:00:00'); /* Linkable Monster Generator ( 3 Min.) */
/* @teleloc 0x90580000 [131.904999 91.745003 0.005000] -0.675204 0.000000 0.000000 -0.737631 */

INSERT INTO `landblock_instance_link` (`parent_GUID`, `child_GUID`, `last_Modified`)
VALUES (0x79058018, 0x7905800E, '2005-02-09 10:00:00') /* Collector (3918) */
     , (0x79058018, 0x79058013, '2005-02-09 10:00:00') /* Jilsaya bint Dah (5152) */
     , (0x79058018, 0x7905802E, '2005-02-09 10:00:00') /* Jalina al-Hajj (25951) */
     , (0x79058018, 0x7905802F, '2005-02-09 10:00:00') /* Adara al-Rajin (27251) */
     , (0x79058018, 0x79058034, '2005-02-09 10:00:00') /* Apprentice Cook (27744) */;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7905801E, 16919, 0x90580000, 110.696, 90.4293, 2.27243E-07, -0.704711, 0, 0, -0.709494, False, '2005-02-09 10:00:00'); /* Pedestal Weak Spot */
/* @teleloc 0x90580000 [110.695999 90.429298 0.000000] -0.704711 0.000000 0.000000 -0.709494 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x79058021, 19457, 0x90580000, 115.148, 90.5245, 7, -0.718897, 0, 0, -0.695117, False, '2005-02-09 10:00:00'); /* Fireworks Generator */
/* @teleloc 0x90580000 [115.148003 90.524498 7.000000] -0.718897 0.000000 0.000000 -0.695117 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x79058024,  1148, 0x90580146, 115.99, 15.5, 34, 0.707107, 0, 0, -0.707107, False, '2005-02-09 10:00:00'); /* Door */
/* @teleloc 0x90580146 [115.989998 15.500000 34.000000] 0.707107 0.000000 0.000000 -0.707107 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x79058025,  1148, 0x90580000, 109.99, 7.5, 34, 0.707107, 0, 0, -0.707107, False, '2005-02-09 10:00:00'); /* Door */
/* @teleloc 0x90580000 [109.989998 7.500000 34.000000] 0.707107 0.000000 0.000000 -0.707107 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x79058026,  1148, 0x90580000, 104.5, 10.49, 34, -1, 0, 0, 8.74228E-08, False, '2005-02-09 10:00:00'); /* Door */
/* @teleloc 0x90580000 [104.500000 10.490000 34.000000] -1.000000 0.000000 0.000000 0.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x79058027, 19199, 0x90580000, 114.493, 90.5114, 6.815, 0.715141, 0, 0, -0.69898, False, '2005-02-09 10:00:00'); /* Nullified Statue of a Gromnie */
/* @teleloc 0x90580000 [114.492996 90.511398 6.815000] 0.715141 0.000000 0.000000 -0.698980 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x79058028, 19717, 0x90580140, 129.483, 90.6703, -5.195, -0.717461, 0, 0, 0.696598, False, '2005-02-09 10:00:00'); /* Mannikin Foundry Portal */
/* @teleloc 0x90580140 [129.483002 90.670303 -5.195000] -0.717461 0.000000 0.000000 0.696598 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7905802E, 25951, 0x9058013E, 154.31, 112.601, -0.295, -0.0664166, 0, 0, -0.997792,  True, '2005-02-09 10:00:00'); /* Jalina al-Hajj */
/* @teleloc 0x9058013E [154.309998 112.600998 -0.295000] -0.066417 0.000000 0.000000 -0.997792 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7905802F, 27251, 0x90580000, 103.614, 125.657, 9.605, 0.925739, 0, 0, -0.378164,  True, '2005-02-09 10:00:00'); /* Adara al-Rajin */
/* @teleloc 0x90580000 [103.613998 125.656998 9.605000] 0.925739 0.000000 0.000000 -0.378164 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x79058031,  6088, 0x90580152, 135.876, 80.0102, 2.005, -0.369186, 0, 0, 0.929356, False, '2005-02-09 10:00:00'); /* Al-Arqas Meeting Hall Portal */
/* @teleloc 0x90580152 [135.876007 80.010201 2.005000] -0.369186 0.000000 0.000000 0.929356 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x79058032,   509, 0x90580000, 78.466, 56.2945, -0.095, 0.0762813, 0, 0, -0.997086, False, '2005-02-09 10:00:00'); /* Life Stone */
/* @teleloc 0x90580000 [78.466003 56.294498 -0.095000] 0.076281 0.000000 0.000000 -0.997086 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x79058033, 27547, 0x90580000, 142.744, 89.0523, 0.00500003, -0.362012, 0, 0, 0.932173, False, '2005-02-09 10:00:00'); /* Bind Stone */
/* @teleloc 0x90580000 [142.744003 89.052299 0.005000] -0.362012 0.000000 0.000000 0.932173 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x79058034, 27744, 0x9058013E, 150.461, 114.783, -0.295, -0.111414, 0, 0, 0.993774,  True, '2005-02-09 10:00:00'); /* Apprentice Cook */
/* @teleloc 0x9058013E [150.460999 114.782997 -0.295000] -0.111414 0.000000 0.000000 0.993774 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x79058035, 43066, 0x90580034, 156.021, 92.1051, 0.198001, 0.958136, 0, 0, 0.286312, False, '2020-06-20 07:36:15'); /* Portal to Town Network */
/* @teleloc 0x90580034 [156.020996 92.105103 0.198001] 0.958136 0.000000 0.000000 0.286312 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x79058036, 15759, 0x90580130, 58.275, 54.624, 0.005, 0.994623, 0, 0, -0.103564, False, '2019-09-02 00:00:00'); /* Linkable Item Generator */
/* @teleloc 0x90580130 [58.275002 54.624001 0.005000] 0.994623 0.000000 0.000000 -0.103564 */

INSERT INTO `landblock_instance_link` (`parent_GUID`, `child_GUID`, `last_Modified`)
VALUES (0x79058036, 0x79058037, '2019-09-02 00:00:00') /* Explorer Heavy Weapons Gem (45990) */
     , (0x79058036, 0x79058038, '2019-09-02 00:00:00') /* Explorer Finesse Weapons Gem (45983) */
     , (0x79058036, 0x79058039, '2019-09-02 00:00:00') /* Explorer Light Weapons Gem (45981) */;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x79058037, 45990, 0x90580130, 58.6856, 59.5393, 0.52, 0.993829, 0, 0, -0.110924,  True, '2019-09-02 00:00:00'); /* Explorer Heavy Weapons Gem */
/* @teleloc 0x90580130 [58.685600 59.539299 0.520000] 0.993829 0.000000 0.000000 -0.110924 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x79058038, 45983, 0x90580130, 59.1581, 58.9066, 0.52, 0.993829, 0, 0, -0.110924,  True, '2019-09-02 00:00:00'); /* Explorer Finesse Weapons Gem */
/* @teleloc 0x90580130 [59.158100 58.906601 0.520000] 0.993829 0.000000 0.000000 -0.110924 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x79058039, 45981, 0x90580130, 59.6273, 58.2554, 0.52, 0.993829, 0, 0, -0.110924,  True, '2019-09-02 00:00:00'); /* Explorer Light Weapons Gem */
/* @teleloc 0x90580130 [59.627300 58.255402 0.520000] 0.993829 0.000000 0.000000 -0.110924 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7905803A, 5000864, 0x9058000B, 32.4618, 57.3681, 5.23441, 0.886269, 0, 0, -0.463171, False, '2020-06-21 20:32:15'); /* ShadowAttack */
/* @teleloc 0x9058000B [32.461800 57.368099 5.234410] 0.886269 0.000000 0.000000 -0.463171 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7905803B, 5000864, 0x90580014, 60.3936, 91.6906, 0.055, 0.868287, 0, 0, -0.496063, False, '2020-06-21 20:32:20'); /* ShadowAttack */
/* @teleloc 0x90580014 [60.393600 91.690598 0.055000] 0.868287 0.000000 0.000000 -0.496063 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7905803C, 5000864, 0x90580025, 98.9247, 113.92, 4.53491, 0.912683, 0, 0, -0.408669, False, '2020-06-21 20:32:24'); /* ShadowAttack */
/* @teleloc 0x90580025 [98.924698 113.919998 4.534910] 0.912683 0.000000 0.000000 -0.408669 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7905803D, 5000864, 0x9058002D, 134.624, 113.78, 2.39912, 0.617222, 0, 0, -0.786789, False, '2020-06-21 20:32:27'); /* ShadowAttack */
/* @teleloc 0x9058002D [134.623993 113.779999 2.399120] 0.617222 0.000000 0.000000 -0.786789 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7905803E, 5000864, 0x90580035, 163.426, 108.21, 0.055, 0.794145, 0, 0, -0.607728, False, '2020-06-21 20:32:29'); /* ShadowAttack */
/* @teleloc 0x90580035 [163.425995 108.209999 0.055000] 0.794145 0.000000 0.000000 -0.607728 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7905803F, 5000864, 0x90580023, 111.456, 64.0278, -0.045, 0.394258, 0, 0, 0.919, False, '2020-06-21 20:32:41'); /* ShadowAttack */
/* @teleloc 0x90580023 [111.456001 64.027802 -0.045000] 0.394258 0.000000 0.000000 0.919000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x79058040, 5000864, 0x9058001B, 85.0875, 60.0066, -0.1, 0.750932, 0, 0, 0.66038, False, '2020-06-21 20:32:45'); /* ShadowAttack */
/* @teleloc 0x9058001B [85.087502 60.006599 -0.100000] 0.750932 0.000000 0.000000 0.660380 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x79058041, 5000866, 0x9058002C, 143.85966, 95.446495, 0.05499999, -0.830184, 0, 0, -0.5574895, False, '2020-06-21 20:33:07'); /* ShadowAttack */
/* @teleloc 0x9058002C [143.859665 95.446495 0.055000] -0.830184 0.000000 0.000000 -0.557490 */
