DELETE FROM `landblock_instance` WHERE `landblock` = 0xE522;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E522000, 24411, 0xE5220031, 163.9047, 23.53693, -0.045, -0.104097, 0, 0, -0.994567, False, '2025-08-16 18:21:01'); /* Asheron Invasion Extreme Generators */
/* @teleloc 0xE5220031 [163.904694 23.536930 -0.045000] -0.104097 0.000000 0.000000 -0.994567 */
