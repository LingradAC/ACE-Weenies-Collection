DELETE FROM `landblock_instance` WHERE `landblock` = 0x2170;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7217000F,  7197, 0x21700029, 132.282, 22.7276, 178, -0.011988, 0, 0, 0.999928, False, '2021-11-01 00:00:00'); /* Cooking pit */
/* @teleloc 0x21700029 [132.281998 22.727600 178.000000] -0.011988 0.000000 0.000000 0.999928 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x72170010,  7195, 0x21700029, 133.76, 22.7894, 177.988, 0.633789, 0, 0, 0.773506, False, '2021-11-01 00:00:00'); /* Cooking pot */
/* @teleloc 0x21700029 [133.759995 22.789400 177.988007] 0.633789 0.000000 0.000000 0.773506 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x72170011,   143, 0x21700103, 153.127, 11.2087, 177.7, 0.018713, 0, 0, -0.999825, False, '2021-11-01 00:00:00'); /* Chest */
/* @teleloc 0x21700103 [153.126999 11.208700 177.699997] 0.018713 0.000000 0.000000 -0.999825 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x72170012,   143, 0x21700103, 155.05, 11.3075, 177.7, 0.018713, 0, 0, -0.999825, False, '2021-11-01 00:00:00'); /* Chest */
/* @teleloc 0x21700103 [155.050003 11.307500 177.699997] 0.018713 0.000000 0.000000 -0.999825 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x72170013,   143, 0x21700103, 157.003, 11.3538, 177.7, 0.018713, 0, 0, -0.999825, False, '2021-11-01 00:00:00'); /* Chest */
/* @teleloc 0x21700103 [157.003006 11.353800 177.699997] 0.018713 0.000000 0.000000 -0.999825 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x72170014,   143, 0x21700103, 158.944, 11.3462, 177.7, 0.018713, 0, 0, -0.999825, False, '2021-11-01 00:00:00'); /* Chest */
/* @teleloc 0x21700103 [158.944000 11.346200 177.699997] 0.018713 0.000000 0.000000 -0.999825 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x72170015,  7923, 0x21700029, 141.978, 20.4317, 178, 0.930078, 0, 0, 0.367361, False, '2021-11-01 00:00:00'); /* Linkable Monster Generator ( 3 Min.) */
/* @teleloc 0x21700029 [141.977997 20.431700 178.000000] 0.930078 0.000000 0.000000 0.367361 */

INSERT INTO `landblock_instance_link` (`parent_GUID`, `child_GUID`, `last_Modified`)
VALUES (0x72170015, 0x72170016, '2021-11-01 00:00:00') /* Campfire (4128) */;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x72170016,  4128, 0x21700029, 141.978, 20.4317, 178, 0.930078, 0, 0, 0.367361,  True, '2021-11-01 00:00:00'); /* Campfire */
/* @teleloc 0x21700029 [141.977997 20.431700 178.000000] 0.930078 0.000000 0.000000 0.367361 */
