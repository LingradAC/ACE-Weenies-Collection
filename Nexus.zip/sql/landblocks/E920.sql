DELETE FROM `landblock_instance` WHERE `landblock` = 0xE920;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E920000, 24411, 0xE9200008, 0.692317, 184.427, 0.055, 0.766635, 0, 0, -0.642084, False, '2025-08-16 18:21:55'); /* Asheron Invasion Extreme Generators */
/* @teleloc 0xE9200008 [0.692317 184.427002 0.055000] 0.766635 0.000000 0.000000 -0.642084 */
