DELETE FROM `landblock_instance` WHERE `landblock` = 0xE4D6;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E4D6002,   412, 0xE4D6001C, 74.7557, 77.9303, 8.082, 0.872658, 0, 0, -0.488331, False, '2021-11-01 00:00:00'); /* Door */
/* @teleloc 0xE4D6001C [74.755699 77.930298 8.082000] 0.872658 0.000000 0.000000 -0.488331 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E4D6003,   412, 0xE4D6000B, 45.0363, 66.0838, 8.082, -0.692853, 0, 0, -0.721079, False, '2021-11-01 00:00:00'); /* Door */
/* @teleloc 0xE4D6000B [45.036301 66.083801 8.082000] -0.692853 0.000000 0.000000 -0.721079 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E4D6004,   412, 0xE4D6000B, 40.7439, 70.1908, 8.082, 0.019958, 0, 0, -0.999801, False, '2021-11-01 00:00:00'); /* Door */
/* @teleloc 0xE4D6000B [40.743900 70.190804 8.082000] 0.019958 0.000000 0.000000 -0.999801 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E4D6034, 93247113, 0xE4D60014, 56.146, 73.5691, 8.0065, -0.131188, 0, 0, -0.991358, False, '2025-07-18 22:04:17'); /* Eggburt */
/* @teleloc 0xE4D60014 [56.146000 73.569099 8.006500] -0.131188 0.000000 0.000000 -0.991358 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E4D6035, 38213982, 0xE4D6001B, 72.0675, 53.9252, 8.005, -0.652375, 0, 0, -0.757896, False, '2025-07-18 22:18:34'); /* George, The Thornbound Savage */
/* @teleloc 0xE4D6001B [72.067497 53.925201 8.005000] -0.652375 0.000000 0.000000 -0.757896 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E4D6036, 12382137, 0xE4D60028, 98.7947, 183.575, -0.395, 0.657407, 0, 0, 0.753536, False, '2025-07-19 07:05:14'); /* Mutated Tusker Generator */
/* @teleloc 0xE4D60028 [98.794701 183.574997 -0.395000] 0.657407 0.000000 0.000000 0.753536 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E4D6037, 4200152, 0xE4D60040, 190.068, 185.587, -0.845, -0.173907, 0, 0, -0.984762, False, '2025-07-19 10:27:41'); /* Gate */
/* @teleloc 0xE4D60040 [190.067993 185.587006 -0.845000] -0.173907 0.000000 0.000000 -0.984762 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E4D6038, 4200152, 0xE4D60040, 175.034, 191.434, -0.845, -0.117419, 0, 0, -0.993083, False, '2025-07-19 10:27:47'); /* Gate */
/* @teleloc 0xE4D60040 [175.033997 191.434006 -0.845000] -0.117419 0.000000 0.000000 -0.993083 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E4D6039, 423823913, 0xE4D6010F, 35.0355, 65.6042, 8.005, 0.717451, 0, 0, -0.696609, False, '2025-07-19 10:51:59'); /* Trevis the Ruiner */
/* @teleloc 0xE4D6010F [35.035500 65.604202 8.005000] 0.717451 0.000000 0.000000 -0.696609 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E4D603C, 38211628, 0xE4D6010A, 81.5247, 75.1708, 8.005, -0.961149, 0, 0, -0.27603, False, '2025-07-19 16:16:27'); /* Oathliege Hunter */
/* @teleloc 0xE4D6010A [81.524696 75.170799 8.005000] -0.961149 0.000000 0.000000 -0.276030 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E4D603F, 9871234, 0xE4D6010A, 80.0459, 74.3788, 8.005, -0.967862, 0, 0, -0.251484, False, '2025-07-19 19:02:20'); /* Snorebert */
/* @teleloc 0xE4D6010A [80.045898 74.378799 8.005000] -0.967862 0.000000 0.000000 -0.251484 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E4D6044, 38213823, 0xE4D60102, 69.7242, 69.835, 7.205, 0.277493, 0, 0, 0.960728, False, '2025-07-21 17:19:01'); /* Fatos The Lugian Slayer */
/* @teleloc 0xE4D60102 [69.724197 69.834999 7.205000] 0.277493 0.000000 0.000000 0.960728 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E4D6046, 38213898, 0xE4D60107, 73.9576, 55.7182, 7.205, -0.377322, 0, 0, 0.926082, False, '2025-07-22 01:42:46'); /* Hells the Hooded One Hunter */
/* @teleloc 0xE4D60107 [73.957603 55.718201 7.205000] -0.377322 0.000000 0.000000 0.926082 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E4D6048, 960230, 0xE4D6001C, 84.9332, 90.2033, 8.01, -0.973108, 0, 0, -0.230348, False, '2025-07-23 22:41:39'); /* Tammy The Tailor Vendor */
/* @teleloc 0xE4D6001C [84.933197 90.203300 8.010000] -0.973108 0.000000 0.000000 -0.230348 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E4D604A, 213788148, 0xE4D60116, 41.9387, 83.706, 7.205, -0.029481, 0, 0, -0.999565, False, '2025-07-29 18:50:02'); /* Bael'zharon's Acolyte */
/* @teleloc 0xE4D60116 [41.938702 83.706001 7.205000] -0.029481 0.000000 0.000000 -0.999565 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E4D604B, 38211629, 0xE4D6000B, 45.4184, 68.0222, 8.005, 0.762471, 0, 0, -0.647023, False, '2025-07-29 18:57:23'); /* Vermino */
/* @teleloc 0xE4D6000B [45.418400 68.022202 8.005000] 0.762471 0.000000 0.000000 -0.647023 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E4D604C,  5772, 0xE4D60012, 51.006, 46.2596, 7.85997, -0.987607, 0, 0, 0.156947, False, '2025-07-30 01:07:11'); /* Town Crier */
/* @teleloc 0xE4D60012 [51.006001 46.259602 7.859970] -0.987607 0.000000 0.000000 0.156947 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E4D604D, 63212983, 0xE4D60012, 67.5795, 30.4057, 6.47081, -0.429026, 0, 0, 0.903292, False, '2025-07-30 05:26:58'); /* Simiran Portal */
/* @teleloc 0xE4D60012 [67.579498 30.405701 6.470810] -0.429026 0.000000 0.000000 0.903292 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E4D604F, 91332772, 0xE4D60012, 55.933, 26.0177, 6.10514, 0.999222, 0, 0, 0.03945, False, '2025-08-06 00:25:59'); /* Calfadar Village Portal */
/* @teleloc 0xE4D60012 [55.932999 26.017700 6.105140] 0.999222 0.000000 0.000000 0.039450 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E4D6050, 999977, 0xE4D6000B, 45.5764, 63.9804, 8.005, -0.686435, 0, 0, 0.727192, False, '2025-08-06 00:33:23'); /* Wraith Hunter */
/* @teleloc 0xE4D6000B [45.576401 63.980400 8.005000] -0.686435 0.000000 0.000000 0.727192 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E4D6053, 8953268, 0xE4D60014, 63.287, 93.6295, 7.937, -0.997833, 0, 0, 0.065804, False, '2025-08-19 07:56:39'); /* Wraith Dungeon */
/* @teleloc 0xE4D60014 [63.286999 93.629501 7.937000] -0.997833 0.000000 0.000000 0.065804 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E4D6054, 42852, 0xE4D60012, 49.271, 27.5738, 6.23482, 0.027259, 0, 0, 0.999628, False, '2025-08-19 16:24:53'); /* Portal to Town Network */
/* @teleloc 0xE4D60012 [49.271000 27.573799 6.234820] 0.027259 0.000000 0.000000 0.999628 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E4D6055, 92731237, 0xE4D6010A, 83.41031, 76.32516, 8.005, -0.904933, 0, 0, -0.425554, False, '2025-08-26 15:38:59'); /* Born The Tail Hunter */
/* @teleloc 0xE4D6010A [83.410309 76.325157 8.005000] -0.904933 0.000000 0.000000 -0.425554 */
