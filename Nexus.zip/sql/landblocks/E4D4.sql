DELETE FROM `landblock_instance` WHERE `landblock` = 0xE4D4;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E4D4000, 12382138, 0xE4D4001B, 77.2627, 56.3297, -0.395, 0.041997, 0, 0, 0.999118, False, '2025-07-19 09:57:35'); /* Picker Golem Generator */
/* @teleloc 0xE4D4001B [77.262703 56.329700 -0.395000] 0.041997 0.000000 0.000000 0.999118 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E4D4001, 91737171, 0xE4D40017, 70.6002, 167.883, -0.395, 0.060377, 0, 0, -0.998176, False, '2025-07-27 14:43:10'); /* cultistsoldiergen */
/* @teleloc 0xE4D40017 [70.600197 167.882996 -0.395000] 0.060377 0.000000 0.000000 -0.998176 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E4D4002, 12310925, 0xE4D4003B, 181.7359, 56.45864, -0.845, 0.186308, 0, 0, -0.982492, False, '2025-07-27 19:57:09'); /* RavagedDrudgegener */
/* @teleloc 0xE4D4003B [181.735901 56.458641 -0.845000] 0.186308 0.000000 0.000000 -0.982492 */
