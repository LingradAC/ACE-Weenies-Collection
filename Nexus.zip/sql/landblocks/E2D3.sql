DELETE FROM `landblock_instance` WHERE `landblock` = 0xE2D3;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E2D3000, 213788146, 0xE2D30025, 112.768, 102.7715, -0.845, -0.366899, 0, 0, -0.930261, False, '2025-07-20 14:07:15');
/* @teleloc 0xE2D30025 [112.767998 102.771500 -0.845000] -0.366899 0.000000 0.000000 -0.930261 */
