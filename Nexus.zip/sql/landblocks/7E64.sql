DELETE FROM `landblock_instance` WHERE `landblock` = 0x7E64;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x77E64000,   794, 0x7E640000, 16.8134, 2.98519, 17.0177, -0.967679, 0, 0, 0.252184, False, '2022-04-12 04:33:53'); /* Apple Generator */
/* @teleloc 0x7E640000 [16.813400 2.985190 17.017700] -0.967679 0.000000 0.000000 0.252184 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x77E64001,  1110, 0x7E640000, 50.5739, 98.7056, 13.7855, 0.92388, 0, 0, -0.382683, False, '2022-04-12 04:33:53'); /* Yaraq */
/* @teleloc 0x7E640000 [50.573898 98.705597 13.785500] 0.923880 0.000000 0.000000 -0.382683 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x77E64002, 29503, 0x7E640119, 108.3312, 107.9985, 11.937, -0.71647, 0, 0, -0.697618, False, '2025-07-22 10:46:02'); /* Nexus Gambling Den */
/* @teleloc 0x7E640119 [108.331200 107.998497 11.937000] -0.716470 0.000000 0.000000 -0.697618 */
