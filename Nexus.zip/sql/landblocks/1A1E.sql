DELETE FROM `landblock_instance` WHERE `landblock` = 0x1A1E;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x71A1E012,  3988, 0x1A1E002A, 128.889, 32.6846, 30, -0.801729, 0, 0, -0.597688, False, '2021-11-08 06:01:47'); /* Chest */
/* @teleloc 0x1A1E002A [128.889008 32.684601 30.000000] -0.801729 0.000000 0.000000 -0.597688 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x71A1E013,  7924, 0x1A1E0014, 52.9161, 86.4962, 0.417927, 0.11437, 0, 0, -0.993438, False, '2021-11-08 06:01:47'); /* Linkable Monster Generator ( 5 Min.) */
/* @teleloc 0x1A1E0014 [52.916100 86.496201 0.417927] 0.114370 0.000000 0.000000 -0.993438 */
