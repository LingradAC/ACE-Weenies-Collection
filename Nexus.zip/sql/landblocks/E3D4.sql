DELETE FROM `landblock_instance` WHERE `landblock` = 0xE3D4;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E3D4000, 213788146, 0xE3D4002F, 133.054, 167.583, 6.055, -0.118656, 0, 0, -0.992936, False, '2025-07-20 14:06:50'); /* bzmobgen */
/* @teleloc 0xE3D4002F [133.054001 167.582993 6.055000] -0.118656 0.000000 0.000000 -0.992936 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E3D4001, 700255, 0xE3D40012, 66.4906, 35.6374, 3.54433, -0.348118, 0, 0, -0.937451, False, '2025-07-29 16:47:49'); /* OathliegeGen */
/* @teleloc 0xE3D40012 [66.490601 35.637402 3.544330] -0.348118 0.000000 0.000000 -0.937451 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E3D4002, 700255, 0xE3D4001A, 91.0025, 31.4508, 3.4341, 0.744716, 0, 0, -0.667382, False, '2025-07-29 16:47:53'); /* OathliegeGen */
/* @teleloc 0xE3D4001A [91.002502 31.450800 3.434100] 0.744716 0.000000 0.000000 -0.667382 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E3D4003, 700255, 0xE3D4002B, 133.458, 56.1305, 6.0549, 0.954647, 0, 0, -0.297739, False, '2025-07-29 16:47:57'); /* OathliegeGen */
/* @teleloc 0xE3D4002B [133.457993 56.130501 6.054900] 0.954647 0.000000 0.000000 -0.297739 */
