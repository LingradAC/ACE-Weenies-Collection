DELETE FROM `landblock_instance` WHERE `landblock` = 0xE625;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E625000, 24411, 0xE6250039, 184.404, 0.139404, -0.045, 0.958276, 0, 0, 0.285846, False, '2025-08-14 11:19:57'); /* Asheron Invasion Extreme Generators */
/* @teleloc 0xE6250039 [184.404007 0.139404 -0.045000] 0.958276 0.000000 0.000000 0.285846 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E625001, 24411, 0xE6250029, 139.495, 21.5404, 0.055, 0.755801, 0, 0, 0.654801, False, '2025-08-14 11:20:01'); /* Asheron Invasion Extreme Generators */
/* @teleloc 0xE6250029 [139.494995 21.540400 0.055000] 0.755801 0.000000 0.000000 0.654801 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E625002, 24411, 0xE6250019, 77.6311, 23.8713, 0.055, 0.707677, 0, 0, 0.706536, False, '2025-08-14 11:20:04'); /* Asheron Invasion Extreme Generators */
/* @teleloc 0xE6250019 [77.631104 23.871300 0.055000] 0.707677 0.000000 0.000000 0.706536 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E625003, 24411, 0xE6250001, 8.569361, 22.87828, 0.055, 0.680691, 0, 0, 0.732571, False, '2025-08-14 11:20:09'); /* Asheron Invasion Extreme Generators */
/* @teleloc 0xE6250001 [8.569361 22.878281 0.055000] 0.680691 0.000000 0.000000 0.732571 */
