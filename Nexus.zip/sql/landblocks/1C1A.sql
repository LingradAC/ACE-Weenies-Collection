DELETE FROM `landblock_instance` WHERE `landblock` = 0x1C1A;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x71C1A002,  3994, 0x1C1A000D, 40.5013, 106.571, 22, -0.797423, 0, 0, 0.60342, False, '2021-11-08 06:01:47'); /* Chest */
/* @teleloc 0x1C1A000D [40.501301 106.570999 22.000000] -0.797423 0.000000 0.000000 0.603420 */
