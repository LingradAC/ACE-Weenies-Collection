DELETE FROM `landblock_instance` WHERE `landblock` = 0xF663;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F663002, 490118, 0xF6630018, 59.5024, 189.403, 0.958532, 0.382684, 0, 0, 0.92388, False, '2023-12-31 09:40:23'); /* Outpost Large Tree2 */
/* @teleloc 0xF6630018 [59.502399 189.403000 0.958532] 0.382684 0.000000 0.000000 0.923880 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F663003, 490118, 0xF6630030, 135.603, 172.662, 5.7783, 0.285305, 0, 0, -0.958437, False, '2023-12-31 09:40:27'); /* Outpost Large Tree2 */
/* @teleloc 0xF6630030 [135.602997 172.662003 5.778300] 0.285305 0.000000 0.000000 -0.958437 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F663004, 490118, 0xF663003D, 169.478, 106.706, 3.78619, 0.484392, 0, 0, -0.874851, False, '2023-12-31 09:40:32'); /* Outpost Large Tree2 */
/* @teleloc 0xF663003D [169.477997 106.706001 3.786190] 0.484392 0.000000 0.000000 -0.874851 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F663005, 490118, 0xF663002A, 143.959, 35.696, 13.1207, -0.081257, 0, 0, -0.996693, False, '2023-12-31 09:40:37'); /* Outpost Large Tree2 */
/* @teleloc 0xF663002A [143.959000 35.695999 13.120700] -0.081257 0.000000 0.000000 -0.996693 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F663006, 490118, 0xF6630021, 112.289, 14.5594, 11.9167, -0.782789, 0, 0, -0.622287, False, '2023-12-31 09:40:41'); /* Outpost Large Tree2 */
/* @teleloc 0xF6630021 [112.289001 14.559400 11.916700] -0.782789 0.000000 0.000000 -0.622287 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F663007, 490118, 0xF6630011, 67.0785, 23.0504, 5.72401, -0.506695, 0, 0, -0.862125, False, '2023-12-31 09:40:44'); /* Outpost Large Tree2 */
/* @teleloc 0xF6630011 [67.078499 23.050400 5.724010] -0.506695 0.000000 0.000000 -0.862125 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F663008, 490161, 0xF6630014, 53.2577, 88.3022, 0.438139, 0.971139, 0, 0, -0.238514, False, '2024-01-06 11:16:48'); /* Hay Stack */
/* @teleloc 0xF6630014 [53.257702 88.302200 0.438139] 0.971139 0.000000 0.000000 -0.238514 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F663009, 490161, 0xF6630014, 50.3376, 90.0618, 0.194802, 0.039098, 0, 0, -0.999235, False, '2024-01-06 11:16:51'); /* Hay Stack */
/* @teleloc 0xF6630014 [50.337601 90.061798 0.194802] 0.039098 0.000000 0.000000 -0.999235 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F66300B, 490161, 0xF6630014, 50.4334, 86.6781, 0.202784, -0.894588, 0, 0, -0.446891, False, '2024-01-06 11:16:55'); /* Hay Stack */
/* @teleloc 0xF6630014 [50.433399 86.678101 0.202784] -0.894588 0.000000 0.000000 -0.446891 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F66300C, 490161, 0xF6630006, 19.1623, 123.485, -0.1, -0.932719, 0, 0, 0.360604, False, '2024-01-06 11:17:03'); /* Hay Stack */
/* @teleloc 0xF6630006 [19.162300 123.485001 -0.100000] -0.932719 0.000000 0.000000 0.360604 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F66302D, 490161, 0xF663000F, 38.6806, 146.495, -0.1, -0.841667, 0, 0, -0.539998, False, '2024-01-06 12:18:10'); /* Hay Stack */
/* @teleloc 0xF663000F [38.680599 146.494995 -0.100000] -0.841667 0.000000 0.000000 -0.539998 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F66302E, 490161, 0xF663000F, 35.7754, 145.824, -0.1, -0.695844, 0, 0, -0.718193, False, '2024-01-06 12:18:13'); /* Hay Stack */
/* @teleloc 0xF663000F [35.775398 145.824005 -0.100000] -0.695844 0.000000 0.000000 -0.718193 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F663030, 490161, 0xF663001D, 95.3889, 111.111, 0, -0.002321, 0, 0, 0.999997, False, '2024-01-06 12:18:22'); /* Hay Stack */
/* @teleloc 0xF663001D [95.388901 111.111000 0.000000] -0.002321 0.000000 0.000000 0.999997 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F663031, 490161, 0xF663001D, 93.4328, 108.791, 0, 0.031504, 0, 0, 0.999504, False, '2024-01-06 12:18:27'); /* Hay Stack */
/* @teleloc 0xF663001D [93.432800 108.791000 0.000000] 0.031504 0.000000 0.000000 0.999504 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F663033, 490144, 0xF6630006, 22.8552, 128.064, -0.1, -0.553273, 0, 0, 0.833, False, '2024-01-06 12:19:30'); /* Outpost Fish */
/* @teleloc 0xF6630006 [22.855200 128.063995 -0.100000] -0.553273 0.000000 0.000000 0.833000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F663034, 490144, 0xF663000E, 27.5032, 136.059, 0, -0.553273, 0, 0, 0.833, False, '2024-01-06 12:19:31'); /* Outpost Fish */
/* @teleloc 0xF663000E [27.503201 136.059006 0.000000] -0.553273 0.000000 0.000000 0.833000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F663036, 490097, 0xF6630005, 23.2668, 101.653, -0.1, -0.609271, 0, 0, -0.792962, False, '2024-01-06 12:20:48'); /* Gate */
/* @teleloc 0xF6630005 [23.266800 101.653000 -0.100000] -0.609271 0.000000 0.000000 -0.792962 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F663037, 490097, 0xF6630015, 55.8796, 101.766, 0, -0.708201, 0, 0, 0.706011, False, '2024-01-06 12:20:53'); /* Gate */
/* @teleloc 0xF6630015 [55.879601 101.765999 0.000000] -0.708201 0.000000 0.000000 0.706011 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F663039, 490161, 0xF663001F, 80.6648, 163.509, 0, -0.072727, 0, 0, -0.997352, False, '2024-01-06 12:22:41'); /* Hay Stack */
/* @teleloc 0xF663001F [80.664803 163.509003 0.000000] -0.072727 0.000000 0.000000 -0.997352 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F66303A, 490161, 0xF6630004, 18.2291, 90.746, 0.437833, 0.67377, 0, 0, 0.738941, False, '2024-01-06 12:23:29'); /* Hay Stack */
/* @teleloc 0xF6630004 [18.229099 90.746002 0.437833] 0.673770 0.000000 0.000000 0.738941 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F66303B, 490161, 0xF6630004, 13.9662, 92.681, 0.276581, -0.455373, 0, 0, -0.890301, False, '2024-01-06 12:23:31'); /* Hay Stack */
/* @teleloc 0xF6630004 [13.966200 92.681000 0.276581] -0.455373 0.000000 0.000000 -0.890301 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F66303C, 490161, 0xF6630005, 14.9227, 115.19, -0.1, -0.984841, 0, 0, -0.173461, False, '2024-01-06 12:23:38'); /* Hay Stack */
/* @teleloc 0xF6630005 [14.922700 115.190002 -0.100000] -0.984841 0.000000 0.000000 -0.173461 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F66303D, 490161, 0xF663000C, 42.4994, 85.6726, 0.458383, -0.052342, 0, 0, 0.998629, False, '2024-01-06 12:23:46'); /* Hay Stack */
/* @teleloc 0xF663000C [42.499401 85.672600 0.458383] -0.052342 0.000000 0.000000 0.998629 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F663045, 490117, 0xF6630039, 191.608, 12.4171, 26.955, -0.55731, 0, 0, -0.830305, False, '2024-01-06 15:00:22'); /* Outpost Large Tree */
/* @teleloc 0xF6630039 [191.608002 12.417100 26.955000] -0.557310 0.000000 0.000000 -0.830305 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F663046, 490117, 0xF6630024, 104.78, 82.5498, 1.17585, -0.907093, 0, 0, -0.420931, False, '2024-01-06 15:00:31'); /* Outpost Large Tree */
/* @teleloc 0xF6630024 [104.779999 82.549797 1.175850] -0.907093 0.000000 0.000000 -0.420931 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F663047, 490117, 0xF663000B, 30.7537, 63.8726, 1.49219, -0.73831, 0, 0, -0.674461, False, '2024-01-06 15:00:36'); /* Outpost Large Tree */
/* @teleloc 0xF663000B [30.753700 63.872601 1.492190] -0.738310 0.000000 0.000000 -0.674461 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F66304A, 80007, 0xF663001C, 74.0141, 88.8267, 0.652778, -0.864711, 0, 0, 0.502269, False, '2024-01-14 13:24:17'); /* Landblock KeepAlive */
/* @teleloc 0xF663001C [74.014099 88.826698 0.652778] -0.864711 0.000000 0.000000 0.502269 */
