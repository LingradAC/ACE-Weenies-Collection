DELETE FROM `landblock_instance` WHERE `landblock` = 0xF1D8;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F1D8002, 5000767, 0xF1D8002E, 129.477, 136.321, 0.055, 0.340177, 0, 0, -0.940362, False, '2020-05-07 18:49:57'); /* Wasp gen */
/* @teleloc 0xF1D8002E [129.477005 136.320999 0.055000] 0.340177 0.000000 0.000000 -0.940362 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F1D8003, 5000764, 0xF1D80025, 119.96, 108.433, 0.055, -0.178375, 0, 0, -0.983963, False, '2020-05-07 18:50:00'); /* Melee Skellie gen */
/* @teleloc 0xF1D80025 [119.959999 108.432999 0.055000] -0.178375 0.000000 0.000000 -0.983963 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F1D8009, 5000766, 0xF1D8000A, 32.6564, 24.1322, 0.055, 0.843364, 0, 0, 0.537342, False, '2020-05-07 19:31:17'); /* Shreth gen */
/* @teleloc 0xF1D8000A [32.656399 24.132200 0.055000] 0.843364 0.000000 0.000000 0.537342 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F1D800A, 5000662, 0xF1D80001, 2.42966, 23.8157, 0.055, -0.200585, 0, 0, 0.979676, False, '2020-01-13 01:39:45'); /* Plant */
/* @teleloc 0xF1D80001 [2.429660 23.815701 0.055000] -0.200585 0.000000 0.000000 0.979676 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F1D800B, 5000662, 0xF1D80001, 10.6733, 7.62553, 0.055, 0.100753, 0, 0, 0.994911, False, '2020-01-13 01:39:47'); /* Plant */
/* @teleloc 0xF1D80001 [10.673300 7.625530 0.055000] 0.100753 0.000000 0.000000 0.994911 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F1D800C, 5000662, 0xF1D80001, 10.1323, 12.0129, 0.055, 0.940261, 0, 0, -0.340456, False, '2020-01-13 01:39:51'); /* Plant */
/* @teleloc 0xF1D80001 [10.132300 12.012900 0.055000] 0.940261 0.000000 0.000000 -0.340456 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F1D800D, 5000294, 0xF1D80009, 30.649, 10.2935, 0.055, -0.508381, 0, 0, -0.861132, False, '2020-01-13 01:39:53'); /* Plant */
/* @teleloc 0xF1D80009 [30.649000 10.293500 0.055000] -0.508381 0.000000 0.000000 -0.861132 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F1D800E, 5000295, 0xF1D80001, 23.5568, 7.2132, 0.055, -0.700149, 0, 0, -0.713997, False, '2020-01-13 01:39:53'); /* Plant */
/* @teleloc 0xF1D80001 [23.556801 7.213200 0.055000] -0.700149 0.000000 0.000000 -0.713997 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F1D800F, 5000295, 0xF1D80001, 7.93236, 17.535, 0.055, -0.829117, 0, 0, -0.559076, False, '2020-01-13 01:39:55'); /* Plant */
/* @teleloc 0xF1D80001 [7.932360 17.535000 0.055000] -0.829117 0.000000 0.000000 -0.559076 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F1D8010, 5000294, 0xF1D80001, 6.48273, 0.390396, 0.055, -0.977103, 0, 0, 0.212768, False, '2020-01-13 01:40:00'); /* Plant */
/* @teleloc 0xF1D80001 [6.482730 0.390396 0.055000] -0.977103 0.000000 0.000000 0.212768 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F1D8011, 5000661, 0xF1D80001, 14.543, 23.0677, 0.055, -0.843099, 0, 0, 0.537758, False, '2020-01-13 01:40:06'); /* Plant */
/* @teleloc 0xF1D80001 [14.543000 23.067699 0.055000] -0.843099 0.000000 0.000000 0.537758 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F1D8012, 5000662, 0xF1D80001, 19.3253, 17.525, 0.055, 0.758671, 0, 0, 0.651474, False, '2020-01-13 01:40:11'); /* Plant */
/* @teleloc 0xF1D80001 [19.325300 17.525000 0.055000] 0.758671 0.000000 0.000000 0.651474 */
