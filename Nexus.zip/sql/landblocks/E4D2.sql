DELETE FROM `landblock_instance` WHERE `landblock` = 0xE4D2;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E4D2000, 4200152, 0xE4D20039, 187.049, 13.9115, -0.045, -0.643238, 0, 0, 0.765666, False, '2025-07-19 10:31:38'); /* Gate */
/* @teleloc 0xE4D20039 [187.048996 13.911500 -0.045000] -0.643238 0.000000 0.000000 0.765666 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E4D2001, 213788146, 0xE4D20001, 16.0453, 6.8985, -0.395, 0.570414, 0, 0, -0.821358, False, '2025-07-20 14:07:47'); /* bzmobgen */
/* @teleloc 0xE4D20001 [16.045300 6.898500 -0.395000] 0.570414 0.000000 0.000000 -0.821358 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E4D2002, 91737171, 0xE4D20006, 0.94268, 131.769, -0.045, 0.325451, 0, 0, -0.945559, False, '2025-07-27 14:43:54'); /* cultistsoldiergen */
/* @teleloc 0xE4D20006 [0.942680 131.768997 -0.045000] 0.325451 0.000000 0.000000 -0.945559 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E4D2003, 700043, 0xE4D20021, 105.3095, 0.121918, -0.845, 0.975383, 0, 0, 0.220516, False, '2025-08-24 14:42:06'); /* BiglugianGen */
/* @teleloc 0xE4D20021 [105.309502 0.121918 -0.845000] 0.975383 0.000000 0.000000 0.220516 */
