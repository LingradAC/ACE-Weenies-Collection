DELETE FROM `landblock_instance` WHERE `landblock` = 0x4690;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x74690000, 999962, 0x4690000A, 42.87701, 28.91175, 563.8796, 0.943586, 0, 0, -0.331129, False, '2025-07-07 03:48:40');
/* @teleloc 0x4690000A [42.877010 28.911751 563.879578] 0.943586 0.000000 0.000000 -0.331129 */
