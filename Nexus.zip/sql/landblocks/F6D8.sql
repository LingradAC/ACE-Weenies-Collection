DELETE FROM `landblock_instance` WHERE `landblock` = 0xF6D8;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F6D8000, 5000767, 0xF6D8003E, 189.043, 120.059, 0.055, -0.955175, 0, 0, -0.296041, False, '2020-05-07 19:10:30'); /* Wasp gen */
/* @teleloc 0xF6D8003E [189.042999 120.058998 0.055000] -0.955175 0.000000 0.000000 -0.296041 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F6D8001, 5000765, 0xF6D80007, 4.25043, 167.714, 0.055, 0.338294, 0, 0, -0.94104, False, '2020-05-07 19:11:28'); /* Mage Skellie gen */
/* @teleloc 0xF6D80007 [4.250430 167.714005 0.055000] 0.338294 0.000000 0.000000 -0.941040 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F6D8002, 5000767, 0xF6D80016, 48.3247, 138.626, 0.055, 0.619554, 0, 0, -0.784954, False, '2020-05-07 19:11:31'); /* Wasp gen */
/* @teleloc 0xF6D80016 [48.324699 138.626007 0.055000] 0.619554 0.000000 0.000000 -0.784954 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F6D8003, 5000764, 0xF6D80014, 56.0587, 81.9358, 0.055, -0.306139, 0, 0, -0.951987, False, '2020-05-07 19:11:36'); /* Melee Skellie gen */
/* @teleloc 0xF6D80014 [56.058701 81.935799 0.055000] -0.306139 0.000000 0.000000 -0.951987 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F6D8005, 5000766, 0xF6D80001, 14.3065, 4.50029, 0.055, 0.617471, 0, 0, 0.786593, False, '2020-05-07 19:29:27'); /* Shreth gen */
/* @teleloc 0xF6D80001 [14.306500 4.500290 0.055000] 0.617471 0.000000 0.000000 0.786593 */
