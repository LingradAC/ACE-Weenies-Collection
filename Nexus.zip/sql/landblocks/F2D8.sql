DELETE FROM `landblock_instance` WHERE `landblock` = 0xF2D8;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F2D8002, 5000764, 0xF2D8000E, 38.5364, 124.303, 0.055, -0.99776, 0, 0, -0.066892, False, '2020-05-07 18:51:45'); /* Melee Skellie gen */
/* @teleloc 0xF2D8000E [38.536400 124.303001 0.055000] -0.997760 0.000000 0.000000 -0.066892 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F2D8003, 5000766, 0xF2D8000F, 42.204, 153.196, 0.055, -0.01585, 0, 0, -0.999874, False, '2020-05-07 19:22:41'); /* Shreth gen */
/* @teleloc 0xF2D8000F [42.203999 153.195999 0.055000] -0.015850 0.000000 0.000000 -0.999874 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F2D8004, 5000661, 0xF2D80029, 143.885, 13.8152, 0.055, 0.953561, 0, 0, 0.301199, False, '2020-01-13 01:42:17'); /* Plant */
/* @teleloc 0xF2D80029 [143.884995 13.815200 0.055000] 0.953561 0.000000 0.000000 0.301199 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F2D8005, 5000296, 0xF2D8002A, 133.439, 38.1846, 0.055, 0.98959, 0, 0, 0.143913, False, '2020-01-13 01:42:19'); /* Plant */
/* @teleloc 0xF2D8002A [133.438995 38.184601 0.055000] 0.989590 0.000000 0.000000 0.143913 */
