DELETE FROM `landblock_instance` WHERE `landblock` = 0x114E;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7114E000, 86653111, 0x114E0001, 10.4123, 11.4416, 85.05, 0.265945, 0, 0, -0.963988, False, '2025-07-19 00:02:29'); /* WOOD111 */
/* @teleloc 0x114E0001 [10.412300 11.441600 85.050003] 0.265945 0.000000 0.000000 -0.963988 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7114E001, 86653111, 0x114E0001, 0.166407, 22.0432, 85.505, -0.888156, 0, 0, -0.459543, False, '2025-07-19 00:02:38'); /* WOOD111 */
/* @teleloc 0x114E0001 [0.166407 22.043200 85.504997] -0.888156 0.000000 0.000000 -0.459543 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7114E002, 86653111, 0x114E0004, 22.1392, 87.2863, 88.8922, -0.41166, 0, 0, -0.911338, False, '2025-07-19 00:06:39'); /* WOOD111 */
/* @teleloc 0x114E0004 [22.139200 87.286301 88.892197] -0.411660 0.000000 0.000000 -0.911338 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7114E003, 86653111, 0x114E000D, 39.0062, 105.668, 90.9009, -0.342068, 0, 0, -0.939675, False, '2025-07-19 00:08:01'); /* WOOD111 */
/* @teleloc 0x114E000D [39.006199 105.667999 90.900902] -0.342068 0.000000 0.000000 -0.939675 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7114E004, 86653122, 0x114E0016, 65.671, 132.429, 91.3559, 0.916431, 0, 0, -0.400193, False, '2025-07-19 00:08:33'); /* 1platform */
/* @teleloc 0x114E0016 [65.670998 132.429001 91.355904] 0.916431 0.000000 0.000000 -0.400193 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7114E005, 86653111, 0x114E0016, 60.1284, 125.631, 90.2353, -0.904957, 0, 0, -0.425502, False, '2025-07-19 00:11:49'); /* WOOD111 */
/* @teleloc 0x114E0016 [60.128399 125.630997 90.235298] -0.904957 0.000000 0.000000 -0.425502 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7114E006, 86653111, 0x114E0004, 9.08451, 74.3361, 88.7338, 0.925342, 0, 0, -0.379133, False, '2025-07-22 18:44:28'); /* WOOD111 */
/* @teleloc 0x114E0004 [9.084510 74.336098 88.733803] 0.925342 0.000000 0.000000 -0.379133 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7114E007, 86653111, 0x114E0015, 51.7166, 117.082, 90.6913, -0.366665, 0, 0, -0.930353, False, '2025-07-22 18:49:01'); /* WOOD111 */
/* @teleloc 0x114E0015 [51.716599 117.082001 90.691299] -0.366665 0.000000 0.000000 -0.930353 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7114E008, 38213691, 0x114E0016, 68.3487, 136.734, 91.4464, 0.382684, 0, 0, 0.92388, False, '2025-07-22 19:04:17'); /* Slipz McFallin */
/* @teleloc 0x114E0016 [68.348701 136.733994 91.446404] 0.382684 0.000000 0.000000 0.923880 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7114E009, 5167232, 0x114E0001, 0.521241, 0.434563, -0.513, 0.995487, 0, 0, 0.094901, False, '2025-07-28 14:01:58'); /* Parkour Challenge */
/* @teleloc 0x114E0001 [0.521241 0.434563 -0.513000] 0.995487 0.000000 0.000000 0.094901 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7114E00A, 5167232, 0x114E0004, 10.1262, 82.4392, -0.963, 0.921201, 0, 0, -0.389088, False, '2025-07-28 14:02:06'); /* Parkour Challenge */
/* @teleloc 0x114E0004 [10.126200 82.439201 -0.963000] 0.921201 0.000000 0.000000 -0.389088 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7114E00B, 5167232, 0x114E0004, 23.9966, 95.9298, -0.963, 0.921201, 0, 0, -0.389088, False, '2025-07-28 14:02:07'); /* Parkour Challenge */
/* @teleloc 0x114E0004 [23.996599 95.929802 -0.963000] 0.921201 0.000000 0.000000 -0.389088 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7114E00C, 5167232, 0x114E000D, 40.1355, 111.627, -0.963, 0.921201, 0, 0, -0.389088, False, '2025-07-28 14:02:10'); /* Parkour Challenge */
/* @teleloc 0x114E000D [40.135502 111.626999 -0.963000] 0.921201 0.000000 0.000000 -0.389088 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7114E00D, 5167232, 0x114E0015, 48.00896, 119.2845, -0.963, 0.921201, 0, 0, -0.389088, False, '2025-07-28 14:02:11'); /* Parkour Challenge */
/* @teleloc 0x114E0015 [48.008961 119.284500 -0.963000] 0.921201 0.000000 0.000000 -0.389088 */
