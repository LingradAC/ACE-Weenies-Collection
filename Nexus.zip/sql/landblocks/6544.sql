DELETE FROM `landblock_instance` WHERE `landblock` = 0x6544;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x76544001, 27306, 0x6544013A, 76.9662, -53.0111, 6.005, -0.923874, 0, 0, 0.382696,  True, '2005-02-09 10:00:00'); /* Guardian of the Forbidden */
/* @teleloc 0x6544013A [76.966202 -53.011101 6.005000] -0.923874 0.000000 0.000000 0.382696 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x76544002,  7923, 0x6544013A, 79.5754, -53.2568, 6.005, 0.731705, 0, 0, 0.681622, False, '2005-02-09 10:00:00'); /* Linkable Monster Generator ( 3 Min.) */
/* @teleloc 0x6544013A [79.575401 -53.256802 6.005000] 0.731705 0.000000 0.000000 0.681622 */

INSERT INTO `landblock_instance_link` (`parent_GUID`, `child_GUID`, `last_Modified`)
VALUES (0x76544002, 0x76544001, '2005-02-09 10:00:00') /* Guardian of the Forbidden (27306) */;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x76544006, 312831, 0x6544010E, 62.9382, -66.9758, 0.005, -0.999952, 0, 0, -0.009799, False, '2025-08-19 08:57:31'); /* The Pit Boss */
/* @teleloc 0x6544010E [62.938202 -66.975800 0.005000] -0.999952 0.000000 0.000000 -0.009799 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x76544007, 86659155, 0x6544010E, 61.0416, -67.6228, 0.0066, 0.999652, 0, 0, 0.026394, False, '2025-08-19 08:57:54'); /* Vorr the House Rat */
/* @teleloc 0x6544010E [61.041599 -67.622803 0.006600] 0.999652 0.000000 0.000000 0.026394 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x76544008, 34892348, 0x6544010E, 64.68451, -67.43027, 0.0066, 0.999652, 0, 0, 0.026394, False, '2025-08-19 08:58:05'); /* Adonis The Defiler */
/* @teleloc 0x6544010E [64.684509 -67.430267 0.006600] 0.999652 0.000000 0.000000 0.026394 */
