DELETE FROM `landblock_instance` WHERE `landblock` = 0x002B;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7002B000,  7932, 0x002B0371, 459.309, -170.694, 0.005, 0.333, 0, 0, 0.942927, False, '2021-11-01 00:00:00'); /* Linkable Monster Generator ( 4 Min.) */
/* @teleloc 0x002B0371 [459.308990 -170.694000 0.005000] 0.333000 0.000000 0.000000 0.942927 */

INSERT INTO `landblock_instance_link` (`parent_GUID`, `child_GUID`, `last_Modified`)
VALUES (0x7002B000, 0x7002B004, '2021-11-01 00:00:00') /* Olthoi Slasher (31007) */
     , (0x7002B000, 0x7002B005, '2021-11-01 00:00:00') /* Olthoi Slasher (31007) */
     , (0x7002B000, 0x7002B006, '2021-11-01 00:00:00') /* Olthoi Slasher (31007) */
     , (0x7002B000, 0x7002B007, '2021-11-01 00:00:00') /* Olthoi Slasher (31007) */
     , (0x7002B000, 0x7002B008, '2021-11-01 00:00:00') /* Olthoi Slasher (31007) */
     , (0x7002B000, 0x7002B009, '2021-11-01 00:00:00') /* Olthoi Slasher (31007) */
     , (0x7002B000, 0x7002B00A, '2021-11-01 00:00:00') /* Olthoi Slasher (31007) */
     , (0x7002B000, 0x7002B00B, '2021-11-01 00:00:00') /* Olthoi Slasher (31007) */
     , (0x7002B000, 0x7002B00C, '2021-11-01 00:00:00') /* Olthoi Slasher (31007) */
     , (0x7002B000, 0x7002B00D, '2021-11-01 00:00:00') /* Olthoi Slasher (31007) */
     , (0x7002B000, 0x7002B00E, '2021-11-01 00:00:00') /* Olthoi Slasher (31007) */
     , (0x7002B000, 0x7002B00F, '2021-11-01 00:00:00') /* Olthoi Slasher (31007) */
     , (0x7002B000, 0x7002B010, '2021-11-01 00:00:00') /* Olthoi Slasher (31007) */
     , (0x7002B000, 0x7002B011, '2021-11-01 00:00:00') /* Olthoi Slasher (31007) */
     , (0x7002B000, 0x7002B012, '2021-11-01 00:00:00') /* Olthoi Slasher (31007) */
     , (0x7002B000, 0x7002B013, '2021-11-01 00:00:00') /* Olthoi Slasher (31007) */
     , (0x7002B000, 0x7002B014, '2021-11-01 00:00:00') /* Olthoi Slasher (31007) */
     , (0x7002B000, 0x7002B015, '2021-11-01 00:00:00') /* Olthoi Slasher (31007) */
     , (0x7002B000, 0x7002B016, '2021-11-01 00:00:00') /* Olthoi Slasher (31007) */
     , (0x7002B000, 0x7002B017, '2021-11-01 00:00:00') /* Olthoi Slasher (31007) */
     , (0x7002B000, 0x7002B018, '2021-11-01 00:00:00') /* Olthoi Slasher (31007) */
     , (0x7002B000, 0x7002B019, '2021-11-01 00:00:00') /* Olthoi Slasher (31007) */
     , (0x7002B000, 0x7002B01A, '2021-11-01 00:00:00') /* Olthoi Slasher (31007) */
     , (0x7002B000, 0x7002B01B, '2021-11-01 00:00:00') /* Olthoi Slasher (31007) */
     , (0x7002B000, 0x7002B01C, '2021-11-01 00:00:00') /* Olthoi Slasher (31007) */
     , (0x7002B000, 0x7002B01D, '2021-11-01 00:00:00') /* Olthoi Slasher (31007) */
     , (0x7002B000, 0x7002B01E, '2021-11-01 00:00:00') /* Olthoi Slasher (31007) */
     , (0x7002B000, 0x7002B01F, '2021-11-01 00:00:00') /* Olthoi Slasher (31007) */
     , (0x7002B000, 0x7002B020, '2021-11-01 00:00:00') /* Olthoi Slasher (31007) */
     , (0x7002B000, 0x7002B021, '2021-11-01 00:00:00') /* Olthoi Slasher (31007) */
     , (0x7002B000, 0x7002B022, '2021-11-01 00:00:00') /* Olthoi Slasher (31007) */
     , (0x7002B000, 0x7002B023, '2021-11-01 00:00:00') /* Olthoi Slasher (31007) */
     , (0x7002B000, 0x7002B024, '2021-11-01 00:00:00') /* Olthoi Slasher (31007) */
     , (0x7002B000, 0x7002B025, '2021-11-01 00:00:00') /* Olthoi Slasher (31007) */
     , (0x7002B000, 0x7002B026, '2021-11-01 00:00:00') /* Olthoi Slasher (31007) */
     , (0x7002B000, 0x7002B027, '2021-11-01 00:00:00') /* Olthoi Slasher (31007) */
     , (0x7002B000, 0x7002B028, '2021-11-01 00:00:00') /* Olthoi Slasher (31007) */
     , (0x7002B000, 0x7002B029, '2021-11-01 00:00:00') /* Olthoi Slasher (31007) */
     , (0x7002B000, 0x7002B02A, '2021-11-01 00:00:00') /* Olthoi Slayer (31008) */
     , (0x7002B000, 0x7002B02B, '2021-11-01 00:00:00') /* Olthoi Slayer (31008) */
     , (0x7002B000, 0x7002B02C, '2021-11-01 00:00:00') /* Olthoi Slayer (31008) */
     , (0x7002B000, 0x7002B02D, '2021-11-01 00:00:00') /* Olthoi Slayer (31008) */
     , (0x7002B000, 0x7002B02E, '2021-11-01 00:00:00') /* Olthoi Slayer (31008) */
     , (0x7002B000, 0x7002B02F, '2021-11-01 00:00:00') /* Olthoi Slayer (31008) */
     , (0x7002B000, 0x7002B030, '2021-11-01 00:00:00') /* Olthoi Slayer (31008) */
     , (0x7002B000, 0x7002B031, '2021-11-01 00:00:00') /* Olthoi Slayer (31008) */
     , (0x7002B000, 0x7002B032, '2021-11-01 00:00:00') /* Olthoi Slayer (31008) */
     , (0x7002B000, 0x7002B033, '2021-11-01 00:00:00') /* Olthoi Slayer (31008) */
     , (0x7002B000, 0x7002B034, '2021-11-01 00:00:00') /* Olthoi Slayer (31008) */
     , (0x7002B000, 0x7002B035, '2021-11-01 00:00:00') /* Olthoi Slayer (31008) */
     , (0x7002B000, 0x7002B036, '2021-11-01 00:00:00') /* Olthoi Slayer (31008) */
     , (0x7002B000, 0x7002B037, '2021-11-01 00:00:00') /* Olthoi Slayer (31008) */
     , (0x7002B000, 0x7002B038, '2021-11-01 00:00:00') /* Olthoi Slayer (31008) */
     , (0x7002B000, 0x7002B039, '2021-11-01 00:00:00') /* Olthoi Slayer (31008) */
     , (0x7002B000, 0x7002B03A, '2021-11-01 00:00:00') /* Olthoi Slayer (31008) */
     , (0x7002B000, 0x7002B03B, '2021-11-01 00:00:00') /* Olthoi Slayer (31008) */
     , (0x7002B000, 0x7002B03C, '2021-11-01 00:00:00') /* Olthoi Slayer (31008) */
     , (0x7002B000, 0x7002B03D, '2021-11-01 00:00:00') /* Olthoi Slayer (31008) */
     , (0x7002B000, 0x7002B03E, '2021-11-01 00:00:00') /* Olthoi Slayer (31008) */
     , (0x7002B000, 0x7002B03F, '2021-11-01 00:00:00') /* Olthoi Slayer (31008) */
     , (0x7002B000, 0x7002B040, '2021-11-01 00:00:00') /* Olthoi Slayer (31008) */
     , (0x7002B000, 0x7002B041, '2021-11-01 00:00:00') /* Olthoi Slayer (31008) */
     , (0x7002B000, 0x7002B042, '2021-11-01 00:00:00') /* Olthoi Slayer (31008) */
     , (0x7002B000, 0x7002B043, '2021-11-01 00:00:00') /* Olthoi Slayer (31008) */
     , (0x7002B000, 0x7002B044, '2021-11-01 00:00:00') /* Olthoi Slayer (31008) */
     , (0x7002B000, 0x7002B045, '2021-11-01 00:00:00') /* Olthoi Slayer (31008) */
     , (0x7002B000, 0x7002B046, '2021-11-01 00:00:00') /* Olthoi Slayer (31008) */
     , (0x7002B000, 0x7002B047, '2021-11-01 00:00:00') /* Olthoi Slayer (31008) */
     , (0x7002B000, 0x7002B048, '2021-11-01 00:00:00') /* Olthoi Slayer (31008) */
     , (0x7002B000, 0x7002B049, '2021-11-01 00:00:00') /* Olthoi Slayer (31008) */
     , (0x7002B000, 0x7002B04A, '2021-11-01 00:00:00') /* Olthoi Slayer (31008) */
     , (0x7002B000, 0x7002B04B, '2021-11-01 00:00:00') /* Olthoi Slayer (31008) */
     , (0x7002B000, 0x7002B04C, '2021-11-01 00:00:00') /* Olthoi Slayer (31008) */
     , (0x7002B000, 0x7002B04D, '2021-11-01 00:00:00') /* Olthoi Slayer (31008) */
     , (0x7002B000, 0x7002B04E, '2021-11-01 00:00:00') /* Olthoi Slayer (31008) */
     , (0x7002B000, 0x7002B04F, '2021-11-01 00:00:00') /* Olthoi Slayer (31008) */
     , (0x7002B000, 0x7002B050, '2021-11-01 00:00:00') /* Olthoi Slayer (31008) */
     , (0x7002B000, 0x7002B051, '2021-11-01 00:00:00') /* Olthoi Ripper (31005) */
     , (0x7002B000, 0x7002B052, '2021-11-01 00:00:00') /* Olthoi Ripper (31005) */
     , (0x7002B000, 0x7002B053, '2021-11-01 00:00:00') /* Olthoi Ripper (31005) */
     , (0x7002B000, 0x7002B054, '2021-11-01 00:00:00') /* Olthoi Ripper (31005) */
     , (0x7002B000, 0x7002B055, '2021-11-01 00:00:00') /* Olthoi Ripper (31005) */
     , (0x7002B000, 0x7002B056, '2021-11-01 00:00:00') /* Olthoi Ripper (31005) */
     , (0x7002B000, 0x7002B057, '2021-11-01 00:00:00') /* Olthoi Ripper (31005) */
     , (0x7002B000, 0x7002B058, '2021-11-01 00:00:00') /* Olthoi Ripper (31005) */
     , (0x7002B000, 0x7002B059, '2021-11-01 00:00:00') /* Olthoi Ripper (31005) */
     , (0x7002B000, 0x7002B05A, '2021-11-01 00:00:00') /* Olthoi Ripper (31005) */
     , (0x7002B000, 0x7002B05B, '2021-11-01 00:00:00') /* Olthoi Ripper (31005) */
     , (0x7002B000, 0x7002B05C, '2021-11-01 00:00:00') /* Olthoi Ripper (31005) */
     , (0x7002B000, 0x7002B05D, '2021-11-01 00:00:00') /* Olthoi Ripper (31005) */
     , (0x7002B000, 0x7002B05E, '2021-11-01 00:00:00') /* Olthoi Ripper (31005) */
     , (0x7002B000, 0x7002B05F, '2021-11-01 00:00:00') /* Olthoi Ripper (31005) */
     , (0x7002B000, 0x7002B060, '2021-11-01 00:00:00') /* Olthoi Ripper (31005) */
     , (0x7002B000, 0x7002B061, '2021-11-01 00:00:00') /* Olthoi Ripper (31005) */
     , (0x7002B000, 0x7002B062, '2021-11-01 00:00:00') /* Olthoi Ripper (31005) */
     , (0x7002B000, 0x7002B063, '2021-11-01 00:00:00') /* Olthoi Ripper (31005) */
     , (0x7002B000, 0x7002B064, '2021-11-01 00:00:00') /* Olthoi Ripper (31005) */
     , (0x7002B000, 0x7002B065, '2021-11-01 00:00:00') /* Olthoi Ripper (31005) */
     , (0x7002B000, 0x7002B066, '2021-11-01 00:00:00') /* Olthoi Ripper (31005) */
     , (0x7002B000, 0x7002B067, '2021-11-01 00:00:00') /* Olthoi Ripper (31005) */
     , (0x7002B000, 0x7002B068, '2021-11-01 00:00:00') /* Olthoi Ripper (31005) */
     , (0x7002B000, 0x7002B069, '2021-11-01 00:00:00') /* Olthoi Ripper (31005) */
     , (0x7002B000, 0x7002B06A, '2021-11-01 00:00:00') /* Olthoi Ripper (31005) */
     , (0x7002B000, 0x7002B06B, '2021-11-01 00:00:00') /* Olthoi Ripper (31005) */
     , (0x7002B000, 0x7002B06C, '2021-11-01 00:00:00') /* Olthoi Ripper (31005) */
     , (0x7002B000, 0x7002B06D, '2021-11-01 00:00:00') /* Olthoi Ripper (31005) */
     , (0x7002B000, 0x7002B06E, '2021-11-01 00:00:00') /* Olthoi Ripper (31005) */
     , (0x7002B000, 0x7002B06F, '2021-11-01 00:00:00') /* Olthoi Ripper (31005) */
     , (0x7002B000, 0x7002B070, '2021-11-01 00:00:00') /* Olthoi Ripper (31005) */
     , (0x7002B000, 0x7002B071, '2021-11-01 00:00:00') /* Olthoi Ripper (31005) */
     , (0x7002B000, 0x7002B072, '2021-11-01 00:00:00') /* Olthoi Ripper (31005) */
     , (0x7002B000, 0x7002B073, '2021-11-01 00:00:00') /* Olthoi Ripper (31005) */
     , (0x7002B000, 0x7002B074, '2021-11-01 00:00:00') /* Olthoi Ripper (31005) */
     , (0x7002B000, 0x7002B075, '2021-11-01 00:00:00') /* Olthoi Ripper (31005) */
     , (0x7002B000, 0x7002B076, '2021-11-01 00:00:00') /* Olthoi Ripper (31005) */
     , (0x7002B000, 0x7002B077, '2021-11-01 00:00:00') /* Olthoi Ripper (31005) */
     , (0x7002B000, 0x7002B078, '2021-11-01 00:00:00') /* Olthoi Ripper (31005) */
     , (0x7002B000, 0x7002B079, '2021-11-01 00:00:00') /* Olthoi Ripper (31005) */
     , (0x7002B000, 0x7002B07A, '2021-11-01 00:00:00') /* Olthoi Ripper (31005) */
     , (0x7002B000, 0x7002B07B, '2021-11-01 00:00:00') /* Olthoi Ripper (31005) */
     , (0x7002B000, 0x7002B07C, '2021-11-01 00:00:00') /* Olthoi Ripper (31005) */
     , (0x7002B000, 0x7002B07D, '2021-11-01 00:00:00') /* Olthoi Ripper (31005) */
     , (0x7002B000, 0x7002B07E, '2021-11-01 00:00:00') /* Olthoi Ripper (31005) */
     , (0x7002B000, 0x7002B07F, '2021-11-01 00:00:00') /* Olthoi Ripper (31005) */
     , (0x7002B000, 0x7002B080, '2021-11-01 00:00:00') /* Olthoi Ripper (31005) */
     , (0x7002B000, 0x7002B081, '2021-11-01 00:00:00') /* Olthoi Ripper (31005) */
     , (0x7002B000, 0x7002B082, '2021-11-01 00:00:00') /* Olthoi Ripper (31005) */
     , (0x7002B000, 0x7002B083, '2021-11-01 00:00:00') /* Olthoi Ripper (31005) */
     , (0x7002B000, 0x7002B084, '2021-11-01 00:00:00') /* Olthoi Ripper (31005) */
     , (0x7002B000, 0x7002B085, '2021-11-01 00:00:00') /* Olthoi Ripper (31005) */
     , (0x7002B000, 0x7002B086, '2021-11-01 00:00:00') /* Olthoi Ripper (31005) */
     , (0x7002B000, 0x7002B087, '2021-11-01 00:00:00') /* Olthoi Ripper (31005) */
     , (0x7002B000, 0x7002B088, '2021-11-01 00:00:00') /* Olthoi Ripper (31005) */
     , (0x7002B000, 0x7002B089, '2021-11-01 00:00:00') /* Olthoi Ripper (31005) */
     , (0x7002B000, 0x7002B08A, '2021-11-01 00:00:00') /* Olthoi Ripper (31005) */
     , (0x7002B000, 0x7002B08B, '2021-11-01 00:00:00') /* Olthoi Ripper (31005) */
     , (0x7002B000, 0x7002B08C, '2021-11-01 00:00:00') /* Olthoi Ripper (31005) */
     , (0x7002B000, 0x7002B08D, '2021-11-01 00:00:00') /* Olthoi Ripper (31005) */
     , (0x7002B000, 0x7002B08E, '2021-11-01 00:00:00') /* Olthoi Ripper (31005) */
     , (0x7002B000, 0x7002B08F, '2021-11-01 00:00:00') /* Olthoi Ripper (31005) */
     , (0x7002B000, 0x7002B090, '2021-11-01 00:00:00') /* Olthoi Ripper (31005) */
     , (0x7002B000, 0x7002B091, '2021-11-01 00:00:00') /* Olthoi Larvae (31006) */
     , (0x7002B000, 0x7002B092, '2021-11-01 00:00:00') /* Olthoi Larvae (31006) */
     , (0x7002B000, 0x7002B093, '2021-11-01 00:00:00') /* Olthoi Larvae (31006) */
     , (0x7002B000, 0x7002B094, '2021-11-01 00:00:00') /* Olthoi Larvae (31006) */
     , (0x7002B000, 0x7002B095, '2021-11-01 00:00:00') /* Olthoi Larvae (31006) */
     , (0x7002B000, 0x7002B096, '2021-11-01 00:00:00') /* Olthoi Larvae (31006) */
     , (0x7002B000, 0x7002B097, '2021-11-01 00:00:00') /* Olthoi Larvae (31006) */
     , (0x7002B000, 0x7002B098, '2021-11-01 00:00:00') /* Olthoi Larvae (31006) */
     , (0x7002B000, 0x7002B099, '2021-11-01 00:00:00') /* Olthoi Larvae (31006) */
     , (0x7002B000, 0x7002B09A, '2021-11-01 00:00:00') /* Olthoi Larvae (31006) */
     , (0x7002B000, 0x7002B09B, '2021-11-01 00:00:00') /* Olthoi Larvae (31006) */
     , (0x7002B000, 0x7002B09C, '2021-11-01 00:00:00') /* Olthoi Larvae (31006) */
     , (0x7002B000, 0x7002B09D, '2021-11-01 00:00:00') /* Olthoi Larvae (31006) */
     , (0x7002B000, 0x7002B09E, '2021-11-01 00:00:00') /* Olthoi Larvae (31006) */
     , (0x7002B000, 0x7002B09F, '2021-11-01 00:00:00') /* Olthoi Larvae (31006) */
     , (0x7002B000, 0x7002B0A0, '2021-11-01 00:00:00') /* Olthoi Larvae (31006) */
     , (0x7002B000, 0x7002B0A1, '2021-11-01 00:00:00') /* Olthoi Larvae (31006) */
     , (0x7002B000, 0x7002B0A2, '2021-11-01 00:00:00') /* Olthoi Larvae (31006) */;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7002B001, 30965, 0x002B036F, 450.807, -179.448, -0.063, -0.366778, 0, 0, -0.930309, False, '2021-11-01 00:00:00'); /* Surface */
/* @teleloc 0x002B036F [450.807007 -179.447998 -0.063000] -0.366778 0.000000 0.000000 -0.930309 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7002B002, 30965, 0x002B0100, 9.70408, -113.312, -60.063, 0.999303, 0, 0, 0.037323, False, '2021-11-01 00:00:00'); /* Surface */
/* @teleloc 0x002B0100 [9.704080 -113.311996 -60.063000] 0.999303 0.000000 0.000000 0.037323 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7002B004, 31007, 0x002B0326, 489.367, -110.084, -11.995, 0.961765, 0, 0, -0.273878,  True, '2021-11-01 00:00:00'); /* Olthoi Slasher */
/* @teleloc 0x002B0326 [489.367004 -110.084000 -11.995000] 0.961765 0.000000 0.000000 -0.273878 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7002B005, 31007, 0x002B0321, 489.914, -90.9733, -11.995, 0.034758, 0, 0, -0.999396,  True, '2021-11-01 00:00:00'); /* Olthoi Slasher */
/* @teleloc 0x002B0321 [489.914001 -90.973297 -11.995000] 0.034758 0.000000 0.000000 -0.999396 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7002B006, 31007, 0x002B0329, 502.002, -72.0854, -11.995, 0.275532, 0, 0, -0.961292,  True, '2021-11-01 00:00:00'); /* Olthoi Slasher */
/* @teleloc 0x002B0329 [502.002014 -72.085403 -11.995000] 0.275532 0.000000 0.000000 -0.961292 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7002B007, 31007, 0x002B032F, 509.428, -72.6268, -11.995, -0.318107, 0, 0, -0.948055,  True, '2021-11-01 00:00:00'); /* Olthoi Slasher */
/* @teleloc 0x002B032F [509.428009 -72.626801 -11.995000] -0.318107 0.000000 0.000000 -0.948055 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7002B008, 31007, 0x002B0333, 517.709, -81.8441, -11.995, 0.674624, 0, 0, 0.738162,  True, '2021-11-01 00:00:00'); /* Olthoi Slasher */
/* @teleloc 0x002B0333 [517.708984 -81.844101 -11.995000] 0.674624 0.000000 0.000000 0.738162 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7002B009, 31007, 0x002B0335, 516.539, -96.9646, -11.995, -0.991093, 0, 0, -0.133169,  True, '2021-11-01 00:00:00'); /* Olthoi Slasher */
/* @teleloc 0x002B0335 [516.539001 -96.964600 -11.995000] -0.991093 0.000000 0.000000 -0.133169 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7002B00A, 31007, 0x002B0332, 511.502, -96.3612, -11.995, -0.980116, 0, 0, -0.198424,  True, '2021-11-01 00:00:00'); /* Olthoi Slasher */
/* @teleloc 0x002B0332 [511.502014 -96.361198 -11.995000] -0.980116 0.000000 0.000000 -0.198424 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7002B00B, 31007, 0x002B0330, 507.027, -81.6814, -11.995, -0.970092, 0, 0, -0.242736,  True, '2021-11-01 00:00:00'); /* Olthoi Slasher */
/* @teleloc 0x002B0330 [507.027008 -81.681396 -11.995000] -0.970092 0.000000 0.000000 -0.242736 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7002B00C, 31007, 0x002B031C, 470.14, -89.7508, -11.995, -0.943668, 0, 0, -0.330893,  True, '2021-11-01 00:00:00'); /* Olthoi Slasher */
/* @teleloc 0x002B031C [470.140015 -89.750801 -11.995000] -0.943668 0.000000 0.000000 -0.330893 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7002B00D, 31007, 0x002B0313, 461.289, -78.2145, -11.995, -0.909367, 0, 0, -0.415995,  True, '2021-11-01 00:00:00'); /* Olthoi Slasher */
/* @teleloc 0x002B0313 [461.289001 -78.214500 -11.995000] -0.909367 0.000000 0.000000 -0.415995 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7002B00E, 31007, 0x002B0309, 448.879, -69.6562, -11.995, -0.60349, 0, 0, -0.79737,  True, '2021-11-01 00:00:00'); /* Olthoi Slasher */
/* @teleloc 0x002B0309 [448.878998 -69.656197 -11.995000] -0.603490 0.000000 0.000000 -0.797370 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7002B00F, 31007, 0x002B0305, 436.711, -79.8274, -11.995, -0.6942, 0, 0, -0.719782,  True, '2021-11-01 00:00:00'); /* Olthoi Slasher */
/* @teleloc 0x002B0305 [436.710999 -79.827400 -11.995000] -0.694200 0.000000 0.000000 -0.719782 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7002B010, 31007, 0x002B02EE, 422.519, -69.4805, -11.995, -0.91571, 0, 0, -0.401841,  True, '2021-11-01 00:00:00'); /* Olthoi Slasher */
/* @teleloc 0x002B02EE [422.519012 -69.480499 -11.995000] -0.915710 0.000000 0.000000 -0.401841 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7002B011, 31007, 0x002B02EC, 420.355, -53.7482, -11.995, -0.998675, 0, 0, -0.051461,  True, '2021-11-01 00:00:00'); /* Olthoi Slasher */
/* @teleloc 0x002B02EC [420.355011 -53.748199 -11.995000] -0.998675 0.000000 0.000000 -0.051461 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7002B012, 31007, 0x002B02E0, 405.263, -48.0313, -11.995, -0.524839, 0, 0, -0.851202,  True, '2021-11-01 00:00:00'); /* Olthoi Slasher */
/* @teleloc 0x002B02E0 [405.263000 -48.031300 -11.995000] -0.524839 0.000000 0.000000 -0.851202 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7002B013, 31007, 0x002B02DC, 399.371, -57.7233, -11.995, 0.996927, 0, 0, -0.07833,  True, '2021-11-01 00:00:00'); /* Olthoi Slasher */
/* @teleloc 0x002B02DC [399.371002 -57.723301 -11.995000] 0.996927 0.000000 0.000000 -0.078330 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7002B014, 31007, 0x002B02DA, 400.228, -41.4837, -11.995, 0.461176, 0, 0, -0.887309,  True, '2021-11-01 00:00:00'); /* Olthoi Slasher */
/* @teleloc 0x002B02DA [400.227997 -41.483700 -11.995000] 0.461176 0.000000 0.000000 -0.887309 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7002B015, 31007, 0x002B02D5, 392.438, -56.6086, -11.995, 0.923697, 0, 0, -0.383123,  True, '2021-11-01 00:00:00'); /* Olthoi Slasher */
/* @teleloc 0x002B02D5 [392.437988 -56.608601 -11.995000] 0.923697 0.000000 0.000000 -0.383123 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7002B016, 31007, 0x002B02D3, 391.603, -43.7048, -11.995, -0.945064, 0, 0, 0.326885,  True, '2021-11-01 00:00:00'); /* Olthoi Slasher */
/* @teleloc 0x002B02D3 [391.602997 -43.704800 -11.995000] -0.945064 0.000000 0.000000 0.326885 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7002B017, 31007, 0x002B02DA, 404.526, -41.0086, -11.995, -0.907479, 0, 0, 0.420098,  True, '2021-11-01 00:00:00'); /* Olthoi Slasher */
/* @teleloc 0x002B02DA [404.526001 -41.008598 -11.995000] -0.907479 0.000000 0.000000 0.420098 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7002B018, 31007, 0x002B02DE, 411.446, -30.8273, -11.995, -0.605561, 0, 0, 0.795799,  True, '2021-11-01 00:00:00'); /* Olthoi Slasher */
/* @teleloc 0x002B02DE [411.446014 -30.827299 -11.995000] -0.605561 0.000000 0.000000 0.795799 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7002B019, 31007, 0x002B02E9, 417.919, -33.728, -11.995, 0.083463, 0, 0, 0.996511,  True, '2021-11-01 00:00:00'); /* Olthoi Slasher */
/* @teleloc 0x002B02E9 [417.919006 -33.728001 -11.995000] 0.083463 0.000000 0.000000 0.996511 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7002B01A, 31007, 0x002B02BD, 343.25, -120.908, -11.995, 0.066951, 0, 0, -0.997756,  True, '2021-11-01 00:00:00'); /* Olthoi Slasher */
/* @teleloc 0x002B02BD [343.250000 -120.907997 -11.995000] 0.066951 0.000000 0.000000 -0.997756 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7002B01B, 31007, 0x002B02BF, 342.223, -135.49, -11.995, 0.208258, 0, 0, -0.978074,  True, '2021-11-01 00:00:00'); /* Olthoi Slasher */
/* @teleloc 0x002B02BF [342.222992 -135.490005 -11.995000] 0.208258 0.000000 0.000000 -0.978074 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7002B01C, 31007, 0x002B02CB, 355.591, -137.627, -11.995, 0.668265, 0, 0, -0.743924,  True, '2021-11-01 00:00:00'); /* Olthoi Slasher */
/* @teleloc 0x002B02CB [355.591003 -137.626999 -11.995000] 0.668265 0.000000 0.000000 -0.743924 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7002B01D, 31007, 0x002B02C9, 359.108, -121.955, -11.995, 0.989355, 0, 0, -0.145521,  True, '2021-11-01 00:00:00'); /* Olthoi Slasher */
/* @teleloc 0x002B02C9 [359.108002 -121.955002 -11.995000] 0.989355 0.000000 0.000000 -0.145521 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7002B01E, 31007, 0x002B02CC, 370.042, -94.3812, -11.995, -0.01402, 0, 0, -0.999902,  True, '2021-11-01 00:00:00'); /* Olthoi Slasher */
/* @teleloc 0x002B02CC [370.041992 -94.381203 -11.995000] -0.014020 0.000000 0.000000 -0.999902 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7002B01F, 31007, 0x002B02D6, 388.339, -100.859, -11.995, 0.239646, 0, 0, -0.97086,  True, '2021-11-01 00:00:00'); /* Olthoi Slasher */
/* @teleloc 0x002B02D6 [388.338989 -100.859001 -11.995000] 0.239646 0.000000 0.000000 -0.970860 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7002B020, 31007, 0x002B02E2, 408.731, -109.721, -11.995, 0.640619, 0, 0, 0.767859,  True, '2021-11-01 00:00:00'); /* Olthoi Slasher */
/* @teleloc 0x002B02E2 [408.730988 -109.721001 -11.995000] 0.640619 0.000000 0.000000 0.767859 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7002B021, 31007, 0x002B035D, 468.438, -130.704, -5.995, 0.179621, 0, 0, -0.983736,  True, '2021-11-01 00:00:00'); /* Olthoi Slasher */
/* @teleloc 0x002B035D [468.437988 -130.703995 -5.995000] 0.179621 0.000000 0.000000 -0.983736 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7002B022, 31007, 0x002B0354, 460.757, -120.87, -5.995, 0.032624, 0, 0, -0.999468,  True, '2021-11-01 00:00:00'); /* Olthoi Slasher */
/* @teleloc 0x002B0354 [460.756989 -120.870003 -5.995000] 0.032624 0.000000 0.000000 -0.999468 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7002B023, 31007, 0x002B0359, 473.273, -112.119, -5.995, 0.398952, 0, 0, -0.916972,  True, '2021-11-01 00:00:00'); /* Olthoi Slasher */
/* @teleloc 0x002B0359 [473.273010 -112.119003 -5.995000] 0.398952 0.000000 0.000000 -0.916972 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7002B024, 31007, 0x002B02F6, 415.88, -119.716, -11.995, 0.75531, 0, 0, 0.655368,  True, '2021-11-01 00:00:00'); /* Olthoi Slasher */
/* @teleloc 0x002B02F6 [415.880005 -119.716003 -11.995000] 0.755310 0.000000 0.000000 0.655368 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7002B025, 31007, 0x002B02F2, 419.761, -97.1236, -11.995, 0.640495, 0, 0, -0.767963,  True, '2021-11-01 00:00:00'); /* Olthoi Slasher */
/* @teleloc 0x002B02F2 [419.760986 -97.123596 -11.995000] 0.640495 0.000000 0.000000 -0.767963 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7002B026, 31007, 0x002B0307, 436.816, -100.318, -11.995, 0.43708, 0, 0, -0.899423,  True, '2021-11-01 00:00:00'); /* Olthoi Slasher */
/* @teleloc 0x002B0307 [436.816010 -100.318001 -11.995000] 0.437080 0.000000 0.000000 -0.899423 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7002B027, 31007, 0x002B02F1, 420.767, -94.3919, -11.995, 0.332688, 0, 0, 0.943037,  True, '2021-11-01 00:00:00'); /* Olthoi Slasher */
/* @teleloc 0x002B02F1 [420.766998 -94.391899 -11.995000] 0.332688 0.000000 0.000000 0.943037 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7002B028, 31007, 0x002B0350, 441.281, -119.486, -5.995, -0.720898, 0, 0, 0.693041,  True, '2021-11-01 00:00:00'); /* Olthoi Slasher */
/* @teleloc 0x002B0350 [441.281006 -119.486000 -5.995000] -0.720898 0.000000 0.000000 0.693041 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7002B029, 31007, 0x002B02BF, 342.068, -137.533, -11.995, -0.873109, 0, 0, 0.487524,  True, '2021-11-01 00:00:00'); /* Olthoi Slasher */
/* @teleloc 0x002B02BF [342.067993 -137.533005 -11.995000] -0.873109 0.000000 0.000000 0.487524 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7002B02A, 31008, 0x002B02A6, 329.86, -130.857, -17.995, -0.009722, 0, 0, 0.999953,  True, '2021-11-01 00:00:00'); /* Olthoi Slayer */
/* @teleloc 0x002B02A6 [329.859985 -130.856995 -17.995001] -0.009722 0.000000 0.000000 0.999953 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7002B02B, 31008, 0x002B0293, 319.923, -119.716, -17.995, 0.992976, 0, 0, -0.11832,  True, '2021-11-01 00:00:00'); /* Olthoi Slayer */
/* @teleloc 0x002B0293 [319.923004 -119.716003 -17.995001] 0.992976 0.000000 0.000000 -0.118320 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7002B02C, 31008, 0x002B028A, 309.732, -128.868, -17.995, -0.057744, 0, 0, 0.998331,  True, '2021-11-01 00:00:00'); /* Olthoi Slayer */
/* @teleloc 0x002B028A [309.731995 -128.867996 -17.995001] -0.057744 0.000000 0.000000 0.998331 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7002B02D, 31008, 0x002B028C, 313.813, -139.857, -17.995, -0.713289, 0, 0, 0.70087,  True, '2021-11-01 00:00:00'); /* Olthoi Slayer */
/* @teleloc 0x002B028C [313.812988 -139.856995 -17.995001] -0.713289 0.000000 0.000000 0.700870 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7002B02E, 31008, 0x002B029E, 316.997, -150.383, -17.995, 0.800471, 0, 0, 0.599372,  True, '2021-11-01 00:00:00'); /* Olthoi Slayer */
/* @teleloc 0x002B029E [316.997009 -150.382996 -17.995001] 0.800471 0.000000 0.000000 0.599372 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7002B02F, 31008, 0x002B02A3, 328.237, -110.005, -17.995, 0.977951, 0, 0, -0.208836,  True, '2021-11-01 00:00:00'); /* Olthoi Slayer */
/* @teleloc 0x002B02A3 [328.237000 -110.004997 -17.995001] 0.977951 0.000000 0.000000 -0.208836 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7002B030, 31008, 0x002B0283, 300.214, -95.917, -17.995, 0.999985, 0, 0, -0.005459,  True, '2021-11-01 00:00:00'); /* Olthoi Slayer */
/* @teleloc 0x002B0283 [300.213989 -95.917000 -17.995001] 0.999985 0.000000 0.000000 -0.005459 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7002B031, 31008, 0x002B022E, 289.015, -90.0092, -23.995, 0.971908, 0, 0, -0.23536,  True, '2021-11-01 00:00:00'); /* Olthoi Slayer */
/* @teleloc 0x002B022E [289.015015 -90.009201 -23.995001] 0.971908 0.000000 0.000000 -0.235360 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7002B032, 31008, 0x002B025D, 310.379, -63.6461, -23.995, 0.986813, 0, 0, -0.161867,  True, '2021-11-01 00:00:00'); /* Olthoi Slayer */
/* @teleloc 0x002B025D [310.378998 -63.646099 -23.995001] 0.986813 0.000000 0.000000 -0.161867 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7002B033, 31008, 0x002B0261, 315.908, -39.5647, -23.995, 0.650119, 0, 0, 0.759833,  True, '2021-11-01 00:00:00'); /* Olthoi Slayer */
/* @teleloc 0x002B0261 [315.907990 -39.564701 -23.995001] 0.650119 0.000000 0.000000 0.759833 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7002B034, 31008, 0x002B0277, 289.557, -28.8067, -17.995, 0.999957, 0, 0, 0.009316,  True, '2021-11-01 00:00:00'); /* Olthoi Slayer */
/* @teleloc 0x002B0277 [289.557007 -28.806700 -17.995001] 0.999957 0.000000 0.000000 0.009316 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7002B035, 31008, 0x002B026F, 274.215, -27.4444, -17.995, 0.375413, 0, 0, 0.926858,  True, '2021-11-01 00:00:00'); /* Olthoi Slayer */
/* @teleloc 0x002B026F [274.214996 -27.444401 -17.995001] 0.375413 0.000000 0.000000 0.926858 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7002B036, 31008, 0x002B026E, 272.028, -20.827, -17.995, 0.802665, 0, 0, -0.59643,  True, '2021-11-01 00:00:00'); /* Olthoi Slayer */
/* @teleloc 0x002B026E [272.028015 -20.827000 -17.995001] 0.802665 0.000000 0.000000 -0.596430 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7002B037, 31008, 0x002B0270, 281.622, -11.3306, -17.995, 0.910739, 0, 0, -0.412983,  True, '2021-11-01 00:00:00'); /* Olthoi Slayer */
/* @teleloc 0x002B0270 [281.622009 -11.330600 -17.995001] 0.910739 0.000000 0.000000 -0.412983 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7002B038, 31008, 0x002B0273, 291.028, -0.460156, -17.995, 0.377279, 0, 0, -0.9261,  True, '2021-11-01 00:00:00'); /* Olthoi Slayer */
/* @teleloc 0x002B0273 [291.028015 -0.460156 -17.995001] 0.377279 0.000000 0.000000 -0.926100 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7002B039, 31008, 0x002B027D, 298.555, -0.383194, -17.995, 0.619822, 0, 0, -0.784742,  True, '2021-11-01 00:00:00'); /* Olthoi Slayer */
/* @teleloc 0x002B027D [298.554993 -0.383194 -17.995001] 0.619822 0.000000 0.000000 -0.784742 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7002B03A, 31008, 0x002B027E, 299.23, -8.12525, -17.995, -0.056454, 0, 0, -0.998405,  True, '2021-11-01 00:00:00'); /* Olthoi Slayer */
/* @teleloc 0x002B027E [299.230011 -8.125250 -17.995001] -0.056454 0.000000 0.000000 -0.998405 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7002B03B, 31008, 0x002B0269, 332.71, -56.858, -23.995, 0.924121, 0, 0, -0.382101,  True, '2021-11-01 00:00:00'); /* Olthoi Slayer */
/* @teleloc 0x002B0269 [332.709991 -56.858002 -23.995001] 0.924121 0.000000 0.000000 -0.382101 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7002B03C, 31008, 0x002B0269, 332.831, -62.9242, -23.995, 0.251014, 0, 0, -0.967983,  True, '2021-11-01 00:00:00'); /* Olthoi Slayer */
/* @teleloc 0x002B0269 [332.830994 -62.924198 -23.995001] 0.251014 0.000000 0.000000 -0.967983 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7002B03D, 31008, 0x002B024A, 301.923, -149.877, -23.995, -0.724258, 0, 0, -0.689529,  True, '2021-11-01 00:00:00'); /* Olthoi Slayer */
/* @teleloc 0x002B024A [301.923004 -149.876999 -23.995001] -0.724258 0.000000 0.000000 -0.689529 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7002B03E, 31008, 0x002B0231, 289.091, -143.429, -23.995, 0.014128, 0, 0, -0.9999,  True, '2021-11-01 00:00:00'); /* Olthoi Slayer */
/* @teleloc 0x002B0231 [289.091003 -143.429001 -23.995001] 0.014128 0.000000 0.000000 -0.999900 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7002B03F, 31008, 0x002B0235, 289.752, -159.778, -23.995, -0.649805, 0, 0, -0.760101,  True, '2021-11-01 00:00:00'); /* Olthoi Slayer */
/* @teleloc 0x002B0235 [289.752014 -159.778000 -23.995001] -0.649805 0.000000 0.000000 -0.760101 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7002B040, 31008, 0x002B0253, 299.694, -174.215, -23.995, -0.253793, 0, 0, -0.967259,  True, '2021-11-01 00:00:00'); /* Olthoi Slayer */
/* @teleloc 0x002B0253 [299.694000 -174.214996 -23.995001] -0.253793 0.000000 0.000000 -0.967259 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7002B041, 31008, 0x002B023E, 291.056, -185.307, -23.995, -0.32167, 0, 0, -0.946852,  True, '2021-11-01 00:00:00'); /* Olthoi Slayer */
/* @teleloc 0x002B023E [291.056000 -185.307007 -23.995001] -0.321670 0.000000 0.000000 -0.946852 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7002B042, 31008, 0x002B0215, 273.959, -190.215, -23.995, 0.684418, 0, 0, -0.72909,  True, '2021-11-01 00:00:00'); /* Olthoi Slayer */
/* @teleloc 0x002B0215 [273.959015 -190.214996 -23.995001] 0.684418 0.000000 0.000000 -0.729090 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7002B043, 31008, 0x002B022B, 284.561, -199.703, -23.995, 0.566127, 0, 0, -0.824318,  True, '2021-11-01 00:00:00'); /* Olthoi Slayer */
/* @teleloc 0x002B022B [284.561005 -199.703003 -23.995001] 0.566127 0.000000 0.000000 -0.824318 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7002B044, 31008, 0x002B0245, 290.674, -218.662, -23.995, 0.749999, 0, 0, -0.661438,  True, '2021-11-01 00:00:00'); /* Olthoi Slayer */
/* @teleloc 0x002B0245 [290.674011 -218.662003 -23.995001] 0.749999 0.000000 0.000000 -0.661438 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7002B045, 31008, 0x002B0256, 298.658, -216.769, -23.995, 0.844941, 0, 0, -0.53486,  True, '2021-11-01 00:00:00'); /* Olthoi Slayer */
/* @teleloc 0x002B0256 [298.657990 -216.768997 -23.995001] 0.844941 0.000000 0.000000 -0.534860 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7002B046, 31008, 0x002B0255, 298.256, -210.659, -23.995, 0.949304, 0, 0, 0.314358,  True, '2021-11-01 00:00:00'); /* Olthoi Slayer */
/* @teleloc 0x002B0255 [298.256012 -210.658997 -23.995001] 0.949304 0.000000 0.000000 0.314358 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7002B047, 31008, 0x002B0214, 269.992, -175.537, -23.995, 0.996338, 0, 0, -0.085498,  True, '2021-11-01 00:00:00'); /* Olthoi Slayer */
/* @teleloc 0x002B0214 [269.992004 -175.537003 -23.995001] 0.996338 0.000000 0.000000 -0.085498 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7002B048, 31008, 0x002B020B, 271.135, -160.623, -23.995, 0.734532, 0, 0, -0.678575,  True, '2021-11-01 00:00:00'); /* Olthoi Slayer */
/* @teleloc 0x002B020B [271.135010 -160.623001 -23.995001] 0.734532 0.000000 0.000000 -0.678575 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7002B049, 31008, 0x002B020A, 270.396, -150.335, -23.995, -0.690931, 0, 0, 0.722921,  True, '2021-11-01 00:00:00'); /* Olthoi Slayer */
/* @teleloc 0x002B020A [270.395996 -150.335007 -23.995001] -0.690931 0.000000 0.000000 0.722921 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7002B04A, 31008, 0x002B0202, 252.176, -139.051, -23.995, -0.999517, 0, 0, -0.031087,  True, '2021-11-01 00:00:00'); /* Olthoi Slayer */
/* @teleloc 0x002B0202 [252.175995 -139.050995 -23.995001] -0.999517 0.000000 0.000000 -0.031087 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7002B04B, 31008, 0x002B01FD, 239.802, -134.266, -23.995, 0.098318, 0, 0, -0.995155,  True, '2021-11-01 00:00:00'); /* Olthoi Slayer */
/* @teleloc 0x002B01FD [239.802002 -134.266006 -23.995001] 0.098318 0.000000 0.000000 -0.995155 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7002B04C, 31008, 0x002B01F1, 249.786, -111.988, -29.995, 0.817409, 0, 0, 0.576058,  True, '2021-11-01 00:00:00'); /* Olthoi Slayer */
/* @teleloc 0x002B01F1 [249.785995 -111.987999 -29.995001] 0.817409 0.000000 0.000000 0.576058 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7002B04D, 31008, 0x002B01E4, 230.68, -111.198, -35.995, 0.18843, 0, 0, 0.982087,  True, '2021-11-01 00:00:00'); /* Olthoi Slayer */
/* @teleloc 0x002B01E4 [230.679993 -111.197998 -35.994999] 0.188430 0.000000 0.000000 0.982087 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7002B04E, 31008, 0x002B01E7, 232.804, -122.657, -35.995, 0.935713, 0, 0, 0.352761,  True, '2021-11-01 00:00:00'); /* Olthoi Slayer */
/* @teleloc 0x002B01E7 [232.804001 -122.656998 -35.994999] 0.935713 0.000000 0.000000 0.352761 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7002B04F, 31008, 0x002B0272, 278.599, -28.8293, -17.995, 0.97643, 0, 0, -0.215833,  True, '2021-11-01 00:00:00'); /* Olthoi Slayer */
/* @teleloc 0x002B0272 [278.598999 -28.829300 -17.995001] 0.976430 0.000000 0.000000 -0.215833 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7002B050, 31008, 0x002B0222, 280.138, -182.075, -23.995, 0.009592, 0, 0, 0.999954,  True, '2021-11-01 00:00:00'); /* Olthoi Slayer */
/* @teleloc 0x002B0222 [280.138000 -182.074997 -23.995001] 0.009592 0.000000 0.000000 0.999954 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7002B051, 31005, 0x002B026A, 212.187, -89.6716, -17.995, -0.027678, 0, 0, 0.999617,  True, '2021-11-01 00:00:00'); /* Olthoi Ripper */
/* @teleloc 0x002B026A [212.186996 -89.671600 -17.995001] -0.027678 0.000000 0.000000 0.999617 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7002B052, 31005, 0x002B026A, 207.009, -89.403, -17.995, -0.090059, 0, 0, 0.995936,  True, '2021-11-01 00:00:00'); /* Olthoi Ripper */
/* @teleloc 0x002B026A [207.009003 -89.403000 -17.995001] -0.090059 0.000000 0.000000 0.995936 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7002B053, 31005, 0x002B026D, 217.562, -131.217, -17.995, 0.997916, 0, 0, -0.064532,  True, '2021-11-01 00:00:00'); /* Olthoi Ripper */
/* @teleloc 0x002B026D [217.561996 -131.216995 -17.995001] 0.997916 0.000000 0.000000 -0.064532 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7002B054, 31005, 0x002B026D, 222.408, -131.532, -17.995, 0.999373, 0, 0, 0.035416,  True, '2021-11-01 00:00:00'); /* Olthoi Ripper */
/* @teleloc 0x002B026D [222.408005 -131.531998 -17.995001] 0.999373 0.000000 0.000000 0.035416 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7002B055, 31005, 0x002B01DE, 213.622, -122.808, -35.995, 0.674774, 0, 0, -0.738024,  True, '2021-11-01 00:00:00'); /* Olthoi Ripper */
/* @teleloc 0x002B01DE [213.621994 -122.807999 -35.994999] 0.674774 0.000000 0.000000 -0.738024 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7002B056, 31005, 0x002B01DE, 214.155, -116.871, -35.995, 0.674774, 0, 0, -0.738024,  True, '2021-11-01 00:00:00'); /* Olthoi Ripper */
/* @teleloc 0x002B01DE [214.154999 -116.871002 -35.994999] 0.674774 0.000000 0.000000 -0.738024 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7002B057, 31005, 0x002B01DC, 213.273, -98.3851, -35.995, 0.555248, 0, 0, 0.831685,  True, '2021-11-01 00:00:00'); /* Olthoi Ripper */
/* @teleloc 0x002B01DC [213.272995 -98.385101 -35.994999] 0.555248 0.000000 0.000000 0.831685 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7002B058, 31005, 0x002B01D8, 199.232, -100.889, -35.995, 0.668795, 0, 0, -0.743447,  True, '2021-11-01 00:00:00'); /* Olthoi Ripper */
/* @teleloc 0x002B01D8 [199.231995 -100.889000 -35.994999] 0.668795 0.000000 0.000000 -0.743447 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7002B059, 31005, 0x002B01A9, 187.063, -98.1671, -53.995, 0.185461, 0, 0, -0.982652,  True, '2021-11-01 00:00:00'); /* Olthoi Ripper */
/* @teleloc 0x002B01A9 [187.063004 -98.167099 -53.994999] 0.185461 0.000000 0.000000 -0.982652 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7002B05A, 31005, 0x002B01A9, 193.885, -99.079, -53.995, 0.047109, 0, 0, -0.99889,  True, '2021-11-01 00:00:00'); /* Olthoi Ripper */
/* @teleloc 0x002B01A9 [193.884995 -99.079002 -53.994999] 0.047109 0.000000 0.000000 -0.998890 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7002B05B, 31005, 0x002B01AF, 198.229, -105.171, -53.995, -0.641036, 0, 0, -0.767511,  True, '2021-11-01 00:00:00'); /* Olthoi Ripper */
/* @teleloc 0x002B01AF [198.229004 -105.170998 -53.994999] -0.641036 0.000000 0.000000 -0.767511 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7002B05C, 31005, 0x002B01A3, 180.346, -106.146, -53.995, 0.618861, 0, 0, -0.785501,  True, '2021-11-01 00:00:00'); /* Olthoi Ripper */
/* @teleloc 0x002B01A3 [180.345993 -106.146004 -53.994999] 0.618861 0.000000 0.000000 -0.785501 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7002B05D, 31005, 0x002B01AA, 189.235, -113.486, -53.995, -0.997963, 0, 0, -0.063801,  True, '2021-11-01 00:00:00'); /* Olthoi Ripper */
/* @teleloc 0x002B01AA [189.235001 -113.486000 -53.994999] -0.997963 0.000000 0.000000 -0.063801 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7002B05E, 31005, 0x002B01A5, 180.209, -130.141, -53.995, 0.716797, 0, 0, 0.697282,  True, '2021-11-01 00:00:00'); /* Olthoi Ripper */
/* @teleloc 0x002B01A5 [180.209000 -130.141006 -53.994999] 0.716797 0.000000 0.000000 0.697282 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7002B05F, 31005, 0x002B019B, 172.638, -139.57, -53.995, 0.727845, 0, 0, -0.685742,  True, '2021-11-01 00:00:00'); /* Olthoi Ripper */
/* @teleloc 0x002B019B [172.638000 -139.570007 -53.994999] 0.727845 0.000000 0.000000 -0.685742 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7002B060, 31005, 0x002B018E, 161.486, -150.111, -53.995, 0.060053, 0, 0, 0.998195,  True, '2021-11-01 00:00:00'); /* Olthoi Ripper */
/* @teleloc 0x002B018E [161.485992 -150.110992 -53.994999] 0.060053 0.000000 0.000000 0.998195 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7002B061, 31005, 0x002B0184, 151.582, -167.054, -53.995, 0.992809, 0, 0, -0.119711,  True, '2021-11-01 00:00:00'); /* Olthoi Ripper */
/* @teleloc 0x002B0184 [151.582001 -167.054001 -53.994999] 0.992809 0.000000 0.000000 -0.119711 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7002B062, 31005, 0x002B0197, 160.049, -173.298, -53.995, 0.088713, 0, 0, -0.996057,  True, '2021-11-01 00:00:00'); /* Olthoi Ripper */
/* @teleloc 0x002B0197 [160.048996 -173.298004 -53.994999] 0.088713 0.000000 0.000000 -0.996057 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7002B063, 31005, 0x002B01BC, 163.914, -189.485, -47.995, 0.805192, 0, 0, -0.593014,  True, '2021-11-01 00:00:00'); /* Olthoi Ripper */
/* @teleloc 0x002B01BC [163.914001 -189.485001 -47.994999] 0.805192 0.000000 0.000000 -0.593014 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7002B064, 31005, 0x002B01C4, 182.406, -179.776, -47.995, 0.710491, 0, 0, -0.703706,  True, '2021-11-01 00:00:00'); /* Olthoi Ripper */
/* @teleloc 0x002B01C4 [182.406006 -179.776001 -47.994999] 0.710491 0.000000 0.000000 -0.703706 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7002B065, 31005, 0x002B01CB, 196.785, -179.133, -47.995, 0.763937, 0, 0, -0.64529,  True, '2021-11-01 00:00:00'); /* Olthoi Ripper */
/* @teleloc 0x002B01CB [196.785004 -179.132996 -47.994999] 0.763937 0.000000 0.000000 -0.645290 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7002B066, 31005, 0x002B01D0, 198.529, -160.904, -41.995, 0.991682, 0, 0, 0.128712,  True, '2021-11-01 00:00:00'); /* Olthoi Ripper */
/* @teleloc 0x002B01D0 [198.529007 -160.904007 -41.994999] 0.991682 0.000000 0.000000 0.128712 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7002B067, 31005, 0x002B01CD, 192.198, -160.803, -41.995, 0.19342, 0, 0, 0.981116,  True, '2021-11-01 00:00:00'); /* Olthoi Ripper */
/* @teleloc 0x002B01CD [192.197998 -160.802994 -41.994999] 0.193420 0.000000 0.000000 0.981116 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7002B068, 31005, 0x002B01CE, 190.613, -168.986, -44.3066, 0.006508, 0, 0, 0.999979,  True, '2021-11-01 00:00:00'); /* Olthoi Ripper */
/* @teleloc 0x002B01CE [190.613007 -168.985992 -44.306599] 0.006508 0.000000 0.000000 0.999979 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7002B069, 31005, 0x002B01D2, 198.544, -169.089, -44.3686, -0.999742, 0, 0, -0.022693,  True, '2021-11-01 00:00:00'); /* Olthoi Ripper */
/* @teleloc 0x002B01D2 [198.544006 -169.089005 -44.368599] -0.999742 0.000000 0.000000 -0.022693 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7002B06A, 31005, 0x002B01E1, 220.198, -157.775, -35.995, -0.999922, 0, 0, 0.012522,  True, '2021-11-01 00:00:00'); /* Olthoi Ripper */
/* @teleloc 0x002B01E1 [220.197998 -157.774994 -35.994999] -0.999922 0.000000 0.000000 0.012522 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7002B06B, 31005, 0x002B01F7, 220.157, -130.212, -23.995, -0.999922, 0, 0, 0.012522,  True, '2021-11-01 00:00:00'); /* Olthoi Ripper */
/* @teleloc 0x002B01F7 [220.156998 -130.212006 -23.995001] -0.999922 0.000000 0.000000 0.012522 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7002B06C, 31005, 0x002B018D, 159.949, -136.55, -53.995, 0.999857, 0, 0, -0.016905,  True, '2021-11-01 00:00:00'); /* Olthoi Ripper */
/* @teleloc 0x002B018D [159.949005 -136.550003 -53.994999] 0.999857 0.000000 0.000000 -0.016905 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7002B06D, 31005, 0x002B0179, 151.044, -120.571, -53.995, -0.998283, 0, 0, -0.05857,  True, '2021-11-01 00:00:00'); /* Olthoi Ripper */
/* @teleloc 0x002B0179 [151.044006 -120.570999 -53.994999] -0.998283 0.000000 0.000000 -0.058570 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7002B06E, 31005, 0x002B016A, 125.018, -149.929, -53.995, 0.766722, 0, 0, -0.64198,  True, '2021-11-01 00:00:00'); /* Olthoi Ripper */
/* @teleloc 0x002B016A [125.017998 -149.929001 -53.994999] 0.766722 0.000000 0.000000 -0.641980 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7002B06F, 31005, 0x002B012F, 70.7089, -134.976, -59.995, -0.702582, 0, 0, 0.711603,  True, '2021-11-01 00:00:00'); /* Olthoi Ripper */
/* @teleloc 0x002B012F [70.708900 -134.975998 -59.994999] -0.702582 0.000000 0.000000 0.711603 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7002B070, 31005, 0x002B014F, 79.8744, -131.176, -56.9906, -0.702582, 0, 0, 0.711603,  True, '2021-11-01 00:00:00'); /* Olthoi Ripper */
/* @teleloc 0x002B014F [79.874397 -131.175995 -56.990601] -0.702582 0.000000 0.000000 0.711603 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7002B071, 31005, 0x002B0150, 79.7748, -138.984, -57.0504, -0.702582, 0, 0, 0.711603,  True, '2021-11-01 00:00:00'); /* Olthoi Ripper */
/* @teleloc 0x002B0150 [79.774803 -138.983994 -57.050400] -0.702582 0.000000 0.000000 0.711603 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7002B072, 31005, 0x002B0153, 88.4739, -139.858, -53.995, -0.66967, 0, 0, 0.742659,  True, '2021-11-01 00:00:00'); /* Olthoi Ripper */
/* @teleloc 0x002B0153 [88.473900 -139.858002 -53.994999] -0.669670 0.000000 0.000000 0.742659 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7002B073, 31005, 0x002B0151, 88.522, -132.617, -53.995, -0.999928, 0, 0, 0.012032,  True, '2021-11-01 00:00:00'); /* Olthoi Ripper */
/* @teleloc 0x002B0151 [88.522003 -132.617004 -53.994999] -0.999928 0.000000 0.000000 0.012032 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7002B074, 31005, 0x002B010F, 44.4873, -93.7749, -59.995, 0.418231, 0, 0, -0.908341,  True, '2021-11-01 00:00:00'); /* Olthoi Ripper */
/* @teleloc 0x002B010F [44.487301 -93.774902 -59.994999] 0.418231 0.000000 0.000000 -0.908341 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7002B075, 31005, 0x002B0121, 57.8318, -105.011, -59.995, -0.418363, 0, 0, -0.90828,  True, '2021-11-01 00:00:00'); /* Olthoi Ripper */
/* @teleloc 0x002B0121 [57.831799 -105.011002 -59.994999] -0.418363 0.000000 0.000000 -0.908280 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7002B076, 31005, 0x002B0147, 46.1595, -119.787, -53.995, 0.701841, 0, 0, 0.712334,  True, '2021-11-01 00:00:00'); /* Olthoi Ripper */
/* @teleloc 0x002B0147 [46.159500 -119.787003 -53.994999] 0.701841 0.000000 0.000000 0.712334 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7002B077, 31005, 0x002B0140, 39.0613, -119.893, -53.995, 0.701841, 0, 0, 0.712334,  True, '2021-11-01 00:00:00'); /* Olthoi Ripper */
/* @teleloc 0x002B0140 [39.061298 -119.892998 -53.994999] 0.701841 0.000000 0.000000 0.712334 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7002B078, 31005, 0x002B0148, 45.1219, -130.102, -53.995, -0.712097, 0, 0, 0.702081,  True, '2021-11-01 00:00:00'); /* Olthoi Ripper */
/* @teleloc 0x002B0148 [45.121899 -130.102005 -53.994999] -0.712097 0.000000 0.000000 0.702081 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7002B079, 31005, 0x002B0141, 38.3697, -129.917, -53.995, -0.716737, 0, 0, -0.697343,  True, '2021-11-01 00:00:00'); /* Olthoi Ripper */
/* @teleloc 0x002B0141 [38.369701 -129.917007 -53.994999] -0.716737 0.000000 0.000000 -0.697343 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7002B07A, 31005, 0x002B0104, 14.997, -140.348, -59.995, -0.745326, 0, 0, 0.6667,  True, '2021-11-01 00:00:00'); /* Olthoi Ripper */
/* @teleloc 0x002B0104 [14.997000 -140.348007 -59.994999] -0.745326 0.000000 0.000000 0.666700 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7002B07B, 31005, 0x002B0136, 4.07596, -129.903, -53.995, -0.714527, 0, 0, 0.699608,  True, '2021-11-01 00:00:00'); /* Olthoi Ripper */
/* @teleloc 0x002B0136 [4.075960 -129.903000 -53.994999] -0.714527 0.000000 0.000000 0.699608 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7002B07C, 31005, 0x002B0137, 11.0759, -129.82, -53.995, -0.714527, 0, 0, 0.699608,  True, '2021-11-01 00:00:00'); /* Olthoi Ripper */
/* @teleloc 0x002B0137 [11.075900 -129.820007 -53.994999] -0.714527 0.000000 0.000000 0.699608 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7002B07D, 31005, 0x002B0112, 37.7997, -150.772, -59.995, -0.346888, 0, 0, 0.937907,  True, '2021-11-01 00:00:00'); /* Olthoi Ripper */
/* @teleloc 0x002B0112 [37.799702 -150.772003 -59.994999] -0.346888 0.000000 0.000000 0.937907 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7002B07E, 31005, 0x002B011C, 46.3605, -164.589, -59.995, -0.720603, 0, 0, 0.693348,  True, '2021-11-01 00:00:00'); /* Olthoi Ripper */
/* @teleloc 0x002B011C [46.360500 -164.589005 -59.994999] -0.720603 0.000000 0.000000 0.693348 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7002B07F, 31005, 0x002B0156, 104.507, -130.006, -53.995, -0.718131, 0, 0, 0.695908,  True, '2021-11-01 00:00:00'); /* Olthoi Ripper */
/* @teleloc 0x002B0156 [104.507004 -130.005997 -53.994999] -0.718131 0.000000 0.000000 0.695908 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7002B080, 31005, 0x002B015E, 122.706, -138.35, -53.995, -0.56202, 0, 0, 0.827124,  True, '2021-11-01 00:00:00'); /* Olthoi Ripper */
/* @teleloc 0x002B015E [122.706001 -138.350006 -53.994999] -0.562020 0.000000 0.000000 0.827124 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7002B081, 31005, 0x002B0178, 140.354, -156.194, -53.995, -0.999894, 0, 0, -0.014534,  True, '2021-11-01 00:00:00'); /* Olthoi Ripper */
/* @teleloc 0x002B0178 [140.354004 -156.194000 -53.994999] -0.999894 0.000000 0.000000 -0.014534 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7002B082, 31005, 0x002B0171, 139.135, -140.432, -53.995, -0.687003, 0, 0, -0.726654,  True, '2021-11-01 00:00:00'); /* Olthoi Ripper */
/* @teleloc 0x002B0171 [139.134995 -140.432007 -53.994999] -0.687003 0.000000 0.000000 -0.726654 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7002B083, 31005, 0x002B0162, 134.227, -130.082, -53.995, 0.545413, 0, 0, 0.838167,  True, '2021-11-01 00:00:00'); /* Olthoi Ripper */
/* @teleloc 0x002B0162 [134.227005 -130.082001 -53.994999] 0.545413 0.000000 0.000000 0.838167 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7002B084, 31005, 0x002B010B, 30.9473, -118.741, -59.995, 0.185744, 0, 0, 0.982598,  True, '2021-11-01 00:00:00'); /* Olthoi Ripper */
/* @teleloc 0x002B010B [30.947300 -118.740997 -59.994999] 0.185744 0.000000 0.000000 0.982598 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7002B085, 31005, 0x002B010C, 30.7117, -125.688, -59.995, 0.02004, 0, 0, 0.999799,  True, '2021-11-01 00:00:00'); /* Olthoi Ripper */
/* @teleloc 0x002B010C [30.711700 -125.688004 -59.994999] 0.020040 0.000000 0.000000 0.999799 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7002B086, 31005, 0x002B010C, 29.5159, -133.467, -59.995, 0.87555, 0, 0, 0.483127,  True, '2021-11-01 00:00:00'); /* Olthoi Ripper */
/* @teleloc 0x002B010C [29.515900 -133.466995 -59.994999] 0.875550 0.000000 0.000000 0.483127 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7002B087, 31005, 0x002B0101, 12.9028, -119.799, -59.995, -0.668672, 0, 0, 0.743557,  True, '2021-11-01 00:00:00'); /* Olthoi Ripper */
/* @teleloc 0x002B0101 [12.902800 -119.799004 -59.994999] -0.668672 0.000000 0.000000 0.743557 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7002B088, 31005, 0x002B0105, 18.7522, -117.765, -59.995, -0.621495, 0, 0, 0.783418,  True, '2021-11-01 00:00:00'); /* Olthoi Ripper */
/* @teleloc 0x002B0105 [18.752199 -117.764999 -59.994999] -0.621495 0.000000 0.000000 0.783418 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7002B089, 31005, 0x002B010B, 25.8399, -123.741, -59.995, -0.29424, 0, 0, 0.955731,  True, '2021-11-01 00:00:00'); /* Olthoi Ripper */
/* @teleloc 0x002B010B [25.839899 -123.740997 -59.994999] -0.294240 0.000000 0.000000 0.955731 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7002B08A, 31005, 0x002B0338, 340.583, -59.6649, -5.995, 0.202849, 0, 0, 0.97921,  True, '2021-11-01 00:00:00'); /* Olthoi Ripper */
/* @teleloc 0x002B0338 [340.583008 -59.664902 -5.995000] 0.202849 0.000000 0.000000 0.979210 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7002B08B, 31005, 0x002B0339, 340.479, -68.5892, -5.995, 0.801563, 0, 0, 0.59791,  True, '2021-11-01 00:00:00'); /* Olthoi Ripper */
/* @teleloc 0x002B0339 [340.479004 -68.589203 -5.995000] 0.801563 0.000000 0.000000 0.597910 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7002B08C, 31005, 0x002B0337, 330.021, -70.241, -5.995, 0.998737, 0, 0, -0.050236,  True, '2021-11-01 00:00:00'); /* Olthoi Ripper */
/* @teleloc 0x002B0337 [330.020996 -70.240997 -5.995000] 0.998737 0.000000 0.000000 -0.050236 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7002B08D, 31005, 0x002B0269, 329.72, -59.9933, -23.995, 0.749093, 0, 0, 0.662465,  True, '2021-11-01 00:00:00'); /* Olthoi Ripper */
/* @teleloc 0x002B0269 [329.720001 -59.993301 -23.995001] 0.749093 0.000000 0.000000 0.662465 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7002B08E, 31005, 0x002B0264, 319.686, -53.558, -23.995, -0.078048, 0, 0, 0.99695,  True, '2021-11-01 00:00:00'); /* Olthoi Ripper */
/* @teleloc 0x002B0264 [319.686005 -53.557999 -23.995001] -0.078048 0.000000 0.000000 0.996950 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7002B08F, 31005, 0x002B0139, 19.7386, -111.951, -53.995, -0.088276, 0, 0, 0.996096,  True, '2021-11-01 00:00:00'); /* Olthoi Ripper */
/* @teleloc 0x002B0139 [19.738600 -111.950996 -53.994999] -0.088276 0.000000 0.000000 0.996096 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7002B090, 31005, 0x002B0119, 46.8082, -96.3182, -59.995, -0.339143, 0, 0, 0.940735,  True, '2021-11-01 00:00:00'); /* Olthoi Ripper */
/* @teleloc 0x002B0119 [46.808201 -96.318199 -59.994999] -0.339143 0.000000 0.000000 0.940735 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7002B091, 31006, 0x002B0120, 59.4297, -102.349, -59.995, 0.480435, 0, 0, 0.87703,  True, '2021-11-01 00:00:00'); /* Olthoi Larvae */
/* @teleloc 0x002B0120 [59.429699 -102.348999 -59.994999] 0.480435 0.000000 0.000000 0.877030 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7002B092, 31006, 0x002B0119, 53.6258, -100.45, -59.995, 0.250712, 0, 0, 0.968062,  True, '2021-11-01 00:00:00'); /* Olthoi Larvae */
/* @teleloc 0x002B0119 [53.625801 -100.449997 -59.994999] 0.250712 0.000000 0.000000 0.968062 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7002B093, 31006, 0x002B011A, 50.4455, -106.01, -59.995, -0.133683, 0, 0, 0.991024,  True, '2021-11-01 00:00:00'); /* Olthoi Larvae */
/* @teleloc 0x002B011A [50.445499 -106.010002 -59.994999] -0.133683 0.000000 0.000000 0.991024 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7002B094, 31006, 0x002B0110, 42.4176, -96.952, -59.995, -0.725127, 0, 0, 0.688615,  True, '2021-11-01 00:00:00'); /* Olthoi Larvae */
/* @teleloc 0x002B0110 [42.417599 -96.952003 -59.994999] -0.725127 0.000000 0.000000 0.688615 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7002B095, 31006, 0x002B0118, 47.9706, -92.7059, -59.995, -0.13748, 0, 0, 0.990505,  True, '2021-11-01 00:00:00'); /* Olthoi Larvae */
/* @teleloc 0x002B0118 [47.970600 -92.705902 -59.994999] -0.137480 0.000000 0.000000 0.990505 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7002B096, 31006, 0x002B010F, 43.8111, -91.3057, -59.995, -0.271948, 0, 0, 0.962312,  True, '2021-11-01 00:00:00'); /* Olthoi Larvae */
/* @teleloc 0x002B010F [43.811100 -91.305702 -59.994999] -0.271948 0.000000 0.000000 0.962312 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7002B097, 31006, 0x002B011F, 48.2869, -168.051, -59.995, 0.989228, 0, 0, 0.146383,  True, '2021-11-01 00:00:00'); /* Olthoi Larvae */
/* @teleloc 0x002B011F [48.286900 -168.050995 -59.994999] 0.989228 0.000000 0.000000 0.146383 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7002B098, 31006, 0x002B0117, 40.7509, -166.305, -59.995, -0.897481, 0, 0, 0.441052,  True, '2021-11-01 00:00:00'); /* Olthoi Larvae */
/* @teleloc 0x002B0117 [40.750900 -166.304993 -59.994999] -0.897481 0.000000 0.000000 0.441052 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7002B099, 31006, 0x002B011C, 46.7441, -164.173, -59.995, 0.83153, 0, 0, 0.55548,  True, '2021-11-01 00:00:00'); /* Olthoi Larvae */
/* @teleloc 0x002B011C [46.744099 -164.173004 -59.994999] 0.831530 0.000000 0.000000 0.555480 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7002B09A, 31006, 0x002B0117, 43.7914, -169.291, -59.995, 0.999722, 0, 0, -0.023558,  True, '2021-11-01 00:00:00'); /* Olthoi Larvae */
/* @teleloc 0x002B0117 [43.791401 -169.291000 -59.994999] 0.999722 0.000000 0.000000 -0.023558 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7002B09B, 31006, 0x002B0106, 18.8631, -126.508, -59.995, -0.667977, 0, 0, 0.744182,  True, '2021-11-01 00:00:00'); /* Olthoi Larvae */
/* @teleloc 0x002B0106 [18.863100 -126.508003 -59.994999] -0.667977 0.000000 0.000000 0.744182 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7002B09C, 31006, 0x002B0106, 23.6841, -132.016, -59.995, -0.937968, 0, 0, 0.346723,  True, '2021-11-01 00:00:00'); /* Olthoi Larvae */
/* @teleloc 0x002B0106 [23.684099 -132.016006 -59.994999] -0.937968 0.000000 0.000000 0.346723 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7002B09D, 31006, 0x002B0105, 17.0885, -117.362, -59.995, -0.511164, 0, 0, 0.859483,  True, '2021-11-01 00:00:00'); /* Olthoi Larvae */
/* @teleloc 0x002B0105 [17.088499 -117.362000 -59.994999] -0.511164 0.000000 0.000000 0.859483 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7002B09E, 31006, 0x002B0105, 21.8886, -116.395, -59.995, -0.488988, 0, 0, 0.872291,  True, '2021-11-01 00:00:00'); /* Olthoi Larvae */
/* @teleloc 0x002B0105 [21.888599 -116.394997 -59.994999] -0.488988 0.000000 0.000000 0.872291 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7002B09F, 31006, 0x002B010B, 33.0389, -120.554, -59.995, 0.151594, 0, 0, 0.988443,  True, '2021-11-01 00:00:00'); /* Olthoi Larvae */
/* @teleloc 0x002B010B [33.038898 -120.554001 -59.994999] 0.151594 0.000000 0.000000 0.988443 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7002B0A0, 31006, 0x002B010C, 32.9937, -132.395, -59.995, 0.881182, 0, 0, 0.472777,  True, '2021-11-01 00:00:00'); /* Olthoi Larvae */
/* @teleloc 0x002B010C [32.993698 -132.395004 -59.994999] 0.881182 0.000000 0.000000 0.472777 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7002B0A1, 31006, 0x002B0106, 24.1405, -130.089, -59.995, 0.928118, 0, 0, -0.372287,  True, '2021-11-01 00:00:00'); /* Olthoi Larvae */
/* @teleloc 0x002B0106 [24.140499 -130.089005 -59.994999] 0.928118 0.000000 0.000000 -0.372287 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7002B0A2, 31006, 0x002B0105, 22.4352, -121.826, -59.995, 0.591574, 0, 0, -0.806251,  True, '2021-11-01 00:00:00'); /* Olthoi Larvae */
/* @teleloc 0x002B0105 [22.435200 -121.825996 -59.994999] 0.591574 0.000000 0.000000 -0.806251 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7002B6A5,  1154, 0x002B010C, 25.059, -125.081, -60, 1, 0, 0, 0, False, '2021-11-01 00:00:00'); /* Linkable Monster Generator */
/* @teleloc 0x002B010C [25.059000 -125.081001 -60.000000] 1.000000 0.000000 0.000000 0.000000 */

INSERT INTO `landblock_instance_link` (`parent_GUID`, `child_GUID`, `last_Modified`)
VALUES (0x7002B6A5, 0x7002B6A6, '2021-11-01 00:00:00') /* Exploration Marker (39839) */;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7002B6A6, 39839, 0x002B010C, 25.059, -125.081, -60, 1, 0, 0, 0,  True, '2021-11-01 00:00:00'); /* Exploration Marker */
/* @teleloc 0x002B010C [25.059000 -125.081001 -60.000000] 1.000000 0.000000 0.000000 0.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7002B6A7, 931271771, 0x002B0371, 455.892, -174.55, 0.055, -0.352103, 0, 0, -0.935961, False, '2025-08-25 06:58:33');
/* @teleloc 0x002B0371 [455.891998 -174.550003 0.055000] -0.352103 0.000000 0.000000 -0.935961 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7002B6A8, 931271771, 0x002B036F, 446.07, -180.269, 2.63214, -0.811012, 0, 0, 0.58503, False, '2025-08-25 06:58:46');
/* @teleloc 0x002B036F [446.070007 -180.268997 2.632140] -0.811012 0.000000 0.000000 0.585030 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7002B6A9, 931271771, 0x002B0372, 461.027, -179.505, 0.751233, -0.876927, 0, 0, 0.480624, False, '2025-08-25 06:58:48');
/* @teleloc 0x002B0372 [461.027008 -179.505005 0.751233] -0.876927 0.000000 0.000000 0.480624 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7002B6AA, 931271771, 0x002B0377, 465.418, -167.705, 0.055, -0.978325, 0, 0, 0.207074, False, '2025-08-25 06:58:50');
/* @teleloc 0x002B0377 [465.417999 -167.705002 0.055000] -0.978325 0.000000 0.000000 0.207074 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7002B6AB, 931271771, 0x002B0376, 469.294, -161.045, 0.055, -0.99618, 0, 0, 0.087321, False, '2025-08-25 06:58:51');
/* @teleloc 0x002B0376 [469.294006 -161.044998 0.055000] -0.996180 0.000000 0.000000 0.087321 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7002B6AC, 931271771, 0x002B0374, 470.027, -152.766, 0.055, -0.997952, 0, 0, -0.063964, False, '2025-08-25 06:58:52');
/* @teleloc 0x002B0374 [470.027008 -152.766006 0.055000] -0.997952 0.000000 0.000000 -0.063964 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7002B6AD, 931271771, 0x002B0373, 469.011, -144.878, 0.061813, -0.997952, 0, 0, -0.063964, False, '2025-08-25 06:58:54');
/* @teleloc 0x002B0373 [469.010986 -144.878006 0.061813] -0.997952 0.000000 0.000000 -0.063964 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7002B6AE, 931271771, 0x002B0371, 458.206, -166.684, 0.270835, -0.396984, 0, 0, -0.917826, False, '2025-08-25 06:58:59');
/* @teleloc 0x002B0371 [458.205994 -166.684006 0.270835] -0.396984 0.000000 0.000000 -0.917826 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7002B6AF, 931271771, 0x002B036E, 454.961, -166.793, 2.05887, -0.785745, 0, 0, -0.61855, False, '2025-08-25 06:59:00');
/* @teleloc 0x002B036E [454.960999 -166.792999 2.058870] -0.785745 0.000000 0.000000 -0.618550 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7002B6B0, 931271771, 0x002B036E, 446.147, -171.098, 2.44675, -0.274385, 0, 0, -0.96162, False, '2025-08-25 06:59:02');
/* @teleloc 0x002B036E [446.147003 -171.098007 2.446750] -0.274385 0.000000 0.000000 -0.961620 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7002B6B1, 931271771, 0x002B0377, 465.05, -173.889, 2.46802, 0.872602, 0, 0, -0.488432, False, '2025-08-25 06:59:05');
/* @teleloc 0x002B0377 [465.049988 -173.889008 2.468020] 0.872602 0.000000 0.000000 -0.488432 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7002B6B2, 931271771, 0x002B0377, 472.504, -168.458, 1.6371, 0.955845, 0, 0, -0.293873, False, '2025-08-25 06:59:06');
/* @teleloc 0x002B0377 [472.503998 -168.457993 1.637100] 0.955845 0.000000 0.000000 -0.293873 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7002B6B3, 931271771, 0x002B0376, 474.49, -160.703, 2.72538, 0.999985, 0, 0, -0.005493, False, '2025-08-25 06:59:07');
/* @teleloc 0x002B0376 [474.489990 -160.703003 2.725380] 0.999985 0.000000 0.000000 -0.005493 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7002B6B4, 931271771, 0x002B0371, 458.535, -172.203, 0.06, 0.933008, 0, 0, -0.359856, False, '2025-08-25 07:47:24');
/* @teleloc 0x002B0371 [458.535004 -172.203003 0.060000] 0.933008 0.000000 0.000000 -0.359856 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7002B6B5, 931271771, 0x002B036F, 453.838, -180.062, 0.171916, -0.293415, 0, 0, -0.955985, False, '2025-08-25 07:47:29');
/* @teleloc 0x002B036F [453.838013 -180.061996 0.171916] -0.293415 0.000000 0.000000 -0.955985 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7002B6B6, 931271771, 0x002B0377, 465.487, -167.425, 0.055, 0.962985, 0, 0, -0.269556, False, '2025-08-25 07:47:31');
/* @teleloc 0x002B0377 [465.487000 -167.425003 0.055000] 0.962985 0.000000 0.000000 -0.269556 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7002B6B7, 931271771, 0x002B0374, 470.267, -152.824, 0.055, 0.999789, 0, 0, -0.020531, False, '2025-08-25 07:47:33');
/* @teleloc 0x002B0374 [470.266998 -152.824005 0.055000] 0.999789 0.000000 0.000000 -0.020531 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7002B6B8, 931271771, 0x002B035C, 465.3411, -118.1034, -5.945, 0.83214, 0, 0, -0.554565, False, '2025-08-25 07:47:38');
/* @teleloc 0x002B035C [465.341095 -118.103401 -5.945000] 0.832140 0.000000 0.000000 -0.554565 */
