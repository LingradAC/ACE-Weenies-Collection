DELETE FROM `landblock_instance` WHERE `landblock` = 0x1048;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x71048000, 92834236, 0x1048000D, 33.0459, 108.258, 8.055, 0.816179, 0, 0, -0.5778, False, '2025-07-23 05:52:53'); /* Hopeslayer Warden + Ravener Generator */
/* @teleloc 0x1048000D [33.045898 108.258003 8.055000] 0.816179 0.000000 0.000000 -0.577800 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x71048001, 92834236, 0x10480028, 115.598, 180.167, 7.04105, 0.944959, 0, 0, -0.32719, False, '2025-07-23 05:53:01'); /* Hopeslayer Warden + Ravener Generator */
/* @teleloc 0x10480028 [115.598000 180.167007 7.041050] 0.944959 0.000000 0.000000 -0.327190 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x71048002, 56843983, 0x1048003E, 168.031, 140.064, -0.845, 0.602156, 0, 0, -0.798378, False, '2025-07-29 17:08:18'); /* Oathblade Gen */
/* @teleloc 0x1048003E [168.031006 140.063995 -0.845000] 0.602156 0.000000 0.000000 -0.798378 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x71048003, 56843983, 0x10480034, 150.1438, 82.74216, -0.845, -0.256729, 0, 0, -0.966483, False, '2025-07-29 17:08:23'); /* Oathblade Gen */
/* @teleloc 0x10480034 [150.143799 82.742157 -0.845000] -0.256729 0.000000 0.000000 -0.966483 */
