DELETE FROM `landblock_instance` WHERE `landblock` = 0x7208;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x77208002, 24487, 0x72080000, 45.6093, 131.851, -0.095, 0.979924, 0, 0, -0.19937, False, '2005-02-09 10:00:00'); /* Ulgrim Island Beach Gen */
/* @teleloc 0x72080000 [45.609299 131.850998 -0.095000] 0.979924 0.000000 0.000000 -0.199370 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x77208003, 24487, 0x72080000, 69.9181, 113.336, -0.095, 0.338999, 0, 0, -0.940787, False, '2005-02-09 10:00:00'); /* Ulgrim Island Beach Gen */
/* @teleloc 0x72080000 [69.918098 113.335999 -0.095000] 0.338999 0.000000 0.000000 -0.940787 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x77208004, 24487, 0x72080000, 81.1533, 143.698, 0.005, 0.998435, 0, 0, -0.05593, False, '2005-02-09 10:00:00'); /* Ulgrim Island Beach Gen */
/* @teleloc 0x72080000 [81.153297 143.697998 0.005000] 0.998435 0.000000 0.000000 -0.055930 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x77208006, 24487, 0x72080000, 21.9468, 191.642, -0.095, 0.968008, 0, 0, -0.25092, False, '2005-02-09 10:00:00'); /* Ulgrim Island Beach Gen */
/* @teleloc 0x72080000 [21.946800 191.641998 -0.095000] 0.968008 0.000000 0.000000 -0.250920 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x77208007, 73217237, 0x72080038, 157.47, 172.312, -0.045, 0.190296, 0, 0, 0.981727, False, '2025-08-10 19:44:04'); /* Islandgolemgen */
/* @teleloc 0x72080038 [157.470001 172.311996 -0.045000] 0.190296 0.000000 0.000000 0.981727 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x77208008, 73217237, 0x7208001E, 84.1651, 133.62, 0.055, 0.666459, 0, 0, 0.745542, False, '2025-08-10 19:44:14'); /* Islandgolemgen */
/* @teleloc 0x7208001E [84.165100 133.619995 0.055000] 0.666459 0.000000 0.000000 0.745542 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x77208009, 73217237, 0x72080015, 66.0135, 116.047, -0.045, 0.367286, 0, 0, 0.930108, False, '2025-08-10 19:44:16'); /* Islandgolemgen */
/* @teleloc 0x72080015 [66.013496 116.046997 -0.045000] 0.367286 0.000000 0.000000 0.930108 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7720800A, 73217237, 0x72080033, 144.002, 57.0056, 0.055201, -0.400338, 0, 0, 0.916368, False, '2025-08-10 19:44:23'); /* Islandgolemgen */
/* @teleloc 0x72080033 [144.001999 57.005600 0.055201] -0.400338 0.000000 0.000000 0.916368 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7720800B, 73217237, 0x72080038, 154.625, 168.152, -0.395, 0.821234, 0, 0, 0.570592, False, '2025-08-12 12:39:28'); /* Islandgolemgen */
/* @teleloc 0x72080038 [154.625000 168.151993 -0.395000] 0.821234 0.000000 0.000000 0.570592 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7720800C, 73217237, 0x72080010, 47.5299, 190.486, -0.045, 0.549163, 0, 0, 0.835715, False, '2025-08-12 12:39:36'); /* Islandgolemgen */
/* @teleloc 0x72080010 [47.529900 190.485992 -0.045000] 0.549163 0.000000 0.000000 0.835715 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7720800D, 83217237, 0x7208001F, 95.5652, 145.64, -0.045, -0.627874, 0, 0, -0.778315, False, '2025-09-04 22:34:07'); /* Trophy Keeper of Honor */
/* @teleloc 0x7208001F [95.565201 145.639999 -0.045000] -0.627874 0.000000 0.000000 -0.778315 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7720800E, 83217237, 0x7208001E, 81.4029, 139.189, 0.055, -0.357738, 0, 0, -0.933822, False, '2025-09-04 22:34:08'); /* Trophy Keeper of Honor */
/* @teleloc 0x7208001E [81.402901 139.188995 0.055000] -0.357738 0.000000 0.000000 -0.933822 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7720800F, 83217237, 0x72080016, 69.8983, 123.8, -0.045, -0.385853, 0, 0, -0.922561, False, '2025-09-04 22:34:10'); /* Trophy Keeper of Honor */
/* @teleloc 0x72080016 [69.898300 123.800003 -0.045000] -0.385853 0.000000 0.000000 -0.922561 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x77208010, 83217237, 0x7208000F, 41.4268, 155.267, -0.845, -0.991315, 0, 0, -0.131509, False, '2025-09-04 22:34:14'); /* Trophy Keeper of Honor */
/* @teleloc 0x7208000F [41.426800 155.266998 -0.845000] -0.991315 0.000000 0.000000 -0.131509 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x77208011, 83217237, 0x72080010, 32.5305, 181.9535, -0.045, -0.970633, 0, 0, -0.240564, False, '2025-09-04 22:34:15'); /* Trophy Keeper of Honor */
/* @teleloc 0x72080010 [32.530499 181.953506 -0.045000] -0.970633 0.000000 0.000000 -0.240564 */
