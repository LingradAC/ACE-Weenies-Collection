DELETE FROM `landblock_instance` WHERE `landblock` = 0xE3D5;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E3D5001, 12382137, 0xE3D50036, 147.879, 136.145, -0.395, -0.42273, 0, 0, 0.906256, False, '2025-07-19 07:06:10'); /* Mutated Tusker Generator */
/* @teleloc 0xE3D50036 [147.878998 136.145004 -0.395000] -0.422730 0.000000 0.000000 0.906256 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E3D5002, 12382138, 0xE3D50004, 5.25671, 72.3218, -0.045, 0.58952, 0, 0, 0.807754, False, '2025-07-19 09:57:03'); /* Picker Golem Generator */
/* @teleloc 0xE3D50004 [5.256710 72.321800 -0.045000] 0.589520 0.000000 0.000000 0.807754 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E3D5003, 12382137, 0xE3D5003C, 171.556, 87.6059, -0.395, 0.624592, 0, 0, 0.780951, False, '2025-07-20 13:51:12'); /* Mutated Tusker Generator */
/* @teleloc 0xE3D5003C [171.556000 87.605904 -0.395000] 0.624592 0.000000 0.000000 0.780951 */
