DELETE FROM `landblock_instance` WHERE `landblock` = 0xF668;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F668004, 490116, 0xF6680031, 152.949, 21.7369, 3.30925, 0.66384, 0, 0, 0.747875, False, '2023-12-30 12:56:04'); /* Outpost Small Tree */
/* @teleloc 0xF6680031 [152.949005 21.736900 3.309250] 0.663840 0.000000 0.000000 0.747875 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F668006, 490116, 0xF6680021, 119.957, 20.3011, 3.74676, 0.456041, 0, 0, 0.889959, False, '2023-12-30 12:56:06'); /* Outpost Small Tree */
/* @teleloc 0xF6680021 [119.957001 20.301100 3.746760] 0.456041 0.000000 0.000000 0.889959 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F668007, 490118, 0xF6680033, 154.611, 64.7551, 2.93925, 0.974384, 0, 0, -0.22489, False, '2023-12-30 13:02:36'); /* Outpost Large Tree2 */
/* @teleloc 0xF6680033 [154.610992 64.755096 2.939250] 0.974384 0.000000 0.000000 -0.224890 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F668008, 490117, 0xF668003D, 173.194, 110.117, 2.87861, 0.961795, 0, 0, -0.273769, False, '2023-12-30 13:02:43'); /* Outpost Large Tree */
/* @teleloc 0xF668003D [173.194000 110.116997 2.878610] 0.961795 0.000000 0.000000 -0.273769 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F668009, 490116, 0xF6680011, 48.383, 20.1199, 2.37834, -0.997592, 0, 0, 0.069356, False, '2023-12-30 13:04:05'); /* Outpost Small Tree */
/* @teleloc 0xF6680011 [48.382999 20.119900 2.378340] -0.997592 0.000000 0.000000 0.069356 */
