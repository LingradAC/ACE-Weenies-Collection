DELETE FROM `landblock_instance` WHERE `landblock` = 0xE524;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E524000,  8474, 0xE5240100, 23.0794, 23.9524, -5.195, 0.930442, 0, 0, -0.36644, False, '2005-02-09 10:00:00'); /* Mud Cave */
/* @teleloc 0xE5240100 [23.079399 23.952400 -5.195000] 0.930442 0.000000 0.000000 -0.366440 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E524001, 27860, 0xE5240100, 18.9549, 23.3063, -5.195, -0.178423, 0, 0, -0.983954,  True, '2005-02-09 10:00:00'); /* Sallow Moarsman */
/* @teleloc 0xE5240100 [18.954901 23.306299 -5.195000] -0.178423 0.000000 0.000000 -0.983954 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E524002, 27859, 0xE5240100, 21.7581, 18.431, -5.195, -0.628314, 0, 0, -0.77796,  True, '2005-02-09 10:00:00'); /* Pallid Moarsman */
/* @teleloc 0xE5240100 [21.758101 18.431000 -5.195000] -0.628314 0.000000 0.000000 -0.777960 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E524003, 27859, 0xE5240000, 11.8337, 5.10654, 0.005, -0.672271, 0, 0, -0.740305,  True, '2005-02-09 10:00:00'); /* Pallid Moarsman */
/* @teleloc 0xE5240000 [11.833700 5.106540 0.005000] -0.672271 0.000000 0.000000 -0.740305 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E524004, 27860, 0xE5240000, 6.48042, 13.3014, 0.005, -0.062232, 0, 0, -0.998062,  True, '2005-02-09 10:00:00'); /* Sallow Moarsman */
/* @teleloc 0xE5240000 [6.480420 13.301400 0.005000] -0.062232 0.000000 0.000000 -0.998062 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E524005,  4219, 0xE5240100, 20.5286, 14.9529, -5.195, -0.395185, 0, 0, -0.918602, False, '2005-02-09 10:00:00'); /* Linkable Monster Generator ( 7 Min.) */
/* @teleloc 0xE5240100 [20.528601 14.952900 -5.195000] -0.395185 0.000000 0.000000 -0.918602 */

INSERT INTO `landblock_instance_link` (`parent_GUID`, `child_GUID`, `last_Modified`)
VALUES (0x7E524005, 0x7E524001, '2005-02-09 10:00:00') /* Sallow Moarsman (27860) */
     , (0x7E524005, 0x7E524002, '2005-02-09 10:00:00') /* Pallid Moarsman (27859) */
     , (0x7E524005, 0x7E524003, '2005-02-09 10:00:00') /* Pallid Moarsman (27859) */
     , (0x7E524005, 0x7E524004, '2005-02-09 10:00:00') /* Sallow Moarsman (27860) */;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E524006, 24411, 0xE5240030, 143.608, 190.694, -0.045, 0.493838, 0, 0, 0.869554, False, '2025-08-14 11:20:13'); /* Asheron Invasion Extreme Generators */
/* @teleloc 0xE5240030 [143.608002 190.694000 -0.045000] 0.493838 0.000000 0.000000 0.869554 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E524007, 24411, 0xE524001F, 95.5722, 164.719, -0.045, 0.617101, 0, 0, 0.786884, False, '2025-08-14 11:20:16'); /* Asheron Invasion Extreme Generators */
/* @teleloc 0xE524001F [95.572197 164.718994 -0.045000] 0.617101 0.000000 0.000000 0.786884 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E524008, 24411, 0xE5240007, 16.1635, 152.25, -0.045, 0.723794, 0, 0, 0.690016, False, '2025-08-14 11:20:21'); /* Asheron Invasion Extreme Generators */
/* @teleloc 0xE5240007 [16.163500 152.250000 -0.045000] 0.723794 0.000000 0.000000 0.690016 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E524009, 24411, 0xE5240022, 111.659, 24.2236, 20.0736, 0.964192, 0, 0, -0.265205, False, '2025-08-14 11:21:14'); /* Asheron Invasion Extreme Generators */
/* @teleloc 0xE5240022 [111.658997 24.223600 20.073601] 0.964192 0.000000 0.000000 -0.265205 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E52400A, 24411, 0xE524002C, 137.914, 72.1015, 22.0635, 0.900385, 0, 0, -0.435095, False, '2025-08-14 11:21:18'); /* Asheron Invasion Extreme Generators */
/* @teleloc 0xE524002C [137.914001 72.101501 22.063499] 0.900385 0.000000 0.000000 -0.435095 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E52400B, 24411, 0xE5240040, 168.219, 178.4962, 0.055, 0.974655, 0, 0, -0.223714, False, '2025-08-14 11:21:27'); /* Asheron Invasion Extreme Generators */
/* @teleloc 0xE5240040 [168.218994 178.496201 0.055000] 0.974655 0.000000 0.000000 -0.223714 */
