DELETE FROM `landblock_instance` WHERE `landblock` = 0x016C;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7016C000, 700012, 0x016C01BD, 54.3575, -44.04, 0.01, -0.999599, 0, 0, -0.028311, False, '2025-07-18 11:23:48'); /* Nexus Buffer Mage */
/* @teleloc 0x016C01BD [54.357498 -44.040001 0.010000] -0.999599 0.000000 0.000000 -0.028311 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7016C001, 86653870, 0x016C01C2, 56.3849, -25.495, -0.0125, 0.015811, 0, 0, 0.999875, False, '2025-07-25 15:27:16'); /* Asheron */
/* @teleloc 0x016C01C2 [56.384899 -25.495001 -0.012500] 0.015811 0.000000 0.000000 0.999875 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7016C002, 86653868, 0x016C01BC, 53.5324, -25.489, 0.0075, 0.015811, 0, 0, 0.999875, False, '2025-07-25 15:27:22'); /* Bael'Zharon */
/* @teleloc 0x016C01BC [53.532398 -25.489000 0.007500] 0.015811 0.000000 0.000000 0.999875 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7016C003, 931271772, 0x016C01BC, 49.206, -31.935, 0.06, 0.707107, 0, 0, -0.707107, False, '2025-09-04 21:36:02'); /* non pk trap */
/* @teleloc 0x016C01BC [49.206001 -31.934999 0.060000] 0.707107 0.000000 0.000000 -0.707107 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7016C004, 931271772, 0x016C01C2, 58.7855, -31.0807, 0.055, 0.845505, 0, 0, -0.533968, False, '2025-09-04 21:36:04'); /* non pk trap */
/* @teleloc 0x016C01C2 [58.785500 -31.080700 0.055000] 0.845505 0.000000 0.000000 -0.533968 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7016C005, 931271772, 0x016C01C3, 59.6416, -37.9798, 0.055, -0.090916, 0, 0, -0.995859, False, '2025-09-04 21:36:06'); /* non pk trap */
/* @teleloc 0x016C01C3 [59.641602 -37.979801 0.055000] -0.090916 0.000000 0.000000 -0.995859 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7016C006, 931271772, 0x016C01BD, 50.74248, -41.75375, 0.055, -0.703603, 0, 0, -0.710593, False, '2025-09-04 21:36:07'); /* non pk trap */
/* @teleloc 0x016C01BD [50.742481 -41.753750 0.055000] -0.703603 0.000000 0.000000 -0.710593 */
