DELETE FROM `landblock_instance` WHERE `landblock` = 0xE424;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E424000, 24411, 0xE424002E, 134.393, 143.199, -0.045, -0.522683, 0, 0, -0.852527, False, '2025-08-14 11:20:28'); /* Asheron Invasion Extreme Generators */
/* @teleloc 0xE424002E [134.393005 143.199005 -0.045000] -0.522683 0.000000 0.000000 -0.852527 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E424001, 24411, 0xE4240016, 60.6918, 127.948, -0.045, -0.555479, 0, 0, -0.831531, False, '2025-08-14 11:20:34'); /* Asheron Invasion Extreme Generators */
/* @teleloc 0xE4240016 [60.691799 127.947998 -0.045000] -0.555479 0.000000 0.000000 -0.831531 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E424002, 24411, 0xE424000B, 38.0198, 71.7554, -0.045, 0.150383, 0, 0, -0.988628, False, '2025-08-14 11:20:37'); /* Asheron Invasion Extreme Generators */
/* @teleloc 0xE424000B [38.019798 71.755402 -0.045000] 0.150383 0.000000 0.000000 -0.988628 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E424003, 24411, 0xE4240022, 96.2934, 36.3883, -0.045, 0.614318, 0, 0, -0.789059, False, '2025-08-14 11:20:42'); /* Asheron Invasion Extreme Generators */
/* @teleloc 0xE4240022 [96.293404 36.388302 -0.045000] 0.614318 0.000000 0.000000 -0.789059 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E424004, 24411, 0xE4240039, 169.6552, 12.30045, -0.045, 0.414934, 0, 0, -0.909852, False, '2025-08-14 11:20:47'); /* Asheron Invasion Extreme Generators */
/* @teleloc 0xE4240039 [169.655197 12.300450 -0.045000] 0.414934 0.000000 0.000000 -0.909852 */
