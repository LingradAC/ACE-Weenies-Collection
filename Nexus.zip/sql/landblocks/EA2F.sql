DELETE FROM `landblock_instance` WHERE `landblock` = 0xEA2F;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7EA2F000, 99235757, 0xEA2F0028, 99.3865, 191.975, 116.918, -0.938111, 0, 0, 0.346335, False, '2025-08-29 14:07:37');
/* @teleloc 0xEA2F0028 [99.386497 191.975006 116.917999] -0.938111 0.000000 0.000000 0.346335 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7EA2F001, 99235757, 0xEA2F0028, 105.941, 187.361, 113.195, -0.145056, 0, 0, 0.989424, False, '2025-08-29 14:07:39');
/* @teleloc 0xEA2F0028 [105.941002 187.360992 113.195000] -0.145056 0.000000 0.000000 0.989424 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7EA2F002, 99235757, 0xEA2F0027, 108.651, 161.851, 103.788, -0.074833, 0, 0, 0.997196, False, '2025-08-29 14:07:40');
/* @teleloc 0xEA2F0027 [108.651001 161.850998 103.788002] -0.074833 0.000000 0.000000 0.997196 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7EA2F003, 99235757, 0xEA2F002E, 136.804, 140.629, 87.3299, -0.652514, 0, 0, 0.757776, False, '2025-08-29 14:07:43');
/* @teleloc 0xEA2F002E [136.804001 140.628998 87.329903] -0.652514 0.000000 0.000000 0.757776 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7EA2F004, 99235757, 0xEA2F003E, 186.067, 133.415, 64.9987, -0.826802, 0, 0, 0.562494, False, '2025-08-29 14:07:47');
/* @teleloc 0xEA2F003E [186.067001 133.414993 64.998703] -0.826802 0.000000 0.000000 0.562494 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7EA2F005, 99235757, 0xEA2F0038, 156.737, 189.359, 92.8062, -0.875399, 0, 0, 0.483401, False, '2025-08-29 14:08:29');
/* @teleloc 0xEA2F0038 [156.737000 189.358994 92.806198] -0.875399 0.000000 0.000000 0.483401 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7EA2F006, 99235757, 0xEA2F0028, 119.7094, 182.2323, 106.896, -0.376981, 0, 0, -0.926221, False, '2025-08-29 14:08:34');
/* @teleloc 0xEA2F0028 [119.709396 182.232300 106.896004] -0.376981 0.000000 0.000000 -0.926221 */
