DELETE FROM `landblock_instance` WHERE `landblock` = 0xF4D5;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F4D5001, 5000296, 0xF4D50008, 14.0059, 182.191, 0.055, -0.396638, 0, 0, 0.917975, False, '2020-01-13 01:43:16'); /* Plant */
/* @teleloc 0xF4D50008 [14.005900 182.190994 0.055000] -0.396638 0.000000 0.000000 0.917975 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F4D5002, 5000296, 0xF4D50008, 21.3767, 179.221, 0.055, 0.740878, 0, 0, 0.671639, False, '2020-01-13 01:43:17'); /* Plant */
/* @teleloc 0xF4D50008 [21.376699 179.220993 0.055000] 0.740878 0.000000 0.000000 0.671639 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F4D5003, 5000661, 0xF4D50028, 117.679, 175.545, 0.055, 0.851461, 0, 0, -0.524418, False, '2020-01-13 01:43:25'); /* Plant */
/* @teleloc 0xF4D50028 [117.679001 175.544998 0.055000] 0.851461 0.000000 0.000000 -0.524418 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F4D5004, 5000294, 0xF4D50030, 120.139, 176.785, -0.045, 0.851461, 0, 0, -0.524418, False, '2020-01-13 01:43:26'); /* Plant */
/* @teleloc 0xF4D50030 [120.139000 176.785004 -0.045000] 0.851461 0.000000 0.000000 -0.524418 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F4D5005, 5000654, 0xF4D50008, 17.2731, 180.452, 0.005, 0.986832, 0, 0, -0.161748, False, '2019-07-27 14:14:00');
/* @teleloc 0xF4D50008 [17.273100 180.451996 0.005000] 0.986832 0.000000 0.000000 -0.161748 */
