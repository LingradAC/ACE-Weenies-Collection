DELETE FROM `landblock_instance` WHERE `landblock` = 0xA92B;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7A92B000,  9401, 0xA92B0002, 15.71889, 35.57872, 111.5847, 0.974968, 0, 0, -0.222345, False, '2025-08-12 04:14:45'); /* Dread Mattekar */
/* @teleloc 0xA92B0002 [15.718890 35.578720 111.584702] 0.974968 0.000000 0.000000 -0.222345 */
