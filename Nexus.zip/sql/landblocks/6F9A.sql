DELETE FROM `landblock_instance` WHERE `landblock` = 0x6F9A;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x76F9A000,  5773, 0x6F9A0029, 133.732, 7.14826, 240.005, 0.049719, 0, 0, -0.998763, False, '2025-08-04 00:53:03'); /* Town Crier */
/* @teleloc 0x6F9A0029 [133.731995 7.148260 240.005005] 0.049719 0.000000 0.000000 -0.998763 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x76F9A002, 86653855, 0x6F9A0032, 161.395, 24.0992, 240.038, -0.999999, 0, 0, 0.001321, False, '2025-08-04 00:58:09'); /* PILLAR3 */
/* @teleloc 0x6F9A0032 [161.395004 24.099199 240.037994] -0.999999 0.000000 0.000000 0.001321 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x76F9A003, 86653855, 0x6F9A0032, 166.355, 24.0865, 240.041, -0.999999, 0, 0, 0.001321, False, '2025-08-04 00:58:12'); /* PILLAR3 */
/* @teleloc 0x6F9A0032 [166.354996 24.086500 240.041000] -0.999999 0.000000 0.000000 0.001321 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x76F9A004, 43065, 0x6F9A0032, 163.989, 24.5141, 239.851, -0.99972, 0, 0, -0.023677, False, '2025-08-04 00:58:22'); /* Portal to Town Network */
/* @teleloc 0x6F9A0032 [163.988998 24.514099 239.850998] -0.999720 0.000000 0.000000 -0.023677 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x76F9A006, 996000, 0x6F9A0022, 103.781, 43.9346, 240.005, 0, 0, 0, 1, False, '2025-08-04 01:35:00'); /* Halzar */
/* @teleloc 0x6F9A0022 [103.780998 43.934601 240.005005] 0.000000 0.000000 0.000000 1.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x76F9A007, 321777, 0x6F9A0022, 102.601, 43.8716, 240.005, 0, 0, 0, 1, False, '2025-08-04 01:41:54'); /* Sargren */
/* @teleloc 0x6F9A0022 [102.600998 43.871601 240.005005] 0.000000 0.000000 0.000000 1.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x76F9A008, 43398, 0x6F9A0022, 101.099, 43.7406, 240.006, 0.093747, 0, 0, -0.995596, False, '2025-08-04 02:23:30'); /* Nalicana */
/* @teleloc 0x6F9A0022 [101.098999 43.740601 240.005997] 0.093747 0.000000 0.000000 -0.995596 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x76F9A009, 43405, 0x6F9A0022, 105.327, 43.8377, 240.007, -0.102114, 0, 0, 0.994773, False, '2025-08-04 02:24:05'); /* Shade of Lady Adja */
/* @teleloc 0x6F9A0022 [105.327003 43.837700 240.007004] -0.102114 0.000000 0.000000 0.994773 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x76F9A00A, 43404, 0x6F9A0022, 106.891, 44.1991, 240.01, -0.159781, 0, 0, 0.987152, False, '2025-08-04 02:24:51'); /* Ka'hiri */
/* @teleloc 0x6F9A0022 [106.890999 44.199100 240.009995] -0.159781 0.000000 0.000000 0.987152 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x76F9A00B, 43403, 0x6F9A0022, 99.2722, 43.9352, 240.007, -0.123136, 0, 0, 0.99239, False, '2025-08-04 02:25:15'); /* Liam of Gelid */
/* @teleloc 0x6F9A0022 [99.272202 43.935200 240.007004] -0.123136 0.000000 0.000000 0.992390 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x76F9A00C, 43406, 0x6F9A0022, 108.374, 44.1746, 240.006, 0.138146, 0, 0, -0.990412, False, '2025-08-04 02:25:53'); /* Lord Tyragar */
/* @teleloc 0x6F9A0022 [108.374001 44.174599 240.005997] 0.138146 0.000000 0.000000 -0.990412 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x76F9A00D, 423481288, 0x6F9A0039, 189.429, 11.0674, 239.937, -0.694419, 0, 0, 0.719571, False, '2025-08-04 02:32:06'); /* Portal to Ravaged Island */
/* @teleloc 0x6F9A0039 [189.429001 11.067400 239.936996] -0.694419 0.000000 0.000000 0.719571 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x76F9A00E, 86653855, 0x6F9A0031, 157.527, 23.9855, 240.055, 0.004495, 0, 0, 0.99999, False, '2025-08-04 16:49:47'); /* PILLAR3 */
/* @teleloc 0x6F9A0031 [157.526993 23.985500 240.054993] 0.004495 0.000000 0.000000 0.999990 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x76F9A00F, 86653855, 0x6F9A0031, 153.824, 23.971, 240.055, -0.070447, 0, 0, 0.997516, False, '2025-08-04 16:49:54'); /* PILLAR3 */
/* @teleloc 0x6F9A0031 [153.824005 23.971001 240.054993] -0.070447 0.000000 0.000000 0.997516 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x76F9A011, 22849238, 0x6F9A0039, 182.917, 23.1754, 240.013, -0.24447, 0, 0, -0.969657, False, '2025-08-06 19:20:56'); /* Crucible Golem */
/* @teleloc 0x6F9A0039 [182.917007 23.175400 240.013000] -0.244470 0.000000 0.000000 -0.969657 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x76F9A012, 44950, 0x6F9A0022, 97.0489, 38.2827, 240.006, -0.693448, 0, 0, 0.720507, False, '2025-08-10 16:58:14'); /* Chafulumisa */
/* @teleloc 0x6F9A0022 [97.048897 38.282700 240.005997] -0.693448 0.000000 0.000000 0.720507 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x76F9A014, 86653897, 0x6F9A0021, 97.751, 6.23918, 240.055, -0.560997, 0, 0, 0.827818, False, '2025-08-12 21:38:24'); /* LIGHTNINGLIGHTSMULTICOLORED1 */
/* @teleloc 0x6F9A0021 [97.750999 6.239180 240.054993] -0.560997 0.000000 0.000000 0.827818 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x76F9A015, 198181, 0x6F9A0021, 99.1853, 4.51657, 240.005, -0.783213, 0, 0, 0.621753, False, '2025-08-12 23:55:59'); /* Geilla */
/* @teleloc 0x6F9A0021 [99.185303 4.516570 240.005005] -0.783213 0.000000 0.000000 0.621753 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x76F9A016, 666999, 0x6F9A0039, 186.458, 19.2216, 240.01, -0.459344, 0, 0, -0.888259, False, '2025-08-26 16:22:18'); /* The Bound Arbiter */
/* @teleloc 0x6F9A0039 [186.457993 19.221600 240.009995] -0.459344 0.000000 0.000000 -0.888259 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x76F9A018, 43941, 0x6F9A0022, 97.3374, 34.0735, 240.006, -0.895935, 0, 0, 0.444185, False, '2025-08-27 18:53:55'); /* Fianhe */
/* @teleloc 0x6F9A0022 [97.337402 34.073502 240.005997] -0.895935 0.000000 0.000000 0.444185 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x76F9A019, 4200152, 0x6F9A003B, 168.929, 51.5013, 233.274, -0.030104, 0, 0, -0.999547, False, '2025-09-10 21:51:15'); /* Gate */
/* @teleloc 0x6F9A003B [168.929001 51.501301 233.274002] -0.030104 0.000000 0.000000 -0.999547 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x76F9A01A, 4200152, 0x6F9A0033, 153.964, 50.8744, 234.139, -0.021038, 0, 0, -0.999779, False, '2025-09-10 21:51:20'); /* Gate */
/* @teleloc 0x6F9A0033 [153.964005 50.874401 234.139008] -0.021038 0.000000 0.000000 -0.999779 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x76F9A01B, 4200152, 0x6F9A002B, 137.682, 50.6763, 235.324, 0.04481, 0, 0, -0.998996, False, '2025-09-10 21:51:24'); /* Gate */
/* @teleloc 0x6F9A002B [137.682007 50.676300 235.324005] 0.044810 0.000000 0.000000 -0.998996 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x76F9A01C, 4200152, 0x6F9A002B, 123.68, 48.7863, 238.917, -0.028252, 0, 0, -0.999601, False, '2025-09-10 21:51:32'); /* Gate */
/* @teleloc 0x6F9A002B [123.680000 48.786301 238.917007] -0.028252 0.000000 0.000000 -0.999601 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x76F9A01D, 4200152, 0x6F9A0023, 107.724, 48.6143, 239.594, -0.035454, 0, 0, -0.999371, False, '2025-09-10 21:51:38'); /* Gate */
/* @teleloc 0x6F9A0023 [107.723999 48.614300 239.593994] -0.035454 0.000000 0.000000 -0.999371 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x76F9A01E, 4200152, 0x6F9A001A, 93.0379, 46.945, 239.561, 0.307443, 0, 0, -0.951567, False, '2025-09-10 21:51:43'); /* Gate */
/* @teleloc 0x6F9A001A [93.037903 46.945000 239.561005] 0.307443 0.000000 0.000000 -0.951567 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x76F9A01F, 4200152, 0x6F9A001A, 84.0951, 35.7006, 238.071, 0.73328, 0, 0, -0.679927, False, '2025-09-10 21:51:48'); /* Gate */
/* @teleloc 0x6F9A001A [84.095100 35.700600 238.070999] 0.733280 0.000000 0.000000 -0.679927 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x76F9A020, 4200152, 0x6F9A0019, 86.3653, 16.4721, 238.449, 0.74084, 0, 0, -0.671681, False, '2025-09-10 21:51:52'); /* Gate */
/* @teleloc 0x6F9A0019 [86.365303 16.472099 238.449005] 0.740840 0.000000 0.000000 -0.671681 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x76F9A021, 4200152, 0x6F9A0019, 88.9385, 0.855002, 238.878, 0.731033, 0, 0, -0.682343, False, '2025-09-10 21:51:57'); /* Gate */
/* @teleloc 0x6F9A0019 [88.938499 0.855002 238.878006] 0.731033 0.000000 0.000000 -0.682343 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x76F9A022, 4200152, 0x6F9A003B, 186.682, 48.3634, 234.195, 0.946607, 0, 0, -0.32239, False, '2025-09-10 21:52:12'); /* Gate */
/* @teleloc 0x6F9A003B [186.682007 48.363400 234.195007] 0.946607 0.000000 0.000000 -0.322390 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x76F9A023, 743223317, 0x6F9A0031, 155.887, 23.7038, 239.937, -0.999648, 0, 0, -0.026528, False, '2025-09-10 21:57:05'); /* White View */
/* @teleloc 0x6F9A0031 [155.886993 23.703800 239.936996] -0.999648 0.000000 0.000000 -0.026528 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x76F9A024, 42145216, 0x6F9A0029, 132.3486, 8.839309, 240.005, -0.67073, 0, 0, -0.741702, False, '2025-09-10 21:58:23'); /* Tingdale the Barterer */
/* @teleloc 0x6F9A0029 [132.348602 8.839309 240.005005] -0.670730 0.000000 0.000000 -0.741702 */
