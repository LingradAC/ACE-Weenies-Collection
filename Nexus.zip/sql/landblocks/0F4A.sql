DELETE FROM `landblock_instance` WHERE `landblock` = 0x0F4A;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70F4A000, 56843983, 0x0F4A0011, 53.97696, 1.274226, 0.055, 0.862751, 0, 0, -0.505629, False, '2025-07-23 07:10:42');
/* @teleloc 0x0F4A0011 [53.976959 1.274226 0.055000] 0.862751 0.000000 0.000000 -0.505629 */
