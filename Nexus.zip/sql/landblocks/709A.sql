DELETE FROM `landblock_instance` WHERE `landblock` = 0x709A;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7709A000, 4200152, 0x709A0002, 10.5979, 35.6798, 234.486, 0.930505, 0, 0, -0.36628, False, '2025-09-10 21:52:19'); /* Gate */
/* @teleloc 0x709A0002 [10.597900 35.679798 234.485992] 0.930505 0.000000 0.000000 -0.366280 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7709A001, 4200152, 0x709A0001, 17.7825, 19.8262, 235.609, 0.622997, 0, 0, -0.782224, False, '2025-09-10 21:52:23'); /* Gate */
/* @teleloc 0x709A0001 [17.782499 19.826200 235.608994] 0.622997 0.000000 0.000000 -0.782224 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7709A002, 4200152, 0x709A0001, 14.40029, 4.178408, 234.7513, 0.561178, 0, 0, -0.827695, False, '2025-09-10 21:52:27'); /* Gate */
/* @teleloc 0x709A0001 [14.400290 4.178408 234.751297] 0.561178 0.000000 0.000000 -0.827695 */
