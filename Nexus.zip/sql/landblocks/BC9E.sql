DELETE FROM `landblock_instance` WHERE `landblock` = 0xBC9E;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7BC9E000, 41518, 0xBC9E0100, 9.52482, 108.187, 70.005, 0.758865, 0, 0, -0.651248, False, '2021-11-01 00:00:00'); /* Emily Yarow */
/* @teleloc 0xBC9E0100 [9.524820 108.186996 70.004997] 0.758865 0.000000 0.000000 -0.651248 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7BC9E001, 41519, 0xBC9E0100, 10.0851, 106.211, 70.005, -0.918744, 0, 0, 0.394854, False, '2021-11-01 00:00:00'); /* Gustuv Lansdown */
/* @teleloc 0xBC9E0100 [10.085100 106.210999 70.004997] -0.918744 0.000000 0.000000 0.394854 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7BC9E002,  5590, 0xBC9E0005, 4.708497, 102.6463, 69.937, 0.411269, 0, 0, -0.911514, False, '2025-07-22 09:27:38'); /* Night Club Portal */
/* @teleloc 0xBC9E0005 [4.708497 102.646301 69.936996] 0.411269 0.000000 0.000000 -0.911514 */
