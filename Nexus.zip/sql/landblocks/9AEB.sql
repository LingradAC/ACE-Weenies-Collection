DELETE FROM `landblock_instance` WHERE `landblock` = 0x9AEB;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x79AEB000,   412, 0x9AEB0000, 82.4022, 133.949, 20, 0.336683, 0, 0, -0.941618, False, '2005-02-09 10:00:00'); /* Door */
/* @teleloc 0x9AEB0000 [82.402199 133.949005 20.000000] 0.336683 0.000000 0.000000 -0.941618 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x79AEB002,  6441, 0x9AEB0000, 88.2309, 130.8, 20.005, -0.869136, 0, 0, -0.494574, False, '2005-02-09 10:00:00'); /* Well */
/* @teleloc 0x9AEB0000 [88.230904 130.800003 20.004999] -0.869136 0.000000 0.000000 -0.494574 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x79AEB003, 571381, 0x9AEB0102, 82.5895, 130.278, 19.205, 0.900084, 0, 0, -0.435716, False, '2025-07-29 03:28:18'); /* Celdiseth's Apprentice */
/* @teleloc 0x9AEB0102 [82.589500 130.278000 19.205000] 0.900084 0.000000 0.000000 -0.435716 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x79AEB004, 86653879, 0x9AEB0102, 86.3597, 131.348, 19.205, 0.727414, 0, 0, -0.686199, False, '2025-07-29 13:20:17'); /* BLUE BALL OF LIGHT */
/* @teleloc 0x9AEB0102 [86.359703 131.348007 19.205000] 0.727414 0.000000 0.000000 -0.686199 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x79AEB005, 79235757, 0x9AEB0016, 71.6212, 131.827, 20.055, -0.346739, 0, 0, -0.937962, False, '2025-08-29 13:35:50');
/* @teleloc 0x9AEB0016 [71.621201 131.826996 20.055000] -0.346739 0.000000 0.000000 -0.937962 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x79AEB006, 79235757, 0x9AEB0016, 70.1597, 125.442, 20.055, 0.277644, 0, 0, -0.960684, False, '2025-08-29 13:35:51');
/* @teleloc 0x9AEB0016 [70.159698 125.442001 20.055000] 0.277644 0.000000 0.000000 -0.960684 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x79AEB007, 79235757, 0x9AEB001D, 86.8151, 118.866, 20.5276, 0.729163, 0, 0, -0.68434, False, '2025-08-29 13:35:53');
/* @teleloc 0x9AEB001D [86.815102 118.865997 20.527599] 0.729163 0.000000 0.000000 -0.684340 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x79AEB008, 79235757, 0x9AEB0026, 96.1872, 121.286, 20.055, 0.928697, 0, 0, -0.37084, False, '2025-08-29 13:35:55');
/* @teleloc 0x9AEB0026 [96.187202 121.286003 20.055000] 0.928697 0.000000 0.000000 -0.370840 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x79AEB009, 79235757, 0x9AEB0026, 101.409, 129.711, 20.055, 0.99766, 0, 0, -0.068374, False, '2025-08-29 13:35:56');
/* @teleloc 0x9AEB0026 [101.408997 129.710999 20.055000] 0.997660 0.000000 0.000000 -0.068374 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x79AEB00A, 79235757, 0x9AEB0026, 100.811, 138.797, 20.055, 0.985871, 0, 0, 0.16751, False, '2025-08-29 13:35:57');
/* @teleloc 0x9AEB0026 [100.810997 138.796997 20.055000] 0.985871 0.000000 0.000000 0.167510 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x79AEB00B, 79235757, 0x9AEB0027, 98.4164, 146.216, 20.055, 0.945953, 0, 0, 0.324304, False, '2025-08-29 13:35:58');
/* @teleloc 0x9AEB0027 [98.416397 146.216003 20.055000] 0.945953 0.000000 0.000000 0.324304 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x79AEB00C, 79235757, 0x9AEB001F, 94.9463, 153.931, 20.055, 0.945953, 0, 0, 0.324304, False, '2025-08-29 13:35:59');
/* @teleloc 0x9AEB001F [94.946297 153.931000 20.055000] 0.945953 0.000000 0.000000 0.324304 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x79AEB00D, 79235757, 0x9AEB001F, 91.5639, 159.588, 20.055, 0.862995, 0, 0, 0.505212, False, '2025-08-29 13:36:00');
/* @teleloc 0x9AEB001F [91.563904 159.587997 20.055000] 0.862995 0.000000 0.000000 0.505212 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x79AEB00E, 79235757, 0x9AEB001F, 86.51925, 164.0509, 20.055, 0.745855, 0, 0, 0.666109, False, '2025-08-29 13:36:01');
/* @teleloc 0x9AEB001F [86.519249 164.050903 20.055000] 0.745855 0.000000 0.000000 0.666109 */
