DELETE FROM `landblock_instance` WHERE `landblock` = 0xE2D4;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E2D4000, 12382138, 0xE2D40021, 96.75217, 7.255543, -0.395, -0.952687, 0, 0, -0.303952, False, '2025-07-19 09:59:59'); /* Picker Golem Generator */
/* @teleloc 0xE2D40021 [96.752167 7.255543 -0.395000] -0.952687 0.000000 0.000000 -0.303952 */
