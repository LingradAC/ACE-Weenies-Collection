DELETE FROM `landblock_instance` WHERE `landblock` = 0x03FC;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x703FC000,  9687, 0x03FC0100, 0.023, -43.404, -5.995, 0, 0, 0, -1,  True, '2005-02-09 10:00:00'); /* Storage */
/* @teleloc 0x03FC0100 [0.023000 -43.403999 -5.995000] 0.000000 0.000000 0.000000 -1.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x703FC001,  9687, 0x03FC0100, -3.608, -39.98, -5.995, -0.707107, 0, 0, -0.707107,  True, '2005-02-09 10:00:00'); /* Storage */
/* @teleloc 0x03FC0100 [-3.608000 -39.980000 -5.995000] -0.707107 0.000000 0.000000 -0.707107 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x703FC002,   278, 0x03FC0102, 4.75, -40, -6, 0.707107, 0, 0, -0.707107, False, '2005-02-09 10:00:00'); /* Door */
/* @teleloc 0x03FC0102 [4.750000 -40.000000 -6.000000] 0.707107 0.000000 0.000000 -0.707107 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x703FC003, 11697, 0x03FC0103, 14.0306, -20.114, -5.995, 0.696707, 0, 0, -0.717356,  True, '2005-02-09 10:00:00'); /* Floor Hook */
/* @teleloc 0x03FC0103 [14.030600 -20.114000 -5.995000] 0.696707 0.000000 0.000000 -0.717356 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x703FC004,  9686, 0x03FC0103, 10.1259, -15.604, -4.32, -0.999989, 0, 0, -0.004782,  True, '2005-02-09 10:00:00'); /* Wall Hook */
/* @teleloc 0x03FC0103 [10.125900 -15.604000 -4.320000] -0.999989 0.000000 0.000000 -0.004782 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x703FC005,   278, 0x03FC0105, 10, -24.75, -6, 0, 0, 0, -1, False, '2005-02-09 10:00:00'); /* Door */
/* @teleloc 0x03FC0105 [10.000000 -24.750000 -6.000000] 0.000000 0.000000 0.000000 -1.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x703FC006, 11697, 0x03FC0110, 20, 4.13086, -5.995, 1, 0, 0, 0,  True, '2005-02-09 10:00:00'); /* Floor Hook */
/* @teleloc 0x03FC0110 [20.000000 4.130860 -5.995000] 1.000000 0.000000 0.000000 0.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x703FC007,  9686, 0x03FC0110, 15.6054, -0.007371, -4.3, -0.707107, 0, 0, -0.707107,  True, '2005-02-09 10:00:00'); /* Wall Hook */
/* @teleloc 0x03FC0110 [15.605400 -0.007371 -4.300000] -0.707107 0.000000 0.000000 -0.707107 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x703FC008,   278, 0x03FC0112, 20, -4.75, -6, 0, 0, 0, -1, False, '2005-02-09 10:00:00'); /* Door */
/* @teleloc 0x03FC0112 [20.000000 -4.750000 -6.000000] 0.000000 0.000000 0.000000 -1.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x703FC009,  9686, 0x03FC0118, 19.9588, -15.1013, -4.3, 1, 0, 0, 0,  True, '2005-02-09 10:00:00'); /* Wall Hook */
/* @teleloc 0x03FC0118 [19.958799 -15.101300 -4.300000] 1.000000 0.000000 0.000000 0.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x703FC00A, 11697, 0x03FC0118, 20, -20, -5.995, 1, 0, 0, 0,  True, '2005-02-09 10:00:00'); /* Floor Hook */
/* @teleloc 0x03FC0118 [20.000000 -20.000000 -5.995000] 1.000000 0.000000 0.000000 0.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x703FC00B,  9686, 0x03FC0118, 15.1014, -19.9684, -4.3, -0.714424, 0, 0, -0.699713,  True, '2005-02-09 10:00:00'); /* Wall Hook */
/* @teleloc 0x03FC0118 [15.101400 -19.968399 -4.300000] -0.714424 0.000000 0.000000 -0.699713 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x703FC00C, 10661, 0x03FC0118, 20.0682, -18.5777, -5.995, 1, 0, 0, 0, False, '2005-02-09 10:00:00'); /* Villa */
/* @teleloc 0x03FC0118 [20.068199 -18.577700 -5.995000] 1.000000 0.000000 0.000000 0.000000 */

INSERT INTO `landblock_instance_link` (`parent_GUID`, `child_GUID`, `last_Modified`)
VALUES (0x703FC00C, 0x703FC000, '2005-02-09 10:00:00') /* Storage (9687) */
     , (0x703FC00C, 0x703FC001, '2005-02-09 10:00:00') /* Storage (9687) */
     , (0x703FC00C, 0x703FC003, '2005-02-09 10:00:00') /* Floor Hook (11697) */
     , (0x703FC00C, 0x703FC004, '2005-02-09 10:00:00') /* Wall Hook (9686) */
     , (0x703FC00C, 0x703FC006, '2005-02-09 10:00:00') /* Floor Hook (11697) */
     , (0x703FC00C, 0x703FC007, '2005-02-09 10:00:00') /* Wall Hook (9686) */
     , (0x703FC00C, 0x703FC009, '2005-02-09 10:00:00') /* Wall Hook (9686) */
     , (0x703FC00C, 0x703FC00A, '2005-02-09 10:00:00') /* Floor Hook (11697) */
     , (0x703FC00C, 0x703FC00B, '2005-02-09 10:00:00') /* Wall Hook (9686) */
     , (0x703FC00C, 0x703FC00D, '2005-02-09 10:00:00') /* Wall Hook (9686) */
     , (0x703FC00C, 0x703FC00E, '2005-02-09 10:00:00') /* Floor Hook (11697) */
     , (0x703FC00C, 0x703FC00F, '2005-02-09 10:00:00') /* Wall Hook (9686) */
     , (0x703FC00C, 0x703FC010, '2005-02-09 10:00:00') /* House Portal (11730) */
     , (0x703FC00C, 0x703FC012, '2005-02-09 10:00:00') /* Wall Hook (9686) */
     , (0x703FC00C, 0x703FC014, '2005-02-09 10:00:00') /* Floor Hook (11697) */
     , (0x703FC00C, 0x703FC015, '2005-02-09 10:00:00') /* Wall Hook (9686) */
     , (0x703FC00C, 0x703FC017, '2005-02-09 10:00:00') /* Wall Hook (9686) */
     , (0x703FC00C, 0x703FC018, '2005-02-09 10:00:00') /* Floor Hook (11697) */
     , (0x703FC00C, 0x703FC01A, '2005-02-09 10:00:00') /* Wall Hook (9686) */
     , (0x703FC00C, 0x703FC01B, '2005-02-09 10:00:00') /* Wall Hook (9686) */
     , (0x703FC00C, 0x703FC01C, '2005-02-09 10:00:00') /* Floor Hook (11697) */
     , (0x703FC00C, 0x703FC01D, '2005-02-09 10:00:00') /* Wall Hook (9686) */;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x703FC00D,  9686, 0x03FC0119, 19.9979, -34.8959, -4.3, 0.003683, 0, 0, -0.999993,  True, '2005-02-09 10:00:00'); /* Wall Hook */
/* @teleloc 0x03FC0119 [19.997900 -34.895901 -4.300000] 0.003683 0.000000 0.000000 -0.999993 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x703FC00E, 11697, 0x03FC0119, 20, -30, -5.995, 1, 0, 0, 0,  True, '2005-02-09 10:00:00'); /* Floor Hook */
/* @teleloc 0x03FC0119 [20.000000 -30.000000 -5.995000] 1.000000 0.000000 0.000000 0.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x703FC00F,  9686, 0x03FC0119, 24.8939, -29.9547, -4.3, 0.714424, 0, 0, -0.699713,  True, '2005-02-09 10:00:00'); /* Wall Hook */
/* @teleloc 0x03FC0119 [24.893900 -29.954700 -4.300000] 0.714424 0.000000 0.000000 -0.699713 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x703FC010, 11730, 0x03FC011F, 20, -50, -5.995, 1, 0, 0, 0,  True, '2005-02-09 10:00:00'); /* House Portal */
/* @teleloc 0x03FC011F [20.000000 -50.000000 -5.995000] 1.000000 0.000000 0.000000 0.000000 */

INSERT INTO `landblock_instance_link` (`parent_GUID`, `child_GUID`, `last_Modified`)
VALUES (0x703FC010, 0x703FC01F, '2005-02-09 10:00:00') /* Portal Linkspot (10762) */;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x703FC011,   568, 0x03FC0121, 20, -45.25, -6, 1, 0, 0, 0, False, '2005-02-09 10:00:00'); /* Door */
/* @teleloc 0x03FC0121 [20.000000 -45.250000 -6.000000] 1.000000 0.000000 0.000000 0.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x703FC012,  9686, 0x03FC012C, 29.8549, -34.3941, -4.3, -0.029195, 0, 0, -0.999574,  True, '2005-02-09 10:00:00'); /* Wall Hook */
/* @teleloc 0x03FC012C [29.854900 -34.394100 -4.300000] -0.029195 0.000000 0.000000 -0.999574 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x703FC013,   278, 0x03FC012E, 30, -25.25, -6, 1, 0, 0, 0, False, '2005-02-09 10:00:00'); /* Door */
/* @teleloc 0x03FC012E [30.000000 -25.250000 -6.000000] 1.000000 0.000000 0.000000 0.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x703FC014, 11697, 0x03FC012F, 40, -5.99258, -5.995, 1, 0, 0, 0,  True, '2005-02-09 10:00:00'); /* Floor Hook */
/* @teleloc 0x03FC012F [40.000000 -5.992580 -5.995000] 1.000000 0.000000 0.000000 0.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x703FC015,  9686, 0x03FC012F, 44.388, -10.2405, -4.3, 0.704517, 0, 0, -0.709687,  True, '2005-02-09 10:00:00'); /* Wall Hook */
/* @teleloc 0x03FC012F [44.388000 -10.240500 -4.300000] 0.704517 0.000000 0.000000 -0.709687 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x703FC016,   278, 0x03FC0131, 35.25, -10, -6, -0.707107, 0, 0, -0.707107, False, '2005-02-09 10:00:00'); /* Door */
/* @teleloc 0x03FC0131 [35.250000 -10.000000 -6.000000] -0.707107 0.000000 0.000000 -0.707107 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x703FC017,  9686, 0x03FC0132, -4.39398, -20.0622, 1.5, -0.696708, 0, 0, -0.717355,  True, '2005-02-09 10:00:00'); /* Wall Hook */
/* @teleloc 0x03FC0132 [-4.393980 -20.062201 1.500000] -0.696708 0.000000 0.000000 -0.717355 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x703FC018, 11697, 0x03FC0132, -0.752003, -24.0199, 0.005, -0.00525, 0, 0, 0.999986,  True, '2005-02-09 10:00:00'); /* Floor Hook */
/* @teleloc 0x03FC0132 [-0.752003 -24.019899 0.005000] -0.005250 0.000000 0.000000 0.999986 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x703FC019,   278, 0x03FC0134, 4.75, -20, 0, 0.707107, 0, 0, -0.707107, False, '2005-02-09 10:00:00'); /* Door */
/* @teleloc 0x03FC0134 [4.750000 -20.000000 0.000000] 0.707107 0.000000 0.000000 -0.707107 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x703FC01A,  9686, 0x03FC0139, 10.0959, -29.9483, 1.5, -0.354161, 0, 0, -0.935185,  True, '2005-02-09 10:00:00'); /* Wall Hook */
/* @teleloc 0x03FC0139 [10.095900 -29.948299 1.500000] -0.354161 0.000000 0.000000 -0.935185 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x703FC01B,  9686, 0x03FC013C, 29.9432, -20.0868, 1.5, 0.935786, 0, 0, -0.352568,  True, '2005-02-09 10:00:00'); /* Wall Hook */
/* @teleloc 0x03FC013C [29.943199 -20.086800 1.500000] 0.935786 0.000000 0.000000 -0.352568 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x703FC01C, 11697, 0x03FC0141, 44.1812, -30.4155, 0.005, 0.716417, 0, 0, -0.697672,  True, '2005-02-09 10:00:00'); /* Floor Hook */
/* @teleloc 0x03FC0141 [44.181198 -30.415501 0.005000] 0.716417 0.000000 0.000000 -0.697672 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x703FC01D,  9686, 0x03FC0141, 40.1348, -25.6021, 1.68725, 0.999755, 0, 0, -0.022137,  True, '2005-02-09 10:00:00'); /* Wall Hook */
/* @teleloc 0x03FC0141 [40.134800 -25.602100 1.687250] 0.999755 0.000000 0.000000 -0.022137 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x703FC01E,   278, 0x03FC0143, 35.25, -30, 0, -0.707107, 0, 0, -0.707107, False, '2005-02-09 10:00:00'); /* Door */
/* @teleloc 0x03FC0143 [35.250000 -30.000000 0.000000] -0.707107 0.000000 0.000000 -0.707107 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x703FC01F, 10762, 0x03FC011F, 26.4724, 36.2113, 171.205, -0.715555, 0, 0, -0.698557,  True, '2005-02-09 10:00:00'); /* Portal Linkspot */
/* @teleloc 0x03FC011F [26.472401 36.211300 171.205002] -0.715555 0.000000 0.000000 -0.698557 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x703FC02B, 5000216, 0x03FC0027, 116.318, 148.039, 0.055, 0.97506, 0, 0, 0.22194, False, '2025-07-07 03:58:42'); /* Gate */
/* @teleloc 0x03FC0027 [116.318001 148.039001 0.055000] 0.975060 0.000000 0.000000 0.221940 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x703FC02C, 5000216, 0x03FC0027, 116.318, 148.039, 0.055, 0.97506, 0, 0, 0.22194, False, '2025-07-07 03:58:42'); /* Gate */
/* @teleloc 0x03FC0027 [116.318001 148.039001 0.055000] 0.975060 0.000000 0.000000 0.221940 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x703FC02D, 5000216, 0x03FC002F, 120.024, 149.818, 0.055, 0.97506, 0, 0, 0.22194, False, '2025-07-07 03:58:43'); /* Gate */
/* @teleloc 0x03FC002F [120.024002 149.817993 0.055000] 0.975060 0.000000 0.000000 0.221940 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x703FC02E, 5000216, 0x03FC002F, 121.208, 150.378, 0.055, 0.988949, 0, 0, 0.148255, False, '2025-07-07 03:58:43'); /* Gate */
/* @teleloc 0x03FC002F [121.208000 150.378006 0.055000] 0.988949 0.000000 0.000000 0.148255 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x703FC02F, 5000216, 0x03FC002F, 122.783, 150.807, 0.055, 0.999341, 0, 0, 0.036296, False, '2025-07-07 03:58:44'); /* Gate */
/* @teleloc 0x03FC002F [122.782997 150.807007 0.055000] 0.999341 0.000000 0.000000 0.036296 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x703FC031, 5000216, 0x03FC002F, 125.343, 150.421, 0.055, 0.9621, 0, 0, -0.272698, False, '2025-07-07 03:58:45'); /* Gate */
/* @teleloc 0x03FC002F [125.343002 150.421005 0.055000] 0.962100 0.000000 0.000000 -0.272698 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x703FC032, 5000216, 0x03FC002F, 125.343, 150.421, 0.055, 0.9621, 0, 0, -0.272698, False, '2025-07-07 03:58:45'); /* Gate */
/* @teleloc 0x03FC002F [125.343002 150.421005 0.055000] 0.962100 0.000000 0.000000 -0.272698 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x703FC034, 5000216, 0x03FC002F, 128.445, 148.509, 0.055, 0.9621, 0, 0, -0.272698, False, '2025-07-07 03:58:46'); /* Gate */
/* @teleloc 0x03FC002F [128.445007 148.509003 0.055000] 0.962100 0.000000 0.000000 -0.272698 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x703FC035, 5000216, 0x03FC002F, 128.445, 148.509, 0.055, 0.9621, 0, 0, -0.272698, False, '2025-07-07 03:58:46'); /* Gate */
/* @teleloc 0x03FC002F [128.445007 148.509003 0.055000] 0.962100 0.000000 0.000000 -0.272698 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x703FC036, 5000216, 0x03FC002F, 128.445, 148.509, 0.055, 0.9621, 0, 0, -0.272698, False, '2025-07-07 03:58:46'); /* Gate */
/* @teleloc 0x03FC002F [128.445007 148.509003 0.055000] 0.962100 0.000000 0.000000 -0.272698 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x703FC037, 5000216, 0x03FC002F, 131.554, 146.592, 0.055, 0.9621, 0, 0, -0.272698, False, '2025-07-07 03:58:47'); /* Gate */
/* @teleloc 0x03FC002F [131.554001 146.591995 0.055000] 0.962100 0.000000 0.000000 -0.272698 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x703FC038, 5000216, 0x03FC002F, 131.554, 146.592, 0.055, 0.9621, 0, 0, -0.272698, False, '2025-07-07 03:58:47'); /* Gate */
/* @teleloc 0x03FC002F [131.554001 146.591995 0.055000] 0.962100 0.000000 0.000000 -0.272698 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x703FC039, 5000216, 0x03FC002F, 131.554, 146.592, 0.055, 0.9621, 0, 0, -0.272698, False, '2025-07-07 03:58:47'); /* Gate */
/* @teleloc 0x03FC002F [131.554001 146.591995 0.055000] 0.962100 0.000000 0.000000 -0.272698 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x703FC03A, 5000216, 0x03FC002F, 134.373, 144.786, 0.055, 0.905306, 0, 0, -0.42476, False, '2025-07-07 03:58:47'); /* Gate */
/* @teleloc 0x03FC002F [134.373001 144.785995 0.055000] 0.905306 0.000000 0.000000 -0.424760 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x703FC03B, 5000216, 0x03FC002F, 134.373, 144.786, 0.055, 0.905306, 0, 0, -0.42476, False, '2025-07-07 03:58:48'); /* Gate */
/* @teleloc 0x03FC002F [134.373001 144.785995 0.055000] 0.905306 0.000000 0.000000 -0.424760 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x703FC03C, 5000216, 0x03FC002E, 135.038, 143.986, 0.055, 0.905306, 0, 0, -0.42476, False, '2025-07-07 03:58:48'); /* Gate */
/* @teleloc 0x03FC002E [135.037994 143.985992 0.055000] 0.905306 0.000000 0.000000 -0.424760 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x703FC03D, 5000216, 0x03FC002E, 135.038, 143.986, 0.055, 0.905306, 0, 0, -0.42476, False, '2025-07-07 03:58:48'); /* Gate */
/* @teleloc 0x03FC002E [135.037994 143.985992 0.055000] 0.905306 0.000000 0.000000 -0.424760 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x703FC03E, 5000216, 0x03FC002E, 135.038, 143.986, 0.055, 0.905306, 0, 0, -0.42476, False, '2025-07-07 03:58:48'); /* Gate */
/* @teleloc 0x03FC002E [135.037994 143.985992 0.055000] 0.905306 0.000000 0.000000 -0.424760 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x703FC03F, 5000216, 0x03FC002E, 135.038, 143.986, 0.055, 0.905306, 0, 0, -0.42476, False, '2025-07-07 03:58:49'); /* Gate */
/* @teleloc 0x03FC002E [135.037994 143.985992 0.055000] 0.905306 0.000000 0.000000 -0.424760 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x703FC041, 5000216, 0x03FC002E, 137.38, 141.168, 0.055, 0.905306, 0, 0, -0.42476, False, '2025-07-07 03:58:49'); /* Gate */
/* @teleloc 0x03FC002E [137.380005 141.167999 0.055000] 0.905306 0.000000 0.000000 -0.424760 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x703FC042, 5000216, 0x03FC002E, 137.38, 141.168, 0.055, 0.905306, 0, 0, -0.42476, False, '2025-07-07 03:58:49'); /* Gate */
/* @teleloc 0x03FC002E [137.380005 141.167999 0.055000] 0.905306 0.000000 0.000000 -0.424760 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x703FC043, 5000216, 0x03FC002E, 137.38, 141.168, 0.055, 0.905306, 0, 0, -0.42476, False, '2025-07-07 03:58:50'); /* Gate */
/* @teleloc 0x03FC002E [137.380005 141.167999 0.055000] 0.905306 0.000000 0.000000 -0.424760 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x703FC044, 5000216, 0x03FC002E, 137.38, 141.168, 0.055, 0.905306, 0, 0, -0.42476, False, '2025-07-07 03:58:50'); /* Gate */
/* @teleloc 0x03FC002E [137.380005 141.167999 0.055000] 0.905306 0.000000 0.000000 -0.424760 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x703FC045, 5000216, 0x03FC002E, 140.728, 137.117, 0.055, 0.870934, 0, 0, -0.4914, False, '2025-07-07 03:58:50'); /* Gate */
/* @teleloc 0x03FC002E [140.727997 137.117004 0.055000] 0.870934 0.000000 0.000000 -0.491400 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x703FC046, 5000216, 0x03FC002E, 140.728, 137.117, 0.055, 0.870934, 0, 0, -0.4914, False, '2025-07-07 03:58:51'); /* Gate */
/* @teleloc 0x03FC002E [140.727997 137.117004 0.055000] 0.870934 0.000000 0.000000 -0.491400 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x703FC047, 5000216, 0x03FC002E, 140.728, 137.117, 0.055, 0.870934, 0, 0, -0.4914, False, '2025-07-07 03:58:51'); /* Gate */
/* @teleloc 0x03FC002E [140.727997 137.117004 0.055000] 0.870934 0.000000 0.000000 -0.491400 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x703FC048, 5000216, 0x03FC002E, 140.728, 137.117, 0.055, 0.870934, 0, 0, -0.4914, False, '2025-07-07 03:58:51'); /* Gate */
/* @teleloc 0x03FC002E [140.727997 137.117004 0.055000] 0.870934 0.000000 0.000000 -0.491400 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x703FC049, 5000216, 0x03FC002E, 140.728, 137.117, 0.055, 0.870934, 0, 0, -0.4914, False, '2025-07-07 03:58:52'); /* Gate */
/* @teleloc 0x03FC002E [140.727997 137.117004 0.055000] 0.870934 0.000000 0.000000 -0.491400 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x703FC04A, 5000216, 0x03FC002E, 140.728, 137.117, 0.055, 0.870934, 0, 0, -0.4914, False, '2025-07-07 03:58:52'); /* Gate */
/* @teleloc 0x03FC002E [140.727997 137.117004 0.055000] 0.870934 0.000000 0.000000 -0.491400 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x703FC04B, 5000216, 0x03FC002E, 140.728, 137.117, 0.055, 0.870934, 0, 0, -0.4914, False, '2025-07-07 03:58:52'); /* Gate */
/* @teleloc 0x03FC002E [140.727997 137.117004 0.055000] 0.870934 0.000000 0.000000 -0.491400 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x703FC04C, 5000216, 0x03FC002E, 142.537, 134.123, 0.055, 0.870934, 0, 0, -0.4914, False, '2025-07-07 03:58:52'); /* Gate */
/* @teleloc 0x03FC002E [142.537003 134.123001 0.055000] 0.870934 0.000000 0.000000 -0.491400 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x703FC04D, 5000216, 0x03FC002E, 142.537, 134.123, 0.055, 0.870934, 0, 0, -0.4914, False, '2025-07-07 03:58:52'); /* Gate */
/* @teleloc 0x03FC002E [142.537003 134.123001 0.055000] 0.870934 0.000000 0.000000 -0.491400 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x703FC04E, 5000216, 0x03FC002E, 142.537, 134.123, 0.055, 0.870934, 0, 0, -0.4914, False, '2025-07-07 03:58:53'); /* Gate */
/* @teleloc 0x03FC002E [142.537003 134.123001 0.055000] 0.870934 0.000000 0.000000 -0.491400 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x703FC050, 5000216, 0x03FC002E, 143.591, 129.64, 0.055, 0.485644, 0, 0, -0.874157, False, '2025-07-07 03:58:53'); /* Gate */
/* @teleloc 0x03FC002E [143.591003 129.639999 0.055000] 0.485644 0.000000 0.000000 -0.874157 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x703FC051, 5000216, 0x03FC002E, 143.591, 129.64, 0.055, 0.485644, 0, 0, -0.874157, False, '2025-07-07 03:58:53'); /* Gate */
/* @teleloc 0x03FC002E [143.591003 129.639999 0.055000] 0.485644 0.000000 0.000000 -0.874157 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x703FC052, 5000216, 0x03FC002E, 143.591, 129.64, 0.055, 0.485644, 0, 0, -0.874157, False, '2025-07-07 03:58:53'); /* Gate */
/* @teleloc 0x03FC002E [143.591003 129.639999 0.055000] 0.485644 0.000000 0.000000 -0.874157 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x703FC053, 5000216, 0x03FC002E, 143.591, 129.64, 0.055, 0.485644, 0, 0, -0.874157, False, '2025-07-07 03:58:53'); /* Gate */
/* @teleloc 0x03FC002E [143.591003 129.639999 0.055000] 0.485644 0.000000 0.000000 -0.874157 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x703FC055, 5000216, 0x03FC002E, 141.369, 126.066, 0.055, 0.518076, 0, 0, -0.855335, False, '2025-07-07 03:58:54'); /* Gate */
/* @teleloc 0x03FC002E [141.369003 126.066002 0.055000] 0.518076 0.000000 0.000000 -0.855335 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x703FC056, 5000216, 0x03FC002E, 141.369, 126.066, 0.055, 0.518076, 0, 0, -0.855335, False, '2025-07-07 03:58:54'); /* Gate */
/* @teleloc 0x03FC002E [141.369003 126.066002 0.055000] 0.518076 0.000000 0.000000 -0.855335 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x703FC057, 5000216, 0x03FC002E, 140.539, 124.439, 0.055, 0.58071, 0, 0, -0.814111, False, '2025-07-07 03:58:54'); /* Gate */
/* @teleloc 0x03FC002E [140.539001 124.439003 0.055000] 0.580710 0.000000 0.000000 -0.814111 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x703FC058, 5000216, 0x03FC002E, 140.539, 124.439, 0.055, 0.58071, 0, 0, -0.814111, False, '2025-07-07 03:58:55'); /* Gate */
/* @teleloc 0x03FC002E [140.539001 124.439003 0.055000] 0.580710 0.000000 0.000000 -0.814111 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x703FC059, 5000216, 0x03FC002E, 140.027, 123.014, 0.055, 0.518076, 0, 0, -0.855335, False, '2025-07-07 03:58:55'); /* Gate */
/* @teleloc 0x03FC002E [140.026993 123.014000 0.055000] 0.518076 0.000000 0.000000 -0.855335 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x703FC05A, 5000216, 0x03FC002E, 140.027, 123.014, 0.055, 0.518076, 0, 0, -0.855335, False, '2025-07-07 03:58:55'); /* Gate */
/* @teleloc 0x03FC002E [140.026993 123.014000 0.055000] 0.518076 0.000000 0.000000 -0.855335 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x703FC05B, 5000216, 0x03FC002E, 140.027, 123.014, 0.055, 0.518076, 0, 0, -0.855335, False, '2025-07-07 03:58:55'); /* Gate */
/* @teleloc 0x03FC002E [140.026993 123.014000 0.055000] 0.518076 0.000000 0.000000 -0.855335 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x703FC05C, 5000216, 0x03FC002E, 140.027, 123.014, 0.055, 0.518076, 0, 0, -0.855335, False, '2025-07-07 03:58:56'); /* Gate */
/* @teleloc 0x03FC002E [140.026993 123.014000 0.055000] 0.518076 0.000000 0.000000 -0.855335 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x703FC05E, 5000216, 0x03FC002D, 138.396, 119.894, 0.055, 0.518076, 0, 0, -0.855335, False, '2025-07-07 03:58:56'); /* Gate */
/* @teleloc 0x03FC002D [138.395996 119.893997 0.055000] 0.518076 0.000000 0.000000 -0.855335 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x703FC05F, 5000216, 0x03FC002D, 138.396, 119.894, 0.055, 0.518076, 0, 0, -0.855335, False, '2025-07-07 03:58:56'); /* Gate */
/* @teleloc 0x03FC002D [138.395996 119.893997 0.055000] 0.518076 0.000000 0.000000 -0.855335 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x703FC060, 5000216, 0x03FC002D, 138.396, 119.894, 0.055, 0.518076, 0, 0, -0.855335, False, '2025-07-07 03:58:57'); /* Gate */
/* @teleloc 0x03FC002D [138.395996 119.893997 0.055000] 0.518076 0.000000 0.000000 -0.855335 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x703FC061, 5000216, 0x03FC002D, 137.111, 117.436, 0.055, 0.47468, 0, 0, -0.880159, False, '2025-07-07 03:58:57'); /* Gate */
/* @teleloc 0x03FC002D [137.110992 117.435997 0.055000] 0.474680 0.000000 0.000000 -0.880159 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x703FC063, 5000216, 0x03FC002D, 135.473, 116.399, 0.055, 0.069544, 0, 0, -0.997579, False, '2025-07-07 03:58:57'); /* Gate */
/* @teleloc 0x03FC002D [135.473007 116.399002 0.055000] 0.069544 0.000000 0.000000 -0.997579 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x703FC064, 5000216, 0x03FC002D, 135.473, 116.399, 0.055, 0.069544, 0, 0, -0.997579, False, '2025-07-07 03:58:57'); /* Gate */
/* @teleloc 0x03FC002D [135.473007 116.399002 0.055000] 0.069544 0.000000 0.000000 -0.997579 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x703FC065, 5000216, 0x03FC002D, 135.473, 116.399, 0.055, 0.069544, 0, 0, -0.997579, False, '2025-07-07 03:58:58'); /* Gate */
/* @teleloc 0x03FC002D [135.473007 116.399002 0.055000] 0.069544 0.000000 0.000000 -0.997579 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x703FC066, 5000216, 0x03FC002D, 135.473, 116.399, 0.055, 0.069544, 0, 0, -0.997579, False, '2025-07-07 03:58:58'); /* Gate */
/* @teleloc 0x03FC002D [135.473007 116.399002 0.055000] 0.069544 0.000000 0.000000 -0.997579 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x703FC067, 5000216, 0x03FC002D, 135.473, 116.399, 0.055, 0.069544, 0, 0, -0.997579, False, '2025-07-07 03:58:58'); /* Gate */
/* @teleloc 0x03FC002D [135.473007 116.399002 0.055000] 0.069544 0.000000 0.000000 -0.997579 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x703FC068, 5000216, 0x03FC002D, 135.473, 116.399, 0.055, 0.069544, 0, 0, -0.997579, False, '2025-07-07 03:58:58'); /* Gate */
/* @teleloc 0x03FC002D [135.473007 116.399002 0.055000] 0.069544 0.000000 0.000000 -0.997579 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x703FC06A, 5000216, 0x03FC002D, 132.02, 115.916, 0.055, 0.069544, 0, 0, -0.997579, False, '2025-07-07 03:58:59'); /* Gate */
/* @teleloc 0x03FC002D [132.020004 115.916000 0.055000] 0.069544 0.000000 0.000000 -0.997579 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x703FC06B, 5000216, 0x03FC002D, 132.02, 115.916, 0.055, 0.069544, 0, 0, -0.997579, False, '2025-07-07 03:58:59'); /* Gate */
/* @teleloc 0x03FC002D [132.020004 115.916000 0.055000] 0.069544 0.000000 0.000000 -0.997579 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x703FC06C, 5000216, 0x03FC002D, 132.02, 115.916, 0.055, 0.069544, 0, 0, -0.997579, False, '2025-07-07 03:58:59'); /* Gate */
/* @teleloc 0x03FC002D [132.020004 115.916000 0.055000] 0.069544 0.000000 0.000000 -0.997579 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x703FC06D, 5000216, 0x03FC002D, 128.316, 115.397, 0.055, 0.069544, 0, 0, -0.997579, False, '2025-07-07 03:59:00'); /* Gate */
/* @teleloc 0x03FC002D [128.315994 115.397003 0.055000] 0.069544 0.000000 0.000000 -0.997579 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x703FC06E, 5000216, 0x03FC002D, 128.316, 115.397, 0.055, 0.069544, 0, 0, -0.997579, False, '2025-07-07 03:59:00'); /* Gate */
/* @teleloc 0x03FC002D [128.315994 115.397003 0.055000] 0.069544 0.000000 0.000000 -0.997579 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x703FC06F, 5000216, 0x03FC002D, 128.316, 115.397, 0.055, 0.069544, 0, 0, -0.997579, False, '2025-07-07 03:59:00'); /* Gate */
/* @teleloc 0x03FC002D [128.315994 115.397003 0.055000] 0.069544 0.000000 0.000000 -0.997579 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x703FC070, 5000216, 0x03FC002D, 128.316, 115.397, 0.055, 0.069544, 0, 0, -0.997579, False, '2025-07-07 03:59:00'); /* Gate */
/* @teleloc 0x03FC002D [128.315994 115.397003 0.055000] 0.069544 0.000000 0.000000 -0.997579 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x703FC071, 5000216, 0x03FC002D, 128.316, 115.397, 0.055, 0.069544, 0, 0, -0.997579, False, '2025-07-07 03:59:01'); /* Gate */
/* @teleloc 0x03FC002D [128.315994 115.397003 0.055000] 0.069544 0.000000 0.000000 -0.997579 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x703FC072, 5000216, 0x03FC002D, 128.316, 115.397, 0.055, 0.069544, 0, 0, -0.997579, False, '2025-07-07 03:59:01'); /* Gate */
/* @teleloc 0x03FC002D [128.315994 115.397003 0.055000] 0.069544 0.000000 0.000000 -0.997579 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x703FC073, 5000216, 0x03FC002D, 128.316, 115.397, 0.055, 0.069544, 0, 0, -0.997579, False, '2025-07-07 03:59:01'); /* Gate */
/* @teleloc 0x03FC002D [128.315994 115.397003 0.055000] 0.069544 0.000000 0.000000 -0.997579 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x703FC074, 5000216, 0x03FC002D, 128.316, 115.397, 0.055, 0.069544, 0, 0, -0.997579, False, '2025-07-07 03:59:02'); /* Gate */
/* @teleloc 0x03FC002D [128.315994 115.397003 0.055000] 0.069544 0.000000 0.000000 -0.997579 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x703FC076, 5000216, 0x03FC002D, 124.818, 114.907, 0.055, 0.069544, 0, 0, -0.997579, False, '2025-07-07 03:59:02'); /* Gate */
/* @teleloc 0x03FC002D [124.818001 114.906998 0.055000] 0.069544 0.000000 0.000000 -0.997579 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x703FC077, 5000216, 0x03FC002D, 124.818, 114.907, 0.055, 0.069544, 0, 0, -0.997579, False, '2025-07-07 03:59:02'); /* Gate */
/* @teleloc 0x03FC002D [124.818001 114.906998 0.055000] 0.069544 0.000000 0.000000 -0.997579 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x703FC078, 5000216, 0x03FC002D, 124.818, 114.907, 0.055, 0.069544, 0, 0, -0.997579, False, '2025-07-07 03:59:02'); /* Gate */
/* @teleloc 0x03FC002D [124.818001 114.906998 0.055000] 0.069544 0.000000 0.000000 -0.997579 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x703FC07A, 5000216, 0x03FC0025, 119.796, 114.44, 0.055, -0.240519, 0, 0, -0.970645, False, '2025-07-07 03:59:03'); /* Gate */
/* @teleloc 0x03FC0025 [119.795998 114.440002 0.055000] -0.240519 0.000000 0.000000 -0.970645 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x703FC07B, 5000216, 0x03FC0025, 119.796, 114.44, 0.055, -0.240519, 0, 0, -0.970645, False, '2025-07-07 03:59:03'); /* Gate */
/* @teleloc 0x03FC0025 [119.795998 114.440002 0.055000] -0.240519 0.000000 0.000000 -0.970645 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x703FC07D, 5000216, 0x03FC0025, 119.019, 114.886, 0.055, -0.394387, 0, 0, -0.918945, False, '2025-07-07 03:59:03'); /* Gate */
/* @teleloc 0x03FC0025 [119.018997 114.886002 0.055000] -0.394387 0.000000 0.000000 -0.918945 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x703FC07E, 5000216, 0x03FC0025, 119.019, 114.886, 0.055, -0.394387, 0, 0, -0.918945, False, '2025-07-07 03:59:04'); /* Gate */
/* @teleloc 0x03FC0025 [119.018997 114.886002 0.055000] -0.394387 0.000000 0.000000 -0.918945 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x703FC07F, 5000216, 0x03FC0025, 116.924, 117.091, 0.055, -0.394387, 0, 0, -0.918945, False, '2025-07-07 03:59:04'); /* Gate */
/* @teleloc 0x03FC0025 [116.924004 117.091003 0.055000] -0.394387 0.000000 0.000000 -0.918945 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x703FC080, 5000216, 0x03FC0025, 116.924, 117.091, 0.055, -0.394387, 0, 0, -0.918945, False, '2025-07-07 03:59:04'); /* Gate */
/* @teleloc 0x03FC0025 [116.924004 117.091003 0.055000] -0.394387 0.000000 0.000000 -0.918945 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x703FC081, 5000216, 0x03FC0025, 116.924, 117.091, 0.055, -0.394387, 0, 0, -0.918945, False, '2025-07-07 03:59:04'); /* Gate */
/* @teleloc 0x03FC0025 [116.924004 117.091003 0.055000] -0.394387 0.000000 0.000000 -0.918945 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x703FC082, 5000216, 0x03FC0025, 116.924, 117.091, 0.055, -0.394387, 0, 0, -0.918945, False, '2025-07-07 03:59:05'); /* Gate */
/* @teleloc 0x03FC0025 [116.924004 117.091003 0.055000] -0.394387 0.000000 0.000000 -0.918945 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x703FC083, 5000216, 0x03FC0025, 116.924, 117.091, 0.055, -0.394387, 0, 0, -0.918945, False, '2025-07-07 03:59:05'); /* Gate */
/* @teleloc 0x03FC0025 [116.924004 117.091003 0.055000] -0.394387 0.000000 0.000000 -0.918945 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x703FC084, 5000216, 0x03FC0025, 116.924, 117.091, 0.055, -0.394387, 0, 0, -0.918945, False, '2025-07-07 03:59:05'); /* Gate */
/* @teleloc 0x03FC0025 [116.924004 117.091003 0.055000] -0.394387 0.000000 0.000000 -0.918945 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x703FC086, 5000216, 0x03FC0025, 115.251, 118.851, 0.055, -0.394387, 0, 0, -0.918945, False, '2025-07-07 03:59:05'); /* Gate */
/* @teleloc 0x03FC0025 [115.250999 118.850998 0.055000] -0.394387 0.000000 0.000000 -0.918945 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x703FC087, 5000216, 0x03FC0025, 115.251, 118.851, 0.055, -0.394387, 0, 0, -0.918945, False, '2025-07-07 03:59:06'); /* Gate */
/* @teleloc 0x03FC0025 [115.250999 118.850998 0.055000] -0.394387 0.000000 0.000000 -0.918945 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x703FC088, 5000216, 0x03FC0026, 114.131, 120.03, 0.055, -0.394387, 0, 0, -0.918945, False, '2025-07-07 03:59:06'); /* Gate */
/* @teleloc 0x03FC0026 [114.130997 120.029999 0.055000] -0.394387 0.000000 0.000000 -0.918945 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x703FC089, 5000216, 0x03FC0026, 114.131, 120.03, 0.055, -0.394387, 0, 0, -0.918945, False, '2025-07-07 03:59:06'); /* Gate */
/* @teleloc 0x03FC0026 [114.130997 120.029999 0.055000] -0.394387 0.000000 0.000000 -0.918945 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x703FC08A, 5000216, 0x03FC0026, 114.131, 120.03, 0.055, -0.394387, 0, 0, -0.918945, False, '2025-07-07 03:59:07'); /* Gate */
/* @teleloc 0x03FC0026 [114.130997 120.029999 0.055000] -0.394387 0.000000 0.000000 -0.918945 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x703FC08B, 5000216, 0x03FC0026, 112.662, 121.575, 0.055, -0.394387, 0, 0, -0.918945, False, '2025-07-07 03:59:07'); /* Gate */
/* @teleloc 0x03FC0026 [112.662003 121.574997 0.055000] -0.394387 0.000000 0.000000 -0.918945 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x703FC08C, 5000216, 0x03FC0026, 112.662, 121.575, 0.055, -0.394387, 0, 0, -0.918945, False, '2025-07-07 03:59:07'); /* Gate */
/* @teleloc 0x03FC0026 [112.662003 121.574997 0.055000] -0.394387 0.000000 0.000000 -0.918945 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x703FC08D, 5000216, 0x03FC0026, 112.662, 121.575, 0.055, -0.394387, 0, 0, -0.918945, False, '2025-07-07 03:59:07'); /* Gate */
/* @teleloc 0x03FC0026 [112.662003 121.574997 0.055000] -0.394387 0.000000 0.000000 -0.918945 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x703FC08E, 5000216, 0x03FC0026, 112.662, 121.575, 0.055, -0.394387, 0, 0, -0.918945, False, '2025-07-07 03:59:08'); /* Gate */
/* @teleloc 0x03FC0026 [112.662003 121.574997 0.055000] -0.394387 0.000000 0.000000 -0.918945 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x703FC08F, 5000216, 0x03FC0026, 111.851, 122.445, 0.055, -0.505879, 0, 0, -0.862605, False, '2025-07-07 03:59:08'); /* Gate */
/* @teleloc 0x03FC0026 [111.850998 122.445000 0.055000] -0.505879 0.000000 0.000000 -0.862605 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x703FC090, 5000216, 0x03FC0026, 111.851, 122.445, 0.055, -0.505879, 0, 0, -0.862605, False, '2025-07-07 03:59:09'); /* Gate */
/* @teleloc 0x03FC0026 [111.850998 122.445000 0.055000] -0.505879 0.000000 0.000000 -0.862605 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x703FC091, 5000216, 0x03FC0026, 111.851, 122.445, 0.055, -0.505879, 0, 0, -0.862605, False, '2025-07-07 03:59:09'); /* Gate */
/* @teleloc 0x03FC0026 [111.850998 122.445000 0.055000] -0.505879 0.000000 0.000000 -0.862605 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x703FC092, 5000216, 0x03FC0026, 111.851, 122.445, 0.055, -0.505879, 0, 0, -0.862605, False, '2025-07-07 03:59:09'); /* Gate */
/* @teleloc 0x03FC0026 [111.850998 122.445000 0.055000] -0.505879 0.000000 0.000000 -0.862605 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x703FC093, 5000216, 0x03FC0026, 111.851, 122.445, 0.055, -0.505879, 0, 0, -0.862605, False, '2025-07-07 03:59:09'); /* Gate */
/* @teleloc 0x03FC0026 [111.850998 122.445000 0.055000] -0.505879 0.000000 0.000000 -0.862605 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x703FC094, 5000216, 0x03FC0026, 111.851, 122.445, 0.055, -0.505879, 0, 0, -0.862605, False, '2025-07-07 03:59:10'); /* Gate */
/* @teleloc 0x03FC0026 [111.850998 122.445000 0.055000] -0.505879 0.000000 0.000000 -0.862605 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x703FC095, 5000216, 0x03FC0026, 111.851, 122.445, 0.055, -0.505879, 0, 0, -0.862605, False, '2025-07-07 03:59:10'); /* Gate */
/* @teleloc 0x03FC0026 [111.850998 122.445000 0.055000] -0.505879 0.000000 0.000000 -0.862605 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x703FC096, 5000216, 0x03FC0026, 111.851, 122.445, 0.055, -0.505879, 0, 0, -0.862605, False, '2025-07-07 03:59:11'); /* Gate */
/* @teleloc 0x03FC0026 [111.850998 122.445000 0.055000] -0.505879 0.000000 0.000000 -0.862605 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x703FC098, 5000216, 0x03FC0026, 110.017, 125.724, 0.055, -0.505879, 0, 0, -0.862605, False, '2025-07-07 03:59:11'); /* Gate */
/* @teleloc 0x03FC0026 [110.016998 125.723999 0.055000] -0.505879 0.000000 0.000000 -0.862605 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x703FC099, 5000216, 0x03FC0026, 110.017, 125.724, 0.055, -0.505879, 0, 0, -0.862605, False, '2025-07-07 03:59:12'); /* Gate */
/* @teleloc 0x03FC0026 [110.016998 125.723999 0.055000] -0.505879 0.000000 0.000000 -0.862605 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x703FC09A, 5000216, 0x03FC0026, 110.017, 125.724, 0.055, -0.505879, 0, 0, -0.862605, False, '2025-07-07 03:59:12'); /* Gate */
/* @teleloc 0x03FC0026 [110.016998 125.723999 0.055000] -0.505879 0.000000 0.000000 -0.862605 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x703FC09B, 5000216, 0x03FC0026, 110.017, 125.724, 0.055, -0.505879, 0, 0, -0.862605, False, '2025-07-07 03:59:12'); /* Gate */
/* @teleloc 0x03FC0026 [110.016998 125.723999 0.055000] -0.505879 0.000000 0.000000 -0.862605 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x703FC09C, 4200152, 0x03FC0031, 153.333, 11.2312, 0.055, -0.830931, 0, 0, -0.556376, False, '2025-07-07 04:01:29'); /* Gate */
/* @teleloc 0x03FC0031 [153.332993 11.231200 0.055000] -0.830931 0.000000 0.000000 -0.556376 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x703FC09D, 4200152, 0x03FC0039, 189.264, 20.8601, 0.055, -0.980939, 0, 0, 0.194319, False, '2025-07-07 04:01:41'); /* Gate */
/* @teleloc 0x03FC0039 [189.264008 20.860100 0.055000] -0.980939 0.000000 0.000000 0.194319 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x703FC09E, 4200152, 0x03FC0039, 176.429, 23.5616, 0.055, -0.991894, 0, 0, -0.127069, False, '2025-07-07 04:01:44'); /* Gate */
/* @teleloc 0x03FC0039 [176.429001 23.561600 0.055000] -0.991894 0.000000 0.000000 -0.127069 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x703FC09F, 4200152, 0x03FC0031, 160.319, 19.8639, 0.055, -0.960242, 0, 0, -0.27917, False, '2025-07-07 04:04:09'); /* Gate */
/* @teleloc 0x03FC0031 [160.319000 19.863899 0.055000] -0.960242 0.000000 0.000000 -0.279170 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x703FC0A0, 4200152, 0x03FC0031, 162.308, 18.2043, 0.055, -0.983315, 0, 0, -0.181911, False, '2025-07-07 04:04:12'); /* Gate */
/* @teleloc 0x03FC0031 [162.307999 18.204300 0.055000] -0.983315 0.000000 0.000000 -0.181911 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x703FC0A1, 86656970, 0x03FC0039, 180.012, 22.189, 0, -0.993047, 0, 0, 0.117723, False, '2025-07-07 04:08:34');
/* @teleloc 0x03FC0039 [180.011993 22.188999 0.000000] -0.993047 0.000000 0.000000 0.117723 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x703FC0A2, 86653140, 0x03FC0031, 167.223, 11.2723, 0.055, 0.504705, 0, 0, -0.863292, False, '2025-07-07 04:11:16'); /* Big Rock */
/* @teleloc 0x03FC0031 [167.223007 11.272300 0.055000] 0.504705 0.000000 0.000000 -0.863292 */
