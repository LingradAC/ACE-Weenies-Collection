DELETE FROM `landblock_instance` WHERE `landblock` = 0x114D;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7114D000, 86653111, 0x114D000E, 45.733, 131.022, 71, -0.580308, 0, 0, -0.814397, False, '2025-07-18 23:51:07'); /* WOOD111 */
/* @teleloc 0x114D000E [45.733002 131.022003 71.000000] -0.580308 0.000000 0.000000 -0.814397 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7114D001, 86653122, 0x114D0016, 69.6486, 131.186, 71.455, -0.853406, 0, 0, 0.521246, False, '2025-07-18 23:51:20'); /* 1platform */
/* @teleloc 0x114D0016 [69.648598 131.186005 71.455002] -0.853406 0.000000 0.000000 0.521246 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7114D002, 86653111, 0x114D000E, 35.7129, 131.322, 71.455, -0.580127, 0, 0, -0.814526, False, '2025-07-18 23:52:07'); /* WOOD111 */
/* @teleloc 0x114D000E [35.712898 131.322006 71.455002] -0.580127 0.000000 0.000000 -0.814526 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7114D003, 86653111, 0x114D000E, 27.5365, 139.719, 71.91, -0.925133, 0, 0, -0.379644, False, '2025-07-18 23:54:04'); /* WOOD111 */
/* @teleloc 0x114D000E [27.536501 139.718994 71.910004] -0.925133 0.000000 0.000000 -0.379644 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7114D004, 86653111, 0x114D000F, 27.5869, 155.489, 72.365, -0.999943, 0, 0, 0.010683, False, '2025-07-18 23:55:03'); /* WOOD111 */
/* @teleloc 0x114D000F [27.586901 155.488998 72.364998] -0.999943 0.000000 0.000000 0.010683 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7114D005, 86653111, 0x114D000F, 27.3444, 158.403, 77.42, -0.999996, 0, 0, 0.00272, False, '2025-07-18 23:55:57'); /* WOOD111 */
/* @teleloc 0x114D000F [27.344400 158.403000 77.419998] -0.999996 0.000000 0.000000 0.002720 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7114D006, 86653111, 0x114D000F, 27.2383, 162.52, 80.275, 0.999977, 0, 0, -0.006812, False, '2025-07-18 23:56:38'); /* WOOD111 */
/* @teleloc 0x114D000F [27.238300 162.520004 80.275002] 0.999977 0.000000 0.000000 -0.006812 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7114D007, 86653111, 0x114D000F, 27.391, 166.245, 82.73, 0.999921, 0, 0, -0.012581, False, '2025-07-18 23:57:03'); /* WOOD111 */
/* @teleloc 0x114D000F [27.391001 166.244995 82.730003] 0.999921 0.000000 0.000000 -0.012581 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7114D008, 86653111, 0x114D0010, 27.5202, 175.391, 83.185, 0.999294, 0, 0, -0.037573, False, '2025-07-18 23:57:16'); /* WOOD111 */
/* @teleloc 0x114D0010 [27.520201 175.391006 83.184998] 0.999294 0.000000 0.000000 -0.037573 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7114D009, 86653111, 0x114D0008, 17.8894, 185.411, 83.64, 0.897514, 0, 0, 0.440987, False, '2025-07-18 23:57:34'); /* WOOD111 */
/* @teleloc 0x114D0008 [17.889400 185.410995 83.639999] 0.897514 0.000000 0.000000 0.440987 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7114D00C, 86653111, 0x114D0008, 17.6537, 191.689, 84.095, 0.996306, 0, 0, 0.085877, False, '2025-07-19 00:00:28'); /* WOOD111 */
/* @teleloc 0x114D0008 [17.653700 191.688995 84.095001] 0.996306 0.000000 0.000000 0.085877 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7114D00D, 5167232, 0x114D0006, 18.1789, 136.23, -0.163, -0.957037, 0, 0, 0.289965, False, '2025-07-28 14:01:37'); /* Parkour Challenge */
/* @teleloc 0x114D0006 [18.178900 136.229996 -0.163000] -0.957037 0.000000 0.000000 0.289965 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7114D00E, 5167232, 0x114D0010, 32.2816, 178.519, 0.627134, -0.612127, 0, 0, -0.790759, False, '2025-07-28 14:01:52'); /* Parkour Challenge */
/* @teleloc 0x114D0010 [32.281601 178.518997 0.627134] -0.612127 0.000000 0.000000 -0.790759 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7114D00F, 5167232, 0x114D0008, 9.240676, 172.4709, -0.513, 0.895012, 0, 0, 0.446042, False, '2025-07-28 14:01:56'); /* Parkour Challenge */
/* @teleloc 0x114D0008 [9.240676 172.470901 -0.513000] 0.895012 0.000000 0.000000 0.446042 */
