DELETE FROM `landblock_instance` WHERE `landblock` = 0xE620;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E620000, 24411, 0xE6200028, 105.679, 191.8759, -0.045, 0.488294, 0, 0, -0.87268, False, '2025-08-16 18:21:19'); /* Asheron Invasion Extreme Generators */
/* @teleloc 0xE6200028 [105.679001 191.875900 -0.045000] 0.488294 0.000000 0.000000 -0.872680 */
