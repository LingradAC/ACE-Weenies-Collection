DELETE FROM `landblock_instance` WHERE `landblock` = 0xF6D6;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F6D6001, 5000296, 0xF6D60006, 4.32502, 135.013, -0.045, -0.998423, 0, 0, 0.056132, False, '2020-01-13 01:44:03'); /* Plant */
/* @teleloc 0xF6D60006 [4.325020 135.013000 -0.045000] -0.998423 0.000000 0.000000 0.056132 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F6D6002, 5000661, 0xF6D60007, 5.02239, 150.044, 0.055, -0.974453, 0, 0, -0.224594, False, '2020-01-13 01:44:04'); /* Plant */
/* @teleloc 0xF6D60007 [5.022390 150.044006 0.055000] -0.974453 0.000000 0.000000 -0.224594 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F6D6003, 5000295, 0xF6D60018, 48.5371, 179.488, -0.045, -0.904833, 0, 0, 0.425766, False, '2020-01-13 01:44:09'); /* Plant */
/* @teleloc 0xF6D60018 [48.537102 179.488007 -0.045000] -0.904833 0.000000 0.000000 0.425766 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F6D6004, 5000296, 0xF6D60018, 48.5371, 179.488, -0.045, -0.904833, 0, 0, 0.425766, False, '2020-01-13 01:44:10'); /* Plant */
/* @teleloc 0xF6D60018 [48.537102 179.488007 -0.045000] -0.904833 0.000000 0.000000 0.425766 */
