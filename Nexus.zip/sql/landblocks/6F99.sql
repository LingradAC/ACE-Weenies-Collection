DELETE FROM `landblock_instance` WHERE `landblock` = 0x6F99;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x76F99000, 999702, 0x6F990026, 97.2987, 131.387, 240.005, -0.650639, 0, 0, 0.759388, False, '2025-08-04 00:49:17'); /* Hallas The Longwinded */
/* @teleloc 0x6F990026 [97.298698 131.386993 240.005005] -0.650639 0.000000 0.000000 0.759388 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x76F99001, 999701, 0x6F990026, 98.3287, 126.447, 240.005, -0.947231, 0, 0, 0.320551, False, '2025-08-04 00:49:28'); /* Xavier Dabsworth */
/* @teleloc 0x6F990026 [98.328697 126.446999 240.005005] -0.947231 0.000000 0.000000 0.320551 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x76F99002, 69692321, 0x6F990026, 97.2633, 136.001, 240.005, -0.659846, 0, 0, 0.751401, False, '2025-08-04 00:49:44'); /* Captain Stupid */
/* @teleloc 0x6F990026 [97.263298 136.001007 240.005005] -0.659846 0.000000 0.000000 0.751401 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x76F99003, 999762, 0x6F990026, 97.3624, 140.605, 240.005, -0.693421, 0, 0, 0.720533, False, '2025-08-04 00:50:01'); /* Sky The Inspirational */
/* @teleloc 0x6F990026 [97.362396 140.604996 240.005005] -0.693421 0.000000 0.000000 0.720533 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x76F99005, 48743, 0x6F990037, 149.169, 156.641, 240.055, 0.477705, 0, 0, -0.87852, False, '2025-08-04 00:51:36'); /* Legendary Chest */
/* @teleloc 0x6F990037 [149.169006 156.641006 240.054993] 0.477705 0.000000 0.000000 -0.878520 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x76F99006, 48743, 0x6F990037, 148.035, 154.89, 240.055, 0.477705, 0, 0, -0.87852, False, '2025-08-04 00:51:40'); /* Legendary Chest */
/* @teleloc 0x6F990037 [148.035004 154.889999 240.054993] 0.477705 0.000000 0.000000 -0.878520 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x76F99007, 48743, 0x6F990037, 146.996, 153.286, 240.055, 0.477705, 0, 0, -0.87852, False, '2025-08-04 00:51:43'); /* Legendary Chest */
/* @teleloc 0x6F990037 [146.996002 153.285995 240.054993] 0.477705 0.000000 0.000000 -0.878520 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x76F99008, 48743, 0x6F990037, 144.768, 149.846, 240.055, 0.477705, 0, 0, -0.87852, False, '2025-08-04 00:51:45'); /* Legendary Chest */
/* @teleloc 0x6F990037 [144.768005 149.845993 240.054993] 0.477705 0.000000 0.000000 -0.878520 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x76F99009, 48743, 0x6F990037, 145.813, 151.389, 240.055, 0.479248, 0, 0, -0.87768, False, '2025-08-04 00:51:51'); /* Legendary Chest */
/* @teleloc 0x6F990037 [145.813004 151.389008 240.054993] 0.479248 0.000000 0.000000 -0.877680 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x76F9900A, 29503, 0x6F990027, 97.9099, 166.902, 239.937, -0.727827, 0, 0, 0.685761, False, '2025-08-04 00:54:18'); /* Nexus Gambling Den */
/* @teleloc 0x6F990027 [97.909897 166.901993 239.936996] -0.727827 0.000000 0.000000 0.685761 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x76F9900B, 86653870, 0x6F990027, 116.585, 160.719, 239.988, -0.775946, 0, 0, 0.630799, False, '2025-08-04 00:54:45'); /* Asheron */
/* @teleloc 0x6F990027 [116.584999 160.718994 239.988007] -0.775946 0.000000 0.000000 0.630799 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x76F9900E, 2316916, 0x6F990026, 112.067, 126.104, 240.022, 0.999876, 0, 0, 0.015746, False, '2025-08-04 01:00:23'); /* Stanley The Stomper */
/* @teleloc 0x6F990026 [112.067001 126.103996 240.022003] 0.999876 0.000000 0.000000 0.015746 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x76F99010, 238288, 0x6F99002F, 143.209, 145.043, 239.953, 0.324993, 0, 0, 0.945716, False, '2025-08-04 01:03:16'); /* Gorvaxs Vault */
/* @teleloc 0x6F99002F [143.209000 145.042999 239.953003] 0.324993 0.000000 0.000000 0.945716 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x76F99011, 48743, 0x6F990037, 146.822, 148.664, 240.055, -0.886141, 0, 0, -0.463416, False, '2025-08-04 01:03:56'); /* Legendary Chest */
/* @teleloc 0x6F990037 [146.822006 148.664001 240.054993] -0.886141 0.000000 0.000000 -0.463416 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x76F99012, 48743, 0x6F990037, 147.762, 150.141, 240.055, -0.886141, 0, 0, -0.463416, False, '2025-08-04 01:03:59'); /* Legendary Chest */
/* @teleloc 0x6F990037 [147.761993 150.141006 240.054993] -0.886141 0.000000 0.000000 -0.463416 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x76F99013, 48743, 0x6F990037, 149.356, 152.31, 240.055, -0.886141, 0, 0, -0.463416, False, '2025-08-04 01:04:00'); /* Legendary Chest */
/* @teleloc 0x6F990037 [149.356003 152.309998 240.054993] -0.886141 0.000000 0.000000 -0.463416 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x76F99014, 48743, 0x6F990037, 151.281, 154.967, 240.055, -0.886141, 0, 0, -0.463416, False, '2025-08-04 01:04:02'); /* Legendary Chest */
/* @teleloc 0x6F990037 [151.281006 154.966995 240.054993] -0.886141 0.000000 0.000000 -0.463416 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x76F99015, 32487234, 0x6F99002E, 139.722, 140.704, 239.937, -0.453711, 0, 0, 0.891149, False, '2025-08-04 01:04:29'); /* Portal to Gorvax The Devourer */
/* @teleloc 0x6F99002E [139.722000 140.703995 239.936996] -0.453711 0.000000 0.000000 0.891149 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x76F99016, 63212983, 0x6F990030, 143.619, 180.436, 240.137, -0.428156, 0, 0, 0.903705, False, '2025-08-04 02:28:25'); /* Simiran Portal */
/* @teleloc 0x6F990030 [143.619003 180.436005 240.136993] -0.428156 0.000000 0.000000 0.903705 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x76F99017, 31315, 0x6F990026, 117.598, 125.242, 239.937, 0.3926, 0, 0, -0.919709, False, '2025-08-04 02:30:55'); /* Venom Tusker Den */
/* @teleloc 0x6F990026 [117.598000 125.241997 239.936996] 0.392600 0.000000 0.000000 -0.919709 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x76F99018, 42841, 0x6F990027, 97.099, 146.061, 239.937, -0.693445, 0, 0, -0.72051, False, '2025-08-04 02:31:26'); /* Tou-Tou Portal */
/* @teleloc 0x6F990027 [97.098999 146.061005 239.936996] -0.693445 0.000000 0.000000 -0.720510 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x76F99019,   509, 0x6F990030, 129.049, 187.9, 240, 0.135124, 0, 0, 0.990829, False, '2025-08-04 02:34:47'); /* Life Stone */
/* @teleloc 0x6F990030 [129.048996 187.899994 240.000000] 0.135124 0.000000 0.000000 0.990829 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x76F9901A, 86653868, 0x6F990038, 154.734, 173.37, 240.008, -0.761818, 0, 0, -0.647791, False, '2025-08-04 02:35:23'); /* Bael'Zharon */
/* @teleloc 0x6F990038 [154.733994 173.369995 240.007996] -0.761818 0.000000 0.000000 -0.647791 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x76F9901B, 716165, 0x6F990038, 158.564, 172.906, 239.79, -0.761818, 0, 0, -0.647791, False, '2025-08-04 02:35:38'); /* Hopeslayer's Reach */
/* @teleloc 0x6F990038 [158.563995 172.906006 239.789993] -0.761818 0.000000 0.000000 -0.647791 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x76F9901C, 328372711, 0x6F990028, 109.26, 190.351, 240.055, 0.613922, 0, 0, -0.789367, False, '2025-08-04 02:39:06'); /* Calfadar */
/* @teleloc 0x6F990028 [109.260002 190.350998 240.054993] 0.613922 0.000000 0.000000 -0.789367 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x76F9901D, 73626312, 0x6F99002F, 136.86, 155.24, 240.005, -0.916243, 0, 0, -0.400624, False, '2025-08-04 03:38:36'); /* Xander The Great */
/* @teleloc 0x6F99002F [136.860001 155.240005 240.005005] -0.916243 0.000000 0.000000 -0.400624 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x76F9901E, 999420, 0x6F990026, 101.098, 127.078, 240.005, 0.92388, 0, 0, 0.382684, False, '2025-08-04 19:45:58'); /* Wiccan Witch */
/* @teleloc 0x6F990026 [101.098000 127.078003 240.005005] 0.923880 0.000000 0.000000 0.382684 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x76F9901F, 23471287, 0x6F99002F, 137.754, 159.244, 240.006, -0.928278, 0, 0, -0.371886, False, '2025-08-19 12:37:01'); /* Trainer of Specialized Magic */
/* @teleloc 0x6F99002F [137.753998 159.244003 240.005997] -0.928278 0.000000 0.000000 -0.371886 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x76F99020, 4200152, 0x6F990040, 186.023, 168.258, 235.549, 0.484435, 0, 0, -0.874828, False, '2025-09-10 21:52:37'); /* Gate */
/* @teleloc 0x6F990040 [186.022995 168.257996 235.548996] 0.484435 0.000000 0.000000 -0.874828 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x76F99023, 4200152, 0x6F990036, 151.301, 124.601, 234.93, 0.390025, 0, 0, -0.920804, False, '2025-09-10 21:52:48'); /* Gate */
/* @teleloc 0x6F990036 [151.300995 124.600998 234.929993] 0.390025 0.000000 0.000000 -0.920804 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x76F99024, 4200152, 0x6F99002D, 140.214, 113.227, 234.495, 0.209139, 0, 0, -0.977886, False, '2025-09-10 21:52:53'); /* Gate */
/* @teleloc 0x6F99002D [140.214005 113.226997 234.494995] 0.209139 0.000000 0.000000 -0.977886 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x76F99025, 4200152, 0x6F99002D, 125.244, 106.827, 235.888, 0.261879, 0, 0, -0.965101, False, '2025-09-10 21:52:56'); /* Gate */
/* @teleloc 0x6F99002D [125.244003 106.827003 235.888000] 0.261879 0.000000 0.000000 -0.965101 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x76F99026, 4200152, 0x6F990025, 107.335, 99.2744, 235.656, 0.135219, 0, 0, -0.990816, False, '2025-09-10 21:52:59'); /* Gate */
/* @teleloc 0x6F990025 [107.334999 99.274399 235.656006] 0.135219 0.000000 0.000000 -0.990816 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x76F99027, 4200152, 0x6F990020, 90.7441, 176.741, 239.179, -0.749787, 0, 0, 0.661679, False, '2025-09-10 21:53:08'); /* Gate */
/* @teleloc 0x6F990020 [90.744102 176.740997 239.179001] -0.749787 0.000000 0.000000 0.661679 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x76F99028, 4200152, 0x6F99001F, 92.8863, 160.908, 239.536, -0.804817, 0, 0, 0.593523, False, '2025-09-10 21:53:11'); /* Gate */
/* @teleloc 0x6F99001F [92.886299 160.908005 239.535995] -0.804817 0.000000 0.000000 0.593523 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x76F99029, 4200152, 0x6F99001F, 93.5698, 145.409, 239.65, -0.625374, 0, 0, 0.780326, False, '2025-09-10 21:53:15'); /* Gate */
/* @teleloc 0x6F99001F [93.569801 145.408997 239.649994] -0.625374 0.000000 0.000000 0.780326 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x76F9902A, 4200152, 0x6F99001E, 90.4644, 130.038, 239.132, -0.739297, 0, 0, 0.67338, False, '2025-09-10 21:53:18'); /* Gate */
/* @teleloc 0x6F99001E [90.464401 130.037994 239.132004] -0.739297 0.000000 0.000000 0.673380 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x76F9902B, 4200152, 0x6F99001D, 95.1911, 108.315, 237.905, -0.80063, 0, 0, 0.59916, False, '2025-09-10 21:53:47'); /* Gate */
/* @teleloc 0x6F99001D [95.191101 108.315002 237.904999] -0.800630 0.000000 0.000000 0.599160 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x76F9902C, 4200152, 0x6F99003F, 180.087, 153.097, 232.535, 0.542486, 0, 0, -0.840065, False, '2025-09-10 22:03:43'); /* Gate */
/* @teleloc 0x6F99003F [180.087006 153.097000 232.535004] 0.542486 0.000000 0.000000 -0.840065 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x76F9902D, 4200152, 0x6F990036, 167.2286, 136.8183, 233.384, 0.371941, 0, 0, -0.928256, False, '2025-09-10 22:04:08'); /* Gate */
/* @teleloc 0x6F990036 [167.228607 136.818298 233.384003] 0.371941 0.000000 0.000000 -0.928256 */
