DELETE FROM `landblock_instance` WHERE `landblock` = 0xE3D3;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E3D3000, 700245, 0xE3D30007, 8.44083, 167.781, 6.055, 0.066253, 0, 0, 0.997803, False, '2025-07-19 15:53:29'); /* MassiveEnragedPenguinGen */
/* @teleloc 0xE3D30007 [8.440830 167.781006 6.055000] 0.066253 0.000000 0.000000 0.997803 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E3D3001, 91737171, 0xE3D3000C, 29.234, 77.8537, -0.395, -0.621295, 0, 0, -0.783577, False, '2025-07-27 14:43:39');
/* @teleloc 0xE3D3000C [29.233999 77.853699 -0.395000] -0.621295 0.000000 0.000000 -0.783577 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E3D3002, 91737171, 0xE3D30021, 114.7907, 0.502441, -0.845, -0.99238, 0, 0, -0.123219, False, '2025-07-27 15:42:16');
/* @teleloc 0xE3D30021 [114.790703 0.502441 -0.845000] -0.992380 0.000000 0.000000 -0.123219 */
