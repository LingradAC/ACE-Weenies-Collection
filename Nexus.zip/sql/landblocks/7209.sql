DELETE FROM `landblock_instance` WHERE `landblock` = 0x7209;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x77209000, 24487, 0x72090000, 2.60062, 24.9863, -0.095, 0.205266, 0, 0, -0.978706, False, '2021-11-01 00:00:00'); /* Ulgrim Island Beach Gen */
/* @teleloc 0x72090000 [2.600620 24.986300 -0.095000] 0.205266 0.000000 0.000000 -0.978706 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x77209002, 24487, 0x72090000, 54.215, 57.7744, -0.445, 0.705338, 0, 0, -0.708872, False, '2021-11-01 00:00:00'); /* Ulgrim Island Beach Gen */
/* @teleloc 0x72090000 [54.215000 57.774399 -0.445000] 0.705338 0.000000 0.000000 -0.708872 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x77209004, 24487, 0x72090000, 69.3784, 14.3632, -0.095, 0.982168, 0, 0, -0.188006, False, '2021-11-01 00:00:00'); /* Ulgrim Island Beach Gen */
/* @teleloc 0x72090000 [69.378403 14.363200 -0.095000] 0.982168 0.000000 0.000000 -0.188006 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x77209007, 24487, 0x72090000, 125.632, 54.7459, -0.00283, -0.773068, 0, 0, 0.634323, False, '2021-11-01 00:00:00'); /* Ulgrim Island Beach Gen */
/* @teleloc 0x72090000 [125.632004 54.745899 -0.002830] -0.773068 0.000000 0.000000 0.634323 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x77209009, 24487, 0x72090000, 165.3, 99.0139, 0.005, -0.829976, 0, 0, 0.557799, False, '2021-11-01 00:00:00'); /* Ulgrim Island Beach Gen */
/* @teleloc 0x72090000 [165.300003 99.013901 0.005000] -0.829976 0.000000 0.000000 0.557799 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7720900B, 24487, 0x72090000, 181.169, 117.514, -0.095, 0.912751, 0, 0, 0.408516, False, '2021-11-01 00:00:00'); /* Ulgrim Island Beach Gen */
/* @teleloc 0x72090000 [181.169006 117.514000 -0.095000] 0.912751 0.000000 0.000000 0.408516 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7720900E, 24487, 0x72090000, 172.472, 178.289, -0.095, 0.898611, 0, 0, -0.438747, False, '2021-11-01 00:00:00'); /* Ulgrim Island Beach Gen */
/* @teleloc 0x72090000 [172.472000 178.289001 -0.095000] 0.898611 0.000000 0.000000 -0.438747 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x77209010, 24490, 0x72090000, 110.795, 87.5071, 3.29726, 0.590162, 0, 0, 0.807285, False, '2021-11-01 00:00:00'); /* Ulgrim Island Tree-Line Gen */
/* @teleloc 0x72090000 [110.794998 87.507103 3.297260] 0.590162 0.000000 0.000000 0.807285 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x77209012, 24490, 0x72090000, 109.464, 163.446, 3.26251, -0.935622, 0, 0, -0.353004, False, '2021-11-01 00:00:00'); /* Ulgrim Island Tree-Line Gen */
/* @teleloc 0x72090000 [109.463997 163.445999 3.262510] -0.935622 0.000000 0.000000 -0.353004 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x77209013, 24490, 0x72090000, 75.2287, 95.3261, 0.486962, -0.611894, 0, 0, 0.79094, False, '2021-11-01 00:00:00'); /* Ulgrim Island Tree-Line Gen */
/* @teleloc 0x72090000 [75.228699 95.326103 0.486962] -0.611894 0.000000 0.000000 0.790940 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x77209014, 24490, 0x72090000, 29.1561, 120.393, 4, -0.079655, 0, 0, -0.996822, False, '2021-11-01 00:00:00'); /* Ulgrim Island Tree-Line Gen */
/* @teleloc 0x72090000 [29.156099 120.392998 4.000000] -0.079655 0.000000 0.000000 -0.996822 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x77209016, 24488, 0x72090000, 71.8362, 157.229, 2.9026, -0.806323, 0, 0, 0.591475, False, '2021-11-01 00:00:00'); /* Ulgrim Island Jungle-Mix Gen */
/* @teleloc 0x72090000 [71.836197 157.229004 2.902600] -0.806323 0.000000 0.000000 0.591475 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x77209018, 24488, 0x72090000, 79.6081, 126.454, 4.005, -0.569564, 0, 0, -0.821947, False, '2021-11-01 00:00:00'); /* Ulgrim Island Jungle-Mix Gen */
/* @teleloc 0x72090000 [79.608101 126.454002 4.005000] -0.569564 0.000000 0.000000 -0.821947 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x77209019, 24488, 0x72090000, 20.3821, 162.11, 1.2881, -0.766706, 0, 0, -0.641998, False, '2021-11-01 00:00:00'); /* Ulgrim Island Jungle-Mix Gen */
/* @teleloc 0x72090000 [20.382099 162.110001 1.288100] -0.766706 0.000000 0.000000 -0.641998 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7720901A, 23884, 0x72090000, 73.918, 191.753, 2.005, -0.602061, 0, 0, -0.79845, False, '2021-11-01 00:00:00'); /* Keg */
/* @teleloc 0x72090000 [73.917999 191.753006 2.005000] -0.602061 0.000000 0.000000 -0.798450 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7720901B,  1154, 0x7209002B, 130.129, 53.6735, 0.463012, -0.773068, 0, 0, 0.634323, False, '2021-11-01 00:00:00'); /* Linkable Monster Generator */
/* @teleloc 0x7209002B [130.128998 53.673500 0.463012] -0.773068 0.000000 0.000000 0.634323 */

INSERT INTO `landblock_instance_link` (`parent_GUID`, `child_GUID`, `last_Modified`)
VALUES (0x7720901B, 0x7720901C, '2021-11-01 00:00:00') /* The Black Breath (32804) */
     , (0x7720901B, 0x7720901D, '2021-11-01 00:00:00')
     , (0x7720901B, 0x7720901E, '2021-11-01 00:00:00')
     , (0x7720901B, 0x7720901F, '2021-11-01 00:00:00')
     , (0x7720901B, 0x77209020, '2021-11-01 00:00:00')
     , (0x7720901B, 0x77209021, '2021-11-01 00:00:00')
     , (0x7720901B, 0x77209022, '2021-11-01 00:00:00')
     , (0x7720901B, 0x77209023, '2021-11-01 00:00:00')
     , (0x7720901B, 0x77209024, '2021-11-01 00:00:00')
     , (0x7720901B, 0x77209025, '2021-11-01 00:00:00')
     , (0x7720901B, 0x77209026, '2021-11-01 00:00:00')
     , (0x7720901B, 0x77209027, '2021-11-01 00:00:00')
     , (0x7720901B, 0x77209028, '2021-11-01 00:00:00');

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7720901C, 32804, 0x7209002F, 125.494, 153.357, 2.77238, -0.935622, 0, 0, -0.353004,  True, '2021-11-01 00:00:00'); /* The Black Breath */
/* @teleloc 0x7209002F [125.494003 153.356995 2.772380] -0.935622 0.000000 0.000000 -0.353004 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x77209233, 32804, 0x7209001C, 88.974, 92.2144, 2.52353, -0.611894, 0, 0, 0.79094,  True, '2021-11-01 00:00:00'); /* The Black Breath */
/* @teleloc 0x7209001C [88.973999 92.214401 2.523530] -0.611894 0.000000 0.000000 0.790940 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x77209259, 32804, 0x72090027, 115.013, 164.997, 2.67584, -0.935622, 0, 0, -0.353004,  True, '2021-11-01 00:00:00'); /* The Black Breath */
/* @teleloc 0x72090027 [115.013000 164.996994 2.675840] -0.935622 0.000000 0.000000 -0.353004 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x77209308, 32804, 0x72090024, 119.729, 81.4488, 2.7974, 0.590162, 0, 0, 0.807285,  True, '2021-11-01 00:00:00'); /* The Black Breath */
/* @teleloc 0x72090024 [119.728996 81.448799 2.797400] 0.590162 0.000000 0.000000 0.807285 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7720930B, 32804, 0x72090027, 107.786, 163.79, 3.37864, -0.935622, 0, 0, -0.353004,  True, '2021-11-01 00:00:00'); /* The Black Breath */
/* @teleloc 0x72090027 [107.786003 163.789993 3.378640] -0.935622 0.000000 0.000000 -0.353004 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x77209386, 32804, 0x7209001E, 80.2172, 132.158, 4.01, -0.569564, 0, 0, -0.821947,  True, '2021-11-01 00:00:00'); /* The Black Breath */
/* @teleloc 0x7209001E [80.217201 132.158005 4.010000] -0.569564 0.000000 0.000000 -0.821947 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x77209387, 32804, 0x72090014, 71.6058, 85.3714, -0.09, -0.611894, 0, 0, 0.79094,  True, '2021-11-01 00:00:00'); /* The Black Breath */
/* @teleloc 0x72090014 [71.605797 85.371399 -0.090000] -0.611894 0.000000 0.000000 0.790940 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7720944D, 32804, 0x7209001C, 74.0185, 93.342, 0.178205, -0.611894, 0, 0, 0.79094,  True, '2021-11-01 00:00:00'); /* The Black Breath */
/* @teleloc 0x7209001C [74.018501 93.342003 0.178205] -0.611894 0.000000 0.000000 0.790940 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7720950B, 32804, 0x7209001C, 73.9476, 87.06, 0.172299, -0.611894, 0, 0, 0.79094,  True, '2021-11-01 00:00:00'); /* The Black Breath */
/* @teleloc 0x7209001C [73.947601 87.059998 0.172299] -0.611894 0.000000 0.000000 0.790940 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x772095C8, 32804, 0x72090027, 119.007, 150.58, 3.54439, -0.935622, 0, 0, -0.353004,  True, '2021-11-01 00:00:00'); /* The Black Breath */
/* @teleloc 0x72090027 [119.007004 150.580002 3.544390] -0.935622 0.000000 0.000000 -0.353004 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7720960B, 32804, 0x72090027, 101.758, 163.157, 3.93379, -0.935622, 0, 0, -0.353004,  True, '2021-11-01 00:00:00'); /* The Black Breath */
/* @teleloc 0x72090027 [101.758003 163.156998 3.933790] -0.935622 0.000000 0.000000 -0.353004 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x77209697, 32804, 0x72090027, 99.7604, 154.257, 4.01, -0.935622, 0, 0, -0.353004,  True, '2021-11-01 00:00:00'); /* The Black Breath */
/* @teleloc 0x72090027 [99.760399 154.257004 4.010000] -0.935622 0.000000 0.000000 -0.353004 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x77209699, 32804, 0x72090027, 106.909, 149.902, 4.01, -0.935622, 0, 0, -0.353004,  True, '2021-11-01 00:00:00'); /* The Black Breath */
/* @teleloc 0x72090027 [106.908997 149.901993 4.010000] -0.935622 0.000000 0.000000 -0.353004 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7720969A, 73217237, 0x72090023, 115.169, 48.0605, 0.060044, -0.90203, 0, 0, -0.431674, False, '2025-08-10 19:44:53'); /* Islandgolemgen */
/* @teleloc 0x72090023 [115.168999 48.060501 0.060044] -0.902030 0.000000 0.000000 -0.431674 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7720969B, 73217237, 0x7209000A, 34.0578, 29.5992, -0.395, -0.600536, 0, 0, -0.799598, False, '2025-08-10 19:44:59'); /* Islandgolemgen */
/* @teleloc 0x7209000A [34.057800 29.599199 -0.395000] -0.600536 0.000000 0.000000 -0.799598 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7720969C, 73217237, 0x72090026, 96.211, 124.536, 4.05498, -0.571592, 0, 0, 0.820538, False, '2025-08-10 19:47:43'); /* Islandgolemgen */
/* @teleloc 0x72090026 [96.210999 124.536003 4.054980] -0.571592 0.000000 0.000000 0.820538 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7720969D, 73217237, 0x72090021, 119.504, 10.9221, -0.395, 0.907225, 0, 0, 0.420645, False, '2025-08-12 12:39:31'); /* Islandgolemgen */
/* @teleloc 0x72090021 [119.503998 10.922100 -0.395000] 0.907225 0.000000 0.000000 0.420645 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7720969E, 73217237, 0x72090019, 95.6163, 13.3329, -0.045, 0.606805, 0, 0, 0.794851, False, '2025-08-12 12:39:33'); /* Islandgolemgen */
/* @teleloc 0x72090019 [95.616302 13.332900 -0.045000] 0.606805 0.000000 0.000000 0.794851 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7720969F, 73217237, 0x72090001, 15.5846, 2.0542, -0.045, 0.951413, 0, 0, 0.307918, False, '2025-08-12 12:39:39'); /* Islandgolemgen */
/* @teleloc 0x72090001 [15.584600 2.054200 -0.045000] 0.951413 0.000000 0.000000 0.307918 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x772096A0, 73217237, 0x72090003, 2.45383, 48.4797, -0.045, 0.997502, 0, 0, 0.070642, False, '2025-08-12 12:39:42'); /* Islandgolemgen */
/* @teleloc 0x72090003 [2.453830 48.479698 -0.045000] 0.997502 0.000000 0.000000 0.070642 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x772096A1, 73217237, 0x72090030, 120.029, 179.813, 0.967451, 0.249905, 0, 0, -0.96827, False, '2025-08-12 12:40:52'); /* Islandgolemgen */
/* @teleloc 0x72090030 [120.028999 179.813004 0.967451] 0.249905 0.000000 0.000000 -0.968270 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x772096A2, 73217237, 0x7209003E, 169.848, 143.688, 0.055, 0.331293, 0, 0, -0.943528, False, '2025-08-12 12:40:56'); /* Islandgolemgen */
/* @teleloc 0x7209003E [169.848007 143.688004 0.055000] 0.331293 0.000000 0.000000 -0.943528 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x772096A3, 73217237, 0x7209003D, 181.196, 105.707, -0.395, -0.05604, 0, 0, -0.998429, False, '2025-08-12 12:40:58'); /* Islandgolemgen */
/* @teleloc 0x7209003D [181.195999 105.707001 -0.395000] -0.056040 0.000000 0.000000 -0.998429 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x772096A4, 73217237, 0x72090034, 167.678, 85.5427, -0.045, -0.434796, 0, 0, -0.900529, False, '2025-08-12 12:41:01'); /* Islandgolemgen */
/* @teleloc 0x72090034 [167.677994 85.542702 -0.045000] -0.434796 0.000000 0.000000 -0.900529 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x772096A5, 83217237, 0x72090009, 26.5709, 2.02964, -0.045, -0.999783, 0, 0, -0.020834, False, '2025-09-04 22:34:17'); /* Trophy Keeper of Honor */
/* @teleloc 0x72090009 [26.570900 2.029640 -0.045000] -0.999783 0.000000 0.000000 -0.020834 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x772096A6, 83217237, 0x72090020, 78.2398, 177.632, 2.055, 0.260125, 0, 0, 0.965575, False, '2025-09-04 22:35:28'); /* Trophy Keeper of Honor */
/* @teleloc 0x72090020 [78.239799 177.632004 2.055000] 0.260125 0.000000 0.000000 0.965575 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x772096A7, 83217237, 0x7209000E, 47.4698, 138.838, 4.055, 0.33718, 0, 0, 0.94144, False, '2025-09-04 22:35:31'); /* Trophy Keeper of Honor */
/* @teleloc 0x7209000E [47.469799 138.837997 4.055000] 0.337180 0.000000 0.000000 0.941440 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x772096A8, 83217237, 0x7209000D, 31.7351, 119.689, 4.0032, 0.33718, 0, 0, 0.94144, False, '2025-09-04 22:35:33'); /* Trophy Keeper of Honor */
/* @teleloc 0x7209000D [31.735100 119.689003 4.003200] 0.337180 0.000000 0.000000 0.941440 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x772096A9, 73217237, 0x7209000F, 27.876, 156.767, 1.92714, 0.671295, 0, 0, -0.74119, False, '2025-09-06 02:51:14'); /* Islandgolemgen */
/* @teleloc 0x7209000F [27.875999 156.766998 1.927140] 0.671295 0.000000 0.000000 -0.741190 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x772096AA, 73217237, 0x7209002A, 121.084, 43.7172, -0.045, -0.970285, 0, 0, -0.241966, False, '2025-09-06 18:57:08'); /* Islandgolemgen */
/* @teleloc 0x7209002A [121.084000 43.717201 -0.045000] -0.970285 0.000000 0.000000 -0.241966 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x772096AB, 73217237, 0x72090022, 105.514, 42.6581, -0.045, -0.677735, 0, 0, -0.735306, False, '2025-09-06 18:57:10'); /* Islandgolemgen */
/* @teleloc 0x72090022 [105.514000 42.658100 -0.045000] -0.677735 0.000000 0.000000 -0.735306 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x772096AC, 73217237, 0x7209001A, 78.7037, 40.5535, 0.055, -0.916248, 0, 0, -0.400611, False, '2025-09-06 18:57:13'); /* Islandgolemgen */
/* @teleloc 0x7209001A [78.703697 40.553501 0.055000] -0.916248 0.000000 0.000000 -0.400611 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x772096AD, 73217237, 0x72090013, 59.2294, 55.6535, -0.395, -0.983848, 0, 0, -0.179007, False, '2025-09-06 18:57:15'); /* Islandgolemgen */
/* @teleloc 0x72090013 [59.229401 55.653500 -0.395000] -0.983848 0.000000 0.000000 -0.179007 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x772096AE, 73217237, 0x72090013, 51.8215, 67.3255, 0.185309, -0.942249, 0, 0, -0.334912, False, '2025-09-06 18:57:16'); /* Islandgolemgen */
/* @teleloc 0x72090013 [51.821499 67.325500 0.185309] -0.942249 0.000000 0.000000 -0.334912 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x772096AF, 73217237, 0x7209000C, 31.7734, 79.8233, -0.395, -0.58155, 0, 0, -0.813511, False, '2025-09-06 18:57:18'); /* Islandgolemgen */
/* @teleloc 0x7209000C [31.773399 79.823303 -0.395000] -0.581550 0.000000 0.000000 -0.813511 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x772096B0, 73217237, 0x72090004, 0.843694, 75.6883, -0.395, -0.697621, 0, 0, -0.716467, False, '2025-09-06 18:57:20'); /* Islandgolemgen */
/* @teleloc 0x72090004 [0.843694 75.688301 -0.395000] -0.697621 0.000000 0.000000 -0.716467 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x772096B1, 73217237, 0x72090030, 139.866, 179.004, -0.045, -0.491901, 0, 0, 0.870651, False, '2025-09-06 18:58:33'); /* Islandgolemgen */
/* @teleloc 0x72090030 [139.865997 179.003998 -0.045000] -0.491901 0.000000 0.000000 0.870651 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x772096B2, 73217237, 0x7209003F, 168.962, 147.635, -0.045, -0.100169, 0, 0, 0.99497, False, '2025-09-06 18:58:36'); /* Islandgolemgen */
/* @teleloc 0x7209003F [168.962006 147.634995 -0.045000] -0.100169 0.000000 0.000000 0.994970 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x772096B3, 73217237, 0x7209003D, 169.128, 117.085, -0.045, 0.279535, 0, 0, 0.960136, False, '2025-09-06 18:58:39'); /* Islandgolemgen */
/* @teleloc 0x7209003D [169.128006 117.084999 -0.045000] 0.279535 0.000000 0.000000 0.960136 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x772096B4, 73217237, 0x72090034, 159.038, 95.3081, -0.045, 0.346635, 0, 0, 0.938, False, '2025-09-06 18:58:41'); /* Islandgolemgen */
/* @teleloc 0x72090034 [159.037994 95.308098 -0.045000] 0.346635 0.000000 0.000000 0.938000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x772096B5, 73217237, 0x7209002B, 127.1043, 51.24525, -0.045, 0.629866, 0, 0, 0.776704, False, '2025-09-06 18:58:45'); /* Islandgolemgen */
/* @teleloc 0x7209002B [127.104301 51.245251 -0.045000] 0.629866 0.000000 0.000000 0.776704 */
