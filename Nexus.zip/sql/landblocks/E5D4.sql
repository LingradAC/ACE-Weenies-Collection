DELETE FROM `landblock_instance` WHERE `landblock` = 0xE5D4;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E5D4000, 43581, 0xE5D40102, 131.983, 116.687, 192.337, -0.99996, 0, 0, -0.008969, False, '2021-11-01 00:00:00'); /* Queen's Burrow */
/* @teleloc 0xE5D40102 [131.983002 116.686996 192.337006] -0.999960 0.000000 0.000000 -0.008969 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E5D4001, 43582, 0xE5D40106, 84.0812, 44.0264, 192.347, -0.999578, 0, 0, -0.029036, False, '2021-11-01 00:00:00'); /* Queen's Burrow */
/* @teleloc 0xE5D40106 [84.081200 44.026402 192.347000] -0.999578 0.000000 0.000000 -0.029036 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E5D4002, 12310925, 0xE5D40027, 116.689, 144.182, -0.045, 0.996918, 0, 0, 0.078453, False, '2025-07-27 19:50:10'); /* RavagedDrudgegener */
/* @teleloc 0xE5D40027 [116.689003 144.182007 -0.045000] 0.996918 0.000000 0.000000 0.078453 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E5D4003, 12310925, 0xE5D40014, 69.1756, 76.1176, 0.055, 0.96567, 0, 0, -0.259771, False, '2025-07-27 19:51:50'); /* RavagedDrudgegener */
/* @teleloc 0xE5D40014 [69.175598 76.117599 0.055000] 0.965670 0.000000 0.000000 -0.259771 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E5D4004, 12310925, 0xE5D4000C, 31.819, 84.9368, -0.395, 0.867092, 0, 0, -0.498147, False, '2025-07-27 19:51:54'); /* RavagedDrudgegener */
/* @teleloc 0xE5D4000C [31.819000 84.936798 -0.395000] 0.867092 0.000000 0.000000 -0.498147 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E5D4005, 12310925, 0xE5D4001E, 86.896, 123.763, -0.045, 0.635603, 0, 0, -0.772016, False, '2025-07-27 19:52:00'); /* RavagedDrudgegener */
/* @teleloc 0xE5D4001E [86.896004 123.763000 -0.045000] 0.635603 0.000000 0.000000 -0.772016 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E5D4008, 86653838, 0xE5D40038, 145.396, 169.826, 0.055, 0.147019, 0, 0, -0.989134, False, '2025-07-27 19:54:07'); /* palmtree1 */
/* @teleloc 0xE5D40038 [145.395996 169.826004 0.055000] 0.147019 0.000000 0.000000 -0.989134 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E5D4009, 86653838, 0xE5D4002F, 133.334, 160.987, 0.055, -0.172094, 0, 0, -0.985081, False, '2025-07-27 19:54:09'); /* palmtree1 */
/* @teleloc 0xE5D4002F [133.334000 160.987000 0.055000] -0.172094 0.000000 0.000000 -0.985081 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E5D400A, 86653838, 0xE5D40040, 173.811, 169.465, -0.045, -0.779158, 0, 0, -0.626828, False, '2025-07-27 19:54:21'); /* palmtree1 */
/* @teleloc 0xE5D40040 [173.811005 169.464996 -0.045000] -0.779158 0.000000 0.000000 -0.626828 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E5D400B, 12310925, 0xE5D4000A, 25.4792, 30.6182, 0.055, -0.229721, 0, 0, 0.973257, False, '2025-07-27 19:56:58'); /* RavagedDrudgegener */
/* @teleloc 0xE5D4000A [25.479200 30.618200 0.055000] -0.229721 0.000000 0.000000 0.973257 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E5D400C, 2316917, 0xE5D40038, 166.721, 176.585, 0.055, 0.858291, 0, 0, 0.513164, False, '2025-08-03 16:03:59'); /* stompygene */
/* @teleloc 0xE5D40038 [166.720993 176.585007 0.055000] 0.858291 0.000000 0.000000 0.513164 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E5D400D, 2316917, 0xE5D40040, 170.0272, 180.4424, -0.045, 0.690848, 0, 0, -0.723, False, '2025-08-21 10:31:59'); /* stompygene */
/* @teleloc 0xE5D40040 [170.027206 180.442398 -0.045000] 0.690848 0.000000 0.000000 -0.723000 */
