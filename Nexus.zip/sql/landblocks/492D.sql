DELETE FROM `landblock_instance` WHERE `landblock` = 0x492D;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7492D001, 40919, 0x492D0017, 59.6104, 156.702, 4.02797, -0.468859, 0, 0, -0.883273, False, '2022-03-31 06:02:40'); /* Up to Arcanum Lookout */
/* @teleloc 0x492D0017 [59.610401 156.701996 4.027970] -0.468859 0.000000 0.000000 -0.883273 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7492D002, 40920, 0x492D0017, 60.0659, 148.216, 29.5125, 0.029407, 0, 0, 0.999568, False, '2022-03-31 06:02:40'); /* Down to Surface */
/* @teleloc 0x492D0017 [60.065899 148.216003 29.512501] 0.029407 0.000000 0.000000 0.999568 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7492D003, 36236, 0x492D0017, 64.1195, 155.677, 29.5805, 0.678557, 0, 0, 0.734548, False, '2022-03-31 06:02:40'); /* Lo Shoen */
/* @teleloc 0x492D0017 [64.119499 155.677002 29.580500] 0.678557 0.000000 0.000000 0.734548 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7492D004, 52310, 0x492D0017, 55.6993, 161.671, 29.5805, -0.735851, 0, 0, -0.677143, False, '2022-03-31 06:02:40'); /* Slubbley */
/* @teleloc 0x492D0017 [55.699299 161.671005 29.580500] -0.735851 0.000000 0.000000 -0.677143 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7492D005, 40922, 0x492D0017, 52.5783, 156.265, 29.5805, 0.707107, 0, 0, -0.707107, False, '2022-03-31 06:02:40'); /* Sharia Blackmist */
/* @teleloc 0x492D0017 [52.578300 156.264999 29.580500] 0.707107 0.000000 0.000000 -0.707107 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7492D006, 36237, 0x492D0017, 64.3193, 154.385, 29.573, 0.764842, 0, 0, 0.644218, False, '2022-03-31 06:02:40'); /* Lo Shoen's Pack */
/* @teleloc 0x492D0017 [64.319298 154.384995 29.573000] 0.764842 0.000000 0.000000 0.644218 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7492D007, 86653879, 0x492D0017, 53.70186, 152.8782, 29.58046, -0.420635, 0, 0, -0.90723, False, '2025-07-29 13:37:55'); /* BLUE BALL OF LIGHT */
/* @teleloc 0x492D0017 [53.701859 152.878204 29.580460] -0.420635 0.000000 0.000000 -0.907230 */
