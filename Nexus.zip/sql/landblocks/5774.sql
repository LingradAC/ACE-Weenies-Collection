DELETE FROM `landblock_instance` WHERE `landblock` = 0x5774;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x75774018,  6122, 0x57740100, 230, -100, -0.5, 1, 0, 0, 0, False, '2005-02-09 10:00:00'); /* Acid */
/* @teleloc 0x57740100 [230.000000 -100.000000 -0.500000] 1.000000 0.000000 0.000000 0.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x75774019,  6122, 0x57740101, 230, -110, -0.5, 1, 0, 0, 0, False, '2005-02-09 10:00:00'); /* Acid */
/* @teleloc 0x57740101 [230.000000 -110.000000 -0.500000] 1.000000 0.000000 0.000000 0.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7577401A,  6122, 0x57740102, 240, -100, -0.5, 1, 0, 0, 0, False, '2005-02-09 10:00:00'); /* Acid */
/* @teleloc 0x57740102 [240.000000 -100.000000 -0.500000] 1.000000 0.000000 0.000000 0.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7577401B,  6122, 0x57740103, 240, -110, -0.5, 1, 0, 0, 0, False, '2005-02-09 10:00:00'); /* Acid */
/* @teleloc 0x57740103 [240.000000 -110.000000 -0.500000] 1.000000 0.000000 0.000000 0.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x75774029, 14546, 0x577401EF, 233.424, -90.068, 6.005, -0.787051, 0, 0, -0.616888, False, '2005-02-09 10:00:00'); /* Putrescent Air */
/* @teleloc 0x577401EF [233.423996 -90.068001 6.005000] -0.787051 0.000000 0.000000 -0.616888 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x75774033, 14546, 0x57740206, 242.48, -89.919, 6.005, -0.689327, 0, 0, -0.72445, False, '2005-02-09 10:00:00'); /* Putrescent Air */
/* @teleloc 0x57740206 [242.479996 -89.918999 6.005000] -0.689327 0.000000 0.000000 -0.724450 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x75774041, 10900, 0x57740101, 226.126, -113.867, -0.5, 1, 0, 0, 0, False, '2005-02-09 10:00:00'); /* Pressure Plate - Olthoi Worker */
/* @teleloc 0x57740101 [226.126007 -113.866997 -0.500000] 1.000000 0.000000 0.000000 0.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x75774047, 10900, 0x57740102, 243.863, -96.1266, -0.45, 1, 0, 0, 0, False, '2005-02-09 10:00:00'); /* Pressure Plate - Olthoi Worker */
/* @teleloc 0x57740102 [243.863007 -96.126602 -0.450000] 1.000000 0.000000 0.000000 0.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x75774070, 24349, 0x5774014E, 43.7851, -123.567, 6.005, 0.054288, 0, 0, -0.998525, False, '2005-02-09 10:00:00'); /* Olthoi Cistern */
/* @teleloc 0x5774014E [43.785099 -123.567001 6.005000] 0.054288 0.000000 0.000000 -0.998525 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7577407D, 24348, 0x57740159, 48.1557, -123.164, 6.005, 0.349401, 0, 0, 0.936973, False, '2005-02-09 10:00:00'); /* Olthoi Cistern */
/* @teleloc 0x57740159 [48.155701 -123.164001 6.005000] 0.349401 0.000000 0.000000 0.936973 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x757740B4,  4074, 0x577401C3, 205.558, -109.803, 6.005, -0.712256, 0, 0, -0.70192, False, '2005-02-09 10:00:00'); /* Magic trap */
/* @teleloc 0x577401C3 [205.557999 -109.803001 6.005000] -0.712256 0.000000 0.000000 -0.701920 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x757740BF, 14546, 0x577401D2, 221.605, -87.4057, 6.005, 0.581683, 0, 0, -0.813416, False, '2005-02-09 10:00:00'); /* Putrescent Air */
/* @teleloc 0x577401D2 [221.604996 -87.405701 6.005000] 0.581683 0.000000 0.000000 -0.813416 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x757740C0, 14546, 0x577401D2, 220.087, -90.9162, 6.005, 0.940703, 0, 0, -0.339232, False, '2005-02-09 10:00:00'); /* Putrescent Air */
/* @teleloc 0x577401D2 [220.087006 -90.916199 6.005000] 0.940703 0.000000 0.000000 -0.339232 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x757740C1, 14546, 0x577401D2, 223.937, -89.9632, 6.005, 0.717144, 0, 0, -0.696925, False, '2005-02-09 10:00:00'); /* Putrescent Air */
/* @teleloc 0x577401D2 [223.936996 -89.963203 6.005000] 0.717144 0.000000 0.000000 -0.696925 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x757740C2,  7561, 0x577401D7, 220, -97.1044, 6.005, 1, 0, 0, 0, False, '2005-02-09 10:00:00'); /* Magic trap */
/* @teleloc 0x577401D7 [220.000000 -97.104401 6.005000] 1.000000 0.000000 0.000000 0.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x757740C3,  7562, 0x577401D7, 221.206, -103.949, 6.005, 0.062981, 0, 0, -0.998015, False, '2005-02-09 10:00:00'); /* Magic trap */
/* @teleloc 0x577401D7 [221.205994 -103.948997 6.005000] 0.062981 0.000000 0.000000 -0.998015 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x757740CC, 14546, 0x577401EF, 227.613, -90, 6.005, 1, 0, 0, 0, False, '2005-02-09 10:00:00'); /* Putrescent Air */
/* @teleloc 0x577401EF [227.613007 -90.000000 6.005000] 1.000000 0.000000 0.000000 0.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x757740DD, 14546, 0x57740206, 237.581, -90, 6.005, 1, 0, 0, 0, False, '2005-02-09 10:00:00'); /* Putrescent Air */
/* @teleloc 0x57740206 [237.580994 -90.000000 6.005000] 1.000000 0.000000 0.000000 0.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x757740E5, 14546, 0x57740215, 246.7, -90, 6.005, 1, 0, 0, 0, False, '2005-02-09 10:00:00'); /* Putrescent Air */
/* @teleloc 0x57740215 [246.699997 -90.000000 6.005000] 1.000000 0.000000 0.000000 0.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x757740E6, 14546, 0x57740215, 254.349, -90, 6.005, 1, 0, 0, 0, False, '2005-02-09 10:00:00'); /* Putrescent Air */
/* @teleloc 0x57740215 [254.348999 -90.000000 6.005000] 1.000000 0.000000 0.000000 0.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x757740E7, 14546, 0x57740215, 250.683, -90, 6.005, 1, 0, 0, 0, False, '2005-02-09 10:00:00'); /* Putrescent Air */
/* @teleloc 0x57740215 [250.682999 -90.000000 6.005000] 1.000000 0.000000 0.000000 0.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x75774102, 14546, 0x57740227, 258.892, -88.6667, 6.005, 1, 0, 0, 0, False, '2005-02-09 10:00:00'); /* Putrescent Air */
/* @teleloc 0x57740227 [258.891998 -88.666702 6.005000] 1.000000 0.000000 0.000000 0.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x75774151, 10900, 0x57740100, 233.409, -99.5215, -0.5, 1, 0, 0, 0, False, '2005-02-09 10:00:00'); /* Pressure Plate - Olthoi Worker */
/* @teleloc 0x57740100 [233.408997 -99.521500 -0.500000] 1.000000 0.000000 0.000000 0.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7577416F, 9928283, 0x57740146, 35.5767, -71.3761, 6.12419, -0.698566, 0, 0, 0.715545, False, '2025-07-11 12:37:40'); /* Pressure Plate */
/* @teleloc 0x57740146 [35.576698 -71.376099 6.124190] -0.698566 0.000000 0.000000 0.715545 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x75774170, 9928283, 0x57740146, 35.9497, -68.8456, 6, -0.698566, 0, 0, 0.715545, False, '2025-07-11 12:37:42'); /* Pressure Plate */
/* @teleloc 0x57740146 [35.949699 -68.845596 6.000000] -0.698566 0.000000 0.000000 0.715545 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7577418C, 9928283, 0x57740137, 18.8762, -64.064, 6, 0.999728, 0, 0, 0.023327, False, '2025-07-11 12:47:40'); /* Pressure Plate */
/* @teleloc 0x57740137 [18.876200 -64.064003 6.000000] 0.999728 0.000000 0.000000 0.023327 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x757741A1, 51719, 0x57740193, 118.634, -126.657, 5.937, -0.450344, 0, 0, 0.892855, False, '2025-07-11 13:39:45'); /* Platforms of Torment */
/* @teleloc 0x57740193 [118.634003 -126.656998 5.937000] -0.450344 0.000000 0.000000 0.892855 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x757741A2, 1623822, 0x57740243, 270.127, -137.436, 6.055, 0.775639, 0, 0, -0.631177, False, '2025-07-29 17:23:43'); /* BloodyOthloigener */
/* @teleloc 0x57740243 [270.127014 -137.436005 6.055000] 0.775639 0.000000 0.000000 -0.631177 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x757741A3, 1623822, 0x5774024B, 285.786, -114.838, 6.055, 0.996449, 0, 0, 0.084197, False, '2025-07-29 17:23:46'); /* BloodyOthloigener */
/* @teleloc 0x5774024B [285.786011 -114.837997 6.055000] 0.996449 0.000000 0.000000 0.084197 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x757741A4, 1623822, 0x57740216, 251.759, -101.035, 6.055, 0.630423, 0, 0, 0.776252, False, '2025-07-29 17:23:58'); /* BloodyOthloigener */
/* @teleloc 0x57740216 [251.759003 -101.035004 6.055000] 0.630423 0.000000 0.000000 0.776252 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x757741A5, 1623822, 0x57740220, 249.613, -125.228, 6.055, 0.096848, 0, 0, 0.995299, False, '2025-07-29 17:24:12'); /* BloodyOthloigener */
/* @teleloc 0x57740220 [249.613007 -125.227997 6.055000] 0.096848 0.000000 0.000000 0.995299 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x757741A6, 1623822, 0x577401E0, 222.141, -128.951, 6.055, 0.766829, 0, 0, 0.641852, False, '2025-07-29 17:26:18'); /* BloodyOthloigener */
/* @teleloc 0x577401E0 [222.141006 -128.951004 6.055000] 0.766829 0.000000 0.000000 0.641852 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x757741A7, 1623822, 0x577401B9, 211.559, -79.7314, 6.055, 0.519755, 0, 0, -0.854315, False, '2025-07-29 17:26:53'); /* BloodyOthloigener */
/* @teleloc 0x577401B9 [211.559006 -79.731400 6.055000] 0.519755 0.000000 0.000000 -0.854315 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x757741A8, 1623822, 0x5774019D, 200.453, -61.2388, 6.055, -0.995833, 0, 0, 0.091196, False, '2025-07-29 17:27:04'); /* BloodyOthloigener */
/* @teleloc 0x5774019D [200.453003 -61.238800 6.055000] -0.995833 0.000000 0.000000 0.091196 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x757741AA, 1623822, 0x57740196, 182.026, -136.802, 6.055, -0.317627, 0, 0, -0.948216, False, '2025-07-29 17:36:08'); /* BloodyOthloigener */
/* @teleloc 0x57740196 [182.026001 -136.802002 6.055000] -0.317627 0.000000 0.000000 -0.948216 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x757741AB, 1623822, 0x57740198, 191.064, -134.357, 6.055, 0.869743, 0, 0, -0.493504, False, '2025-07-29 17:36:10'); /* BloodyOthloigener */
/* @teleloc 0x57740198 [191.063995 -134.356995 6.055000] 0.869743 0.000000 0.000000 -0.493504 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x757741AC, 1623822, 0x577401C8, 211.226, -148.187, 6.055, -0.22559, 0, 0, 0.974222, False, '2025-07-29 17:36:18'); /* BloodyOthloigener */
/* @teleloc 0x577401C8 [211.225998 -148.186996 6.055000] -0.225590 0.000000 0.000000 0.974222 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x757741AD, 1623822, 0x5774024E, 289.941, -138.129, 6.09923, -0.7344, 0, 0, 0.678718, False, '2025-07-29 17:37:16'); /* BloodyOthloigener */
/* @teleloc 0x5774024E [289.941010 -138.128998 6.099230] -0.734400 0.000000 0.000000 0.678718 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x757741AE, 1623822, 0x57740102, 235.844, -104.633, -0.445, -0.784725, 0, 0, -0.619845, False, '2025-07-29 17:37:29'); /* BloodyOthloigener */
/* @teleloc 0x57740102 [235.843994 -104.633003 -0.445000] -0.784725 0.000000 0.000000 -0.619845 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x757741AF, 1623822, 0x57740235, 265.205, -72.1755, 6.055, 0.995071, 0, 0, 0.099164, False, '2025-07-29 17:38:39'); /* BloodyOthloigener */
/* @teleloc 0x57740235 [265.204987 -72.175499 6.055000] 0.995071 0.000000 0.000000 0.099164 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x757741B0, 1623822, 0x57740222, 264.802, -53.0269, 6.055, 0.997618, 0, 0, 0.068981, False, '2025-07-29 17:38:41'); /* BloodyOthloigener */
/* @teleloc 0x57740222 [264.802002 -53.026901 6.055000] 0.997618 0.000000 0.000000 0.068981 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x757741B1, 86659156, 0x57740205, 236.801, -48.1125, 6.0714, 0.841899, 0, 0, 0.539636, False, '2025-07-29 17:43:32'); /* BLACK PILLAR WITH RED LIGHTNING */
/* @teleloc 0x57740205 [236.800995 -48.112499 6.071400] 0.841899 0.000000 0.000000 0.539636 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x757741B2, 86659156, 0x577401ED, 228.289, -36.6994, 6.15041, 0.496071, 0, 0, 0.868282, False, '2025-07-29 17:43:39'); /* BLACK PILLAR WITH RED LIGHTNING */
/* @teleloc 0x577401ED [228.289001 -36.699402 6.150410] 0.496071 0.000000 0.000000 0.868282 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x757741B3, 86659156, 0x5774019D, 203.299, -62.7225, 6.05503, -0.240546, 0, 0, 0.970638, False, '2025-07-29 17:43:47'); /* BLACK PILLAR WITH RED LIGHTNING */
/* @teleloc 0x5774019D [203.298996 -62.722500 6.055030] -0.240546 0.000000 0.000000 0.970638 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x757741B4, 86659156, 0x577401B9, 213.339, -82.6807, 6.0555, -0.279521, 0, 0, 0.96014, False, '2025-07-29 17:43:53'); /* BLACK PILLAR WITH RED LIGHTNING */
/* @teleloc 0x577401B9 [213.339005 -82.680702 6.055500] -0.279521 0.000000 0.000000 0.960140 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x757741B5, 86659156, 0x577401A2, 199.053, -78.945, 6, 0.577559, 0, 0, 0.816349, False, '2025-07-29 17:43:56'); /* BLACK PILLAR WITH RED LIGHTNING */
/* @teleloc 0x577401A2 [199.052994 -78.945000 6.000000] 0.577559 0.000000 0.000000 0.816349 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x757741B6, 86659156, 0x577401A8, 204.056, -98.1057, 6, -0.952605, 0, 0, 0.304209, False, '2025-07-29 17:44:04'); /* BLACK PILLAR WITH RED LIGHTNING */
/* @teleloc 0x577401A8 [204.056000 -98.105698 6.000000] -0.952605 0.000000 0.000000 0.304209 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x757741B7, 86659156, 0x577401A8, 203.47, -102.266, 6, -0.32172, 0, 0, 0.946835, False, '2025-07-29 17:44:06'); /* BLACK PILLAR WITH RED LIGHTNING */
/* @teleloc 0x577401A8 [203.470001 -102.265999 6.000000] -0.321720 0.000000 0.000000 0.946835 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x757741B8, 86659156, 0x57740109, 225.578, -95.5183, -0.5, -0.958559, 0, 0, -0.284896, False, '2025-07-29 17:44:12'); /* BLACK PILLAR WITH RED LIGHTNING */
/* @teleloc 0x57740109 [225.578003 -95.518303 -0.500000] -0.958559 0.000000 0.000000 -0.284896 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x757741B9, 86659156, 0x5774010A, 225.51, -113.988, -0.5, 0.123441, 0, 0, 0.992352, False, '2025-07-29 17:44:15'); /* BLACK PILLAR WITH RED LIGHTNING */
/* @teleloc 0x5774010A [225.509995 -113.987999 -0.500000] 0.123441 0.000000 0.000000 0.992352 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x757741BA, 86659156, 0x57740242, 270.769, -131.946, 6, -0.767732, 0, 0, 0.640771, False, '2025-07-29 17:44:24'); /* BLACK PILLAR WITH RED LIGHTNING */
/* @teleloc 0x57740242 [270.769012 -131.945999 6.000000] -0.767732 0.000000 0.000000 0.640771 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x757741BB, 86659156, 0x5774024E, 287.15, -138.34, 6, -0.58222, 0, 0, 0.813031, False, '2025-07-29 17:44:26'); /* BLACK PILLAR WITH RED LIGHTNING */
/* @teleloc 0x5774024E [287.149994 -138.339996 6.000000] -0.582220 0.000000 0.000000 0.813031 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x757741BC, 86659156, 0x5774024C, 289.984, -117.546, 6.07354, -0.999535, 0, 0, -0.030502, False, '2025-07-29 17:44:28'); /* BLACK PILLAR WITH RED LIGHTNING */
/* @teleloc 0x5774024C [289.984009 -117.545998 6.073540] -0.999535 0.000000 0.000000 -0.030502 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x757741BD, 86659156, 0x5774024A, 288.917, -100.085, 6.03196, -0.999535, 0, 0, -0.030502, False, '2025-07-29 17:44:30'); /* BLACK PILLAR WITH RED LIGHTNING */
/* @teleloc 0x5774024A [288.916992 -100.084999 6.031960] -0.999535 0.000000 0.000000 -0.030502 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x757741BE, 86659156, 0x5774022A, 264.131, -101.787, 6, -0.494016, 0, 0, -0.869453, False, '2025-07-29 17:44:38'); /* BLACK PILLAR WITH RED LIGHTNING */
/* @teleloc 0x5774022A [264.131012 -101.787003 6.000000] -0.494016 0.000000 0.000000 -0.869453 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x757741BF, 86659156, 0x577401D8, 221.789, -112.76, 6, -0.964538, 0, 0, 0.263945, False, '2025-07-29 17:44:44'); /* BLACK PILLAR WITH RED LIGHTNING */
/* @teleloc 0x577401D8 [221.789001 -112.760002 6.000000] -0.964538 0.000000 0.000000 0.263945 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x757741C0, 86659156, 0x577401C3, 212.083, -108.21, 6, -0.844525, 0, 0, -0.535517, False, '2025-07-29 17:44:45'); /* BLACK PILLAR WITH RED LIGHTNING */
/* @teleloc 0x577401C3 [212.082993 -108.209999 6.000000] -0.844525 0.000000 0.000000 -0.535517 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x757741C1, 86659156, 0x57740197, 191.673, -122.805, 6, -0.492734, 0, 0, -0.87018, False, '2025-07-29 17:44:49'); /* BLACK PILLAR WITH RED LIGHTNING */
/* @teleloc 0x57740197 [191.673004 -122.805000 6.000000] -0.492734 0.000000 0.000000 -0.870180 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x757741C2, 86659156, 0x57740196, 181.079, -135.004, 6, -0.16113, 0, 0, -0.986933, False, '2025-07-29 17:44:50'); /* BLACK PILLAR WITH RED LIGHTNING */
/* @teleloc 0x57740196 [181.078995 -135.003998 6.000000] -0.161130 0.000000 0.000000 -0.986933 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x757741C3, 86659156, 0x577401B3, 195.076, -140.084, 6.13354, 0.73078, 0, 0, -0.682613, False, '2025-07-29 17:44:52'); /* BLACK PILLAR WITH RED LIGHTNING */
/* @teleloc 0x577401B3 [195.076004 -140.084000 6.133540] 0.730780 0.000000 0.000000 -0.682613 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x757741C4, 86659156, 0x577401C6, 212.265, -137.084, 6.88314, 0.986806, 0, 0, 0.161906, False, '2025-07-29 17:44:55'); /* BLACK PILLAR WITH RED LIGHTNING */
/* @teleloc 0x577401C6 [212.264999 -137.084000 6.883140] 0.986806 0.000000 0.000000 0.161906 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x757741C5, 86659156, 0x577401C5, 206.502, -125.334, 6, 0.424971, 0, 0, 0.905207, False, '2025-07-29 17:44:59'); /* BLACK PILLAR WITH RED LIGHTNING */
/* @teleloc 0x577401C5 [206.501999 -125.334000 6.000000] 0.424971 0.000000 0.000000 0.905207 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x757741C6, 86659156, 0x577401FB, 227.798, -136.236, 6, -0.981378, 0, 0, 0.192087, False, '2025-07-29 17:45:08'); /* BLACK PILLAR WITH RED LIGHTNING */
/* @teleloc 0x577401FB [227.798004 -136.235992 6.000000] -0.981378 0.000000 0.000000 0.192087 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x757741C7, 86659156, 0x57740241, 265.114, -120.756, 6, -0.778562, 0, 0, 0.627568, False, '2025-07-29 17:45:13'); /* BLACK PILLAR WITH RED LIGHTNING */
/* @teleloc 0x57740241 [265.114014 -120.755997 6.000000] -0.778562 0.000000 0.000000 0.627568 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x757741C8, 86659156, 0x57740232, 261.205, -135.043, 6, 0.388411, 0, 0, -0.921486, False, '2025-07-29 17:45:38'); /* BLACK PILLAR WITH RED LIGHTNING */
/* @teleloc 0x57740232 [261.204987 -135.042999 6.000000] 0.388411 0.000000 0.000000 -0.921486 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x757741C9, 86653875, 0x57740243, 272.961, -137.081, 6, 0.751838, 0, 0, -0.659348, False, '2025-07-29 17:45:42'); /* RED BALL OF LIGHT */
/* @teleloc 0x57740243 [272.960999 -137.080994 6.000000] 0.751838 0.000000 0.000000 -0.659348 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x757741CA, 86653875, 0x5774024D, 286.155, -130.974, 6, 0.947276, 0, 0, -0.320418, False, '2025-07-29 17:45:44'); /* RED BALL OF LIGHT */
/* @teleloc 0x5774024D [286.154999 -130.973999 6.000000] 0.947276 0.000000 0.000000 -0.320418 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x757741CB, 86653875, 0x5774024B, 287.596, -108.007, 6, 0.995715, 0, 0, 0.092477, False, '2025-07-29 17:45:46'); /* RED BALL OF LIGHT */
/* @teleloc 0x5774024B [287.596008 -108.007004 6.000000] 0.995715 0.000000 0.000000 0.092477 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x757741CC, 86653875, 0x5774020C, 241.483, -124.508, 6.12621, -0.522846, 0, 0, 0.852427, False, '2025-07-29 17:45:56'); /* RED BALL OF LIGHT */
/* @teleloc 0x5774020C [241.483002 -124.508003 6.126210] -0.522846 0.000000 0.000000 0.852427 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x757741CD, 86653875, 0x5774021F, 247.441, -128.511, 6, -0.999904, 0, 0, 0.013845, False, '2025-07-29 17:45:59'); /* RED BALL OF LIGHT */
/* @teleloc 0x5774021F [247.440994 -128.511002 6.000000] -0.999904 0.000000 0.000000 0.013845 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x757741CE, 86653875, 0x5774021A, 247.414, -122.818, 6.10967, -0.50288, 0, 0, -0.864356, False, '2025-07-29 17:46:03'); /* RED BALL OF LIGHT */
/* @teleloc 0x5774021A [247.414001 -122.818001 6.109670] -0.502880 0.000000 0.000000 -0.864356 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x757741CF, 86653875, 0x57740199, 194.917, -138.503, 6, -0.634599, 0, 0, -0.772842, False, '2025-07-29 17:46:12'); /* RED BALL OF LIGHT */
/* @teleloc 0x57740199 [194.917007 -138.503006 6.000000] -0.634599 0.000000 0.000000 -0.772842 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x757741D0, 86653875, 0x57740195, 181.421, -133.573, 6, -0.826891, 0, 0, -0.562363, False, '2025-07-29 17:46:14'); /* RED BALL OF LIGHT */
/* @teleloc 0x57740195 [181.421005 -133.572998 6.000000] -0.826891 0.000000 0.000000 -0.562363 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x757741D1, 86653875, 0x57740197, 192.214, -122.024, 6, -0.776517, 0, 0, 0.630096, False, '2025-07-29 17:46:16'); /* RED BALL OF LIGHT */
/* @teleloc 0x57740197 [192.214005 -122.024002 6.000000] -0.776517 0.000000 0.000000 0.630096 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x757741D2, 86653875, 0x577401C4, 206.778, -124.104, 6, -0.29886, 0, 0, 0.954297, False, '2025-07-29 17:46:17'); /* RED BALL OF LIGHT */
/* @teleloc 0x577401C4 [206.778000 -124.103996 6.000000] -0.298860 0.000000 0.000000 0.954297 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x757741D3, 86653897, 0x577401B2, 195.844, -127.929, 6.055, -0.437191, 0, 0, -0.899369, False, '2025-07-29 17:47:04'); /* LIGHTNINGLIGHTSMULTICOLORED1 */
/* @teleloc 0x577401B2 [195.843994 -127.929001 6.055000] -0.437191 0.000000 0.000000 -0.899369 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x757741D4, 1623822, 0x57740198, 186.846, -128.492, 6.055, 0.353188, 0, 0, -0.935553, False, '2025-07-29 17:47:17'); /* BloodyOthloigener */
/* @teleloc 0x57740198 [186.845993 -128.492004 6.055000] 0.353188 0.000000 0.000000 -0.935553 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x757741D5, 38723819, 0x57740198, 193.687, -130.507, 6.055, 0.671888, 0, 0, 0.740653, False, '2025-07-29 18:13:47'); /* XektiktheSpinedGen */
/* @teleloc 0x57740198 [193.686996 -130.507004 6.055000] 0.671888 0.000000 0.000000 0.740653 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x757741D6, 918421371, 0x5774018E, 112.037, -121.39, 6.055, 0.663391, 0, 0, -0.748273, False, '2025-08-23 13:46:23'); /* bloodspawngen2 */
/* @teleloc 0x5774018E [112.037003 -121.389999 6.055000] 0.663391 0.000000 0.000000 -0.748273 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x757741D7, 918421371, 0x57740187, 104.974, -104.647, 6.055, 0.255225, 0, 0, -0.966882, False, '2025-08-23 13:46:38'); /* bloodspawngen2 */
/* @teleloc 0x57740187 [104.973999 -104.647003 6.055000] 0.255225 0.000000 0.000000 -0.966882 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x757741D8, 918421371, 0x57740152, 48.1917, -69.5485, 6.055, -0.666072, 0, 0, -0.745887, False, '2025-08-23 13:46:52'); /* bloodspawngen2 */
/* @teleloc 0x57740152 [48.191700 -69.548500 6.055000] -0.666072 0.000000 0.000000 -0.745887 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x757741D9, 918421371, 0x57740150, 43.9386, -133.517, 6.055, 0.467922, 0, 0, -0.88377, False, '2025-08-23 13:46:59'); /* bloodspawngen2 */
/* @teleloc 0x57740150 [43.938599 -133.516998 6.055000] 0.467922 0.000000 0.000000 -0.883770 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x757741DA, 918421371, 0x5774015A, 46.4573, -129.714, 6.055, 0.951585, 0, 0, 0.307385, False, '2025-08-23 13:47:02'); /* bloodspawngen2 */
/* @teleloc 0x5774015A [46.457298 -129.714005 6.055000] 0.951585 0.000000 0.000000 0.307385 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x757741DB, 918421371, 0x57740138, 15.6352, -74.5809, 6.055, -0.461865, 0, 0, 0.88695, False, '2025-08-23 13:47:13'); /* bloodspawngen2 */
/* @teleloc 0x57740138 [15.635200 -74.580902 6.055000] -0.461865 0.000000 0.000000 0.886950 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x757741DC, 918421371, 0x5774013A, 26.3912, -61.9238, 6.055, -0.989388, 0, 0, -0.145301, False, '2025-08-23 13:47:15'); /* bloodspawngen2 */
/* @teleloc 0x5774013A [26.391199 -61.923801 6.055000] -0.989388 0.000000 0.000000 -0.145301 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x757741DD, 918421371, 0x57740160, 61.4462, -77.4946, 6.055, -0.071091, 0, 0, -0.99747, False, '2025-08-23 13:47:21'); /* bloodspawngen2 */
/* @teleloc 0x57740160 [61.446201 -77.494598 6.055000] -0.071091 0.000000 0.000000 -0.997470 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x757741DE, 918421371, 0x57740164, 63.2354, -109.1, 6.055, 0.552272, 0, 0, -0.833664, False, '2025-08-23 13:47:24'); /* bloodspawngen2 */
/* @teleloc 0x57740164 [63.235401 -109.099998 6.055000] 0.552272 0.000000 0.000000 -0.833664 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x757741DF, 918421371, 0x57740180, 85.7425, -120.687, 6.055, 0.403099, 0, 0, -0.915157, False, '2025-08-23 13:47:27'); /* bloodspawngen2 */
/* @teleloc 0x57740180 [85.742500 -120.686996 6.055000] 0.403099 0.000000 0.000000 -0.915157 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x757741E0, 918421371, 0x5774018C, 110.576, -102.427, 6.055, 0.978182, 0, 0, -0.20775, False, '2025-08-23 13:47:30'); /* bloodspawngen2 */
/* @teleloc 0x5774018C [110.575996 -102.427002 6.055000] 0.978182 0.000000 0.000000 -0.207750 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x757741E1, 918421371, 0x57740138, 16.5817, -65.7123, 6.055, 0.98836, 0, 0, 0.152134, False, '2025-08-23 13:49:19'); /* bloodspawngen2 */
/* @teleloc 0x57740138 [16.581699 -65.712303 6.055000] 0.988360 0.000000 0.000000 0.152134 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x757741E2, 918421371, 0x57740125, 10.9594, -47.0912, 6.055, -0.991646, 0, 0, 0.128992, False, '2025-08-23 13:57:06'); /* bloodspawngen2 */
/* @teleloc 0x57740125 [10.959400 -47.091202 6.055000] -0.991646 0.000000 0.000000 0.128992 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x757741E3, 931271771, 0x577401ED, 232.177, -35.9187, 6.06, 0.197584, 0, 0, 0.980286, False, '2025-08-25 07:04:50');
/* @teleloc 0x577401ED [232.177002 -35.918701 6.060000] 0.197584 0.000000 0.000000 0.980286 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x757741E4, 931271771, 0x57740203, 239.954, -31.5215, 6.10714, 0.863768, 0, 0, -0.50389, False, '2025-08-25 07:04:53');
/* @teleloc 0x57740203 [239.953995 -31.521500 6.107140] 0.863768 0.000000 0.000000 -0.503890 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x757741E5, 931271771, 0x577401EC, 231.094, -30.8675, 6.055, 0.574409, 0, 0, 0.818568, False, '2025-08-25 07:04:56');
/* @teleloc 0x577401EC [231.093994 -30.867500 6.055000] 0.574409 0.000000 0.000000 0.818568 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x757741E6, 931271771, 0x577401CB, 222.474, -33.2472, 6.055, 0.561749, 0, 0, 0.827308, False, '2025-08-25 07:04:57');
/* @teleloc 0x577401CB [222.473999 -33.247200 6.055000] 0.561749 0.000000 0.000000 0.827308 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x757741E7, 931271771, 0x577401CC, 224.289, -40.8484, 6.055, 0.117855, 0, 0, 0.993031, False, '2025-08-25 07:04:59');
/* @teleloc 0x577401CC [224.289001 -40.848400 6.055000] 0.117855 0.000000 0.000000 0.993031 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x757741E8, 931271771, 0x577401CD, 221.629, -47.934, 6.055, 0.246801, 0, 0, 0.969066, False, '2025-08-25 07:05:00');
/* @teleloc 0x577401CD [221.628998 -47.933998 6.055000] 0.246801 0.000000 0.000000 0.969066 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x757741E9, 931271771, 0x577401B4, 214.697, -50.2389, 6.055, 0.686442, 0, 0, 0.727185, False, '2025-08-25 07:05:01');
/* @teleloc 0x577401B4 [214.697006 -50.238899 6.055000] 0.686442 0.000000 0.000000 0.727185 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x757741EA, 931271771, 0x577401EE, 228.028, -49.8651, 6.055, 0.750272, 0, 0, -0.66113, False, '2025-08-25 07:05:04');
/* @teleloc 0x577401EE [228.028000 -49.865101 6.055000] 0.750272 0.000000 0.000000 -0.661130 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x757741EB, 931271771, 0x577401EE, 234.122, -48.2811, 6.16029, 0.872594, 0, 0, -0.488446, False, '2025-08-25 07:05:05');
/* @teleloc 0x577401EE [234.121994 -48.281101 6.160290] 0.872594 0.000000 0.000000 -0.488446 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x757741EC, 931271771, 0x57740204, 239.334, -42.7827, 6.055, 0.989236, 0, 0, -0.146326, False, '2025-08-25 07:05:07');
/* @teleloc 0x57740204 [239.334000 -42.782700 6.055000] 0.989236 0.000000 0.000000 -0.146326 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x757741ED, 931271771, 0x5774019C, 204.859, -50.5019, 6.055, 0.678635, 0, 0, 0.734476, False, '2025-08-25 07:05:27');
/* @teleloc 0x5774019C [204.858994 -50.501900 6.055000] 0.678635 0.000000 0.000000 0.734476 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x757741EE, 931271771, 0x5774019D, 199.928, -56.4521, 6.055, 0.070852, 0, 0, 0.997487, False, '2025-08-25 07:05:28');
/* @teleloc 0x5774019D [199.927994 -56.452099 6.055000] 0.070852 0.000000 0.000000 0.997487 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x757741EF, 931271771, 0x5774011B, 5.85788, -3.14374, 6.06, 0.957709, 0, 0, 0.28774, False, '2025-08-25 07:07:58');
/* @teleloc 0x5774011B [5.857880 -3.143740 6.060000] 0.957709 0.000000 0.000000 0.287740 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x757741F0, 931271771, 0x57740113, 2.98373, -7.9729, 6.055, 0.082383, 0, 0, 0.996601, False, '2025-08-25 07:08:01');
/* @teleloc 0x57740113 [2.983730 -7.972900 6.055000] 0.082383 0.000000 0.000000 0.996601 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x757741F1, 931271771, 0x5774011D, 9.67325, -10.8991, 6.055, -0.217203, 0, 0, 0.976126, False, '2025-08-25 07:08:02');
/* @teleloc 0x5774011D [9.673250 -10.899100 6.055000] -0.217203 0.000000 0.000000 0.976126 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x757741F2, 931271771, 0x5774011E, 9.32732, -17.9441, 6.055, -0.0026, 0, 0, 0.999997, False, '2025-08-25 07:08:04');
/* @teleloc 0x5774011E [9.327320 -17.944099 6.055000] -0.002600 0.000000 0.000000 0.999997 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x757741F3, 931271771, 0x5774011E, 10.0148, -23.4066, 6.055, -0.1634, 0, 0, 0.98656, False, '2025-08-25 07:08:05');
/* @teleloc 0x5774011E [10.014800 -23.406601 6.055000] -0.163400 0.000000 0.000000 0.986560 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x757741F4, 931271771, 0x5774011F, 11.28988, -27.15023, 6.055, -0.1634, 0, 0, 0.98656, False, '2025-08-25 07:08:06');
/* @teleloc 0x5774011F [11.289880 -27.150230 6.055000] -0.163400 0.000000 0.000000 0.986560 */
