DELETE FROM `landblock_instance` WHERE `landblock` = 0x0E49;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70E49000, 56843983, 0x0E490017, 65.8783, 155.363, 10.3078, 0.457616, 0, 0, -0.88915, False, '2025-07-23 07:10:30'); /* Oathblade Gen */
/* @teleloc 0x0E490017 [65.878304 155.363007 10.307800] 0.457616 0.000000 0.000000 -0.889150 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70E49001, 56843983, 0x0E490010, 36.4391, 190.329, 10.1282, 0.43771, 0, 0, -0.899116, False, '2025-07-30 03:55:57'); /* Oathblade Gen */
/* @teleloc 0x0E490010 [36.439098 190.328995 10.128200] 0.437710 0.000000 0.000000 -0.899116 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70E49002, 5000765, 0x0E49002F, 120.6087, 148.1448, 10.29896, 0.537112, 0, 0, -0.843511, False, '2025-07-30 04:21:17'); /* Mage Skellie gen */
/* @teleloc 0x0E49002F [120.608704 148.144806 10.298960] 0.537112 0.000000 0.000000 -0.843511 */
