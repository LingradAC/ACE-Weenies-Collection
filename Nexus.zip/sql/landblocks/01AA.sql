DELETE FROM `landblock_instance` WHERE `landblock` = 0x01AA;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701AA01A,  2087, 0x01AA01FA, 41.6148, -51.0607, 0, 0.707107, 0, 0, -0.707107, False, '2005-02-09 10:00:00'); /* Surface */
/* @teleloc 0x01AA01FA [41.614799 -51.060699 0.000000] 0.707107 0.000000 0.000000 -0.707107 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701AA01B, 24252, 0x01AA0108, 98.6742, -22.0032, -29.921, 0.885334, 0, 0, -0.464955,  True, '2005-02-09 10:00:00'); /* Note from a Scout */
/* @teleloc 0x01AA0108 [98.674202 -22.003201 -29.921000] 0.885334 0.000000 0.000000 -0.464955 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701AA01C, 15759, 0x01AA0108, 100.461, -21.9903, -29.995, 0.997054, 0, 0, -0.076708, False, '2005-02-09 10:00:00'); /* Linkable Item Generator */
/* @teleloc 0x01AA0108 [100.460999 -21.990299 -29.995001] 0.997054 0.000000 0.000000 -0.076708 */

INSERT INTO `landblock_instance_link` (`parent_GUID`, `child_GUID`, `last_Modified`)
VALUES (0x701AA01C, 0x701AA01B, '2005-02-09 10:00:00') /* Note from a Scout (24252) */;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701AA01D, 858357, 0x01AA0109, 104.097, -28.2359, -29.995, 0.70912, 0, 0, 0.705088,  True, '2005-02-09 10:00:00'); /* Spore Thrungus */
/* @teleloc 0x01AA0109 [104.097000 -28.235901 -29.995001] 0.709120 0.000000 0.000000 0.705088 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701AA01E, 24230, 0x01AA010B, 109.834, -4.36318, -29.995, 0.999877, 0, 0, 0.015698, False, '2005-02-09 10:00:00'); /* Deeper Catacombs */
/* @teleloc 0x01AA010B [109.834000 -4.363180 -29.995001] 0.999877 0.000000 0.000000 0.015698 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701AA01F, 31024, 0x01AA0111, 105.377, -35.9467, -29.995, -0.978984, 0, 0, -0.203939,  True, '2005-02-09 10:00:00'); /* Mudwort Thrungus */
/* @teleloc 0x01AA0111 [105.376999 -35.946701 -29.995001] -0.978984 0.000000 0.000000 -0.203939 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701AA020, 858357, 0x01AA0124, 55.2323, -20.1019, -17.995, 0.679602, 0, 0, 0.733581,  True, '2005-02-09 10:00:00'); /* Spore Thrungus */
/* @teleloc 0x01AA0124 [55.232300 -20.101900 -17.995001] 0.679602 0.000000 0.000000 0.733581 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701AA021, 858357, 0x01AA013B, 79.3935, -41.2812, -17.995, 0.053838, 0, 0, 0.99855,  True, '2005-02-09 10:00:00'); /* Spore Thrungus */
/* @teleloc 0x01AA013B [79.393501 -41.281200 -17.995001] 0.053838 0.000000 0.000000 0.998550 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701AA022, 28674, 0x01AA0141, 83.8605, -57.6774, -17.995, 0.784742, 0, 0, -0.619823,  True, '2005-02-09 10:00:00'); /* Enoki Thrungus */
/* @teleloc 0x01AA0141 [83.860497 -57.677399 -17.995001] 0.784742 0.000000 0.000000 -0.619823 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701AA023, 858357, 0x01AA0142, 83.9162, -71.9012, -17.995, 0.685214, 0, 0, 0.728342,  True, '2005-02-09 10:00:00'); /* Spore Thrungus */
/* @teleloc 0x01AA0142 [83.916199 -71.901199 -17.995001] 0.685214 0.000000 0.000000 0.728342 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701AA024, 858357, 0x01AA0146, 87.2776, -59.5659, -17.995, 0.976093, 0, 0, -0.217355,  True, '2005-02-09 10:00:00'); /* Spore Thrungus */
/* @teleloc 0x01AA0146 [87.277603 -59.565899 -17.995001] 0.976093 0.000000 0.000000 -0.217355 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701AA025, 858357, 0x01AA0146, 90.4446, -58.8515, -17.995, -0.836384, 0, 0, -0.548144,  True, '2005-02-09 10:00:00'); /* Spore Thrungus */
/* @teleloc 0x01AA0146 [90.444603 -58.851501 -17.995001] -0.836384 0.000000 0.000000 -0.548144 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701AA026, 858357, 0x01AA015E, 9.56219, -91.2214, -11.995, 0.580041, 0, 0, -0.814588,  True, '2005-02-09 10:00:00'); /* Spore Thrungus */
/* @teleloc 0x01AA015E [9.562190 -91.221397 -11.995000] 0.580041 0.000000 0.000000 -0.814588 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701AA027, 858357, 0x01AA0162, 11.827, -100.611, -11.995, 0.961811, 0, 0, -0.273716,  True, '2005-02-09 10:00:00'); /* Spore Thrungus */
/* @teleloc 0x01AA0162 [11.827000 -100.611000 -11.995000] 0.961811 0.000000 0.000000 -0.273716 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701AA028, 858357, 0x01AA016C, 9.41536, -131.721, -11.995, 0.225108, 0, 0, -0.974334,  True, '2005-02-09 10:00:00'); /* Spore Thrungus */
/* @teleloc 0x01AA016C [9.415360 -131.720993 -11.995000] 0.225108 0.000000 0.000000 -0.974334 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701AA029, 858357, 0x01AA016F, 10.3754, -135.773, -11.995, 0.999624, 0, 0, -0.027417,  True, '2005-02-09 10:00:00'); /* Spore Thrungus */
/* @teleloc 0x01AA016F [10.375400 -135.772995 -11.995000] 0.999624 0.000000 0.000000 -0.027417 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701AA02A, 32593, 0x01AA0171, 22.634, -23.8015, -11.995, 0.624617, 0, 0, -0.780931,  True, '2005-02-09 10:00:00'); /* False Morel Thrungus */
/* @teleloc 0x01AA0171 [22.634001 -23.801500 -11.995000] 0.624617 0.000000 0.000000 -0.780931 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701AA02B, 858357, 0x01AA017F, 19.7948, -122.611, -11.995, -0.990093, 0, 0, 0.140416,  True, '2005-02-09 10:00:00'); /* Spore Thrungus */
/* @teleloc 0x01AA017F [19.794800 -122.611000 -11.995000] -0.990093 0.000000 0.000000 0.140416 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701AA02C, 32593, 0x01AA0184, 25.7391, -24.1501, -11.995, 0.617562, 0, 0, 0.786522,  True, '2005-02-09 10:00:00'); /* False Morel Thrungus */
/* @teleloc 0x01AA0184 [25.739100 -24.150101 -11.995000] 0.617562 0.000000 0.000000 0.786522 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701AA02D, 858357, 0x01AA0185, 29.9744, -30, -11.9073, 0.930508, 0, 0, 0.366273,  True, '2005-02-09 10:00:00'); /* Spore Thrungus */
/* @teleloc 0x01AA0185 [29.974400 -30.000000 -11.907300] 0.930508 0.000000 0.000000 0.366273 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701AA02E, 32593, 0x01AA018B, 30, -90, -11.995, 0.561168, 0, 0, -0.827702,  True, '2005-02-09 10:00:00'); /* False Morel Thrungus */
/* @teleloc 0x01AA018B [30.000000 -90.000000 -11.995000] 0.561168 0.000000 0.000000 -0.827702 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701AA02F, 858357, 0x01AA0192, 29.142, -134.561, -11.995, -0.999978, 0, 0, -0.006706,  True, '2005-02-09 10:00:00'); /* Spore Thrungus */
/* @teleloc 0x01AA0192 [29.142000 -134.561005 -11.995000] -0.999978 0.000000 0.000000 -0.006706 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701AA030, 32593, 0x01AA0198, 40.8315, -59.9773, -11.995, 0.362358, 0, 0, 0.932039,  True, '2005-02-09 10:00:00'); /* False Morel Thrungus */
/* @teleloc 0x01AA0198 [40.831501 -59.977299 -11.995000] 0.362358 0.000000 0.000000 0.932039 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701AA031, 32593, 0x01AA0198, 44.1425, -62.395, -11.995, 0.121916, 0, 0, 0.99254,  True, '2005-02-09 10:00:00'); /* False Morel Thrungus */
/* @teleloc 0x01AA0198 [44.142502 -62.395000 -11.995000] 0.121916 0.000000 0.000000 0.992540 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701AA032, 32593, 0x01AA019E, 49.8305, -53.1947, -11.995, -0.174989, 0, 0, -0.98457,  True, '2005-02-09 10:00:00'); /* False Morel Thrungus */
/* @teleloc 0x01AA019E [49.830502 -53.194698 -11.995000] -0.174989 0.000000 0.000000 -0.984570 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701AA033, 32593, 0x01AA01A2, 48.3162, -78.2568, -11.995, 0.022878, 0, 0, -0.999738,  True, '2005-02-09 10:00:00'); /* False Morel Thrungus */
/* @teleloc 0x01AA01A2 [48.316200 -78.256798 -11.995000] 0.022878 0.000000 0.000000 -0.999738 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701AA034, 32593, 0x01AA01A7, 60, -90, -11.995, -0.227202, 0, 0, 0.973848,  True, '2005-02-09 10:00:00'); /* False Morel Thrungus */
/* @teleloc 0x01AA01A7 [60.000000 -90.000000 -11.995000] -0.227202 0.000000 0.000000 0.973848 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701AA035, 28674, 0x01AA01B0, 59.9017, -107.523, -11.995, -0.139864, 0, 0, -0.990171,  True, '2005-02-09 10:00:00'); /* Enoki Thrungus */
/* @teleloc 0x01AA01B0 [59.901699 -107.523003 -11.995000] -0.139864 0.000000 0.000000 -0.990171 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701AA036, 32593, 0x01AA01B3, 69.1587, -89.8463, -11.995, 0.226815, 0, 0, -0.973938,  True, '2005-02-09 10:00:00'); /* False Morel Thrungus */
/* @teleloc 0x01AA01B3 [69.158699 -89.846298 -11.995000] 0.226815 0.000000 0.000000 -0.973938 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701AA037, 28674, 0x01AA01B9, 0, -48.3095, -5.995, 1, 0, 0, 0,  True, '2005-02-09 10:00:00'); /* Enoki Thrungus */
/* @teleloc 0x01AA01B9 [0.000000 -48.309502 -5.995000] 1.000000 0.000000 0.000000 0.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701AA038, 28674, 0x01AA01B9, 0.000498, -53.391, -5.995, 0.070737, 0, 0, 0.997495,  True, '2005-02-09 10:00:00'); /* Enoki Thrungus */
/* @teleloc 0x01AA01B9 [0.000498 -53.390999 -5.995000] 0.070737 0.000000 0.000000 0.997495 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701AA039, 858357, 0x01AA01BD, 19.8272, -100.214, -5.995, -0.999906, 0, 0, 0.013743,  True, '2005-02-09 10:00:00'); /* Spore Thrungus */
/* @teleloc 0x01AA01BD [19.827200 -100.213997 -5.995000] -0.999906 0.000000 0.000000 0.013743 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701AA03A, 858357, 0x01AA01C5, 30.1779, -91.8589, -5.995, -0.091036, 0, 0, 0.995848,  True, '2005-02-09 10:00:00'); /* Spore Thrungus */
/* @teleloc 0x01AA01C5 [30.177900 -91.858902 -5.995000] -0.091036 0.000000 0.000000 0.995848 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701AA03B, 28674, 0x01AA01D9, 36.3601, -109.96, -5.995, 0.978583, 0, 0, -0.205854,  True, '2005-02-09 10:00:00'); /* Enoki Thrungus */
/* @teleloc 0x01AA01D9 [36.360100 -109.959999 -5.995000] 0.978583 0.000000 0.000000 -0.205854 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701AA03C,  7923, 0x01AA01EC, 18.9771, -47.8825, 0.005, 0.974794, 0, 0, 0.223106, False, '2005-02-09 10:00:00'); /* Linkable Monster Generator ( 3 Min.) */
/* @teleloc 0x01AA01EC [18.977100 -47.882500 0.005000] 0.974794 0.000000 0.000000 0.223106 */

INSERT INTO `landblock_instance_link` (`parent_GUID`, `child_GUID`, `last_Modified`)
VALUES (0x701AA03C, 0x701AA01D, '2005-02-09 10:00:00') /* Spore Thrungus (858357) */
     , (0x701AA03C, 0x701AA01F, '2005-02-09 10:00:00') /* Mudwort Thrungus (31024) */
     , (0x701AA03C, 0x701AA020, '2005-02-09 10:00:00') /* Spore Thrungus (858357) */
     , (0x701AA03C, 0x701AA021, '2005-02-09 10:00:00') /* Spore Thrungus (858357) */
     , (0x701AA03C, 0x701AA022, '2005-02-09 10:00:00') /* Enoki Thrungus (28674) */
     , (0x701AA03C, 0x701AA023, '2005-02-09 10:00:00') /* Spore Thrungus (858357) */
     , (0x701AA03C, 0x701AA024, '2005-02-09 10:00:00') /* Spore Thrungus (858357) */
     , (0x701AA03C, 0x701AA025, '2005-02-09 10:00:00') /* Spore Thrungus (858357) */
     , (0x701AA03C, 0x701AA026, '2005-02-09 10:00:00') /* Spore Thrungus (858357) */
     , (0x701AA03C, 0x701AA027, '2005-02-09 10:00:00') /* Spore Thrungus (858357) */
     , (0x701AA03C, 0x701AA028, '2005-02-09 10:00:00') /* Spore Thrungus (858357) */
     , (0x701AA03C, 0x701AA029, '2005-02-09 10:00:00') /* Spore Thrungus (858357) */
     , (0x701AA03C, 0x701AA02A, '2005-02-09 10:00:00') /* False Morel Thrungus (32593) */
     , (0x701AA03C, 0x701AA02B, '2005-02-09 10:00:00') /* Spore Thrungus (858357) */
     , (0x701AA03C, 0x701AA02C, '2005-02-09 10:00:00') /* False Morel Thrungus (32593) */
     , (0x701AA03C, 0x701AA02D, '2005-02-09 10:00:00') /* Spore Thrungus (858357) */
     , (0x701AA03C, 0x701AA02E, '2005-02-09 10:00:00') /* False Morel Thrungus (32593) */
     , (0x701AA03C, 0x701AA02F, '2005-02-09 10:00:00') /* Spore Thrungus (858357) */
     , (0x701AA03C, 0x701AA030, '2005-02-09 10:00:00') /* False Morel Thrungus (32593) */
     , (0x701AA03C, 0x701AA031, '2005-02-09 10:00:00') /* False Morel Thrungus (32593) */
     , (0x701AA03C, 0x701AA032, '2005-02-09 10:00:00') /* False Morel Thrungus (32593) */
     , (0x701AA03C, 0x701AA033, '2005-02-09 10:00:00') /* False Morel Thrungus (32593) */
     , (0x701AA03C, 0x701AA034, '2005-02-09 10:00:00') /* False Morel Thrungus (32593) */
     , (0x701AA03C, 0x701AA035, '2005-02-09 10:00:00') /* Enoki Thrungus (28674) */
     , (0x701AA03C, 0x701AA036, '2005-02-09 10:00:00') /* False Morel Thrungus (32593) */
     , (0x701AA03C, 0x701AA037, '2005-02-09 10:00:00') /* Enoki Thrungus (28674) */
     , (0x701AA03C, 0x701AA038, '2005-02-09 10:00:00') /* Enoki Thrungus (28674) */
     , (0x701AA03C, 0x701AA039, '2005-02-09 10:00:00') /* Spore Thrungus (858357) */
     , (0x701AA03C, 0x701AA03A, '2005-02-09 10:00:00') /* Spore Thrungus (858357) */
     , (0x701AA03C, 0x701AA03B, '2005-02-09 10:00:00') /* Enoki Thrungus (28674) */;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701AA03D, 3483357, 0x01AA019A, 43.7974, -78.1371, -12.0267, 0.508679, 0, 0, 0.860956, False, '2025-07-21 22:01:17'); /* Blue Glow Mushroom */
/* @teleloc 0x01AA019A [43.797401 -78.137100 -12.026700] 0.508679 0.000000 0.000000 0.860956 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701AA03E, 3483357, 0x01AA01A1, 50.3645, -73.8097, -11.536, -0.999894, 0, 0, 0.014545, False, '2025-07-21 22:01:22'); /* Blue Glow Mushroom */
/* @teleloc 0x01AA01A1 [50.364498 -73.809700 -11.536000] -0.999894 0.000000 0.000000 0.014545 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701AA03F, 3483357, 0x01AA01A1, 48.4874, -67.5296, -12.0267, -0.999905, 0, 0, -0.01382, False, '2025-07-21 22:01:23'); /* Blue Glow Mushroom */
/* @teleloc 0x01AA01A1 [48.487400 -67.529602 -12.026700] -0.999905 0.000000 0.000000 -0.013820 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701AA040, 3483357, 0x01AA01A4, 56.2445, -51.7132, -12.0267, -0.600787, 0, 0, -0.799409, False, '2025-07-21 22:01:26'); /* Blue Glow Mushroom */
/* @teleloc 0x01AA01A4 [56.244499 -51.713200 -12.026700] -0.600787 0.000000 0.000000 -0.799409 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701AA041, 3483357, 0x01AA0198, 44.5878, -55.8076, -12.0267, -0.600787, 0, 0, -0.799409, False, '2025-07-21 22:01:27'); /* Blue Glow Mushroom */
/* @teleloc 0x01AA0198 [44.587799 -55.807598 -12.026700] -0.600787 0.000000 0.000000 -0.799409 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701AA042, 3483357, 0x01AA0187, 32.2623, -63.3116, -12.0267, -0.248124, 0, 0, -0.968728, False, '2025-07-21 22:01:28'); /* Blue Glow Mushroom */
/* @teleloc 0x01AA0187 [32.262299 -63.311600 -12.026700] -0.248124 0.000000 0.000000 -0.968728 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701AA043, 3483357, 0x01AA0176, 22.1021, -91.2423, -12.0267, -0.986246, 0, 0, 0.165283, False, '2025-07-21 22:01:37'); /* Blue Glow Mushroom */
/* @teleloc 0x01AA0176 [22.102100 -91.242302 -12.026700] -0.986246 0.000000 0.000000 0.165283 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701AA044, 3483357, 0x01AA01B3, 71.7334, -87.929, -12.0267, 0.832077, 0, 0, -0.55466, False, '2025-07-21 22:01:57'); /* Blue Glow Mushroom */
/* @teleloc 0x01AA01B3 [71.733398 -87.929001 -12.026700] 0.832077 0.000000 0.000000 -0.554660 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701AA045, 3483357, 0x01AA0147, 93.2484, -66.8798, -18.0268, 0.614473, 0, 0, -0.788938, False, '2025-07-21 22:02:14'); /* Blue Glow Mushroom */
/* @teleloc 0x01AA0147 [93.248398 -66.879799 -18.026800] 0.614473 0.000000 0.000000 -0.788938 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701AA046, 3483357, 0x01AA0146, 93.3605, -64.854, -18.0268, 0.999348, 0, 0, 0.036102, False, '2025-07-21 22:02:15'); /* Blue Glow Mushroom */
/* @teleloc 0x01AA0146 [93.360497 -64.853996 -18.026800] 0.999348 0.000000 0.000000 0.036102 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701AA047, 3483357, 0x01AA0146, 93.3605, -64.854, -18.0268, 0.999348, 0, 0, 0.036102, False, '2025-07-21 22:02:15'); /* Blue Glow Mushroom */
/* @teleloc 0x01AA0146 [93.360497 -64.853996 -18.026800] 0.999348 0.000000 0.000000 0.036102 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701AA048, 3483357, 0x01AA0141, 80.8917, -62.6892, -18.0268, 0.456991, 0, 0, 0.889471, False, '2025-07-21 22:02:16'); /* Blue Glow Mushroom */
/* @teleloc 0x01AA0141 [80.891701 -62.689201 -18.026800] 0.456991 0.000000 0.000000 0.889471 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701AA049, 3483357, 0x01AA011F, 51.8327, -28.1865, -18.0268, 0.905626, 0, 0, -0.424077, False, '2025-07-21 22:02:24'); /* Blue Glow Mushroom */
/* @teleloc 0x01AA011F [51.832699 -28.186501 -18.026800] 0.905626 0.000000 0.000000 -0.424077 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701AA04A, 3483357, 0x01AA0100, 93.7224, -23.5098, -30.0268, 0.604925, 0, 0, -0.796283, False, '2025-07-21 22:02:32'); /* Blue Glow Mushroom */
/* @teleloc 0x01AA0100 [93.722397 -23.509800 -30.026800] 0.604925 0.000000 0.000000 -0.796283 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701AA04C, 3483357, 0x01AA01E7, 13.9289, -41.8149, -0.02675, 0.980351, 0, 0, 0.197262, False, '2025-07-21 22:04:28'); /* Blue Glow Mushroom */
/* @teleloc 0x01AA01E7 [13.928900 -41.814899 -0.026750] 0.980351 0.000000 0.000000 0.197262 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701AA04D, 3483357, 0x01AA01E8, 7.42621, -49.5271, -0.02675, 0.354729, 0, 0, 0.934969, False, '2025-07-21 22:04:30'); /* Blue Glow Mushroom */
/* @teleloc 0x01AA01E8 [7.426210 -49.527100 -0.026750] 0.354729 0.000000 0.000000 0.934969 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701AA04E, 3483357, 0x01AA01E9, 6.885, -56.0919, -0.02675, -0.037367, 0, 0, 0.999302, False, '2025-07-21 22:04:31'); /* Blue Glow Mushroom */
/* @teleloc 0x01AA01E9 [6.885000 -56.091900 -0.026750] -0.037367 0.000000 0.000000 0.999302 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701AA04F, 3483357, 0x01AA01ED, 22.9099, -60.5318, -0.02675, -0.980417, 0, 0, 0.196933, False, '2025-07-21 22:04:34'); /* Blue Glow Mushroom */
/* @teleloc 0x01AA01ED [22.909901 -60.531799 -0.026750] -0.980417 0.000000 0.000000 0.196933 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701AA050, 3483357, 0x01AA01ED, 23.3629, -56.0203, -0.02675, 0.018295, 0, 0, 0.999833, False, '2025-07-21 22:04:36'); /* Blue Glow Mushroom */
/* @teleloc 0x01AA01ED [23.362900 -56.020302 -0.026750] 0.018295 0.000000 0.000000 0.999833 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701AA051, 3483357, 0x01AA01EE, 15.7749, -72.9236, -0.02675, 0.146618, 0, 0, 0.989193, False, '2025-07-21 22:04:38'); /* Blue Glow Mushroom */
/* @teleloc 0x01AA01EE [15.774900 -72.923599 -0.026750] 0.146618 0.000000 0.000000 0.989193 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701AA052, 3483357, 0x01AA01EA, 9.72616, -73.0104, -0.02675, 0.611321, 0, 0, 0.791383, False, '2025-07-21 22:04:40'); /* Blue Glow Mushroom */
/* @teleloc 0x01AA01EA [9.726160 -73.010399 -0.026750] 0.611321 0.000000 0.000000 0.791383 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701AA053, 3483357, 0x01AA01EA, 6.6371, -67.8271, -0.02675, 0.977285, 0, 0, 0.211931, False, '2025-07-21 22:04:41'); /* Blue Glow Mushroom */
/* @teleloc 0x01AA01EA [6.637100 -67.827103 -0.026750] 0.977285 0.000000 0.000000 0.211931 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701AA054, 8729957, 0x01AA01E9, 8.42767, -63.901, -0.01425, 0.574957, 0, 0, 0.818184, False, '2025-07-21 22:05:30'); /* Red Burning Mushroom */
/* @teleloc 0x01AA01E9 [8.427670 -63.901001 -0.014250] 0.574957 0.000000 0.000000 0.818184 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701AA055, 8729957, 0x01AA01EA, 12.1739, -72.376, -0.01425, 0.584357, 0, 0, 0.811497, False, '2025-07-21 22:05:36'); /* Red Burning Mushroom */
/* @teleloc 0x01AA01EA [12.173900 -72.375999 -0.014250] 0.584357 0.000000 0.000000 0.811497 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701AA056, 8729957, 0x01AA01EC, 23.7933, -49.0062, -0.01425, 0.913243, 0, 0, -0.407414, False, '2025-07-21 22:05:41'); /* Red Burning Mushroom */
/* @teleloc 0x01AA01EC [23.793301 -49.006199 -0.014250] 0.913243 0.000000 0.000000 -0.407414 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701AA057, 8729957, 0x01AA01FA, 36.5145, -48.4215, -0.01425, 0.985321, 0, 0, -0.170713, False, '2025-07-21 22:05:43'); /* Red Burning Mushroom */
/* @teleloc 0x01AA01FA [36.514500 -48.421501 -0.014250] 0.985321 0.000000 0.000000 -0.170713 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701AA058, 8729957, 0x01AA01FA, 39.5931, -45.8721, -0.01425, 0.844172, 0, 0, -0.536072, False, '2025-07-21 22:05:44'); /* Red Burning Mushroom */
/* @teleloc 0x01AA01FA [39.593102 -45.872101 -0.014250] 0.844172 0.000000 0.000000 -0.536072 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701AA059, 8729957, 0x01AA01FA, 43.1923, -45.9137, -0.01425, 0.674374, 0, 0, -0.73839, False, '2025-07-21 22:05:45'); /* Red Burning Mushroom */
/* @teleloc 0x01AA01FA [43.192299 -45.913700 -0.014250] 0.674374 0.000000 0.000000 -0.738390 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701AA05A, 8729957, 0x01AA01E9, 9.629, -60.0571, -0.01425, 0.554849, 0, 0, -0.831951, False, '2025-07-21 22:05:53'); /* Red Burning Mushroom */
/* @teleloc 0x01AA01E9 [9.629000 -60.057098 -0.014250] 0.554849 0.000000 0.000000 -0.831951 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701AA05B, 8729957, 0x01AA01C8, 30.4902, -98.1415, -6.01425, -0.288796, 0, 0, 0.957391, False, '2025-07-21 22:06:07'); /* Red Burning Mushroom */
/* @teleloc 0x01AA01C8 [30.490200 -98.141502 -6.014250] -0.288796 0.000000 0.000000 0.957391 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701AA05C, 8729957, 0x01AA0192, 29.2054, -131.709, -12.0142, 0.953053, 0, 0, 0.302803, False, '2025-07-21 22:06:25'); /* Red Burning Mushroom */
/* @teleloc 0x01AA0192 [29.205400 -131.709000 -12.014200] 0.953053 0.000000 0.000000 0.302803 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701AA05D, 8729957, 0x01AA0168, 11.5861, -118.244, -11.9046, 0.978106, 0, 0, -0.208106, False, '2025-07-21 22:06:44'); /* Red Burning Mushroom */
/* @teleloc 0x01AA0168 [11.586100 -118.244003 -11.904600] 0.978106 0.000000 0.000000 -0.208106 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701AA05E, 8729957, 0x01AA0162, 7.23118, -99.4015, -12.0142, 0.962954, 0, 0, 0.269666, False, '2025-07-21 22:06:46'); /* Red Burning Mushroom */
/* @teleloc 0x01AA0162 [7.231180 -99.401497 -12.014200] 0.962954 0.000000 0.000000 0.269666 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701AA05F, 8729957, 0x01AA0162, 11.5086, -97.36, -12.0142, 0.722427, 0, 0, -0.691447, False, '2025-07-21 22:06:48'); /* Red Burning Mushroom */
/* @teleloc 0x01AA0162 [11.508600 -97.360001 -12.014200] 0.722427 0.000000 0.000000 -0.691447 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701AA060, 8729957, 0x01AA0179, 21.3624, -85.6494, -12.0142, 0.944369, 0, 0, -0.328887, False, '2025-07-21 22:06:50'); /* Red Burning Mushroom */
/* @teleloc 0x01AA0179 [21.362400 -85.649399 -12.014200] 0.944369 0.000000 0.000000 -0.328887 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701AA061, 8729957, 0x01AA0187, 33.5908, -64.9921, -12.0142, 0.977195, 0, 0, -0.212344, False, '2025-07-21 22:06:54'); /* Red Burning Mushroom */
/* @teleloc 0x01AA0187 [33.590801 -64.992104 -12.014200] 0.977195 0.000000 0.000000 -0.212344 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701AA062, 8729957, 0x01AA0198, 41.0599, -57.6186, -12.0142, 0.923096, 0, 0, -0.384569, False, '2025-07-21 22:06:56'); /* Red Burning Mushroom */
/* @teleloc 0x01AA0198 [41.059898 -57.618599 -12.014200] 0.923096 0.000000 0.000000 -0.384569 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701AA063, 8729957, 0x01AA0197, 44.992, -52.9267, -12.0142, 0.830444, 0, 0, -0.557102, False, '2025-07-21 22:06:57'); /* Red Burning Mushroom */
/* @teleloc 0x01AA0197 [44.992001 -52.926701 -12.014200] 0.830444 0.000000 0.000000 -0.557102 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701AA064, 8729957, 0x01AA019F, 47.6169, -56.2265, -12.0142, 0.162836, 0, 0, -0.986653, False, '2025-07-21 22:06:58'); /* Red Burning Mushroom */
/* @teleloc 0x01AA019F [47.616901 -56.226501 -12.014200] 0.162836 0.000000 0.000000 -0.986653 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701AA065, 8729957, 0x01AA01A4, 59.1442, -51.3768, -12.0142, 0.992608, 0, 0, -0.121368, False, '2025-07-21 22:07:01'); /* Red Burning Mushroom */
/* @teleloc 0x01AA01A4 [59.144199 -51.376801 -12.014200] 0.992608 0.000000 0.000000 -0.121368 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701AA066, 8729957, 0x01AA01A4, 58.2835, -49.3035, -11.4514, 0.965379, 0, 0, 0.260852, False, '2025-07-21 22:07:02'); /* Red Burning Mushroom */
/* @teleloc 0x01AA01A4 [58.283501 -49.303501 -11.451400] 0.965379 0.000000 0.000000 0.260852 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701AA067, 8729957, 0x01AA01A5, 57.7811, -57.7502, -12.0142, 0.924407, 0, 0, 0.381408, False, '2025-07-21 22:07:07'); /* Red Burning Mushroom */
/* @teleloc 0x01AA01A5 [57.781101 -57.750198 -12.014200] 0.924407 0.000000 0.000000 0.381408 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701AA068, 8729957, 0x01AA011F, 53.3757, -30.0879, -18.0142, 0.975004, 0, 0, -0.222186, False, '2025-07-21 22:07:11'); /* Red Burning Mushroom */
/* @teleloc 0x01AA011F [53.375702 -30.087900 -18.014200] 0.975004 0.000000 0.000000 -0.222186 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701AA069, 8729957, 0x01AA0108, 96.3451, -21.4416, -30.0142, 0.535873, 0, 0, 0.844298, False, '2025-07-21 22:07:19'); /* Red Burning Mushroom */
/* @teleloc 0x01AA0108 [96.345100 -21.441601 -30.014200] 0.535873 0.000000 0.000000 0.844298 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701AA06A, 8729957, 0x01AA0108, 104.232, -21.186, -30.0142, -0.977749, 0, 0, 0.20978, False, '2025-07-21 22:07:22'); /* Red Burning Mushroom */
/* @teleloc 0x01AA0108 [104.232002 -21.186001 -30.014200] -0.977749 0.000000 0.000000 0.209780 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701AA06B, 8729957, 0x01AA0109, 99.7339, -32.2284, -30.0142, 0.591839, 0, 0, 0.806056, False, '2025-07-21 22:07:27'); /* Red Burning Mushroom */
/* @teleloc 0x01AA0109 [99.733902 -32.228401 -30.014200] 0.591839 0.000000 0.000000 0.806056 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701AA06C, 8729957, 0x01AA0102, 91.1231, -34.9632, -30.0142, 0.99802, 0, 0, 0.062898, False, '2025-07-21 22:07:30'); /* Red Burning Mushroom */
/* @teleloc 0x01AA0102 [91.123100 -34.963200 -30.014200] 0.998020 0.000000 0.000000 0.062898 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701AA06D, 8729957, 0x01AA010A, 96.1741, -35.3917, -30.0142, 0.307978, 0, 0, -0.951393, False, '2025-07-21 22:07:32'); /* Red Burning Mushroom */
/* @teleloc 0x01AA010A [96.174103 -35.391701 -30.014200] 0.307978 0.000000 0.000000 -0.951393 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701AA06E, 8729957, 0x01AA0111, 112.959, -42.2651, -28.0941, 0.637638, 0, 0, -0.770336, False, '2025-07-21 22:07:34'); /* Red Burning Mushroom */
/* @teleloc 0x01AA0111 [112.959000 -42.265099 -28.094101] 0.637638 0.000000 0.000000 -0.770336 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701AA06F, 8729957, 0x01AA0111, 112.639, -41.4185, -28.2861, 0.637638, 0, 0, -0.770336, False, '2025-07-21 22:07:35'); /* Red Burning Mushroom */
/* @teleloc 0x01AA0111 [112.639000 -41.418499 -28.286100] 0.637638 0.000000 0.000000 -0.770336 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701AA070, 8729957, 0x01AA0111, 111.194, -42.3517, -29.1153, 0.637638, 0, 0, -0.770336, False, '2025-07-21 22:07:36'); /* Red Burning Mushroom */
/* @teleloc 0x01AA0111 [111.194000 -42.351700 -29.115299] 0.637638 0.000000 0.000000 -0.770336 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701AA071, 8729957, 0x01AA0111, 110.418, -40.9961, -29.6188, 0.637638, 0, 0, -0.770336, False, '2025-07-21 22:07:37'); /* Red Burning Mushroom */
/* @teleloc 0x01AA0111 [110.417999 -40.996101 -29.618799] 0.637638 0.000000 0.000000 -0.770336 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701AA072, 8729957, 0x01AA0111, 109.316, -39.5744, -30.0142, 0.637638, 0, 0, -0.770336, False, '2025-07-21 22:07:38'); /* Red Burning Mushroom */
/* @teleloc 0x01AA0111 [109.316002 -39.574402 -30.014200] 0.637638 0.000000 0.000000 -0.770336 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701AA073, 8729957, 0x01AA0111, 107.984, -40.644, -30.0142, 0.637638, 0, 0, -0.770336, False, '2025-07-21 22:07:39'); /* Red Burning Mushroom */
/* @teleloc 0x01AA0111 [107.984001 -40.644001 -30.014200] 0.637638 0.000000 0.000000 -0.770336 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701AA074, 3102157, 0x01AA010F, 108.176, -20.144, -30, 0.334926, 0, 0, 0.942245, False, '2025-07-21 22:08:11'); /* Puffball Thrungus */
/* @teleloc 0x01AA010F [108.176003 -20.143999 -30.000000] 0.334926 0.000000 0.000000 0.942245 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701AA075, 3102157, 0x01AA010F, 107.456, -23.9727, -30, -0.081934, 0, 0, 0.996638, False, '2025-07-21 22:08:12'); /* Puffball Thrungus */
/* @teleloc 0x01AA010F [107.456001 -23.972700 -30.000000] -0.081934 0.000000 0.000000 0.996638 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701AA076, 3102157, 0x01AA010F, 111.342, -23.106, -29.4987, -0.870422, 0, 0, 0.492307, False, '2025-07-21 22:08:13'); /* Puffball Thrungus */
/* @teleloc 0x01AA010F [111.342003 -23.106001 -29.498699] -0.870422 0.000000 0.000000 0.492307 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701AA077, 3102157, 0x01AA010F, 113.474, -18.969, -28.2288, -0.992747, 0, 0, 0.120222, False, '2025-07-21 22:08:14'); /* Puffball Thrungus */
/* @teleloc 0x01AA010F [113.473999 -18.969000 -28.228800] -0.992747 0.000000 0.000000 0.120222 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701AA078, 3102157, 0x01AA0109, 99.3391, -30.4703, -30, -0.436234, 0, 0, -0.899833, False, '2025-07-21 22:08:17'); /* Puffball Thrungus */
/* @teleloc 0x01AA0109 [99.339104 -30.470301 -30.000000] -0.436234 0.000000 0.000000 -0.899833 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701AA079, 3102157, 0x01AA0109, 95.3638, -30.4511, -30, -0.75221, 0, 0, -0.658924, False, '2025-07-21 22:08:19'); /* Puffball Thrungus */
/* @teleloc 0x01AA0109 [95.363800 -30.451099 -30.000000] -0.752210 0.000000 0.000000 -0.658924 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701AA07A, 3102157, 0x01AA0102, 90.1305, -33.8889, -30, -0.109365, 0, 0, -0.994002, False, '2025-07-21 22:08:21'); /* Puffball Thrungus */
/* @teleloc 0x01AA0102 [90.130501 -33.888901 -30.000000] -0.109365 0.000000 0.000000 -0.994002 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701AA07B, 3102157, 0x01AA0103, 90.3847, -42.1869, -28.6131, 0.35688, 0, 0, -0.93415, False, '2025-07-21 22:08:22'); /* Puffball Thrungus */
/* @teleloc 0x01AA0103 [90.384697 -42.186901 -28.613100] 0.356880 0.000000 0.000000 -0.934150 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701AA07C, 3102157, 0x01AA0103, 90.3847, -42.1869, -28.6131, 0.35688, 0, 0, -0.93415, False, '2025-07-21 22:08:23'); /* Puffball Thrungus */
/* @teleloc 0x01AA0103 [90.384697 -42.186901 -28.613100] 0.356880 0.000000 0.000000 -0.934150 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701AA07D, 3102157, 0x01AA012E, 65.7907, -31.4699, -18.3996, 0.551285, 0, 0, 0.834317, False, '2025-07-21 22:08:27'); /* Puffball Thrungus */
/* @teleloc 0x01AA012E [65.790703 -31.469900 -18.399599] 0.551285 0.000000 0.000000 0.834317 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701AA07E, 3102157, 0x01AA0126, 60.7153, -33.3022, -18, 0.551285, 0, 0, 0.834317, False, '2025-07-21 22:08:28'); /* Puffball Thrungus */
/* @teleloc 0x01AA0126 [60.715302 -33.302200 -18.000000] 0.551285 0.000000 0.000000 0.834317 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701AA07F, 3102157, 0x01AA019C, 48.1046, -35.3549, -17.7123, 0.044484, 0, 0, 0.99901, False, '2025-07-21 22:08:33'); /* Puffball Thrungus */
/* @teleloc 0x01AA019C [48.104599 -35.354900 -17.712299] 0.044484 0.000000 0.000000 0.999010 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701AA080, 3102157, 0x01AA0198, 44.6023, -58.9457, -12, 0.750503, 0, 0, 0.660868, False, '2025-07-21 22:08:37'); /* Puffball Thrungus */
/* @teleloc 0x01AA0198 [44.602299 -58.945702 -12.000000] 0.750503 0.000000 0.000000 0.660868 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701AA081, 3102157, 0x01AA0198, 38.3026, -62.837, -12, 0.016618, 0, 0, 0.999862, False, '2025-07-21 22:08:39'); /* Puffball Thrungus */
/* @teleloc 0x01AA0198 [38.302601 -62.837002 -12.000000] 0.016618 0.000000 0.000000 0.999862 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701AA082, 3102157, 0x01AA01A1, 45.0584, -74.4208, -12, -0.468597, 0, 0, 0.883412, False, '2025-07-21 22:08:40'); /* Puffball Thrungus */
/* @teleloc 0x01AA01A1 [45.058399 -74.420799 -12.000000] -0.468597 0.000000 0.000000 0.883412 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701AA083, 3102157, 0x01AA0175, 24.5981, -78.7061, -12, -0.703863, 0, 0, -0.710335, False, '2025-07-21 22:08:44'); /* Puffball Thrungus */
/* @teleloc 0x01AA0175 [24.598101 -78.706100 -12.000000] -0.703863 0.000000 0.000000 -0.710335 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701AA084, 3102157, 0x01AA0162, 7.79477, -96.4202, -12, -0.150445, 0, 0, -0.988618, False, '2025-07-21 22:08:48'); /* Puffball Thrungus */
/* @teleloc 0x01AA0162 [7.794770 -96.420197 -12.000000] -0.150445 0.000000 0.000000 -0.988618 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701AA085, 3102157, 0x01AA0183, 15.7451, -141.13, -12, 0.427516, 0, 0, -0.904008, False, '2025-07-21 22:09:00'); /* Puffball Thrungus */
/* @teleloc 0x01AA0183 [15.745100 -141.130005 -12.000000] 0.427516 0.000000 0.000000 -0.904008 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701AA086, 3102157, 0x01AA0194, 30.5721, -137.652, -12, 0.624078, 0, 0, -0.781362, False, '2025-07-21 22:09:02'); /* Puffball Thrungus */
/* @teleloc 0x01AA0194 [30.572100 -137.651993 -12.000000] 0.624078 0.000000 0.000000 -0.781362 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701AA087, 3102157, 0x01AA01D1, 31.0333, -114.735, -6, 0.954986, 0, 0, -0.296651, False, '2025-07-21 22:09:05'); /* Puffball Thrungus */
/* @teleloc 0x01AA01D1 [31.033300 -114.735001 -6.000000] 0.954986 0.000000 0.000000 -0.296651 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701AA088, 3102157, 0x01AA01CD, 31.414, -106.264, -6, 0.98198, 0, 0, -0.188985, False, '2025-07-21 22:09:08'); /* Puffball Thrungus */
/* @teleloc 0x01AA01CD [31.414000 -106.264000 -6.000000] 0.981980 0.000000 0.000000 -0.188985 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701AA089, 3102157, 0x01AA01B2, 59.7141, -108.709, -12, 0.709208, 0, 0, -0.704999, False, '2025-07-21 22:09:15'); /* Puffball Thrungus */
/* @teleloc 0x01AA01B2 [59.714100 -108.709000 -12.000000] 0.709208 0.000000 0.000000 -0.704999 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701AA08A, 3102157, 0x01AA01B3, 68.6181, -85.6926, -12, -0.105229, 0, 0, 0.994448, False, '2025-07-21 22:09:32'); /* Puffball Thrungus */
/* @teleloc 0x01AA01B3 [68.618103 -85.692596 -12.000000] -0.105229 0.000000 0.000000 0.994448 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701AA08B, 3102157, 0x01AA0187, 30.0952, -64.1713, -11.9823, 0.979141, 0, 0, 0.203181, False, '2025-07-21 22:09:42'); /* Puffball Thrungus */
/* @teleloc 0x01AA0187 [30.095200 -64.171303 -11.982300] 0.979141 0.000000 0.000000 0.203181 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701AA08C, 3102157, 0x01AA0187, 29.046, -61.8993, -11.3528, 0.930407, 0, 0, 0.366527, False, '2025-07-21 22:09:44'); /* Puffball Thrungus */
/* @teleloc 0x01AA0187 [29.046000 -61.899300 -11.352800] 0.930407 0.000000 0.000000 0.366527 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701AA08D, 3102157, 0x01AA019B, 39.0885, -88.1162, -12, -0.859491, 0, 0, -0.51115, False, '2025-07-21 22:10:04'); /* Puffball Thrungus */
/* @teleloc 0x01AA019B [39.088501 -88.116203 -12.000000] -0.859491 0.000000 0.000000 -0.511150 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701AA08E, 851657, 0x01AA01A7, 61.9861, -91.0956, -11.945, 0.914489, 0, 0, 0.404611, False, '2025-07-21 22:10:34'); /* The Black Breath */
/* @teleloc 0x01AA01A7 [61.986099 -91.095596 -11.945000] 0.914489 0.000000 0.000000 0.404611 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701AA08F, 851657, 0x01AA019B, 42.3978, -88.3533, -11.945, 0.748042, 0, 0, 0.663652, False, '2025-07-21 22:10:36'); /* The Black Breath */
/* @teleloc 0x01AA019B [42.397800 -88.353302 -11.945000] 0.748042 0.000000 0.000000 0.663652 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701AA090, 851657, 0x01AA0176, 19.1906, -87.3831, -11.945, 0.996108, 0, 0, -0.08814, False, '2025-07-21 22:10:41'); /* The Black Breath */
/* @teleloc 0x01AA0176 [19.190599 -87.383102 -11.945000] 0.996108 0.000000 0.000000 -0.088140 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701AA091, 851657, 0x01AA0189, 34.9786, -65.7156, -11.945, 0.928279, 0, 0, -0.371884, False, '2025-07-21 22:10:43'); /* The Black Breath */
/* @teleloc 0x01AA0189 [34.978600 -65.715599 -11.945000] 0.928279 0.000000 0.000000 -0.371884 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701AA092, 851657, 0x01AA019E, 52.79, -54.7911, -11.945, 0.998613, 0, 0, -0.052656, False, '2025-07-21 22:10:46'); /* The Black Breath */
/* @teleloc 0x01AA019E [52.790001 -54.791100 -11.945000] 0.998613 0.000000 0.000000 -0.052656 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701AA093, 851657, 0x01AA01A0, 50.8519, -68.6081, -11.945, -0.11902, 0, 0, 0.992892, False, '2025-07-21 22:10:49'); /* The Black Breath */
/* @teleloc 0x01AA01A0 [50.851898 -68.608101 -11.945000] -0.119020 0.000000 0.000000 0.992892 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701AA094, 851657, 0x01AA0142, 75.2236, -69.514, -17.945, -0.752911, 0, 0, 0.658122, False, '2025-07-21 22:10:51'); /* The Black Breath */
/* @teleloc 0x01AA0142 [75.223602 -69.514000 -17.945000] -0.752911 0.000000 0.000000 0.658122 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701AA095, 851657, 0x01AA0146, 86.5216, -64.9876, -17.945, -0.986028, 0, 0, 0.16658, False, '2025-07-21 22:10:52'); /* The Black Breath */
/* @teleloc 0x01AA0146 [86.521599 -64.987602 -17.945000] -0.986028 0.000000 0.000000 0.166580 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701AA096, 851657, 0x01AA011F, 49.6505, -28.678, -17.945, -0.935845, 0, 0, 0.352411, False, '2025-07-21 22:11:03'); /* The Black Breath */
/* @teleloc 0x01AA011F [49.650501 -28.677999 -17.945000] -0.935845 0.000000 0.000000 0.352411 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701AA097, 851657, 0x01AA0129, 61.8863, -25.3096, -17.945, -0.079818, 0, 0, 0.996809, False, '2025-07-21 22:11:05'); /* The Black Breath */
/* @teleloc 0x01AA0129 [61.886299 -25.309601 -17.945000] -0.079818 0.000000 0.000000 0.996809 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701AA098, 851657, 0x01AA012E, 66.4393, -31.2485, -18.7288, -0.705252, 0, 0, 0.708956, False, '2025-07-21 22:11:07'); /* The Black Breath */
/* @teleloc 0x01AA012E [66.439301 -31.248501 -18.728800] -0.705252 0.000000 0.000000 0.708956 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701AA099, 851657, 0x01AA0112, 75.1616, -31.2938, -23.9622, -0.705252, 0, 0, 0.708956, False, '2025-07-21 22:11:09'); /* The Black Breath */
/* @teleloc 0x01AA0112 [75.161598 -31.293800 -23.962200] -0.705252 0.000000 0.000000 0.708956 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701AA09A, 851657, 0x01AA0101, 89.5499, -30.3006, -29.945, -0.898327, 0, 0, 0.439328, False, '2025-07-21 22:11:10'); /* The Black Breath */
/* @teleloc 0x01AA0101 [89.549896 -30.300600 -29.945000] -0.898327 0.000000 0.000000 0.439328 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701AA09B, 851657, 0x01AA010F, 106.65, -24.1269, -29.945, -0.623462, 0, 0, 0.781854, False, '2025-07-21 22:11:11'); /* The Black Breath */
/* @teleloc 0x01AA010F [106.650002 -24.126900 -29.945000] -0.623462 0.000000 0.000000 0.781854 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701AA09C, 851657, 0x01AA0110, 109.863, -33.3954, -29.945, 0.021059, 0, 0, 0.999778, False, '2025-07-21 22:11:13'); /* The Black Breath */
/* @teleloc 0x01AA0110 [109.862999 -33.395401 -29.945000] 0.021059 0.000000 0.000000 0.999778 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701AA09D, 851657, 0x01AA010A, 104.401, -40.2603, -29.7091, 0.483973, 0, 0, 0.875083, False, '2025-07-21 22:11:14'); /* The Black Breath */
/* @teleloc 0x01AA010A [104.401001 -40.260300 -29.709101] 0.483973 0.000000 0.000000 0.875083 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701AA09E, 851657, 0x01AA0102, 93.9031, -34.0537, -29.945, 0.986474, 0, 0, 0.163917, False, '2025-07-21 22:11:16'); /* The Black Breath */
/* @teleloc 0x01AA0102 [93.903099 -34.053699 -29.945000] 0.986474 0.000000 0.000000 0.163917 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701AA09F, 851657, 0x01AA0102, 91.2605, -29.3006, -29.945, 0.68507, 0, 0, 0.728477, False, '2025-07-21 22:11:19'); /* The Black Breath */
/* @teleloc 0x01AA0102 [91.260498 -29.300600 -29.945000] 0.685070 0.000000 0.000000 0.728477 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701AA0A0, 851657, 0x01AA0126, 64.0369, -30.317, -17.945, 0.713922, 0, 0, 0.700225, False, '2025-07-21 22:11:22'); /* The Black Breath */
/* @teleloc 0x01AA0126 [64.036903 -30.316999 -17.945000] 0.713922 0.000000 0.000000 0.700225 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701AA0A1, 851657, 0x01AA0167, 10.3533, -114.966, -11.945, 0.998923, 0, 0, -0.0464, False, '2025-07-21 22:11:39'); /* The Black Breath */
/* @teleloc 0x01AA0167 [10.353300 -114.966003 -11.945000] 0.998923 0.000000 0.000000 -0.046400 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701AA0A2, 851657, 0x01AA0192, 30.3638, -134.865, -11.945, -0.995466, 0, 0, 0.095114, False, '2025-07-21 22:11:47'); /* The Black Breath */
/* @teleloc 0x01AA0192 [30.363800 -134.865005 -11.945000] -0.995466 0.000000 0.000000 0.095114 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701AA0A3, 851657, 0x01AA01CE, 27.0934, -108.908, -5.945, -0.998422, 0, 0, -0.056151, False, '2025-07-21 22:11:50'); /* The Black Breath */
/* @teleloc 0x01AA01CE [27.093399 -108.907997 -5.945000] -0.998422 0.000000 0.000000 -0.056151 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701AA0A4, 851657, 0x01AA01D7, 40.5062, -104.565, -5.945, -0.992068, 0, 0, 0.125704, False, '2025-07-21 22:11:52'); /* The Black Breath */
/* @teleloc 0x01AA01D7 [40.506199 -104.565002 -5.945000] -0.992068 0.000000 0.000000 0.125704 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701AA0A5, 851657, 0x01AA01DF, 49.8506, -110.503, -8.77561, -0.740099, 0, 0, 0.672499, False, '2025-07-21 22:11:55'); /* The Black Breath */
/* @teleloc 0x01AA01DF [49.850601 -110.502998 -8.775610] -0.740099 0.000000 0.000000 0.672499 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701AA0A6, 851657, 0x01AA01F9, 29.9444, -78.9449, -2.23217, -0.998932, 0, 0, 0.046208, False, '2025-07-21 22:12:02'); /* The Black Breath */
/* @teleloc 0x01AA01F9 [29.944401 -78.944901 -2.232170] -0.998932 0.000000 0.000000 0.046208 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701AA0A7, 851657, 0x01AA01F9, 29.9444, -78.9449, -2.23217, -0.998932, 0, 0, 0.046208, False, '2025-07-21 22:12:03'); /* The Black Breath */
/* @teleloc 0x01AA01F9 [29.944401 -78.944901 -2.232170] -0.998932 0.000000 0.000000 0.046208 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701AA0A8, 851657, 0x01AA01EE, 21.0879, -67.3711, 0.055, -0.753001, 0, 0, -0.658019, False, '2025-07-21 22:12:05'); /* The Black Breath */
/* @teleloc 0x01AA01EE [21.087900 -67.371101 0.055000] -0.753001 0.000000 0.000000 -0.658019 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701AA0A9, 851657, 0x01AA01EA, 11.3043, -66.0611, 0.055, -0.949805, 0, 0, -0.312843, False, '2025-07-21 22:12:06'); /* The Black Breath */
/* @teleloc 0x01AA01EA [11.304300 -66.061096 0.055000] -0.949805 0.000000 0.000000 -0.312843 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701AA0AA, 851657, 0x01AA01E8, 14.5065, -54.1877, 0.055, -0.958798, 0, 0, 0.284087, False, '2025-07-21 22:12:07'); /* The Black Breath */
/* @teleloc 0x01AA01E8 [14.506500 -54.187698 0.055000] -0.958798 0.000000 0.000000 0.284087 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701AA0AB, 851657, 0x01AA01EC, 19.8535, -48.3174, 0.055, -0.796915, 0, 0, 0.604092, False, '2025-07-21 22:12:08'); /* The Black Breath */
/* @teleloc 0x01AA01EC [19.853500 -48.317402 0.055000] -0.796915 0.000000 0.000000 0.604092 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701AA0AC, 851657, 0x01AA01ED, 20.2178, -55.7479, 0.055, 0.015325, 0, 0, 0.999883, False, '2025-07-21 22:12:10'); /* The Black Breath */
/* @teleloc 0x01AA01ED [20.217800 -55.747898 0.055000] 0.015325 0.000000 0.000000 0.999883 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701AA0AD, 851657, 0x01AA01FA, 35.843, -49.8594, 0.055, -0.366779, 0, 0, 0.930308, False, '2025-07-21 22:12:20'); /* The Black Breath */
/* @teleloc 0x01AA01FA [35.842999 -49.859402 0.055000] -0.366779 0.000000 0.000000 0.930308 */
