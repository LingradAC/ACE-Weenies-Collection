DELETE FROM `landblock_instance` WHERE `landblock` = 0x04F9;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x704F9000, 4200001, 0x04F90001, 10, 10, -0.88845, 1, 0, 0, 0, False, '2025-09-12 22:12:58'); /* Holtburg Governor */
/* @teleloc 0x04F90001 [10.000000 10.000000 -0.888450] 1.000000 0.000000 0.000000 0.000000 */
