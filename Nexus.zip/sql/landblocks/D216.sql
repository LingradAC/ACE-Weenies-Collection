DELETE FROM `landblock_instance` WHERE `landblock` = 0xD216;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7D216000, 12383322, 0xD2160014, 65.2028, 90.8809, 0.055, 0.700634, 0, 0, -0.713521, False, '2025-08-21 04:38:07');
/* @teleloc 0xD2160014 [65.202797 90.880898 0.055000] 0.700634 0.000000 0.000000 -0.713521 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7D216001, 12383322, 0xD216001B, 78.3562, 63.532, 0.055, 0.026767, 0, 0, -0.999642, False, '2025-08-21 04:38:13');
/* @teleloc 0xD216001B [78.356201 63.532001 0.055000] 0.026767 0.000000 0.000000 -0.999642 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7D216002, 12383322, 0xD216000B, 47.4566, 63.9899, 0.055, -0.709032, 0, 0, -0.705176, False, '2025-08-21 04:38:16');
/* @teleloc 0xD216000B [47.456600 63.989899 0.055000] -0.709032 0.000000 0.000000 -0.705176 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7D216003, 12383322, 0xD2160004, 13.6867, 72.1843, 0.055, -0.846957, 0, 0, -0.531661, False, '2025-08-21 04:38:18');
/* @teleloc 0xD2160004 [13.686700 72.184303 0.055000] -0.846957 0.000000 0.000000 -0.531661 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7D216004, 12383322, 0xD2160003, 0.045227, 53.6092, 0.055, -0.712863, 0, 0, 0.701304, False, '2025-08-21 04:38:44');
/* @teleloc 0xD2160003 [0.045227 53.609200 0.055000] -0.712863 0.000000 0.000000 0.701304 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7D216005, 12383322, 0xD216000C, 38.641, 78.0242, 0.055, -0.933704, 0, 0, 0.358045, False, '2025-08-21 04:38:48');
/* @teleloc 0xD216000C [38.640999 78.024200 0.055000] -0.933704 0.000000 0.000000 0.358045 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7D216006, 12383322, 0xD216002D, 134.436, 109.9, 0.055, -0.700353, 0, 0, 0.713796, False, '2025-08-21 04:39:00');
/* @teleloc 0xD216002D [134.436005 109.900002 0.055000] -0.700353 0.000000 0.000000 0.713796 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7D216007, 12383322, 0xD2160033, 163.279, 59.1125, 0.055, -0.630459, 0, 0, 0.776222, False, '2025-08-21 04:39:05');
/* @teleloc 0xD2160033 [163.279007 59.112499 0.055000] -0.630459 0.000000 0.000000 0.776222 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7D216008, 12383322, 0xD2160005, 22.4696, 117.701, 0.055, 0.682446, 0, 0, -0.730936, False, '2025-08-21 04:39:36');
/* @teleloc 0xD2160005 [22.469601 117.700996 0.055000] 0.682446 0.000000 0.000000 -0.730936 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7D216009, 12383322, 0xD2160016, 62.8503, 128.999, 0.055, -0.183432, 0, 0, -0.983032, False, '2025-08-21 04:39:40');
/* @teleloc 0xD2160016 [62.850300 128.998993 0.055000] -0.183432 0.000000 0.000000 -0.983032 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7D21600A,  6075, 0xD2160017, 57.7386, 152.486, -0.096675, 0.026714, 0, 0, -0.999643, False, '2025-08-21 04:49:09'); /* Straw Target Drudge */
/* @teleloc 0xD2160017 [57.738602 152.485992 -0.096675] 0.026714 0.000000 0.000000 -0.999643 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7D21600B,  6075, 0xD2160017, 51.851, 152.172, -0.096675, 0.026714, 0, 0, -0.999643, False, '2025-08-21 04:49:11'); /* Straw Target Drudge */
/* @teleloc 0xD2160017 [51.851002 152.171997 -0.096675] 0.026714 0.000000 0.000000 -0.999643 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7D21600C,  6075, 0xD216000F, 47.2096, 151.923, -0.096675, 0.026714, 0, 0, -0.999643, False, '2025-08-21 04:49:13'); /* Straw Target Drudge */
/* @teleloc 0xD216000F [47.209599 151.923004 -0.096675] 0.026714 0.000000 0.000000 -0.999643 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7D21600D,  6075, 0xD216000F, 42.68608, 151.6814, -0.096675, 0.026714, 0, 0, -0.999643, False, '2025-08-21 04:49:14'); /* Straw Target Drudge */
/* @teleloc 0xD216000F [42.686081 151.681396 -0.096675] 0.026714 0.000000 0.000000 -0.999643 */
