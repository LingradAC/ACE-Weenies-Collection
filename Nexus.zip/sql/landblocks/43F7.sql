DELETE FROM `landblock_instance` WHERE `landblock` = 0x43F7;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x743F7000, 31928, 0x43F7000E, 46.9769, 129.812, 99.937, -0.707107, 0, 0, -0.707107, False, '2021-11-01 00:00:00');
/* @teleloc 0x43F7000E [46.976898 129.811996 99.936996] -0.707107 0.000000 0.000000 -0.707107 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x743F7004, 30964, 0x43F70016, 60.4781, 132.661, 100.137, 0.996031, 0, 0, 0.089004, False, '2025-08-04 19:29:51');
/* @teleloc 0x43F70016 [60.478100 132.660995 100.137001] 0.996031 0.000000 0.000000 0.089004 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x743F7005, 43918217, 0x43F70016, 60.9818, 132.969, 100.137, -0.026711, 0, 0, 0.999643, False, '2025-08-14 10:24:35'); /* Egg Orchard */
/* @teleloc 0x43F70016 [60.981800 132.968994 100.137001] -0.026711 0.000000 0.000000 0.999643 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x743F7006, 48239877, 0x43F7001E, 75.6638, 125.2008, 99.937, -0.970028, 0, 0, 0.242993, False, '2025-08-19 16:10:32');
/* @teleloc 0x43F7001E [75.663803 125.200798 99.936996] -0.970028 0.000000 0.000000 0.242993 */
