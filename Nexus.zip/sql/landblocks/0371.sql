DELETE FROM `landblock_instance` WHERE `landblock` = 0x0371;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70371000,  9686, 0x03710103, 10.1696, -15.6031, -4.23, 1, 0, 0, 0,  True, '2005-02-09 10:00:00'); /* Wall Hook */
/* @teleloc 0x03710103 [10.169600 -15.603100 -4.230000] 1.000000 0.000000 0.000000 0.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70371001,   278, 0x03710106, 5.25, -20, -6, -0.707107, 0, 0, -0.707107, False, '2005-02-09 10:00:00'); /* Door */
/* @teleloc 0x03710106 [5.250000 -20.000000 -6.000000] -0.707107 0.000000 0.000000 -0.707107 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70371002, 11697, 0x03710108, 5.88058, -29.9994, -5.995, 1, 0, 0, 0,  True, '2005-02-09 10:00:00'); /* Floor Hook */
/* @teleloc 0x03710108 [5.880580 -29.999399 -5.995000] 1.000000 0.000000 0.000000 0.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70371003,  9686, 0x03710108, 14.3966, -29.9989, -4.3, 0.703922, 0, 0, -0.710278,  True, '2005-02-09 10:00:00'); /* Wall Hook */
/* @teleloc 0x03710108 [14.396600 -29.998899 -4.300000] 0.703922 0.000000 0.000000 -0.710278 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70371004, 11697, 0x03710108, 9.87908, -34.1693, -5.995, -0.004204, 0, 0, -0.999991,  True, '2005-02-09 10:00:00'); /* Floor Hook */
/* @teleloc 0x03710108 [9.879080 -34.169300 -5.995000] -0.004204 0.000000 0.000000 -0.999991 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70371005,   278, 0x0371010A, 10, -25.25, -6, 1, 0, 0, 0, False, '2005-02-09 10:00:00'); /* Door */
/* @teleloc 0x0371010A [10.000000 -25.250000 -6.000000] 1.000000 0.000000 0.000000 0.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70371006,  9686, 0x0371010B, 10.1427, -45.6092, -4.3, 0.999866, 0, 0, -0.016371,  True, '2005-02-09 10:00:00'); /* Wall Hook */
/* @teleloc 0x0371010B [10.142700 -45.609200 -4.300000] 0.999866 0.000000 0.000000 -0.016371 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70371007,  9686, 0x0371010B, 5.61091, -49.4515, -4.3, -0.703698, 0, 0, -0.710499,  True, '2005-02-09 10:00:00'); /* Wall Hook */
/* @teleloc 0x0371010B [5.610910 -49.451500 -4.300000] -0.703698 0.000000 0.000000 -0.710499 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70371008, 11697, 0x0371010B, 9.77066, -54.238, -5.995, -0.013097, 0, 0, 0.999914,  True, '2005-02-09 10:00:00'); /* Floor Hook */
/* @teleloc 0x0371010B [9.770660 -54.237999 -5.995000] -0.013097 0.000000 0.000000 0.999914 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70371009,  9686, 0x0371010E, 20.1077, -15.6069, -4.3, 1, 0, 0, 0,  True, '2005-02-09 10:00:00'); /* Wall Hook */
/* @teleloc 0x0371010E [20.107700 -15.606900 -4.300000] 1.000000 0.000000 0.000000 0.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7037100A,   278, 0x03710110, 24.75, -20, -6, -0.707107, 0, 0, 0.707107, False, '2005-02-09 10:00:00'); /* Door */
/* @teleloc 0x03710110 [24.750000 -20.000000 -6.000000] -0.707107 0.000000 0.000000 0.707107 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7037100B,   278, 0x03710111, 15.25, -20, -6, -0.707107, 0, 0, -0.707107, False, '2005-02-09 10:00:00'); /* Door */
/* @teleloc 0x03710111 [15.250000 -20.000000 -6.000000] -0.707107 0.000000 0.000000 -0.707107 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7037100C,   278, 0x03710112, 20, -24.75, -6, 0, 0, 0, -1, False, '2005-02-09 10:00:00'); /* Door */
/* @teleloc 0x03710112 [20.000000 -24.750000 -6.000000] 0.000000 0.000000 0.000000 -1.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7037100D,  9686, 0x03710113, 15.1863, -29.8995, -4.3, -0.714424, 0, 0, -0.699713,  True, '2005-02-09 10:00:00'); /* Wall Hook */
/* @teleloc 0x03710113 [15.186300 -29.899500 -4.300000] -0.714424 0.000000 0.000000 -0.699713 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7037100E,  9686, 0x03710113, 22.9539, -25.1018, -4.3, 0.999866, 0, 0, -0.016371,  True, '2005-02-09 10:00:00'); /* Wall Hook */
/* @teleloc 0x03710113 [22.953899 -25.101801 -4.300000] 0.999866 0.000000 0.000000 -0.016371 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7037100F, 11697, 0x03710113, 15.3925, -29.8803, -5.995, 0.696707, 0, 0, 0.717356,  True, '2005-02-09 10:00:00'); /* Floor Hook */
/* @teleloc 0x03710113 [15.392500 -29.880301 -5.995000] 0.696707 0.000000 0.000000 0.717356 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70371010,  9686, 0x03710119, 20.2043, -54.3969, -4.3, -0.006746, 0, 0, -0.999977,  True, '2005-02-09 10:00:00'); /* Wall Hook */
/* @teleloc 0x03710119 [20.204300 -54.396900 -4.300000] -0.006746 0.000000 0.000000 -0.999977 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70371011,   278, 0x0371011B, 15.25, -50, -6, -0.707107, 0, 0, -0.707107, False, '2005-02-09 10:00:00'); /* Door */
/* @teleloc 0x0371011B [15.250000 -50.000000 -6.000000] -0.707107 0.000000 0.000000 -0.707107 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70371012,   278, 0x0371011C, 24.75, -50, -6, 0.707107, 0, 0, -0.707107, False, '2005-02-09 10:00:00'); /* Door */
/* @teleloc 0x0371011C [24.750000 -50.000000 -6.000000] 0.707107 0.000000 0.000000 -0.707107 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70371013,   278, 0x0371011D, 20, -45.25, -6, 1, 0, 0, 0, False, '2005-02-09 10:00:00'); /* Door */
/* @teleloc 0x0371011D [20.000000 -45.250000 -6.000000] 1.000000 0.000000 0.000000 0.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70371014, 11697, 0x03710121, 25.7996, -9.86286, -5.995, 0.714421, 0, 0, 0.699716,  True, '2005-02-09 10:00:00'); /* Floor Hook */
/* @teleloc 0x03710121 [25.799601 -9.862860 -5.995000] 0.714421 0.000000 0.000000 0.699716 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70371015,   278, 0x03710123, 30, -5.25001, -6, -1, 0, 0, 0, False, '2005-02-09 10:00:00'); /* Door */
/* @teleloc 0x03710123 [30.000000 -5.250010 -6.000000] -1.000000 0.000000 0.000000 0.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70371016,  9686, 0x03710125, 29.975, -15.119, -4.3, 1, 0, 0, 0,  True, '2005-02-09 10:00:00'); /* Wall Hook */
/* @teleloc 0x03710125 [29.975000 -15.119000 -4.300000] 1.000000 0.000000 0.000000 0.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70371017,  9686, 0x03710125, 34.8896, -23.1519, -4.3, 0.739384, 0, 0, -0.673284,  True, '2005-02-09 10:00:00'); /* Wall Hook */
/* @teleloc 0x03710125 [34.889599 -23.151899 -4.300000] 0.739384 0.000000 0.000000 -0.673284 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70371018, 11697, 0x03710125, 30.0309, -15.4892, -5.995, 0.999687, 0, 0, 0.024998,  True, '2005-02-09 10:00:00'); /* Floor Hook */
/* @teleloc 0x03710125 [30.030899 -15.489200 -5.995000] 0.999687 0.000000 0.000000 0.024998 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70371019, 11697, 0x03710126, 30, -30, -5.995, 1, 0, 0, 0,  True, '2005-02-09 10:00:00'); /* Floor Hook */
/* @teleloc 0x03710126 [30.000000 -30.000000 -5.995000] 1.000000 0.000000 0.000000 0.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7037101A, 13073, 0x03710126, 29.9606, -26.7622, -5.995, 0.992198, 0, 0, -0.124675, False, '2005-02-09 10:00:00'); /* Mansion */
/* @teleloc 0x03710126 [29.960600 -26.762199 -5.995000] 0.992198 0.000000 0.000000 -0.124675 */

INSERT INTO `landblock_instance_link` (`parent_GUID`, `child_GUID`, `last_Modified`)
VALUES (0x7037101A, 0x70371000, '2005-02-09 10:00:00') /* Wall Hook (9686) */
     , (0x7037101A, 0x70371002, '2005-02-09 10:00:00') /* Floor Hook (11697) */
     , (0x7037101A, 0x70371003, '2005-02-09 10:00:00') /* Wall Hook (9686) */
     , (0x7037101A, 0x70371004, '2005-02-09 10:00:00') /* Floor Hook (11697) */
     , (0x7037101A, 0x70371006, '2005-02-09 10:00:00') /* Wall Hook (9686) */
     , (0x7037101A, 0x70371007, '2005-02-09 10:00:00') /* Wall Hook (9686) */
     , (0x7037101A, 0x70371008, '2005-02-09 10:00:00') /* Floor Hook (11697) */
     , (0x7037101A, 0x70371009, '2005-02-09 10:00:00') /* Wall Hook (9686) */
     , (0x7037101A, 0x7037100D, '2005-02-09 10:00:00') /* Wall Hook (9686) */
     , (0x7037101A, 0x7037100E, '2005-02-09 10:00:00') /* Wall Hook (9686) */
     , (0x7037101A, 0x7037100F, '2005-02-09 10:00:00') /* Floor Hook (11697) */
     , (0x7037101A, 0x70371010, '2005-02-09 10:00:00') /* Wall Hook (9686) */
     , (0x7037101A, 0x70371014, '2005-02-09 10:00:00') /* Floor Hook (11697) */
     , (0x7037101A, 0x70371016, '2005-02-09 10:00:00') /* Wall Hook (9686) */
     , (0x7037101A, 0x70371017, '2005-02-09 10:00:00') /* Wall Hook (9686) */
     , (0x7037101A, 0x70371018, '2005-02-09 10:00:00') /* Floor Hook (11697) */
     , (0x7037101A, 0x70371019, '2005-02-09 10:00:00') /* Floor Hook (11697) */
     , (0x7037101A, 0x7037101B, '2005-02-09 10:00:00') /* Wall Hook (9686) */
     , (0x7037101A, 0x7037101C, '2005-02-09 10:00:00') /* Wall Hook (9686) */
     , (0x7037101A, 0x7037101D, '2005-02-09 10:00:00') /* Floor Hook (11697) */
     , (0x7037101A, 0x7037101E, '2005-02-09 10:00:00') /* Wall Hook (9686) */
     , (0x7037101A, 0x7037101F, '2005-02-09 10:00:00') /* Wall Hook (9686) */
     , (0x7037101A, 0x70371021, '2005-02-09 10:00:00') /* Wall Hook (9686) */
     , (0x7037101A, 0x70371025, '2005-02-09 10:00:00') /* Wall Hook (9686) */
     , (0x7037101A, 0x70371026, '2005-02-09 10:00:00') /* Wall Hook (9686) */
     , (0x7037101A, 0x70371027, '2005-02-09 10:00:00') /* Floor Hook (11697) */
     , (0x7037101A, 0x7037102B, '2005-02-09 10:00:00') /* Wall Hook (9686) */
     , (0x7037101A, 0x7037102C, '2005-02-09 10:00:00') /* Floor Hook (11697) */
     , (0x7037101A, 0x7037102D, '2005-02-09 10:00:00') /* Floor Hook (11697) */
     , (0x7037101A, 0x7037102E, '2005-02-09 10:00:00') /* Wall Hook (9686) */
     , (0x7037101A, 0x7037102F, '2005-02-09 10:00:00') /* Floor Hook (11697) */
     , (0x7037101A, 0x70371030, '2005-02-09 10:00:00') /* Storage (9687) */
     , (0x7037101A, 0x70371031, '2005-02-09 10:00:00') /* Storage (9687) */
     , (0x7037101A, 0x70371032, '2005-02-09 10:00:00') /* Storage (9687) */
     , (0x7037101A, 0x70371033, '2005-02-09 10:00:00') /* Storage (9687) */
     , (0x7037101A, 0x70371034, '2005-02-09 10:00:00') /* Storage (9687) */
     , (0x7037101A, 0x70371035, '2005-02-09 10:00:00') /* Wall Hook (9686) */
     , (0x7037101A, 0x70371037, '2005-02-09 10:00:00') /* House Portal (11730) */
     , (0x7037101A, 0x70371039, '2005-02-09 10:00:00') /* Wall Hook (9686) */
     , (0x7037101A, 0x7037103A, '2005-02-09 10:00:00') /* Floor Hook (11697) */
     , (0x7037101A, 0x7037103B, '2005-02-09 10:00:00') /* Wall Hook (9686) */
     , (0x7037101A, 0x7037103C, '2005-02-09 10:00:00') /* Floor Hook (11697) */
     , (0x7037101A, 0x7037103D, '2005-02-09 10:00:00') /* Floor Hook (11697) */
     , (0x7037101A, 0x7037103E, '2005-02-09 10:00:00') /* Wall Hook (9686) */
     , (0x7037101A, 0x7037103F, '2005-02-09 10:00:00') /* Floor Hook (11697) */
     , (0x7037101A, 0x70371040, '2005-02-09 10:00:00') /* Wall Hook (9686) */
     , (0x7037101A, 0x70371041, '2005-02-09 10:00:00') /* Floor Hook (11697) */;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7037101B,  9686, 0x03710127, 29.9008, -44.8921, -4.3, 0.003046, 0, 0, -0.999995,  True, '2005-02-09 10:00:00'); /* Wall Hook */
/* @teleloc 0x03710127 [29.900801 -44.892101 -4.300000] 0.003046 0.000000 0.000000 -0.999995 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7037101C,  9686, 0x03710127, 25.1382, -36.6844, -4.3, -0.662784, 0, 0, -0.748811,  True, '2005-02-09 10:00:00'); /* Wall Hook */
/* @teleloc 0x03710127 [25.138201 -36.684399 -4.300000] -0.662784 0.000000 0.000000 -0.748811 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7037101D, 11697, 0x03710127, 29.8329, -44.5904, -5.995, 0.04578, 0, 0, -0.998952,  True, '2005-02-09 10:00:00'); /* Floor Hook */
/* @teleloc 0x03710127 [29.832899 -44.590401 -5.995000] 0.045780 0.000000 0.000000 -0.998952 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7037101E,  9686, 0x03710128, 30.035, -45.605, -4.3, 1, 0, 0, 0,  True, '2005-02-09 10:00:00'); /* Wall Hook */
/* @teleloc 0x03710128 [30.035000 -45.605000 -4.300000] 1.000000 0.000000 0.000000 0.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7037101F,  9686, 0x03710128, 34.3912, -50.3317, -4.3, 0.71424, 0, 0, -0.6999,  True, '2005-02-09 10:00:00'); /* Wall Hook */
/* @teleloc 0x03710128 [34.391201 -50.331699 -4.300000] 0.714240 0.000000 0.000000 -0.699900 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70371020,   278, 0x0371012A, 30, -54.75, -6, 0, 0, 0, 1, False, '2005-02-09 10:00:00'); /* Door */
/* @teleloc 0x0371012A [30.000000 -54.750000 -6.000000] 0.000000 0.000000 0.000000 1.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70371021,  9686, 0x0371012F, 40.5211, -5.61113, -4.3, 1, 0, 0, 0,  True, '2005-02-09 10:00:00'); /* Wall Hook */
/* @teleloc 0x0371012F [40.521099 -5.611130 -4.300000] 1.000000 0.000000 0.000000 0.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70371022,   278, 0x03710131, 44.75, -10, -6, -0.707107, 0, 0, 0.707107, False, '2005-02-09 10:00:00'); /* Door */
/* @teleloc 0x03710131 [44.750000 -10.000000 -6.000000] -0.707107 0.000000 0.000000 0.707107 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70371023,   278, 0x03710132, 35.25, -10, -6, -0.707107, 0, 0, -0.707107, False, '2005-02-09 10:00:00'); /* Door */
/* @teleloc 0x03710132 [35.250000 -10.000000 -6.000000] -0.707107 0.000000 0.000000 -0.707107 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70371024,   278, 0x03710133, 40, -14.75, -6, 0, 0, 0, -1, False, '2005-02-09 10:00:00'); /* Door */
/* @teleloc 0x03710133 [40.000000 -14.750000 -6.000000] 0.000000 0.000000 0.000000 -1.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70371025,  9686, 0x03710139, 44.8961, -30.0061, -4.3, 0.696708, 0, 0, -0.717355,  True, '2005-02-09 10:00:00'); /* Wall Hook */
/* @teleloc 0x03710139 [44.896099 -30.006100 -4.300000] 0.696708 0.000000 0.000000 -0.717355 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70371026,  9686, 0x03710139, 36.669, -34.895, -4.3, 0.008613, 0, 0, -0.999963,  True, '2005-02-09 10:00:00'); /* Wall Hook */
/* @teleloc 0x03710139 [36.668999 -34.895000 -4.300000] 0.008613 0.000000 0.000000 -0.999963 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70371027, 11697, 0x03710139, 44.605, -30.0435, -5.995, 0.731689, 0, 0, -0.681639,  True, '2005-02-09 10:00:00'); /* Floor Hook */
/* @teleloc 0x03710139 [44.605000 -30.043501 -5.995000] 0.731689 0.000000 0.000000 -0.681639 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70371028,   278, 0x0371013D, 35.25, -40, -6, -0.707107, 0, 0, -0.707107, False, '2005-02-09 10:00:00'); /* Door */
/* @teleloc 0x0371013D [35.250000 -40.000000 -6.000000] -0.707107 0.000000 0.000000 -0.707107 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70371029,   278, 0x0371013E, 44.75, -40, -6, 0.707107, 0, 0, -0.707107, False, '2005-02-09 10:00:00'); /* Door */
/* @teleloc 0x0371013E [44.750000 -40.000000 -6.000000] 0.707107 0.000000 0.000000 -0.707107 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7037102A,   278, 0x0371013F, 40, -35.25, -6, 1, 0, 0, 0, False, '2005-02-09 10:00:00'); /* Door */
/* @teleloc 0x0371013F [40.000000 -35.250000 -6.000000] 1.000000 0.000000 0.000000 0.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7037102B,  9686, 0x03710143, 50.0363, -5.60014, -4.3, -0.999965, 0, 0, -0.008404,  True, '2005-02-09 10:00:00'); /* Wall Hook */
/* @teleloc 0x03710143 [50.036301 -5.600140 -4.300000] -0.999965 0.000000 0.000000 -0.008404 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7037102C, 11697, 0x03710143, 49.8641, -14.2823, -5.995, 0.020795, 0, 0, -0.999784,  True, '2005-02-09 10:00:00'); /* Floor Hook */
/* @teleloc 0x03710143 [49.864101 -14.282300 -5.995000] 0.020795 0.000000 0.000000 -0.999784 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7037102D, 11697, 0x03710146, 54.2191, -30.1795, -5.995, 0.714421, 0, 0, -0.699716,  True, '2005-02-09 10:00:00'); /* Floor Hook */
/* @teleloc 0x03710146 [54.219101 -30.179501 -5.995000] 0.714421 0.000000 0.000000 -0.699716 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7037102E,  9686, 0x03710146, 45.6057, -29.9906, -4.3, -0.714424, 0, 0, -0.699713,  True, '2005-02-09 10:00:00'); /* Wall Hook */
/* @teleloc 0x03710146 [45.605701 -29.990601 -4.300000] -0.714424 0.000000 0.000000 -0.699713 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7037102F, 11697, 0x03710146, 45.8836, -30.0443, -5.995, -0.707107, 0, 0, -0.707107,  True, '2005-02-09 10:00:00'); /* Floor Hook */
/* @teleloc 0x03710146 [45.883598 -30.044300 -5.995000] -0.707107 0.000000 0.000000 -0.707107 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70371030,  9687, 0x03710146, 53.6645, -33.6611, -5.674, 0.422618, 0, 0, -0.906308,  True, '2005-02-09 10:00:00'); /* Storage */
/* @teleloc 0x03710146 [53.664501 -33.661098 -5.674000] 0.422618 0.000000 0.000000 -0.906308 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70371031,  9687, 0x03710146, 52.4107, -26.2337, -5.674, 1, 0, 0, 0,  True, '2005-02-09 10:00:00'); /* Storage */
/* @teleloc 0x03710146 [52.410702 -26.233700 -5.674000] 1.000000 0.000000 0.000000 0.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70371032,  9687, 0x03710146, 50.0166, -26.2337, -5.674, 1, 0, 0, 0,  True, '2005-02-09 10:00:00'); /* Storage */
/* @teleloc 0x03710146 [50.016602 -26.233700 -5.674000] 1.000000 0.000000 0.000000 0.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70371033,  9687, 0x03710146, 47.4754, -26.2338, -5.674, 1, 0, 0, 0,  True, '2005-02-09 10:00:00'); /* Storage */
/* @teleloc 0x03710146 [47.475399 -26.233801 -5.674000] 1.000000 0.000000 0.000000 0.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70371034,  9687, 0x03710146, 46.6099, -33.6215, -5.674, -0.34202, 0, 0, -0.939693,  True, '2005-02-09 10:00:00'); /* Storage */
/* @teleloc 0x03710146 [46.609901 -33.621498 -5.674000] -0.342020 0.000000 0.000000 -0.939693 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70371035,  9686, 0x03710149, 49.5906, -44.3976, -4.3, -0.020794, 0, 0, -0.999784,  True, '2005-02-09 10:00:00'); /* Wall Hook */
/* @teleloc 0x03710149 [49.590599 -44.397598 -4.300000] -0.020794 0.000000 0.000000 -0.999784 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70371036,   278, 0x0371014C, 54.75, -40, -6, 0.707107, 0, 0, -0.707107, False, '2005-02-09 10:00:00'); /* Door */
/* @teleloc 0x0371014C [54.750000 -40.000000 -6.000000] 0.707107 0.000000 0.000000 -0.707107 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70371037, 11730, 0x0371014E, 50, -50, -5.995, -0.68921, 0, 0, -0.724561,  True, '2005-02-09 10:00:00'); /* House Portal */
/* @teleloc 0x0371014E [50.000000 -50.000000 -5.995000] -0.689210 0.000000 0.000000 -0.724561 */

INSERT INTO `landblock_instance_link` (`parent_GUID`, `child_GUID`, `last_Modified`)
VALUES (0x70371037, 0x70371042, '2005-02-09 10:00:00') /* Portal Linkspot (10762) */;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70371038,   568, 0x03710150, 45.25, -50, -6, -0.707107, 0, 0, -0.707107, False, '2005-02-09 10:00:00'); /* Door */
/* @teleloc 0x03710150 [45.250000 -50.000000 -6.000000] -0.707107 0.000000 0.000000 -0.707107 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70371039,  9686, 0x03710157, 10.3637, -19.7886, 1.7, -0.92106, 0, 0, -0.389421,  True, '2005-02-09 10:00:00'); /* Wall Hook */
/* @teleloc 0x03710157 [10.363700 -19.788601 1.700000] -0.921060 0.000000 0.000000 -0.389421 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7037103A, 11697, 0x03710157, 13.6471, -16.8528, 0.005, 0.935366, 0, 0, 0.353681,  True, '2005-02-09 10:00:00'); /* Floor Hook */
/* @teleloc 0x03710157 [13.647100 -16.852800 0.005000] 0.935366 0.000000 0.000000 0.353681 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7037103B,  9686, 0x03710167, 20.0282, -49.8498, 1.7, -0.412819, 0, 0, -0.910813,  True, '2005-02-09 10:00:00'); /* Wall Hook */
/* @teleloc 0x03710167 [20.028200 -49.849800 1.700000] -0.412819 0.000000 0.000000 -0.910813 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7037103C, 11697, 0x03710168, 29.8589, -5.50464, 0.005, 0.999978, 0, 0, 0.006608,  True, '2005-02-09 10:00:00'); /* Floor Hook */
/* @teleloc 0x03710168 [29.858900 -5.504640 0.005000] 0.999978 0.000000 0.000000 0.006608 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7037103D, 11697, 0x0371016C, 29.9232, -54.518, 0.005, -0.00316, 0, 0, 0.999995,  True, '2005-02-09 10:00:00'); /* Floor Hook */
/* @teleloc 0x0371016C [29.923201 -54.518002 0.005000] -0.003160 0.000000 0.000000 0.999995 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7037103E,  9686, 0x0371016D, 39.8922, -10.0338, 1.7, 0.92106, 0, 0, -0.389421,  True, '2005-02-09 10:00:00'); /* Wall Hook */
/* @teleloc 0x0371016D [39.892200 -10.033800 1.700000] 0.921060 0.000000 0.000000 -0.389421 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7037103F, 11697, 0x0371016D, 39.8367, -10.1527, 0.005, 0.921061, 0, 0, -0.389418,  True, '2005-02-09 10:00:00'); /* Floor Hook */
/* @teleloc 0x0371016D [39.836700 -10.152700 0.005000] 0.921061 0.000000 0.000000 -0.389418 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70371040,  9686, 0x0371017D, 49.7629, -40.0938, 1.7, 0.417471, 0, 0, -0.90869,  True, '2005-02-09 10:00:00'); /* Wall Hook */
/* @teleloc 0x0371017D [49.762901 -40.093800 1.700000] 0.417471 0.000000 0.000000 -0.908690 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70371041, 11697, 0x0371017D, 46.3127, -43.0913, 0.005, -0.370586, 0, 0, 0.928798,  True, '2005-02-09 10:00:00'); /* Floor Hook */
/* @teleloc 0x0371017D [46.312698 -43.091301 0.005000] -0.370586 0.000000 0.000000 0.928798 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70371042, 10762, 0x0371014E, 66.5564, 151.044, -9.995, -0.6978, 0, 0, 0.716293,  True, '2005-02-09 10:00:00'); /* Portal Linkspot */
/* @teleloc 0x0371014E [66.556396 151.044006 -9.995000] -0.697800 0.000000 0.000000 0.716293 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70371043,  9687, 0x03710146, 54.01954, -29.7501, -5.945, 0.705832, 0, 0, 0.708379, False, '2025-08-21 15:53:06'); /* Storage */
/* @teleloc 0x03710146 [54.019539 -29.750099 -5.945000] 0.705832 0.000000 0.000000 0.708379 */
