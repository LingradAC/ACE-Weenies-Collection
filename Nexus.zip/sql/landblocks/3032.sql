DELETE FROM `landblock_instance` WHERE `landblock` = 0x3032;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x73032078,  7924, 0x30320014, 62.2826, 73.5039, 132.029, 0.924278, 0, 0, -0.381721, False, '2021-11-01 00:00:00'); /* Linkable Monster Generator ( 5 Min.) */
/* @teleloc 0x30320014 [62.282600 73.503899 132.029007] 0.924278 0.000000 0.000000 -0.381721 */
