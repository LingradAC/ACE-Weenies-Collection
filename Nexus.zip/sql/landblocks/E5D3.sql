DELETE FROM `landblock_instance` WHERE `landblock` = 0xE5D3;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E5D3000, 43583, 0xE5D30143, 60.1413, 165.061, 192.337, -0.999504, 0, 0, -0.031501, False, '2021-11-01 00:00:00'); /* Queen's Burrow */
/* @teleloc 0xE5D30143 [60.141300 165.061005 192.337006] -0.999504 0.000000 0.000000 -0.031501 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E5D3001, 43584, 0xE5D3013F, 84.0236, 116.444, 192.337, -0.999999, 0, 0, 0.001304, False, '2021-11-01 00:00:00'); /* Queen's Burrow */
/* @teleloc 0xE5D3013F [84.023598 116.444000 192.337006] -0.999999 0.000000 0.000000 0.001304 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E5D3002, 4200152, 0xE5D30004, 21.3298, 93.1563, -0.045, -0.417402, 0, 0, 0.908722, False, '2025-07-19 10:30:01'); /* Gate */
/* @teleloc 0xE5D30004 [21.329800 93.156303 -0.045000] -0.417402 0.000000 0.000000 0.908722 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E5D3003, 4200152, 0xE5D30004, 8.68618, 74.8437, -0.395, -0.535432, 0, 0, 0.844578, False, '2025-07-19 10:30:16'); /* Gate */
/* @teleloc 0xE5D30004 [8.686180 74.843697 -0.395000] -0.535432 0.000000 0.000000 0.844578 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E5D3004, 4200152, 0xE5D30003, 3.06555, 57.5517, -0.845, -0.750959, 0, 0, 0.660349, False, '2025-07-19 10:30:23'); /* Gate */
/* @teleloc 0xE5D30003 [3.065550 57.551701 -0.845000] -0.750959 0.000000 0.000000 0.660349 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E5D3005, 4200152, 0xE5D30002, 7.27405, 38.687, -0.845, -0.737866, 0, 0, 0.674947, False, '2025-07-19 10:30:31'); /* Gate */
/* @teleloc 0xE5D30002 [7.274050 38.687000 -0.845000] -0.737866 0.000000 0.000000 0.674947 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E5D3006, 4200152, 0xE5D30001, 8.86056, 20.6256, -0.845, -0.748044, 0, 0, 0.663649, False, '2025-07-19 10:30:35'); /* Gate */
/* @teleloc 0xE5D30001 [8.860560 20.625601 -0.845000] -0.748044 0.000000 0.000000 0.663649 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E5D3007, 4200152, 0xE5D30001, 12.257, 3.99743, -0.845, -0.832494, 0, 0, 0.554033, False, '2025-07-19 10:30:43'); /* Gate */
/* @teleloc 0xE5D30001 [12.257000 3.997430 -0.845000] -0.832494 0.000000 0.000000 0.554033 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E5D3008, 7002199, 0xE5D30004, 15.71384, 95.14321, -0.045, 0.792068, 0, 0, -0.610433, False, '2025-08-24 14:19:08');
/* @teleloc 0xE5D30004 [15.713840 95.143211 -0.045000] 0.792068 0.000000 0.000000 -0.610433 */
