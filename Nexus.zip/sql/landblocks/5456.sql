DELETE FROM `landblock_instance` WHERE `landblock` = 0x5456;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x75456000, 12701, 0x54560100, 126.426, -101.115, -42, 0.732954, 0, 0, -0.680278,  True, '2005-02-09 10:00:00'); /* Tunnelling Grievver */
/* @teleloc 0x54560100 [126.426003 -101.114998 -42.000000] 0.732954 0.000000 0.000000 -0.680278 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x75456001, 12701, 0x54560100, 126.415, -98.889, -42, 0.715719, 0, 0, -0.698388,  True, '2005-02-09 10:00:00'); /* Tunnelling Grievver */
/* @teleloc 0x54560100 [126.415001 -98.889000 -42.000000] 0.715719 0.000000 0.000000 -0.698388 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x75456002, 32950, 0x54560101, 83.0882, -93.24, -36, 0.664305, 0, 0, 0.747462,  True, '2005-02-09 10:00:00'); /* Child of Lightning */
/* @teleloc 0x54560101 [83.088203 -93.239998 -36.000000] 0.664305 0.000000 0.000000 0.747462 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x75456003, 32950, 0x54560102, 82.8804, -98.0609, -35.995, 0.757872, 0, 0, 0.652403,  True, '2005-02-09 10:00:00'); /* Child of Lightning */
/* @teleloc 0x54560102 [82.880402 -98.060898 -35.994999] 0.757872 0.000000 0.000000 0.652403 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x75456004, 32950, 0x54560103, 92.2921, -83.1227, -35.995, -0.99776, 0, 0, 0.06689,  True, '2005-02-09 10:00:00'); /* Child of Lightning */
/* @teleloc 0x54560103 [92.292099 -83.122704 -35.994999] -0.997760 0.000000 0.000000 0.066890 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x75456006, 51352, 0x54560105, 93.3894, -97.8052, -35.995, 0.771085, 0, 0, 0.636733,  True, '2005-02-09 10:00:00'); /* Freezing Wind */
/* @teleloc 0x54560105 [93.389397 -97.805199 -35.994999] 0.771085 0.000000 0.000000 0.636733 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x75456008, 20018, 0x54560106, 90.3849, -109.765, -35.9745, 1, 0, 0, 0, False, '2005-02-09 10:00:00'); /* Scuttling Grievver Pit Hotspot */
/* @teleloc 0x54560106 [90.384903 -109.764999 -35.974499] 1.000000 0.000000 0.000000 0.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x75456009, 32950, 0x54560107, 97.3944, -82.5687, -35.995, -0.989734, 0, 0, -0.14292,  True, '2005-02-09 10:00:00'); /* Child of Lightning */
/* @teleloc 0x54560107 [97.394402 -82.568703 -35.994999] -0.989734 0.000000 0.000000 -0.142920 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7545600B, 51352, 0x54560108, 103, -91.9958, -35.995, 0.929337, 0, 0, 0.369232,  True, '2005-02-09 10:00:00'); /* Freezing Wind */
/* @teleloc 0x54560108 [103.000000 -91.995796 -35.994999] 0.929337 0.000000 0.000000 0.369232 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7545600F, 20032, 0x54560109, 100, -100, -35.995, 1, 0, 0, 0, False, '2005-02-09 10:00:00'); /* Scuttling Grievver Gen B */
/* @teleloc 0x54560109 [100.000000 -100.000000 -35.994999] 1.000000 0.000000 0.000000 0.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x75456011, 20018, 0x5456010A, 100, -109.949, -35.8646, 1, 0, 0, 0, False, '2005-02-09 10:00:00'); /* Scuttling Grievver Pit Hotspot */
/* @teleloc 0x5456010A [100.000000 -109.948997 -35.864601] 1.000000 0.000000 0.000000 0.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x75456012, 20018, 0x5456010B, 109.615, -90.2345, -35.9745, 1, 0, 0, 0, False, '2005-02-09 10:00:00'); /* Scuttling Grievver Pit Hotspot */
/* @teleloc 0x5456010B [109.614998 -90.234497 -35.974499] 1.000000 0.000000 0.000000 0.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x75456015, 20018, 0x5456010E, 109.615, -109.765, -35.9745, 1, 0, 0, 0, False, '2005-02-09 10:00:00'); /* Scuttling Grievver Pit Hotspot */
/* @teleloc 0x5456010E [109.614998 -109.764999 -35.974499] 1.000000 0.000000 0.000000 0.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x75456016, 12701, 0x5456010F, 123.924, -99.8711, -41.2631, 0.698038, 0, 0, -0.716061,  True, '2005-02-09 10:00:00'); /* Tunnelling Grievver */
/* @teleloc 0x5456010F [123.924004 -99.871101 -41.263100] 0.698038 0.000000 0.000000 -0.716061 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x75456017, 51352, 0x54560116, 29.822, -78.2392, -29.995, 0.995988, 0, 0, -0.089489,  True, '2005-02-09 10:00:00'); /* Freezing Wind */
/* @teleloc 0x54560116 [29.822001 -78.239197 -29.995001] 0.995988 0.000000 0.000000 -0.089489 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x75456018, 51352, 0x54560118, 26.1558, -80.3126, -29.995, 0.85791, 0, 0, -0.5138,  True, '2005-02-09 10:00:00'); /* Freezing Wind */
/* @teleloc 0x54560118 [26.155800 -80.312599 -29.995001] 0.857910 0.000000 0.000000 -0.513800 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7545601A, 51352, 0x5456011E, 47.9849, -84.1241, -29.995, -0.559382, 0, 0, -0.82891,  True, '2005-02-09 10:00:00'); /* Freezing Wind */
/* @teleloc 0x5456011E [47.984901 -84.124100 -29.995001] -0.559382 0.000000 0.000000 -0.828910 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7545601C, 51352, 0x54560120, 46.6246, -97.1854, -29.995, -0.905917, 0, 0, -0.423456,  True, '2005-02-09 10:00:00'); /* Freezing Wind */
/* @teleloc 0x54560120 [46.624599 -97.185402 -29.995001] -0.905917 0.000000 0.000000 -0.423456 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7545601F, 51352, 0x54560129, 77.5718, -29.9072, -29.995, 0.692186, 0, 0, 0.721719,  True, '2005-02-09 10:00:00'); /* Freezing Wind */
/* @teleloc 0x54560129 [77.571800 -29.907200 -29.995001] 0.692186 0.000000 0.000000 0.721719 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x75456020, 51352, 0x54560129, 79.9996, -27.2913, -29.995, 0.555957, 0, 0, 0.831211,  True, '2005-02-09 10:00:00'); /* Freezing Wind */
/* @teleloc 0x54560129 [79.999603 -27.291300 -29.995001] 0.555957 0.000000 0.000000 0.831211 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x75456021, 51352, 0x5456012D, 83.0323, -46.7759, -29.995, -0.947953, 0, 0, 0.318409,  True, '2005-02-09 10:00:00'); /* Freezing Wind */
/* @teleloc 0x5456012D [83.032303 -46.775902 -29.995001] -0.947953 0.000000 0.000000 0.318409 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x75456026, 51352, 0x5456013C, 95.7335, -47.166, -29.995, 0.98205, 0, 0, 0.188623,  True, '2005-02-09 10:00:00'); /* Freezing Wind */
/* @teleloc 0x5456013C [95.733498 -47.166000 -29.995001] 0.982050 0.000000 0.000000 0.188623 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x75456027, 5727411, 0x54560109, 99.8107, -99.7146, -36, -0.926734, 0, 0, -0.375719,  True, '2005-02-09 10:00:00'); /* Shimmering Elemental */
/* @teleloc 0x54560109 [99.810699 -99.714600 -36.000000] -0.926734 0.000000 0.000000 -0.375719 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x75456028, 51352, 0x5456015A, 22.5702, -21.342, -24, 0.384906, 0, 0, -0.922956,  True, '2005-02-09 10:00:00'); /* Freezing Wind */
/* @teleloc 0x5456015A [22.570200 -21.341999 -24.000000] 0.384906 0.000000 0.000000 -0.922956 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x75456029, 20017, 0x54560154, 10.3314, -48.2887, -23.9915, -0.966925, 0, 0, -0.255061,  True, '2005-02-09 10:00:00'); /* Cocooned Auroch */
/* @teleloc 0x54560154 [10.331400 -48.288700 -23.991501] -0.966925 0.000000 0.000000 -0.255061 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7545602C, 32950, 0x5456015B, 21.0388, -32.7772, -24, -0.875304, 0, 0, 0.483573,  True, '2005-02-09 10:00:00'); /* Child of Lightning */
/* @teleloc 0x5456015B [21.038799 -32.777199 -24.000000] -0.875304 0.000000 0.000000 0.483573 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7545602D, 51352, 0x5456015C, 22.9447, -39.0488, -24, 0.428039, 0, 0, 0.90376,  True, '2005-02-09 10:00:00'); /* Freezing Wind */
/* @teleloc 0x5456015C [22.944700 -39.048801 -24.000000] 0.428039 0.000000 0.000000 0.903760 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7545602F, 32950, 0x54560163, 31.2592, -21.1379, -24, 0.027307, 0, 0, -0.999627,  True, '2005-02-09 10:00:00'); /* Child of Lightning */
/* @teleloc 0x54560163 [31.259199 -21.137899 -24.000000] 0.027307 0.000000 0.000000 -0.999627 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x75456030, 32950, 0x54560172, 35.0474, -37.0505, -24, -0.959719, 0, 0, -0.28096,  True, '2005-02-09 10:00:00'); /* Child of Lightning */
/* @teleloc 0x54560172 [35.047401 -37.050499 -24.000000] -0.959719 0.000000 0.000000 -0.280960 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x75456031, 51352, 0x54560170, 38.6517, -23.3586, -24, 0.930038, 0, 0, -0.367464,  True, '2005-02-09 10:00:00'); /* Freezing Wind */
/* @teleloc 0x54560170 [38.651699 -23.358601 -24.000000] 0.930038 0.000000 0.000000 -0.367464 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x75456036, 51352, 0x54560171, 39.6251, -34.6869, -24, -0.846344, 0, 0, -0.532636,  True, '2005-02-09 10:00:00'); /* Freezing Wind */
/* @teleloc 0x54560171 [39.625099 -34.686901 -24.000000] -0.846344 0.000000 0.000000 -0.532636 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x75456037, 51352, 0x545601A8, 2.60295, -69.6382, -17.995, -0.627602, 0, 0, 0.778535,  True, '2005-02-09 10:00:00'); /* Freezing Wind */
/* @teleloc 0x545601A8 [2.602950 -69.638199 -17.995001] -0.627602 0.000000 0.000000 0.778535 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x75456038, 51352, 0x545601AA, -0.765593, -66.5006, -17.995, -0.273635, 0, 0, 0.961834,  True, '2005-02-09 10:00:00'); /* Freezing Wind */
/* @teleloc 0x545601AA [-0.765593 -66.500603 -17.995001] -0.273635 0.000000 0.000000 0.961834 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7545603A, 51352, 0x545601C6, 69.3667, -1.44272, -17.995, 0.033703, 0, 0, -0.999432,  True, '2005-02-09 10:00:00'); /* Freezing Wind */
/* @teleloc 0x545601C6 [69.366699 -1.442720 -17.995001] 0.033703 0.000000 0.000000 -0.999432 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7545603B, 51352, 0x545601C7, 65.1956, 0.335026, -17.995, -0.529649, 0, 0, 0.848217,  True, '2005-02-09 10:00:00'); /* Freezing Wind */
/* @teleloc 0x545601C7 [65.195602 0.335026 -17.995001] -0.529649 0.000000 0.000000 0.848217 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7545603C, 51352, 0x545601C9, 89.5479, -52.7132, -17.995, -0.038455, 0, 0, 0.99926,  True, '2005-02-09 10:00:00'); /* Freezing Wind */
/* @teleloc 0x545601C9 [89.547897 -52.713200 -17.995001] -0.038455 0.000000 0.000000 0.999260 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7545603D, 32950, 0x545601CC, 89.8185, -60.3135, -17.995, -0.034236, 0, 0, 0.999414,  True, '2005-02-09 10:00:00'); /* Child of Lightning */
/* @teleloc 0x545601CC [89.818497 -60.313499 -17.995001] -0.034236 0.000000 0.000000 0.999414 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7545603E, 51352, 0x545601CD, 90.2351, -68.5049, -17.995, 0.496365, 0, 0, -0.868114,  True, '2005-02-09 10:00:00'); /* Freezing Wind */
/* @teleloc 0x545601CD [90.235100 -68.504898 -17.995001] 0.496365 0.000000 0.000000 -0.868114 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x75456041, 51352, 0x545601D2, 109.207, -54.0442, -17.995, -0.980355, 0, 0, 0.19724,  True, '2005-02-09 10:00:00'); /* Freezing Wind */
/* @teleloc 0x545601D2 [109.207001 -54.044201 -17.995001] -0.980355 0.000000 0.000000 0.197240 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x75456042, 51352, 0x545601D3, 113.328, -50.381, -17.995, -0.731378, 0, 0, 0.681972,  True, '2005-02-09 10:00:00'); /* Freezing Wind */
/* @teleloc 0x545601D3 [113.328003 -50.381001 -17.995001] -0.731378 0.000000 0.000000 0.681972 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x75456043, 51352, 0x545601D4, 108.211, -59.9311, -17.995, 0.947089, 0, 0, -0.320971,  True, '2005-02-09 10:00:00'); /* Freezing Wind */
/* @teleloc 0x545601D4 [108.210999 -59.931099 -17.995001] 0.947089 0.000000 0.000000 -0.320971 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x75456044, 51352, 0x545601D4, 110.271, -57.4736, -18, -0.999903, 0, 0, 0.013898,  True, '2005-02-09 10:00:00'); /* Freezing Wind */
/* @teleloc 0x545601D4 [110.271004 -57.473598 -18.000000] -0.999903 0.000000 0.000000 0.013898 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x75456045, 51352, 0x545601D9, 120.772, -70.2396, -17.995, 0.890658, 0, 0, 0.454674,  True, '2005-02-09 10:00:00'); /* Freezing Wind */
/* @teleloc 0x545601D9 [120.772003 -70.239601 -17.995001] 0.890658 0.000000 0.000000 0.454674 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x75456047, 51352, 0x545601F6, 142.081, -60.1214, -18, 0.695537, 0, 0, -0.718491,  True, '2005-02-09 10:00:00'); /* Freezing Wind */
/* @teleloc 0x545601F6 [142.080994 -60.121399 -18.000000] 0.695537 0.000000 0.000000 -0.718491 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x75456049, 51352, 0x545601F7, 141.594, -70.6784, -17.995, -0.754017, 0, 0, -0.656854,  True, '2005-02-09 10:00:00'); /* Freezing Wind */
/* @teleloc 0x545601F7 [141.593994 -70.678398 -17.995001] -0.754017 0.000000 0.000000 -0.656854 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7545604B, 51352, 0x54560200, 140.007, -85.4996, -17.995, -0.998509, 0, 0, -0.054588,  True, '2005-02-09 10:00:00'); /* Freezing Wind */
/* @teleloc 0x54560200 [140.007004 -85.499603 -17.995001] -0.998509 0.000000 0.000000 -0.054588 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7545604C, 51352, 0x54560204, 149.381, -58.1466, -17.995, -0.991567, 0, 0, -0.129593,  True, '2005-02-09 10:00:00'); /* Freezing Wind */
/* @teleloc 0x54560204 [149.380997 -58.146599 -17.995001] -0.991567 0.000000 0.000000 -0.129593 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7545604E, 51352, 0x5456020B, 150.003, -80.4014, -17.995, 0.856377, 0, 0, 0.516351,  True, '2005-02-09 10:00:00'); /* Freezing Wind */
/* @teleloc 0x5456020B [150.003006 -80.401398 -17.995001] 0.856377 0.000000 0.000000 0.516351 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x75456051, 32950, 0x54560214, 158.299, -70.1545, -17.995, 0.47213, 0, 0, 0.881529,  True, '2005-02-09 10:00:00'); /* Child of Lightning */
/* @teleloc 0x54560214 [158.298996 -70.154503 -17.995001] 0.472130 0.000000 0.000000 0.881529 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x75456055, 19459, 0x5456021C, 32.3773, -32.5239, -8.34863, 0.99891, 0, 0, -0.04667, False, '2005-02-09 10:00:00'); /* Apple Generator */
/* @teleloc 0x5456021C [32.377300 -32.523899 -8.348630] 0.998910 0.000000 0.000000 -0.046670 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x75456056, 19459, 0x5456021C, 27.3776, -32.8278, -8.1953, -0.985791, 0, 0, 0.167975, False, '2005-02-09 10:00:00'); /* Apple Generator */
/* @teleloc 0x5456021C [27.377600 -32.827801 -8.195300] -0.985791 0.000000 0.000000 0.167975 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x75456059, 19459, 0x5456021C, 32.1002, -27.9906, -8.35619, -0.3153, 0, 0, -0.948992, False, '2005-02-09 10:00:00'); /* Apple Generator */
/* @teleloc 0x5456021C [32.100201 -27.990601 -8.356190] -0.315300 0.000000 0.000000 -0.948992 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7545605C, 19459, 0x5456021C, 27.5333, -28.4117, -8.34863, -0.391032, 0, 0, -0.920377, False, '2005-02-09 10:00:00'); /* Apple Generator */
/* @teleloc 0x5456021C [27.533300 -28.411699 -8.348630] -0.391032 0.000000 0.000000 -0.920377 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7545605E, 51352, 0x5456021E, 70.6169, -69.9512, -11.995, 0.734559, 0, 0, 0.678545,  True, '2005-02-09 10:00:00'); /* Freezing Wind */
/* @teleloc 0x5456021E [70.616898 -69.951202 -11.995000] 0.734559 0.000000 0.000000 0.678545 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x75456060, 32950, 0x54560220, 81.2663, -60.3845, -12, 0.383338, 0, 0, -0.923608,  True, '2005-02-09 10:00:00'); /* Child of Lightning */
/* @teleloc 0x54560220 [81.266296 -60.384499 -12.000000] 0.383338 0.000000 0.000000 -0.923608 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x75456061, 51352, 0x54560226, 93.1351, -60.1942, -12, 0.690165, 0, 0, -0.723652,  True, '2005-02-09 10:00:00'); /* Freezing Wind */
/* @teleloc 0x54560226 [93.135101 -60.194199 -12.000000] 0.690165 0.000000 0.000000 -0.723652 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x75456062, 51352, 0x5456022B, 110.972, -39.2494, -11.995, -0.99508, 0, 0, -0.099073,  True, '2005-02-09 10:00:00'); /* Freezing Wind */
/* @teleloc 0x5456022B [110.972000 -39.249401 -11.995000] -0.995080 0.000000 0.000000 -0.099073 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x75456066, 32950, 0x54560233, 130.031, -24.3744, -12, 0.013469, 0, 0, -0.999909,  True, '2005-02-09 10:00:00'); /* Child of Lightning */
/* @teleloc 0x54560233 [130.031006 -24.374399 -12.000000] 0.013469 0.000000 0.000000 -0.999909 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x75456069, 51352, 0x54560236, 129.73, -54.4292, -11.995, -0.998582, 0, 0, 0.053227,  True, '2005-02-09 10:00:00'); /* Freezing Wind */
/* @teleloc 0x54560236 [129.729996 -54.429199 -11.995000] -0.998582 0.000000 0.000000 0.053227 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7545606A, 51352, 0x5456023C, 137.498, -49.8345, -11.995, -0.965635, 0, 0, -0.259901,  True, '2005-02-09 10:00:00'); /* Freezing Wind */
/* @teleloc 0x5456023C [137.498001 -49.834499 -11.995000] -0.965635 0.000000 0.000000 -0.259901 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7545606B, 20031, 0x54560246, 10, -10, -5.995, 0.714421, 0, 0, -0.699716, False, '2005-02-09 10:00:00'); /* Scuttling Grievver Gen A */
/* @teleloc 0x54560246 [10.000000 -10.000000 -5.995000] 0.714421 0.000000 0.000000 -0.699716 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7545606F, 19474, 0x54560251, 19.803, -39.6489, -5.91981, 0.911039, 0, 0, -0.41232, False, '2005-02-09 10:00:00'); /* Scuttling Sound Hotspot */
/* @teleloc 0x54560251 [19.802999 -39.648899 -5.919810] 0.911039 0.000000 0.000000 -0.412320 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x75456070, 51352, 0x54560252, 16.3631, -69.8389, -11.0805, 0.704906, 0, 0, -0.709301,  True, '2005-02-09 10:00:00'); /* Freezing Wind */
/* @teleloc 0x54560252 [16.363100 -69.838898 -11.080500] 0.704906 0.000000 0.000000 -0.709301 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x75456071, 19474, 0x54560254, 28.6445, -24.6274, -6, 0.911039, 0, 0, -0.41232, False, '2005-02-09 10:00:00'); /* Scuttling Sound Hotspot */
/* @teleloc 0x54560254 [28.644501 -24.627399 -6.000000] 0.911039 0.000000 0.000000 -0.412320 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x75456073, 51352, 0x54560256, 30.3406, -36.8514, -6, -0.576773, 0, 0, 0.816904,  True, '2005-02-09 10:00:00'); /* Freezing Wind */
/* @teleloc 0x54560256 [30.340599 -36.851398 -6.000000] -0.576773 0.000000 0.000000 0.816904 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x75456074, 51352, 0x54560257, 32.1357, -61.7686, -6, -0.436701, 0, 0, 0.899607,  True, '2005-02-09 10:00:00'); /* Freezing Wind */
/* @teleloc 0x54560257 [32.135700 -61.768600 -6.000000] -0.436701 0.000000 0.000000 0.899607 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x75456078, 20017, 0x5456025E, 40.4302, -22.6676, -5.9915, -0.948399, 0, 0, -0.317079,  True, '2005-02-09 10:00:00'); /* Cocooned Auroch */
/* @teleloc 0x5456025E [40.430199 -22.667601 -5.991500] -0.948399 0.000000 0.000000 -0.317079 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7545607A, 32950, 0x54560260, 36.7396, -38.3907, -5.995, 0.561542, 0, 0, -0.827448,  True, '2005-02-09 10:00:00'); /* Child of Lightning */
/* @teleloc 0x54560260 [36.739601 -38.390701 -5.995000] 0.561542 0.000000 0.000000 -0.827448 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7545607D, 51352, 0x54560265, 50.1115, -51.8621, -6, -0.284885, 0, 0, 0.958562,  True, '2005-02-09 10:00:00'); /* Freezing Wind */
/* @teleloc 0x54560265 [50.111500 -51.862099 -6.000000] -0.284885 0.000000 0.000000 0.958562 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7545607F, 51352, 0x5456026C, 59.5962, -39.1486, -5.995, 0.337212, 0, 0, 0.941429,  True, '2005-02-09 10:00:00'); /* Freezing Wind */
/* @teleloc 0x5456026C [59.596199 -39.148602 -5.995000] 0.337212 0.000000 0.000000 0.941429 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x75456080, 51352, 0x5456026E, 56.1328, -47.9818, -5.995, 0.503615, 0, 0, -0.863928,  True, '2005-02-09 10:00:00'); /* Freezing Wind */
/* @teleloc 0x5456026E [56.132801 -47.981800 -5.995000] 0.503615 0.000000 0.000000 -0.863928 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x75456084, 51352, 0x54560276, 115.789, -30.1103, -11.4249, 0.688233, 0, 0, -0.72549,  True, '2005-02-09 10:00:00'); /* Freezing Wind */
/* @teleloc 0x54560276 [115.789001 -30.110300 -11.424900] 0.688233 0.000000 0.000000 -0.725490 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x75456085,  7923, 0x5456027A, 130, -30, -5.995, 0.731689, 0, 0, 0.681639, False, '2005-02-09 10:00:00'); /* Linkable Monster Generator ( 3 Min.) */
/* @teleloc 0x5456027A [130.000000 -30.000000 -5.995000] 0.731689 0.000000 0.000000 0.681639 */

INSERT INTO `landblock_instance_link` (`parent_GUID`, `child_GUID`, `last_Modified`)
VALUES (0x75456085, 0x75456002, '2005-02-09 10:00:00') /* Child of Lightning (32950) */
     , (0x75456085, 0x75456003, '2005-02-09 10:00:00') /* Child of Lightning (32950) */
     , (0x75456085, 0x75456004, '2005-02-09 10:00:00') /* Child of Lightning (32950) */
     , (0x75456085, 0x75456009, '2005-02-09 10:00:00') /* Child of Lightning (32950) */
     , (0x75456085, 0x75456017, '2005-02-09 10:00:00') /* Freezing Wind (51352) */
     , (0x75456085, 0x75456018, '2005-02-09 10:00:00') /* Freezing Wind (51352) */
     , (0x75456085, 0x7545602C, '2005-02-09 10:00:00') /* Child of Lightning (32950) */
     , (0x75456085, 0x7545602D, '2005-02-09 10:00:00') /* Freezing Wind (51352) */
     , (0x75456085, 0x7545602F, '2005-02-09 10:00:00') /* Child of Lightning (32950) */
     , (0x75456085, 0x75456030, '2005-02-09 10:00:00') /* Child of Lightning (32950) */
     , (0x75456085, 0x75456031, '2005-02-09 10:00:00') /* Freezing Wind (51352) */
     , (0x75456085, 0x7545603C, '2005-02-09 10:00:00') /* Freezing Wind (51352) */
     , (0x75456085, 0x7545603D, '2005-02-09 10:00:00') /* Child of Lightning (32950) */
     , (0x75456085, 0x7545603E, '2005-02-09 10:00:00') /* Freezing Wind (51352) */
     , (0x75456085, 0x75456041, '2005-02-09 10:00:00') /* Freezing Wind (51352) */
     , (0x75456085, 0x75456042, '2005-02-09 10:00:00') /* Freezing Wind (51352) */
     , (0x75456085, 0x75456047, '2005-02-09 10:00:00') /* Freezing Wind (51352) */
     , (0x75456085, 0x75456061, '2005-02-09 10:00:00') /* Freezing Wind (51352) */
     , (0x75456085, 0x75456066, '2005-02-09 10:00:00') /* Child of Lightning (32950) */
     , (0x75456085, 0x75456070, '2005-02-09 10:00:00') /* Freezing Wind (51352) */
     , (0x75456085, 0x75456073, '2005-02-09 10:00:00') /* Freezing Wind (51352) */
     , (0x75456085, 0x7545607A, '2005-02-09 10:00:00') /* Child of Lightning (32950) */
     , (0x75456085, 0x7545607D, '2005-02-09 10:00:00') /* Freezing Wind (51352) */
     , (0x75456085, 0x7545607F, '2005-02-09 10:00:00') /* Freezing Wind (51352) */
     , (0x75456085, 0x75456080, '2005-02-09 10:00:00') /* Freezing Wind (51352) */
     , (0x75456085, 0x75456084, '2005-02-09 10:00:00') /* Freezing Wind (51352) */;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x75456086,  7923, 0x5456027A, 130.835, -31.1851, -5.995, -0.077248, 0, 0, -0.997012, False, '2005-02-09 10:00:00'); /* Linkable Monster Generator ( 3 Min.) */
/* @teleloc 0x5456027A [130.835007 -31.185101 -5.995000] -0.077248 0.000000 0.000000 -0.997012 */

INSERT INTO `landblock_instance_link` (`parent_GUID`, `child_GUID`, `last_Modified`)
VALUES (0x75456086, 0x75456000, '2005-02-09 10:00:00') /* Tunnelling Grievver (12701) */
     , (0x75456086, 0x75456001, '2005-02-09 10:00:00') /* Tunnelling Grievver (12701) */
     , (0x75456086, 0x75456006, '2005-02-09 10:00:00') /* Freezing Wind (51352) */
     , (0x75456086, 0x7545600B, '2005-02-09 10:00:00') /* Freezing Wind (51352) */
     , (0x75456086, 0x75456016, '2005-02-09 10:00:00') /* Tunnelling Grievver (12701) */
     , (0x75456086, 0x7545601A, '2005-02-09 10:00:00') /* Freezing Wind (51352) */
     , (0x75456086, 0x7545601C, '2005-02-09 10:00:00') /* Freezing Wind (51352) */
     , (0x75456086, 0x7545601F, '2005-02-09 10:00:00') /* Freezing Wind (51352) */
     , (0x75456086, 0x75456020, '2005-02-09 10:00:00') /* Freezing Wind (51352) */
     , (0x75456086, 0x75456021, '2005-02-09 10:00:00') /* Freezing Wind (51352) */
     , (0x75456086, 0x75456026, '2005-02-09 10:00:00') /* Freezing Wind (51352) */
     , (0x75456086, 0x75456027, '2005-02-09 10:00:00') /* Shimmering Elemental (5727411) */
     , (0x75456086, 0x75456028, '2005-02-09 10:00:00') /* Freezing Wind (51352) */
     , (0x75456086, 0x75456029, '2005-02-09 10:00:00') /* Cocooned Auroch (20017) */
     , (0x75456086, 0x75456036, '2005-02-09 10:00:00') /* Freezing Wind (51352) */
     , (0x75456086, 0x75456037, '2005-02-09 10:00:00') /* Freezing Wind (51352) */
     , (0x75456086, 0x75456038, '2005-02-09 10:00:00') /* Freezing Wind (51352) */
     , (0x75456086, 0x7545603A, '2005-02-09 10:00:00') /* Freezing Wind (51352) */
     , (0x75456086, 0x7545603B, '2005-02-09 10:00:00') /* Freezing Wind (51352) */
     , (0x75456086, 0x75456043, '2005-02-09 10:00:00') /* Freezing Wind (51352) */
     , (0x75456086, 0x75456044, '2005-02-09 10:00:00') /* Freezing Wind (51352) */
     , (0x75456086, 0x75456045, '2005-02-09 10:00:00') /* Freezing Wind (51352) */
     , (0x75456086, 0x75456049, '2005-02-09 10:00:00') /* Freezing Wind (51352) */
     , (0x75456086, 0x7545604B, '2005-02-09 10:00:00') /* Freezing Wind (51352) */
     , (0x75456086, 0x7545604C, '2005-02-09 10:00:00') /* Freezing Wind (51352) */
     , (0x75456086, 0x7545604E, '2005-02-09 10:00:00') /* Freezing Wind (51352) */
     , (0x75456086, 0x75456051, '2005-02-09 10:00:00') /* Child of Lightning (32950) */
     , (0x75456086, 0x7545605E, '2005-02-09 10:00:00') /* Freezing Wind (51352) */
     , (0x75456086, 0x75456060, '2005-02-09 10:00:00') /* Child of Lightning (32950) */
     , (0x75456086, 0x75456062, '2005-02-09 10:00:00') /* Freezing Wind (51352) */
     , (0x75456086, 0x75456069, '2005-02-09 10:00:00') /* Freezing Wind (51352) */
     , (0x75456086, 0x7545606A, '2005-02-09 10:00:00') /* Freezing Wind (51352) */
     , (0x75456086, 0x75456074, '2005-02-09 10:00:00') /* Freezing Wind (51352) */
     , (0x75456086, 0x75456078, '2005-02-09 10:00:00') /* Cocooned Auroch (20017) */;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x75456088, 20643, 0x5456029F, 104.437, -20.014, 0.005, -0.696708, 0, 0, -0.717355, False, '2005-02-09 10:00:00'); /* Surface */
/* @teleloc 0x5456029F [104.436996 -20.014000 0.005000] -0.696708 0.000000 0.000000 -0.717355 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x75456089, 5721188, 0x54560101, 84, -86.3547, -33.678, 0.483155, 0, 0, -0.875535, False, '2025-07-25 00:34:02'); /* Prismatic Crystal */
/* @teleloc 0x54560101 [84.000000 -86.354698 -33.678001] 0.483155 0.000000 0.000000 -0.875535 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7545608A, 5721194, 0x5456010E, 105.609, -105.39, -35.86, -0.946117, 0, 0, -0.323826, False, '2025-07-25 00:49:34'); /* Prismatic Crystal */
/* @teleloc 0x5456010E [105.609001 -105.389999 -35.860001] -0.946117 0.000000 0.000000 -0.323826 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7545608B, 5721190, 0x54560106, 94.3391, -105.474, -35.91, 0.998191, 0, 0, -0.060132, False, '2025-07-25 00:56:01'); /* Prismatic Crystal */
/* @teleloc 0x54560106 [94.339104 -105.473999 -35.910000] 0.998191 0.000000 0.000000 -0.060132 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7545608C, 5721190, 0x54560108, 100.652, -93.4703, -35.91, -0.971096, 0, 0, -0.238691, False, '2025-07-25 00:56:48'); /* Prismatic Crystal */
/* @teleloc 0x54560108 [100.652000 -93.470299 -35.910000] -0.971096 0.000000 0.000000 -0.238691 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7545608D, 5721190, 0x54560165, 27.1934, -35.3631, -23.91, -0.887797, 0, 0, 0.460235, False, '2025-07-25 01:23:35'); /* Prismatic Crystal */
/* @teleloc 0x54560165 [27.193399 -35.363098 -23.910000] -0.887797 0.000000 0.000000 0.460235 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7545608E, 5721190, 0x54560164, 33.5308, -25.3184, -23.91, -0.572743, 0, 0, 0.819735, False, '2025-07-25 01:23:47'); /* Prismatic Crystal */
/* @teleloc 0x54560164 [33.530800 -25.318399 -23.910000] -0.572743 0.000000 0.000000 0.819735 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x75456090, 36177, 0x54560265, 46.8967, -46.8988, -6.00669, -0.043999, 0, 0, 0.999032, False, '2025-07-25 01:34:43'); /* Pillar of Lightning */
/* @teleloc 0x54560265 [46.896702 -46.898800 -6.006690] -0.043999 0.000000 0.000000 0.999032 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x75456091, 36177, 0x54560265, 48.4843, -51.1642, -6.00669, -0.849062, 0, 0, 0.528294, False, '2025-07-25 01:34:56'); /* Pillar of Lightning */
/* @teleloc 0x54560265 [48.484299 -51.164200 -6.006690] -0.849062 0.000000 0.000000 0.528294 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x75456092, 5721194, 0x54560262, 43.1581, -61.2213, -5.86, -0.515878, 0, 0, -0.856662, False, '2025-07-25 01:48:35'); /* Prismatic Crystal */
/* @teleloc 0x54560262 [43.158100 -61.221298 -5.860000] -0.515878 0.000000 0.000000 -0.856662 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x75456093, 5721194, 0x54560121, 58.3186, -81.9467, -29.86, 0.992573, 0, 0, -0.121649, False, '2025-07-25 01:48:57'); /* Prismatic Crystal */
/* @teleloc 0x54560121 [58.318600 -81.946701 -29.860001] 0.992573 0.000000 0.000000 -0.121649 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x75456094, 5721194, 0x54560120, 52.3756, -100.21, -29.6873, -0.840043, 0, 0, -0.54252, False, '2025-07-25 01:49:20'); /* Prismatic Crystal */
/* @teleloc 0x54560120 [52.375599 -100.209999 -29.687300] -0.840043 0.000000 0.000000 -0.542520 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x75456095, 5721194, 0x5456014E, 14.1947, -12.853, -23.86, -0.128714, 0, 0, -0.991682, False, '2025-07-25 01:49:54'); /* Prismatic Crystal */
/* @teleloc 0x5456014E [14.194700 -12.853000 -23.860001] -0.128714 0.000000 0.000000 -0.991682 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x75456096, 5721194, 0x54560181, 50.3189, -51.7875, -23.6221, 0.6149, 0, 0, -0.788605, False, '2025-07-25 01:50:05'); /* Prismatic Crystal */
/* @teleloc 0x54560181 [50.318901 -51.787498 -23.622101] 0.614900 0.000000 0.000000 -0.788605 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x75456098, 575712236, 0x5456027A, 130.11, -29.0857, -5.1675, 0.013468, 0, 0, 0.999909, False, '2025-07-26 23:07:42');
/* @teleloc 0x5456027A [130.110001 -29.085699 -5.167500] 0.013468 0.000000 0.000000 0.999909 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x75456099, 575712236, 0x5456012E, 81.1898, -58.7039, -29.1675, -0.33193, 0, 0, -0.943304, False, '2025-07-26 23:14:11');
/* @teleloc 0x5456012E [81.189796 -58.703899 -29.167500] -0.331930 0.000000 0.000000 -0.943304 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7545609A, 5742015, 0x54560164, 29.9608, -29.9808, -20.932, -0.780925, 0, 0, -0.624625, False, '2025-07-26 23:19:35');
/* @teleloc 0x54560164 [29.960800 -29.980801 -20.931999] -0.780925 0.000000 0.000000 -0.624625 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7545609B, 5742015, 0x545601A8, 0.130558, -70.6662, -18, 0.534332, 0, 0, 0.845275, False, '2025-07-26 23:20:39');
/* @teleloc 0x545601A8 [0.130558 -70.666199 -18.000000] 0.534332 0.000000 0.000000 0.845275 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7545609C, 5742015, 0x54560252, 23.6981, -68.1172, -6.64636, -0.808195, 0, 0, 0.588915, False, '2025-07-26 23:20:44');
/* @teleloc 0x54560252 [23.698099 -68.117203 -6.646360] -0.808195 0.000000 0.000000 0.588915 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7545609D, 5742015, 0x54560255, 30.0386, -29.952, -6, -0.989257, 0, 0, -0.146189, False, '2025-07-26 23:20:53');
/* @teleloc 0x54560255 [30.038601 -29.952000 -6.000000] -0.989257 0.000000 0.000000 -0.146189 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7545609E, 5742015, 0x5456025E, 40.4477, -24.3232, -5.76791, 0.999991, 0, 0, 0.004153, False, '2025-07-26 23:21:04');
/* @teleloc 0x5456025E [40.447701 -24.323200 -5.767910] 0.999991 0.000000 0.000000 0.004153 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7545609F, 5742015, 0x54560227, 95.9927, -58.1027, -12.4608, 0.836211, 0, 0, -0.548407, False, '2025-07-26 23:21:26');
/* @teleloc 0x54560227 [95.992699 -58.102699 -12.460800] 0.836211 0.000000 0.000000 -0.548407 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x754560A0, 5742015, 0x545601E0, 132.584, -42.4727, -18, 0.977773, 0, 0, -0.209669, False, '2025-07-26 23:21:30');
/* @teleloc 0x545601E0 [132.584000 -42.472698 -18.000000] 0.977773 0.000000 0.000000 -0.209669 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x754560A1, 5742015, 0x545601E0, 127.723, -36.5021, -18, 0.790929, 0, 0, 0.611908, False, '2025-07-26 23:21:33');
/* @teleloc 0x545601E0 [127.723000 -36.502102 -18.000000] 0.790929 0.000000 0.000000 0.611908 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x754560A2, 5742015, 0x5456022B, 109.72, -40.4856, -12, 0.788863, 0, 0, 0.614569, False, '2025-07-26 23:21:37');
/* @teleloc 0x5456022B [109.720001 -40.485600 -12.000000] 0.788863 0.000000 0.000000 0.614569 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x754560A3, 5742015, 0x5456027A, 129.872, -29.0177, -6, 0.870495, 0, 0, -0.492178, False, '2025-07-26 23:21:47');
/* @teleloc 0x5456027A [129.871994 -29.017700 -6.000000] 0.870495 0.000000 0.000000 -0.492178 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x754560A4, 5742015, 0x545601D4, 108.597, -61.1879, -18, -0.719058, 0, 0, -0.69495, False, '2025-07-26 23:22:23');
/* @teleloc 0x545601D4 [108.597000 -61.187901 -18.000000] -0.719058 0.000000 0.000000 -0.694950 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x754560A5, 5742015, 0x5456021E, 74.3748, -71.8943, -12, -0.553122, 0, 0, -0.8331, False, '2025-07-26 23:22:29');
/* @teleloc 0x5456021E [74.374802 -71.894302 -12.000000] -0.553122 0.000000 0.000000 -0.833100 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x754560A6, 5742015, 0x5456026A, 48.1069, -66.8743, -6, -0.984796, 0, 0, -0.173717, False, '2025-07-26 23:22:34');
/* @teleloc 0x5456026A [48.106899 -66.874298 -6.000000] -0.984796 0.000000 0.000000 -0.173717 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x754560A7, 5742015, 0x54560272, 68.1064, -26.2484, -6, -0.898526, 0, 0, -0.43892, False, '2025-07-26 23:22:43');
/* @teleloc 0x54560272 [68.106400 -26.248400 -6.000000] -0.898526 0.000000 0.000000 -0.438920 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x754560A8, 5742015, 0x54560274, 65.4895, -35.7435, -6, -0.186926, 0, 0, -0.982374, False, '2025-07-26 23:23:28');
/* @teleloc 0x54560274 [65.489502 -35.743500 -6.000000] -0.186926 0.000000 0.000000 -0.982374 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x754560A9, 575712236, 0x54560273, 65.4895, -35.7435, -5.1675, -0.186926, 0, 0, -0.982374, False, '2025-07-26 23:23:33');
/* @teleloc 0x54560273 [65.489502 -35.743500 -5.167500] -0.186926 0.000000 0.000000 -0.982374 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x754560AA, 575712236, 0x54560172, 39.7979, -38.4387, -23.1675, -0.061646, 0, 0, 0.998098, False, '2025-07-26 23:23:47');
/* @teleloc 0x54560172 [39.797901 -38.438702 -23.167500] -0.061646 0.000000 0.000000 0.998098 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x754560AB, 5742015, 0x54560172, 39.7979, -38.4387, -24, -0.061646, 0, 0, 0.998098, False, '2025-07-26 23:24:05');
/* @teleloc 0x54560172 [39.797901 -38.438702 -24.000000] -0.061646 0.000000 0.000000 0.998098 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x754560AC, 5742015, 0x54560113, 19.0171, -89.1051, -30, -0.13721, 0, 0, 0.990542, False, '2025-07-26 23:24:15');
/* @teleloc 0x54560113 [19.017099 -89.105103 -30.000000] -0.137210 0.000000 0.000000 0.990542 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x754560AD, 5742015, 0x54560122, 64.4132, -94.1551, -30, -0.61823, 0, 0, 0.785998, False, '2025-07-26 23:24:23');
/* @teleloc 0x54560122 [64.413200 -94.155098 -30.000000] -0.618230 0.000000 0.000000 0.785998 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x754560AE, 575712236, 0x54560122, 64.4132, -94.1551, -29.1675, -0.61823, 0, 0, 0.785998, False, '2025-07-26 23:24:28');
/* @teleloc 0x54560122 [64.413200 -94.155098 -29.167500] -0.618230 0.000000 0.000000 0.785998 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x754560AF, 575712236, 0x5456013E, 95.0435, -64.9522, -29.5368, -0.999991, 0, 0, -0.004329, False, '2025-07-26 23:24:50');
/* @teleloc 0x5456013E [95.043503 -64.952202 -29.536800] -0.999991 0.000000 0.000000 -0.004329 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x754560B0, 5742015, 0x5456013D, 95.0435, -64.9522, -30, -0.999991, 0, 0, -0.004329, False, '2025-07-26 23:25:04');
/* @teleloc 0x5456013D [95.043503 -64.952202 -30.000000] -0.999991 0.000000 0.000000 -0.004329 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x754560B1, 5742015, 0x5456012E, 81.0288, -59.1219, -30, -0.961505, 0, 0, 0.274787, False, '2025-07-26 23:25:11');
/* @teleloc 0x5456012E [81.028801 -59.121899 -30.000000] -0.961505 0.000000 0.000000 0.274787 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x754560B2, 5742015, 0x5456012F, 90.4187, -19.5666, -30, 0.91524, 0, 0, -0.402909, False, '2025-07-26 23:25:27');
/* @teleloc 0x5456012F [90.418701 -19.566601 -30.000000] 0.915240 0.000000 0.000000 -0.402909 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x754560B3, 5742015, 0x54560193, 74.9981, -31.9101, -29.8641, 0.046552, 0, 0, 0.998916, False, '2025-07-26 23:25:35');
/* @teleloc 0x54560193 [74.998100 -31.910101 -29.864100] 0.046552 0.000000 0.000000 0.998916 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x754560B4, 5742015, 0x54560186, 60.3851, -19.5552, -24, 0.935255, 0, 0, -0.353975, False, '2025-07-26 23:25:41');
/* @teleloc 0x54560186 [60.385101 -19.555201 -24.000000] 0.935255 0.000000 0.000000 -0.353975 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x754560B5, 5742015, 0x5456017D, 49.6024, -16.1438, -24, -0.094738, 0, 0, -0.995502, False, '2025-07-26 23:25:52');
/* @teleloc 0x5456017D [49.602402 -16.143801 -24.000000] -0.094738 0.000000 0.000000 -0.995502 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x754560B6, 5742015, 0x54560162, 27.2693, -12.6714, -24, 0.562915, 0, 0, -0.826515, False, '2025-07-26 23:25:59');
/* @teleloc 0x54560162 [27.269300 -12.671400 -24.000000] 0.562915 0.000000 0.000000 -0.826515 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x754560B7, 575712236, 0x54560162, 27.2693, -12.6714, -23.1675, 0.562915, 0, 0, -0.826515, False, '2025-07-26 23:26:03');
/* @teleloc 0x54560162 [27.269300 -12.671400 -23.167500] 0.562915 0.000000 0.000000 -0.826515 */
