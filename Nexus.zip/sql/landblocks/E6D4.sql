DELETE FROM `landblock_instance` WHERE `landblock` = 0xE6D4;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E6D4007, 5000204, 0xE6D40007, 5.64296, 150.64, -0.045, 0.27175, 0, 0, 0.962368, False, '2025-07-27 19:54:42'); /* Tall Tree */
/* @teleloc 0xE6D40007 [5.642960 150.639999 -0.045000] 0.271750 0.000000 0.000000 0.962368 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E6D4008, 5000204, 0xE6D40007, 20.2488, 148.925, -0.045, 0.990854, 0, 0, 0.134937, False, '2025-07-27 19:54:47'); /* Tall Tree */
/* @teleloc 0xE6D40007 [20.248800 148.925003 -0.045000] 0.990854 0.000000 0.000000 0.134937 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E6D4009, 5000204, 0xE6D4000F, 35.9198, 165.953, -0.395, 0.85367, 0, 0, -0.520815, False, '2025-07-27 19:54:49'); /* Tall Tree */
/* @teleloc 0xE6D4000F [35.919800 165.953003 -0.395000] 0.853670 0.000000 0.000000 -0.520815 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E6D400B, 4200152, 0xE6D40027, 115.457, 146.55, -0.045, 0.666099, 0, 0, -0.745864, False, '2025-07-27 19:58:39'); /* Gate */
/* @teleloc 0xE6D40027 [115.457001 146.550003 -0.045000] 0.666099 0.000000 0.000000 -0.745864 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E6D400C, 4200152, 0xE6D40027, 110.26, 167.616, -0.45, 0.465717, 0, 0, 0.884934, False, '2025-07-27 19:58:46'); /* Gate */
/* @teleloc 0xE6D40027 [110.260002 167.615997 -0.450000] 0.465717 0.000000 0.000000 0.884934 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E6D400D, 4200152, 0xE6D40020, 95.2466, 181.774, -0.845, 0.202804, 0, 0, 0.979219, False, '2025-07-27 19:59:27'); /* Gate */
/* @teleloc 0xE6D40020 [95.246597 181.774002 -0.845000] 0.202804 0.000000 0.000000 0.979219 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E6D400E, 4200152, 0xE6D40020, 72.9873, 188.121, -0.845, -0.018506, 0, 0, 0.999829, False, '2025-07-27 19:59:37'); /* Gate */
/* @teleloc 0xE6D40020 [72.987297 188.121002 -0.845000] -0.018506 0.000000 0.000000 0.999829 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E6D400F, 4200152, 0xE6D40018, 59.7026, 187.833, -0.845, -0.034039, 0, 0, -0.999421, False, '2025-07-27 19:59:50'); /* Gate */
/* @teleloc 0xE6D40018 [59.702599 187.832993 -0.845000] -0.034039 0.000000 0.000000 -0.999421 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E6D4010, 4200152, 0xE6D40010, 39.9794, 190.106, -0.845, -0.162664, 0, 0, -0.986682, False, '2025-07-27 19:59:55'); /* Gate */
/* @teleloc 0xE6D40010 [39.979401 190.106003 -0.845000] -0.162664 0.000000 0.000000 -0.986682 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E6D4011, 4200152, 0xE6D40008, 23.9861, 191.922, -0.395, -0.94576, 0, 0, -0.324866, False, '2025-07-27 20:00:10'); /* Gate */
/* @teleloc 0xE6D40008 [23.986099 191.921997 -0.395000] -0.945760 0.000000 0.000000 -0.324866 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E6D4012, 4200152, 0xE6D40008, 6.45366, 185.84, -0.395, -0.994385, 0, 0, 0.10582, False, '2025-07-27 20:00:15'); /* Gate */
/* @teleloc 0xE6D40008 [6.453660 185.839996 -0.395000] -0.994385 0.000000 0.000000 0.105820 */
