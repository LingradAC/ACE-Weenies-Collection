DELETE FROM `landblock_instance` WHERE `landblock` = 0x014C;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7014C000,  1905, 0x014C0100, 63.0237, -140, -12, 0.707107, 0, 0, -0.707107, False, '2005-02-09 10:00:00'); /* North Desert Edge */
/* @teleloc 0x014C0100 [63.023701 -140.000000 -12.000000] 0.707107 0.000000 0.000000 -0.707107 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7014C001,   222, 0x014C0101, 72.8283, -118.946, -11.9986, -0.215162, 0, 0, -0.976578,  True, '2005-02-09 10:00:00'); /* Veteran Reedshark */
/* @teleloc 0x014C0101 [72.828300 -118.945999 -11.998600] -0.215162 0.000000 0.000000 -0.976578 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7014C002,    18, 0x014C0101, 67.1017, -118.962, -11.9986, 0.583895, 0, 0, -0.811829,  True, '2005-02-09 10:00:00'); /* Reedshark Elder */
/* @teleloc 0x014C0101 [67.101700 -118.961998 -11.998600] 0.583895 0.000000 0.000000 -0.811829 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7014C003,  5619, 0x014C0101, 67.4, -117.514, -11.995, 0.930508, 0, 0, 0.366273, False, '2005-02-09 10:00:00'); /* Hot Air */
/* @teleloc 0x014C0101 [67.400002 -117.514000 -11.995000] 0.930508 0.000000 0.000000 0.366273 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7014C004,  5619, 0x014C0101, 72.867, -117.385, -11.995, 0.930508, 0, 0, 0.366273, False, '2005-02-09 10:00:00'); /* Hot Air */
/* @teleloc 0x014C0101 [72.866997 -117.385002 -11.995000] 0.930508 0.000000 0.000000 0.366273 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7014C005,  5619, 0x014C0101, 72.9784, -122.515, -11.995, 0.930508, 0, 0, 0.366273, False, '2005-02-09 10:00:00'); /* Hot Air */
/* @teleloc 0x014C0101 [72.978401 -122.514999 -11.995000] 0.930508 0.000000 0.000000 0.366273 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7014C006,  5619, 0x014C0101, 67.3714, -122.381, -11.995, 0.930508, 0, 0, 0.366273, False, '2005-02-09 10:00:00'); /* Hot Air */
/* @teleloc 0x014C0101 [67.371399 -122.380997 -11.995000] 0.930508 0.000000 0.000000 0.366273 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7014C007,  5619, 0x014C0101, 70, -120, -12, 1, 0, 0, 0, False, '2005-02-09 10:00:00'); /* Hot Air */
/* @teleloc 0x014C0101 [70.000000 -120.000000 -12.000000] 1.000000 0.000000 0.000000 0.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7014C008,  3988, 0x014C0101, 66.069, -115.978, -12, -0.913012, 0, 0, -0.407932, False, '2005-02-09 10:00:00'); /* Chest */
/* @teleloc 0x014C0101 [66.069000 -115.977997 -12.000000] -0.913012 0.000000 0.000000 -0.407932 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7014C009,  1624, 0x014C0102, 73.0581, -129.453, -11.988, -0.876674, 0, 0, -0.481084,  True, '2005-02-09 10:00:00'); /* Swamp Rat */
/* @teleloc 0x014C0102 [73.058098 -129.453003 -11.988000] -0.876674 0.000000 0.000000 -0.481084 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7014C00A,   222, 0x014C0102, 68.8378, -130.245, -11.9986, 0.827999, 0, 0, -0.560729,  True, '2005-02-09 10:00:00'); /* Veteran Reedshark */
/* @teleloc 0x014C0102 [68.837799 -130.244995 -11.998600] 0.827999 0.000000 0.000000 -0.560729 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7014C00B,   222, 0x014C0102, 72.3112, -131.507, -11.9986, -0.74939, 0, 0, -0.662129,  True, '2005-02-09 10:00:00'); /* Veteran Reedshark */
/* @teleloc 0x014C0102 [72.311203 -131.507004 -11.998600] -0.749390 0.000000 0.000000 -0.662129 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7014C00C,  1626, 0x014C0102, 68.2581, -128.215, -11.988, 0.236096, 0, 0, -0.97173,  True, '2005-02-09 10:00:00'); /* Silver Rat */
/* @teleloc 0x014C0102 [68.258102 -128.214996 -11.988000] 0.236096 0.000000 0.000000 -0.971730 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7014C00D,  5485, 0x014C0102, 70.6444, -126.38, -11.995, 0.701623, 0, 0, -0.712549, False, '2005-02-09 10:00:00'); /* Linkable Newbie Monster Generator */
/* @teleloc 0x014C0102 [70.644402 -126.379997 -11.995000] 0.701623 0.000000 0.000000 -0.712549 */

INSERT INTO `landblock_instance_link` (`parent_GUID`, `child_GUID`, `last_Modified`)
VALUES (0x7014C00D, 0x7014C001, '2005-02-09 10:00:00') /* Veteran Reedshark (222) */
     , (0x7014C00D, 0x7014C002, '2005-02-09 10:00:00') /* Reedshark Elder (18) */
     , (0x7014C00D, 0x7014C009, '2005-02-09 10:00:00') /* Swamp Rat (1624) */
     , (0x7014C00D, 0x7014C00A, '2005-02-09 10:00:00') /* Veteran Reedshark (222) */
     , (0x7014C00D, 0x7014C00B, '2005-02-09 10:00:00') /* Veteran Reedshark (222) */
     , (0x7014C00D, 0x7014C00C, '2005-02-09 10:00:00') /* Silver Rat (1626) */
     , (0x7014C00D, 0x7014C013, '2005-02-09 10:00:00') /* Swamp Rat (1624) */
     , (0x7014C00D, 0x7014C014, '2005-02-09 10:00:00') /* Silver Rat (1626) */
     , (0x7014C00D, 0x7014C015, '2005-02-09 10:00:00') /* Silver Rat (1626) */;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7014C00E,  5619, 0x014C0102, 73.1165, -126.943, -11.995, 0.999485, 0, 0, 0.032095, False, '2005-02-09 10:00:00'); /* Hot Air */
/* @teleloc 0x014C0102 [73.116501 -126.943001 -11.995000] 0.999485 0.000000 0.000000 0.032095 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7014C00F,  5619, 0x014C0102, 67.1473, -127.072, -11.995, 0.999485, 0, 0, 0.032095, False, '2005-02-09 10:00:00'); /* Hot Air */
/* @teleloc 0x014C0102 [67.147301 -127.071999 -11.995000] 0.999485 0.000000 0.000000 0.032095 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7014C010,  5619, 0x014C0102, 66.9333, -132.501, -11.995, 0.999485, 0, 0, 0.032095, False, '2005-02-09 10:00:00'); /* Hot Air */
/* @teleloc 0x014C0102 [66.933296 -132.501007 -11.995000] 0.999485 0.000000 0.000000 0.032095 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7014C011,  5619, 0x014C0102, 72.9788, -132.514, -11.995, 0.999485, 0, 0, 0.032095, False, '2005-02-09 10:00:00'); /* Hot Air */
/* @teleloc 0x014C0102 [72.978798 -132.514008 -11.995000] 0.999485 0.000000 0.000000 0.032095 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7014C012,  5619, 0x014C0102, 70, -130, -12, 1, 0, 0, 0, False, '2005-02-09 10:00:00'); /* Hot Air */
/* @teleloc 0x014C0102 [70.000000 -130.000000 -12.000000] 1.000000 0.000000 0.000000 0.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7014C013,  1624, 0x014C0103, 68.5602, -140.128, -11.988, 0.889915, 0, 0, -0.456127,  True, '2005-02-09 10:00:00'); /* Swamp Rat */
/* @teleloc 0x014C0103 [68.560204 -140.128006 -11.988000] 0.889915 0.000000 0.000000 -0.456127 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7014C014,  1626, 0x014C0103, 66.1422, -137.716, -11.988, 0.407932, 0, 0, -0.913012,  True, '2005-02-09 10:00:00'); /* Silver Rat */
/* @teleloc 0x014C0103 [66.142197 -137.716003 -11.988000] 0.407932 0.000000 0.000000 -0.913012 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7014C015,  1626, 0x014C0103, 72.6527, -143.462, -11.988, -0.952263, 0, 0, -0.30528,  True, '2005-02-09 10:00:00'); /* Silver Rat */
/* @teleloc 0x014C0103 [72.652702 -143.462006 -11.988000] -0.952263 0.000000 0.000000 -0.305280 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7014C016,  5619, 0x014C0103, 70, -140, -12, 0, 0, 0, -1, False, '2005-02-09 10:00:00'); /* Hot Air */
/* @teleloc 0x014C0103 [70.000000 -140.000000 -12.000000] 0.000000 0.000000 0.000000 -1.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7014C017,  5619, 0x014C0103, 73.1873, -136.833, -12, 0, 0, 0, -1, False, '2005-02-09 10:00:00'); /* Hot Air */
/* @teleloc 0x014C0103 [73.187302 -136.832993 -12.000000] 0.000000 0.000000 0.000000 -1.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7014C018,  5619, 0x014C0103, 67.026, -136.894, -12, 0, 0, 0, -1, False, '2005-02-09 10:00:00'); /* Hot Air */
/* @teleloc 0x014C0103 [67.026001 -136.893997 -12.000000] 0.000000 0.000000 0.000000 -1.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7014C019,  5619, 0x014C0103, 67.1693, -142.876, -12, 0, 0, 0, -1, False, '2005-02-09 10:00:00'); /* Hot Air */
/* @teleloc 0x014C0103 [67.169296 -142.876007 -12.000000] 0.000000 0.000000 0.000000 -1.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7014C01A,  5619, 0x014C0103, 73.1967, -142.609, -12, 0, 0, 0, -1, False, '2005-02-09 10:00:00'); /* Hot Air */
/* @teleloc 0x014C0103 [73.196701 -142.608994 -12.000000] 0.000000 0.000000 0.000000 -1.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7014C01B,   221, 0x014C010C, 102.78, -141.34, 0.051, 1, 0, 0, 0,  True, '2005-02-09 10:00:00'); /* Adult Reedshark */
/* @teleloc 0x014C010C [102.779999 -141.339996 0.051000] 1.000000 0.000000 0.000000 0.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7014C01C,   221, 0x014C011B, 107.625, -172.375, 0.0014, 1, 0, 0, 0,  True, '2005-02-09 10:00:00'); /* Adult Reedshark */
/* @teleloc 0x014C011B [107.625000 -172.375000 0.001400] 1.000000 0.000000 0.000000 0.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7014C01D,   221, 0x014C0126, 123.478, -179.932, 0.0014, 0.707107, 0, 0, -0.707107,  True, '2005-02-09 10:00:00'); /* Adult Reedshark */
/* @teleloc 0x014C0126 [123.477997 -179.932007 0.001400] 0.707107 0.000000 0.000000 -0.707107 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7014C01E,   221, 0x014C0131, 130, -130, 0.0014, 1, 0, 0, 0,  True, '2005-02-09 10:00:00'); /* Adult Reedshark */
/* @teleloc 0x014C0131 [130.000000 -130.000000 0.001400] 1.000000 0.000000 0.000000 0.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7014C01F,   221, 0x014C0134, 127.049, -159.098, 0.0014, 1, 0, 0, 0,  True, '2005-02-09 10:00:00'); /* Adult Reedshark */
/* @teleloc 0x014C0134 [127.049004 -159.098007 0.001400] 1.000000 0.000000 0.000000 0.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7014C021,   223, 0x014C013B, 148.298, -103.958, 0.001, 0.237897, 0, 0, -0.97129,  True, '2005-02-09 10:00:00'); /* Reedshark Pup */
/* @teleloc 0x014C013B [148.298004 -103.958000 0.001000] 0.237897 0.000000 0.000000 -0.971290 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7014C022,   223, 0x014C013C, 149.005, -108.49, 0.001, 0.237898, 0, 0, -0.97129,  True, '2005-02-09 10:00:00'); /* Reedshark Pup */
/* @teleloc 0x014C013C [149.005005 -108.489998 0.001000] 0.237898 0.000000 0.000000 -0.971290 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7014C023,   223, 0x014C014A, 159.692, -119.539, 0.001, 0.134743, 0, 0, -0.990881,  True, '2005-02-09 10:00:00'); /* Reedshark Pup */
/* @teleloc 0x014C014A [159.692001 -119.539001 0.001000] 0.134743 0.000000 0.000000 -0.990881 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7014C024,  3955, 0x014C014F, 160, -170, 0, 1, 0, 0, 0, False, '2005-02-09 10:00:00'); /* Linkable Monster Gen (15 min.) */
/* @teleloc 0x014C014F [160.000000 -170.000000 0.000000] 1.000000 0.000000 0.000000 0.000000 */

INSERT INTO `landblock_instance_link` (`parent_GUID`, `child_GUID`, `last_Modified`)
VALUES (0x7014C024, 0x7014C01B, '2005-02-09 10:00:00') /* Adult Reedshark (221) */
     , (0x7014C024, 0x7014C01C, '2005-02-09 10:00:00') /* Adult Reedshark (221) */
     , (0x7014C024, 0x7014C01D, '2005-02-09 10:00:00') /* Adult Reedshark (221) */
     , (0x7014C024, 0x7014C01E, '2005-02-09 10:00:00') /* Adult Reedshark (221) */
     , (0x7014C024, 0x7014C01F, '2005-02-09 10:00:00') /* Adult Reedshark (221) */
     , (0x7014C024, 0x7014C028, '2005-02-09 10:00:00') /* Reedshark Elder (18) */
     , (0x7014C024, 0x7014C02E, '2005-02-09 10:00:00') /* Adult Reedshark (221) */
     , (0x7014C024, 0x7014C031, '2005-02-09 10:00:00') /* Reedshark Elder (18) */
     , (0x7014C024, 0x7014C03F, '2005-02-09 10:00:00') /* Adult Reedshark (221) */
     , (0x7014C024, 0x7014C041, '2005-02-09 10:00:00') /* Veteran Reedshark (222) */
     , (0x7014C024, 0x7014C042, '2005-02-09 10:00:00') /* Adult Reedshark (221) */
     , (0x7014C024, 0x7014C044, '2005-02-09 10:00:00') /* Adult Reedshark (221) */
     , (0x7014C024, 0x7014C045, '2005-02-09 10:00:00') /* Adult Reedshark (221) */
     , (0x7014C024, 0x7014C049, '2005-02-09 10:00:00') /* Reedshark Elder (18) */
     , (0x7014C024, 0x7014C04A, '2005-02-09 10:00:00') /* Veteran Reedshark (222) */
     , (0x7014C024, 0x7014C051, '2005-02-09 10:00:00') /* Reedshark Elder (18) */
     , (0x7014C024, 0x7014C052, '2005-02-09 10:00:00') /* Reedshark Elder (18) */
     , (0x7014C024, 0x7014C053, '2005-02-09 10:00:00') /* Veteran Reedshark (222) */
     , (0x7014C024, 0x7014C054, '2005-02-09 10:00:00') /* Veteran Reedshark (222) */
     , (0x7014C024, 0x7014C055, '2005-02-09 10:00:00') /* Veteran Reedshark (222) */
     , (0x7014C024, 0x7014C056, '2005-02-09 10:00:00') /* Veteran Reedshark (222) */
     , (0x7014C024, 0x7014C057, '2005-02-09 10:00:00') /* Veteran Reedshark (222) */
     , (0x7014C024, 0x7014C058, '2005-02-09 10:00:00') /* Veteran Reedshark (222) */
     , (0x7014C024, 0x7014C059, '2005-02-09 10:00:00') /* Adult Reedshark (221) */;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7014C025,  7923, 0x014C014F, 161.324, -170, 0, 1, 0, 0, 0, False, '2005-02-09 10:00:00'); /* Linkable Monster Generator ( 3 Min.) */
/* @teleloc 0x014C014F [161.324005 -170.000000 0.000000] 1.000000 0.000000 0.000000 0.000000 */

INSERT INTO `landblock_instance_link` (`parent_GUID`, `child_GUID`, `last_Modified`)
VALUES (0x7014C025, 0x7014C021, '2005-02-09 10:00:00') /* Reedshark Pup (223) */
     , (0x7014C025, 0x7014C022, '2005-02-09 10:00:00') /* Reedshark Pup (223) */
     , (0x7014C025, 0x7014C023, '2005-02-09 10:00:00') /* Reedshark Pup (223) */
     , (0x7014C025, 0x7014C02A, '2005-02-09 10:00:00') /* Reedshark Pup (223) */
     , (0x7014C025, 0x7014C038, '2005-02-09 10:00:00') /* Reedshark Pup (223) */
     , (0x7014C025, 0x7014C03B, '2005-02-09 10:00:00') /* Reedshark Pup (223) */
     , (0x7014C025, 0x7014C03C, '2005-02-09 10:00:00') /* Reedshark Pup (223) */
     , (0x7014C025, 0x7014C03D, '2005-02-09 10:00:00') /* Reedshark Pup (223) */
     , (0x7014C025, 0x7014C04F, '2005-02-09 10:00:00') /* Reedshark Elder (18) */
     , (0x7014C025, 0x7014C050, '2005-02-09 10:00:00') /* Adult Reedshark (221) */
     , (0x7014C025, 0x7014C05A, '2005-02-09 10:00:00') /* Adult Reedshark (221) */;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7014C026,  1302, 0x014C0151, 155.25, -170, 0, -0.707107, 0, 0, -0.707107, False, '2005-02-09 10:00:00'); /* Door */
/* @teleloc 0x014C0151 [155.250000 -170.000000 0.000000] -0.707107 0.000000 0.000000 -0.707107 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7014C027,  2609, 0x014C015C, 36.3314, -90.0429, 6, 1, 0, 0, 0,  True, '2005-02-09 10:00:00'); /* Lever */
/* @teleloc 0x014C015C [36.331402 -90.042900 6.000000] 1.000000 0.000000 0.000000 0.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7014C028,    18, 0x014C0168, 90.7396, -104.909, 6.051, 1, 0, 0, 0,  True, '2005-02-09 10:00:00'); /* Reedshark Elder */
/* @teleloc 0x014C0168 [90.739601 -104.908997 6.051000] 1.000000 0.000000 0.000000 0.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7014C029,  4381, 0x014C0168, 90.1936, -103.098, 6, -0.940992, 0, 0, -0.33843, False, '2005-02-09 10:00:00'); /* Corpse */
/* @teleloc 0x014C0168 [90.193604 -103.098000 6.000000] -0.940992 0.000000 0.000000 -0.338430 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7014C02A,   223, 0x014C017D, 100, -120, 6.001, 1, 0, 0, 0,  True, '2005-02-09 10:00:00'); /* Reedshark Pup */
/* @teleloc 0x014C017D [100.000000 -120.000000 6.001000] 1.000000 0.000000 0.000000 0.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7014C02B,  5148, 0x014C0191, 115.692, -94.316, 7.8, -0.707107, 0, 0, -0.707107, False, '2005-02-09 10:00:00'); /* Flames */
/* @teleloc 0x014C0191 [115.692001 -94.316002 7.800000] -0.707107 0.000000 0.000000 -0.707107 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7014C02C,  4179, 0x014C0191, 115.692, -94.316, 7.8, -0.707107, 0, 0, -0.707107, False, '2005-02-09 10:00:00'); /* Bonfire */
/* @teleloc 0x014C0191 [115.692001 -94.316002 7.800000] -0.707107 0.000000 0.000000 -0.707107 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7014C02D,  2609, 0x014C0197, 129.917, 3.60414, 6, 0.707107, 0, 0, -0.707107,  True, '2005-02-09 10:00:00'); /* Lever */
/* @teleloc 0x014C0197 [129.917007 3.604140 6.000000] 0.707107 0.000000 0.000000 -0.707107 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7014C02E,   221, 0x014C019E, 130.122, -68.9866, 6.0014, -0.313164, 0, 0, -0.949699,  True, '2005-02-09 10:00:00'); /* Adult Reedshark */
/* @teleloc 0x014C019E [130.121994 -68.986603 6.001400] -0.313164 0.000000 0.000000 -0.949699 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7014C02F,  5148, 0x014C019F, 125.685, -75.672, 7.8, 1, 0, 0, 0, False, '2005-02-09 10:00:00'); /* Flames */
/* @teleloc 0x014C019F [125.684998 -75.671997 7.800000] 1.000000 0.000000 0.000000 0.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7014C030,  4179, 0x014C019F, 125.685, -75.672, 7.8, 1, 0, 0, 0, False, '2005-02-09 10:00:00'); /* Bonfire */
/* @teleloc 0x014C019F [125.684998 -75.671997 7.800000] 1.000000 0.000000 0.000000 0.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7014C031,    18, 0x014C01A0, 130.32, -89.0717, 6.0014, -0.707107, 0, 0, -0.707107,  True, '2005-02-09 10:00:00'); /* Reedshark Elder */
/* @teleloc 0x014C01A0 [130.320007 -89.071701 6.001400] -0.707107 0.000000 0.000000 -0.707107 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7014C032,  5148, 0x014C01A0, 134, -94, 7.8, 0, 0, 0, -1, False, '2005-02-09 10:00:00'); /* Flames */
/* @teleloc 0x014C01A0 [134.000000 -94.000000 7.800000] 0.000000 0.000000 0.000000 -1.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7014C033,  5148, 0x014C01A0, 126.013, -94, 7.8, -0.707107, 0, 0, -0.707107, False, '2005-02-09 10:00:00'); /* Flames */
/* @teleloc 0x014C01A0 [126.013000 -94.000000 7.800000] -0.707107 0.000000 0.000000 -0.707107 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7014C034,  4179, 0x014C01A0, 134, -94, 7.8, 0, 0, 0, -1, False, '2005-02-09 10:00:00'); /* Bonfire */
/* @teleloc 0x014C01A0 [134.000000 -94.000000 7.800000] 0.000000 0.000000 0.000000 -1.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7014C035,  4179, 0x014C01A0, 126.013, -94, 7.8, -0.707107, 0, 0, -0.707107, False, '2005-02-09 10:00:00'); /* Bonfire */
/* @teleloc 0x014C01A0 [126.013000 -94.000000 7.800000] -0.707107 0.000000 0.000000 -0.707107 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7014C036,  5148, 0x014C01AB, 144.32, -85.676, 7.8, 0.707107, 0, 0, -0.707107, False, '2005-02-09 10:00:00'); /* Flames */
/* @teleloc 0x014C01AB [144.320007 -85.676003 7.800000] 0.707107 0.000000 0.000000 -0.707107 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7014C037,  4179, 0x014C01AB, 144.32, -85.676, 7.8, 0.707107, 0, 0, -0.707107, False, '2005-02-09 10:00:00'); /* Bonfire */
/* @teleloc 0x014C01AB [144.320007 -85.676003 7.800000] 0.707107 0.000000 0.000000 -0.707107 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7014C038,   223, 0x014C01AE, 143.307, -117.737, 6.001, 0.997193, 0, 0, -0.074869,  True, '2005-02-09 10:00:00'); /* Reedshark Pup */
/* @teleloc 0x014C01AE [143.307007 -117.737000 6.001000] 0.997193 0.000000 0.000000 -0.074869 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7014C039,  5624, 0x014C01BA, 150, -84.75, 6, 0, 0, 0, -1, False, '2005-02-09 10:00:00'); /* Door */
/* @teleloc 0x014C01BA [150.000000 -84.750000 6.000000] 0.000000 0.000000 0.000000 -1.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7014C03A,  5624, 0x014C01C2, 150, -124.75, 6, 0, 0, 0, -1, False, '2005-02-09 10:00:00'); /* Door */
/* @teleloc 0x014C01C2 [150.000000 -124.750000 6.000000] 0.000000 0.000000 0.000000 -1.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7014C03B,   223, 0x014C01C4, 145.15, -130.055, 6.001, 1, 0, 0, 0,  True, '2005-02-09 10:00:00'); /* Reedshark Pup */
/* @teleloc 0x014C01C4 [145.149994 -130.054993 6.001000] 1.000000 0.000000 0.000000 0.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7014C03C,   223, 0x014C01C5, 153.447, -142.647, 6.001, -0.985352, 0, 0, -0.170531,  True, '2005-02-09 10:00:00'); /* Reedshark Pup */
/* @teleloc 0x014C01C5 [153.447006 -142.647003 6.001000] -0.985352 0.000000 0.000000 -0.170531 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7014C03D,   223, 0x014C01C5, 153.284, -141.419, 6.001, -0.13658, 0, 0, -0.990629,  True, '2005-02-09 10:00:00'); /* Reedshark Pup */
/* @teleloc 0x014C01C5 [153.283997 -141.419006 6.001000] -0.136580 0.000000 0.000000 -0.990629 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7014C03E,  1930, 0x014C01C5, 148.811, -143.651, 6, 0, 0, 0, -1, False, '2005-02-09 10:00:00'); /* Chest */
/* @teleloc 0x014C01C5 [148.811005 -143.651001 6.000000] 0.000000 0.000000 0.000000 -1.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7014C03F,   221, 0x014C01C5, 152.109, -143.806, 6.051, 1, 0, 0, 0,  True, '2005-02-09 10:00:00'); /* Adult Reedshark */
/* @teleloc 0x014C01C5 [152.108994 -143.806000 6.051000] 1.000000 0.000000 0.000000 0.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7014C040,  1919, 0x014C01CB, 159.15, -77.3207, 6, -0.915003, 0, 0, -0.403446, False, '2005-02-09 10:00:00'); /* Chest */
/* @teleloc 0x014C01CB [159.149994 -77.320702 6.000000] -0.915003 0.000000 0.000000 -0.403446 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7014C041,   222, 0x014C01CB, 160.888, -77.4999, 6.0014, 0, 0, 0, -1,  True, '2005-02-09 10:00:00'); /* Veteran Reedshark */
/* @teleloc 0x014C01CB [160.888000 -77.499901 6.001400] 0.000000 0.000000 0.000000 -1.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7014C042,   221, 0x014C01CB, 161.989, -77.9833, 6.0014, 0, 0, 0, -1,  True, '2005-02-09 10:00:00'); /* Adult Reedshark */
/* @teleloc 0x014C01CB [161.988998 -77.983299 6.001400] 0.000000 0.000000 0.000000 -1.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7014C043,  5624, 0x014C01CD, 160, -84.75, 6, 0, 0, 0, -1, False, '2005-02-09 10:00:00'); /* Door */
/* @teleloc 0x014C01CD [160.000000 -84.750000 6.000000] 0.000000 0.000000 0.000000 -1.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7014C044,   221, 0x014C01DB, 166.978, -98.3432, 6.051, 0.707107, 0, 0, -0.707107,  True, '2005-02-09 10:00:00'); /* Adult Reedshark */
/* @teleloc 0x014C01DB [166.977997 -98.343201 6.051000] 0.707107 0.000000 0.000000 -0.707107 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7014C045,   221, 0x014C01ED, 182.773, -101.431, 6.051, 0.707107, 0, 0, -0.707107,  True, '2005-02-09 10:00:00'); /* Adult Reedshark */
/* @teleloc 0x014C01ED [182.772995 -101.431000 6.051000] 0.707107 0.000000 0.000000 -0.707107 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7014C049,    18, 0x014C01FF, 61.8728, -89.6966, 12.0014, -0.684149, 0, 0, -0.729343,  True, '2005-02-09 10:00:00'); /* Reedshark Elder */
/* @teleloc 0x014C01FF [61.872799 -89.696602 12.001400] -0.684149 0.000000 0.000000 -0.729343 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7014C04A,   222, 0x014C0208, 66.7911, -89.6491, 12.0014, -0.860076, 0, 0, -0.510167,  True, '2005-02-09 10:00:00'); /* Veteran Reedshark */
/* @teleloc 0x014C0208 [66.791100 -89.649101 12.001400] -0.860076 0.000000 0.000000 -0.510167 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7014C04C,  5624, 0x014C020C, 84.75, -120, 12, 0.707107, 0, 0, -0.707107, False, '2005-02-09 10:00:00'); /* Door */
/* @teleloc 0x014C020C [84.750000 -120.000000 12.000000] 0.707107 0.000000 0.000000 -0.707107 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7014C04D,  4139, 0x014C020D, 84.75, -130, 12, 0.707107, 0, 0, -0.707107, False, '2005-02-09 10:00:00'); /* Door */
/* @teleloc 0x014C020D [84.750000 -130.000000 12.000000] 0.707107 0.000000 0.000000 -0.707107 */

INSERT INTO `landblock_instance_link` (`parent_GUID`, `child_GUID`, `last_Modified`)
VALUES (0x7014C04D, 0x7014C027, '2005-02-09 10:00:00') /* Lever (2609) */
     , (0x7014C04D, 0x7014C02D, '2005-02-09 10:00:00') /* Lever (2609) */;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7014C04E,  5624, 0x014C020E, 84.75, -140, 12, 0.707107, 0, 0, -0.707107, False, '2005-02-09 10:00:00'); /* Door */
/* @teleloc 0x014C020E [84.750000 -140.000000 12.000000] 0.707107 0.000000 0.000000 -0.707107 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7014C04F,    18, 0x014C020F, 90.5261, -122.039, 12.0014, 1, 0, 0, 0,  True, '2005-02-09 10:00:00'); /* Reedshark Elder */
/* @teleloc 0x014C020F [90.526100 -122.039001 12.001400] 1.000000 0.000000 0.000000 0.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7014C050,   221, 0x014C0213, 103.449, -128.961, 12.0014, 0.931056, 0, 0, -0.364877,  True, '2005-02-09 10:00:00'); /* Adult Reedshark */
/* @teleloc 0x014C0213 [103.448997 -128.960999 12.001400] 0.931056 0.000000 0.000000 -0.364877 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7014C051,    18, 0x014C0223, 130.126, -21.9737, 12.0014, 1, 0, 0, 0,  True, '2005-02-09 10:00:00'); /* Reedshark Elder */
/* @teleloc 0x014C0223 [130.126007 -21.973700 12.001400] 1.000000 0.000000 0.000000 0.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7014C052,    18, 0x014C0224, 129.512, -25.6228, 12.051, 1, 0, 0, 0,  True, '2005-02-09 10:00:00'); /* Reedshark Elder */
/* @teleloc 0x014C0224 [129.511993 -25.622801 12.051000] 1.000000 0.000000 0.000000 0.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7014C053,   222, 0x014C0247, 14.8096, -120.001, 18.0014, 0.707107, 0, 0, -0.707107,  True, '2005-02-09 10:00:00'); /* Veteran Reedshark */
/* @teleloc 0x014C0247 [14.809600 -120.000999 18.001400] 0.707107 0.000000 0.000000 -0.707107 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7014C054,   222, 0x014C0249, 22.0608, -120.014, 18.0014, 0.707107, 0, 0, -0.707107,  True, '2005-02-09 10:00:00'); /* Veteran Reedshark */
/* @teleloc 0x014C0249 [22.060801 -120.014000 18.001400] 0.707107 0.000000 0.000000 -0.707107 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7014C055,   222, 0x014C0249, 19.1324, -119.956, 18.051, 0.707107, 0, 0, -0.707107,  True, '2005-02-09 10:00:00'); /* Veteran Reedshark */
/* @teleloc 0x014C0249 [19.132401 -119.956001 18.051001] 0.707107 0.000000 0.000000 -0.707107 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7014C056,   222, 0x014C024B, 21.6091, -139.995, 18.0014, 0.707107, 0, 0, -0.707107,  True, '2005-02-09 10:00:00'); /* Veteran Reedshark */
/* @teleloc 0x014C024B [21.609100 -139.994995 18.001400] 0.707107 0.000000 0.000000 -0.707107 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7014C057,   222, 0x014C024B, 18.8118, -140.018, 18.051, 0.707107, 0, 0, -0.707107,  True, '2005-02-09 10:00:00'); /* Veteran Reedshark */
/* @teleloc 0x014C024B [18.811800 -140.018005 18.051001] 0.707107 0.000000 0.000000 -0.707107 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7014C058,   222, 0x014C024B, 15.2346, -139.983, 18.0014, 0.707107, 0, 0, -0.707107,  True, '2005-02-09 10:00:00'); /* Veteran Reedshark */
/* @teleloc 0x014C024B [15.234600 -139.983002 18.001400] 0.707107 0.000000 0.000000 -0.707107 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7014C059,   221, 0x014C025E, 110.779, -130.124, 18.0014, -0.718733, 0, 0, -0.695286,  True, '2005-02-09 10:00:00'); /* Adult Reedshark */
/* @teleloc 0x014C025E [110.778999 -130.123993 18.001400] -0.718733 0.000000 0.000000 -0.695286 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7014C05A,   221, 0x014C0261, 116.309, -130.278, 18.0014, -0.80184, 0, 0, -0.597539,  True, '2005-02-09 10:00:00'); /* Adult Reedshark */
/* @teleloc 0x014C0261 [116.308998 -130.278000 18.001400] -0.801840 0.000000 0.000000 -0.597539 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7014C05B, 198186, 0x014C01F1, 19.9751, -130.098, 12.055, 0.702144, 0, 0, -0.712035, False, '2025-08-12 17:34:08');
/* @teleloc 0x014C01F1 [19.975100 -130.098007 12.055000] 0.702144 0.000000 0.000000 -0.712035 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7014C05C, 198187, 0x014C01F3, 34.0085, -128.261, 12.055, 0.643148, 0, 0, -0.765742, False, '2025-08-12 17:37:46');
/* @teleloc 0x014C01F3 [34.008499 -128.261002 12.055000] 0.643148 0.000000 0.000000 -0.765742 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7014C05D, 198187, 0x014C01F9, 36.6071, -134.217, 12.055, 0.20154, 0, 0, -0.97948, False, '2025-08-12 17:37:47');
/* @teleloc 0x014C01F9 [36.607101 -134.216995 12.055000] 0.201540 0.000000 0.000000 -0.979480 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7014C05E, 198187, 0x014C01F4, 31.0394, -140.831, 12.055, -0.626355, 0, 0, -0.779538, False, '2025-08-12 17:37:48');
/* @teleloc 0x014C01F4 [31.039400 -140.830994 12.055000] -0.626355 0.000000 0.000000 -0.779538 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7014C05F, 198187, 0x014C01A0, 126.654, -87.0426, 6.055, -0.602852, 0, 0, -0.797853, False, '2025-08-12 17:38:33');
/* @teleloc 0x014C01A0 [126.653999 -87.042603 6.055000] -0.602852 0.000000 0.000000 -0.797853 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7014C060, 198187, 0x014C01BB, 145.478, -90.2176, 6.055, 0.708955, 0, 0, -0.705253, False, '2025-08-12 17:38:38');
/* @teleloc 0x014C01BB [145.477997 -90.217598 6.055000] 0.708955 0.000000 0.000000 -0.705253 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7014C061, 198187, 0x014C01EE, 182.893, -99.8116, 6.055, 0.217984, 0, 0, -0.975952, False, '2025-08-12 17:38:42');
/* @teleloc 0x014C01EE [182.893005 -99.811600 6.055000] 0.217984 0.000000 0.000000 -0.975952 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7014C062, 198187, 0x014C01D2, 158.342, -120.466, 6.055, -0.811708, 0, 0, -0.584064, False, '2025-08-12 17:38:48');
/* @teleloc 0x014C01D2 [158.341995 -120.466003 6.055000] -0.811708 0.000000 0.000000 -0.584064 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7014C063, 198187, 0x014C01C5, 149.542, -137.383, 6.055, 0.045213, 0, 0, -0.998977, False, '2025-08-12 17:38:51');
/* @teleloc 0x014C01C5 [149.542007 -137.382996 6.055000] 0.045213 0.000000 0.000000 -0.998977 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7014C064, 198187, 0x014C0120, 124.848, -116.521, 0.055, -0.93272, 0, 0, -0.360601, False, '2025-08-12 17:38:57');
/* @teleloc 0x014C0120 [124.848000 -116.521004 0.055000] -0.932720 0.000000 0.000000 -0.360601 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7014C065, 198187, 0x014C0137, 138.755, -103.65, 0.055, -0.456755, 0, 0, 0.889593, False, '2025-08-12 17:39:00');
/* @teleloc 0x014C0137 [138.755005 -103.650002 0.055000] -0.456755 0.000000 0.000000 0.889593 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7014C066, 198187, 0x014C014B, 162.143, -125.066, 0.055, -0.070447, 0, 0, 0.997516, False, '2025-08-12 17:39:03');
/* @teleloc 0x014C014B [162.143005 -125.066002 0.055000] -0.070447 0.000000 0.000000 0.997516 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7014C067, 198187, 0x014C014F, 159.713, -170.356, 0.055, -0.53072, 0, 0, 0.847547, False, '2025-08-12 17:39:09');
/* @teleloc 0x014C014F [159.712997 -170.356003 0.055000] -0.530720 0.000000 0.000000 0.847547 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7014C068, 198187, 0x014C0158, 168.503, -170.482, 0.055, -0.7249, 0, 0, 0.688854, False, '2025-08-12 17:39:10');
/* @teleloc 0x014C0158 [168.503006 -170.481995 0.055000] -0.724900 0.000000 0.000000 0.688854 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7014C069, 198187, 0x014C0139, 144.068, -170.684, 0.055, 0.636592, 0, 0, 0.771201, False, '2025-08-12 17:39:14');
/* @teleloc 0x014C0139 [144.067993 -170.684006 0.055000] 0.636592 0.000000 0.000000 0.771201 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7014C06A, 198187, 0x014C0134, 129.741, -164.944, 0.055, 0.960852, 0, 0, 0.277062, False, '2025-08-12 17:39:15');
/* @teleloc 0x014C0134 [129.740997 -164.944000 0.055000] 0.960852 0.000000 0.000000 0.277062 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7014C06B, 198187, 0x014C0132, 127.936, -141.511, 0.055, 0.992432, 0, 0, -0.122792, False, '2025-08-12 17:39:18');
/* @teleloc 0x014C0132 [127.935997 -141.511002 0.055000] 0.992432 0.000000 0.000000 -0.122792 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7014C06C, 198187, 0x014C018A, 114.703, -129.349, 6.055, 0.703247, 0, 0, 0.710945, False, '2025-08-12 17:39:23');
/* @teleloc 0x014C018A [114.703003 -129.348999 6.055000] 0.703247 0.000000 0.000000 0.710945 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7014C06D, 198187, 0x014C016A, 88.817, -105.069, 6.055, 0.20681, 0, 0, 0.978381, False, '2025-08-12 17:39:30');
/* @teleloc 0x014C016A [88.817001 -105.069000 6.055000] 0.206810 0.000000 0.000000 0.978381 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7014C06E, 198187, 0x014C0114, 111.001, -157.301, 0.055, -0.779621, 0, 0, 0.626251, False, '2025-08-12 17:39:41');
/* @teleloc 0x014C0114 [111.000999 -157.300995 0.055000] -0.779621 0.000000 0.000000 0.626251 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7014C06F, 198187, 0x014C013A, 135.686, -180.417, 0.055, -0.737038, 0, 0, 0.675852, False, '2025-08-12 17:39:47');
/* @teleloc 0x014C013A [135.686005 -180.417007 0.055000] -0.737038 0.000000 0.000000 0.675852 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7014C070, 198187, 0x014C013F, 149.703, -169.628, 0.055, -0.985441, 0, 0, -0.170016, False, '2025-08-12 17:39:50');
/* @teleloc 0x014C013F [149.703003 -169.628006 0.055000] -0.985441 0.000000 0.000000 -0.170016 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7014C071, 198187, 0x014C014E, 159.147, -156.485, 0.055, -0.998668, 0, 0, -0.051591, False, '2025-08-12 17:39:54');
/* @teleloc 0x014C014E [159.147003 -156.485001 0.055000] -0.998668 0.000000 0.000000 -0.051591 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7014C072, 198187, 0x014C0155, 167.129, -138.072, 0.055, -0.972755, 0, 0, 0.231834, False, '2025-08-12 17:39:56');
/* @teleloc 0x014C0155 [167.128998 -138.072006 0.055000] -0.972755 0.000000 0.000000 0.231834 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7014C073, 198187, 0x014C013C, 146.525, -107.76, 0.055, -0.299161, 0, 0, -0.954203, False, '2025-08-12 17:40:14');
/* @teleloc 0x014C013C [146.524994 -107.760002 0.055000] -0.299161 0.000000 0.000000 -0.954203 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7014C074, 198187, 0x014C0176, 101.327, -113.944, 6.055, -0.966166, 0, 0, 0.257923, False, '2025-08-12 17:40:49');
/* @teleloc 0x014C0176 [101.327003 -113.944000 6.055000] -0.966166 0.000000 0.000000 0.257923 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7014C075, 198187, 0x014C01CB, 159.576, -80.4115, 6.055, -0.266684, 0, 0, -0.963784, False, '2025-08-12 17:41:20');
/* @teleloc 0x014C01CB [159.576004 -80.411499 6.055000] -0.266684 0.000000 0.000000 -0.963784 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7014C076, 198187, 0x014C019A, 129.975, -34.6725, 6.055, -0.999857, 0, 0, 0.016912, False, '2025-08-12 17:41:29');
/* @teleloc 0x014C019A [129.975006 -34.672501 6.055000] -0.999857 0.000000 0.000000 0.016912 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7014C077, 198187, 0x014C0198, 130.306, -7.73354, 6.055, -0.999857, 0, 0, 0.016912, False, '2025-08-12 17:41:31');
/* @teleloc 0x014C0198 [130.306000 -7.733540 6.055000] -0.999857 0.000000 0.000000 0.016912 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7014C078, 198187, 0x014C0162, 74.6655, -90.2231, 6.055, -0.708408, 0, 0, -0.705803, False, '2025-08-12 17:41:44');
/* @teleloc 0x014C0162 [74.665497 -90.223099 6.055000] -0.708408 0.000000 0.000000 -0.705803 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7014C079, 198187, 0x014C015C, 44.6586, -90.1128, 6.055, -0.708408, 0, 0, -0.705803, False, '2025-08-12 17:41:45');
/* @teleloc 0x014C015C [44.658600 -90.112801 6.055000] -0.708408 0.000000 0.000000 -0.705803 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7014C07A, 198187, 0x014C0213, 96.912, -132.461, 12.055, -0.631396, 0, 0, -0.775461, False, '2025-08-12 17:42:51');
/* @teleloc 0x014C0213 [96.912003 -132.460999 12.055000] -0.631396 0.000000 0.000000 -0.775461 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7014C07B, 198187, 0x014C020F, 92.2066, -122.523, 12.055, -0.999971, 0, 0, -0.007646, False, '2025-08-12 17:42:53');
/* @teleloc 0x014C020F [92.206596 -122.523003 12.055000] -0.999971 0.000000 0.000000 -0.007646 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7014C07C, 198187, 0x014C0211, 91.4406, -135.981, 12.055, -0.007387, 0, 0, -0.999973, False, '2025-08-12 17:42:55');
/* @teleloc 0x014C0211 [91.440598 -135.981003 12.055000] -0.007387 0.000000 0.000000 -0.999973 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7014C07D, 23616, 0x014C0158, 170, -170, 0, -0.707107, 0, 0, -0.707107, False, '2025-08-12 21:09:16'); /* Crystal Shard */
/* @teleloc 0x014C0158 [170.000000 -170.000000 0.000000] -0.707107 0.000000 0.000000 -0.707107 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7014C07E, 23616, 0x014C0139, 144.506, -169.879, 0, -0.717567, 0, 0, -0.69649, False, '2025-08-12 21:09:21'); /* Crystal Shard */
/* @teleloc 0x014C0139 [144.505997 -169.878998 0.000000] -0.717567 0.000000 0.000000 -0.696490 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7014C07F, 23616, 0x014C0132, 128.698, -144.531, 0, -0.961212, 0, 0, 0.275812, False, '2025-08-12 21:09:25'); /* Crystal Shard */
/* @teleloc 0x014C0132 [128.697998 -144.531006 0.000000] -0.961212 0.000000 0.000000 0.275812 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7014C080, 23616, 0x014C0120, 123.648, -118.857, 0, -0.901558, 0, 0, -0.432658, False, '2025-08-12 21:09:27'); /* Crystal Shard */
/* @teleloc 0x014C0120 [123.648003 -118.857002 0.000000] -0.901558 0.000000 0.000000 -0.432658 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7014C081, 23616, 0x014C014A, 160.771, -118.159, 0, 0.211259, 0, 0, 0.97743, False, '2025-08-12 21:09:32'); /* Crystal Shard */
/* @teleloc 0x014C014A [160.770996 -118.158997 0.000000] 0.211259 0.000000 0.000000 0.977430 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7014C082, 23616, 0x014C01D2, 155.998, -122.199, 6, -0.376045, 0, 0, 0.926601, False, '2025-08-12 21:09:36'); /* Crystal Shard */
/* @teleloc 0x014C01D2 [155.998001 -122.198997 6.000000] -0.376045 0.000000 0.000000 0.926601 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7014C083, 23616, 0x014C01E8, 180.624, -93.8292, 6, -0.977963, 0, 0, -0.208778, False, '2025-08-12 21:09:43'); /* Crystal Shard */
/* @teleloc 0x014C01E8 [180.623993 -93.829201 6.000000] -0.977963 0.000000 0.000000 -0.208778 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7014C084, 23616, 0x014C01BB, 146.389, -90.1848, 6, -0.677713, 0, 0, -0.735327, False, '2025-08-12 21:09:45'); /* Crystal Shard */
/* @teleloc 0x014C01BB [146.389008 -90.184799 6.000000] -0.677713 0.000000 0.000000 -0.735327 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7014C085, 23616, 0x014C01A0, 131.15, -89.8739, 6, -0.734827, 0, 0, -0.678255, False, '2025-08-12 21:09:47'); /* Crystal Shard */
/* @teleloc 0x014C01A0 [131.149994 -89.873901 6.000000] -0.734827 0.000000 0.000000 -0.678255 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7014C086, 23616, 0x014C019B, 130.527, -42.4088, 6, -0.999936, 0, 0, -0.01128, False, '2025-08-12 21:09:51'); /* Crystal Shard */
/* @teleloc 0x014C019B [130.526993 -42.408798 6.000000] -0.999936 0.000000 0.000000 -0.011280 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7014C087, 23616, 0x014C0172, 100.609, -81.3084, 6, -0.551398, 0, 0, -0.834242, False, '2025-08-12 21:09:58'); /* Crystal Shard */
/* @teleloc 0x014C0172 [100.609001 -81.308403 6.000000] -0.551398 0.000000 0.000000 -0.834242 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7014C088, 23616, 0x014C015F, 54.3728, -90.0809, 6, -0.686812, 0, 0, -0.726835, False, '2025-08-12 21:10:02'); /* Crystal Shard */
/* @teleloc 0x014C015F [54.372799 -90.080902 6.000000] -0.686812 0.000000 0.000000 -0.726835 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7014C089, 23616, 0x014C0216, 109.81, -115.025, 12, 0.001416, 0, 0, 0.999999, False, '2025-08-12 21:10:11'); /* Crystal Shard */
/* @teleloc 0x014C0216 [109.809998 -115.025002 12.000000] 0.001416 0.000000 0.000000 0.999999 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7014C08A, 23616, 0x014C0213, 99.0491, -132.499, 12, 0.519761, 0, 0, 0.854312, False, '2025-08-12 21:10:14'); /* Crystal Shard */
/* @teleloc 0x014C0213 [99.049103 -132.498993 12.000000] 0.519761 0.000000 0.000000 0.854312 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7014C08B, 23616, 0x014C0201, 63.3348, -129.292, 12, 0.731542, 0, 0, 0.681796, False, '2025-08-12 21:10:17'); /* Crystal Shard */
/* @teleloc 0x014C0201 [63.334801 -129.292007 12.000000] 0.731542 0.000000 0.000000 0.681796 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7014C08C, 23616, 0x014C01F9, 38.0541, -129.722, 12, 0.71056, 0, 0, 0.703636, False, '2025-08-12 21:10:19'); /* Crystal Shard */
/* @teleloc 0x014C01F9 [38.054100 -129.722000 12.000000] 0.710560 0.000000 0.000000 0.703636 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7014C08D, 23616, 0x014C01F3, 31.2419, -131.459, 12, 0.39555, 0, 0, 0.918444, False, '2025-08-12 21:10:20'); /* Crystal Shard */
/* @teleloc 0x014C01F3 [31.241899 -131.459000 12.000000] 0.395550 0.000000 0.000000 0.918444 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7014C08E, 23616, 0x014C01F4, 29.4779, -138.234, 12, -0.162761, 0, 0, 0.986666, False, '2025-08-12 21:10:21'); /* Crystal Shard */
/* @teleloc 0x014C01F4 [29.477900 -138.233994 12.000000] -0.162761 0.000000 0.000000 0.986666 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7014C08F, 23616, 0x014C01F2, 32.72049, -120.4063, 12, -0.870909, 0, 0, -0.491445, False, '2025-08-12 21:10:24'); /* Crystal Shard */
/* @teleloc 0x014C01F2 [32.720490 -120.406303 12.000000] -0.870909 0.000000 0.000000 -0.491445 */
