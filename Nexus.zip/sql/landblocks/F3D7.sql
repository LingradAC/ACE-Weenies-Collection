DELETE FROM `landblock_instance` WHERE `landblock` = 0xF3D7;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3D7000, 5000768, 0xF3D70026, 102.957, 143.715, 0.055, 0.406815, 0, 0, 0.913511, False, '2020-05-07 18:52:42'); /* Stealth Remoran gen */
/* @teleloc 0xF3D70026 [102.957001 143.714996 0.055000] 0.406815 0.000000 0.000000 0.913511 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3D7001, 5000765, 0xF3D70035, 144.152, 117.597, 0.055, -0.668341, 0, 0, 0.743855, False, '2020-05-07 18:52:47'); /* Mage Skellie gen */
/* @teleloc 0xF3D70035 [144.151993 117.597000 0.055000] -0.668341 0.000000 0.000000 0.743855 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3D7002, 5000767, 0xF3D7003B, 178.48, 62.007, 0.055, 0.155832, 0, 0, 0.987784, False, '2020-05-07 18:52:52'); /* Wasp gen */
/* @teleloc 0xF3D7003B [178.479996 62.007000 0.055000] 0.155832 0.000000 0.000000 0.987784 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3D7003, 5000768, 0xF3D70019, 78.7873, 0.323212, 0.055, 0.996747, 0, 0, 0.080598, False, '2020-05-07 18:53:06'); /* Stealth Remoran gen */
/* @teleloc 0xF3D70019 [78.787300 0.323212 0.055000] 0.996747 0.000000 0.000000 0.080598 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3D7007, 5000295, 0xF3D70014, 50.7258, 92.5779, 0.055, 0.482664, 0, 0, -0.875805, False, '2020-01-13 01:42:33'); /* Plant */
/* @teleloc 0xF3D70014 [50.725800 92.577904 0.055000] 0.482664 0.000000 0.000000 -0.875805 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3D7008, 5000661, 0xF3D70013, 54.91, 71.5536, 0.055, -0.21151, 0, 0, -0.977376, False, '2020-01-13 01:42:35'); /* Plant */
/* @teleloc 0xF3D70013 [54.910000 71.553596 0.055000] -0.211510 0.000000 0.000000 -0.977376 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3D7009, 5000294, 0xF3D7000B, 47.8648, 56.0382, 0.055, -0.21151, 0, 0, -0.977376, False, '2020-01-13 01:42:35'); /* Plant */
/* @teleloc 0xF3D7000B [47.864799 56.038200 0.055000] -0.211510 0.000000 0.000000 -0.977376 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3D700A, 5000285, 0xF3D70010, 23.7441, 178.006, 0.0975, -0.965061, 0, 0, -0.262026, False, '2020-01-15 20:21:51'); /* bone */
/* @teleloc 0xF3D70010 [23.744101 178.005997 0.097500] -0.965061 0.000000 0.000000 -0.262026 */
