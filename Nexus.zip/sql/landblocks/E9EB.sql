DELETE FROM `landblock_instance` WHERE `landblock` = 0xE9EB;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E9EB000, 73217237, 0xE9EB0018, 66.6944, 190.947, 0.055, -0.556162, 0, 0, -0.831074, False, '2025-09-08 17:01:27'); /* Islandgolemgen */
/* @teleloc 0xE9EB0018 [66.694397 190.947006 0.055000] -0.556162 0.000000 0.000000 -0.831074 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E9EB001, 73217237, 0xE9EB0018, 65.9655, 190.647, 0.055, -0.556162, 0, 0, -0.831074, False, '2025-09-08 17:01:29'); /* Islandgolemgen */
/* @teleloc 0xE9EB0018 [65.965500 190.647003 0.055000] -0.556162 0.000000 0.000000 -0.831074 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E9EB002, 73217237, 0xE9EB0020, 83.11266, 175.931, 0.055, 0.96733, 0, 0, 0.253522, False, '2025-09-08 17:01:49'); /* Islandgolemgen */
/* @teleloc 0xE9EB0020 [83.112663 175.931000 0.055000] 0.967330 0.000000 0.000000 0.253522 */
