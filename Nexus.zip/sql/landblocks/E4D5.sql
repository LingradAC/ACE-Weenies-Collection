DELETE FROM `landblock_instance` WHERE `landblock` = 0xE4D5;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E4D5000, 12382137, 0xE4D5001C, 88.2589, 72.5866, -0.395, -0.734162, 0, 0, 0.678975, False, '2025-07-19 07:06:25'); /* Mutated Tusker Generator */
/* @teleloc 0xE4D5001C [88.258904 72.586601 -0.395000] -0.734162 0.000000 0.000000 0.678975 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E4D5001, 12382137, 0xE4D50036, 158.869, 131.178, -0.845, -0.909159, 0, 0, 0.41645, False, '2025-07-19 07:06:48'); /* Mutated Tusker Generator */
/* @teleloc 0xE4D50036 [158.869003 131.177994 -0.845000] -0.909159 0.000000 0.000000 0.416450 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E4D5002, 213788146, 0xE4D50002, 23.3129, 32.2028, -0.045, 0.37858, 0, 0, -0.925569, False, '2025-07-20 14:06:36'); /* bzmobgen */
/* @teleloc 0xE4D50002 [23.312901 32.202801 -0.045000] 0.378580 0.000000 0.000000 -0.925569 */
