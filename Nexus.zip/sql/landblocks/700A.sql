DELETE FROM `landblock_instance` WHERE `landblock` = 0x700A;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7700A003, 24489, 0x700A0000, 168.389, 71.261, 7.91097, 0.923133, 0, 0, -0.38448, False, '2005-02-09 10:00:00'); /* Ulgrim Island Rock-Mix Gen */
/* @teleloc 0x700A0000 [168.389008 71.261002 7.910970] 0.923133 0.000000 0.000000 -0.384480 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7700A004, 24489, 0x700A0000, 190.908, 95.5858, 7.89199, 0.90524, 0, 0, -0.424901, False, '2005-02-09 10:00:00'); /* Ulgrim Island Rock-Mix Gen */
/* @teleloc 0x700A0000 [190.908005 95.585800 7.891990] 0.905240 0.000000 0.000000 -0.424901 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7700A005, 24487, 0x700A0000, 171.445, 174.548, -0.895, 0.364428, 0, 0, -0.931232, False, '2005-02-09 10:00:00'); /* Ulgrim Island Beach Gen */
/* @teleloc 0x700A0000 [171.445007 174.548004 -0.895000] 0.364428 0.000000 0.000000 -0.931232 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7700A006, 24487, 0x700A0000, 177.395, 147.921, -0.095, -0.249539, 0, 0, -0.968365, False, '2005-02-09 10:00:00'); /* Ulgrim Island Beach Gen */
/* @teleloc 0x700A0000 [177.395004 147.921005 -0.095000] -0.249539 0.000000 0.000000 -0.968365 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7700A008, 24487, 0x700A0000, 139.54, 105.085, -0.095, 0.505638, 0, 0, 0.862746, False, '2005-02-09 10:00:00'); /* Ulgrim Island Beach Gen */
/* @teleloc 0x700A0000 [139.539993 105.084999 -0.095000] 0.505638 0.000000 0.000000 0.862746 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7700A009, 24487, 0x700A0000, 118.065, 71.5356, -0.095, 0.717567, 0, 0, 0.696489, False, '2005-02-09 10:00:00'); /* Ulgrim Island Beach Gen */
/* @teleloc 0x700A0000 [118.065002 71.535599 -0.095000] 0.717567 0.000000 0.000000 0.696489 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7700A00A, 24487, 0x700A0000, 120.992, 17.8266, 0.170341, 0.044321, 0, 0, 0.999017, False, '2005-02-09 10:00:00'); /* Ulgrim Island Beach Gen */
/* @teleloc 0x700A0000 [120.991997 17.826599 0.170341] 0.044321 0.000000 0.000000 0.999017 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7700A00B, 24487, 0x700A0000, 60.0722, 20.8549, -0.895, -0.384101, 0, 0, 0.923291, False, '2005-02-09 10:00:00'); /* Ulgrim Island Beach Gen */
/* @teleloc 0x700A0000 [60.072201 20.854900 -0.895000] -0.384101 0.000000 0.000000 0.923291 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7700A00E, 24487, 0x700A0000, 32.9526, 60.106, -0.895, 0.559669, 0, 0, -0.828716, False, '2005-02-09 10:00:00'); /* Ulgrim Island Beach Gen */
/* @teleloc 0x700A0000 [32.952599 60.105999 -0.895000] 0.559669 0.000000 0.000000 -0.828716 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7700A010, 24487, 0x700A0000, 88.6194, 101.179, -0.895, 0.572695, 0, 0, -0.819769, False, '2005-02-09 10:00:00'); /* Ulgrim Island Beach Gen */
/* @teleloc 0x700A0000 [88.619400 101.179001 -0.895000] 0.572695 0.000000 0.000000 -0.819769 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7700A012,  7786, 0x700A0000, 105.195, 110.677, 0, -0.707107, 0, 0, -0.707107, False, '2005-02-09 10:00:00'); /* Volcanic Vent */
/* @teleloc 0x700A0000 [105.195000 110.677002 0.000000] -0.707107 0.000000 0.000000 -0.707107 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7700A013,  7482, 0x700A0000, 106.574, 177.221, -0.895, 0.732834, 0, 0, -0.680408, False, '2005-02-09 10:00:00'); /* Steam Plume */
/* @teleloc 0x700A0000 [106.573997 177.220993 -0.895000] 0.732834 0.000000 0.000000 -0.680408 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7700A014,  7482, 0x700A0000, 110.435, 130.56, -0.895, 0.966716, 0, 0, -0.255851, False, '2005-02-09 10:00:00'); /* Steam Plume */
/* @teleloc 0x700A0000 [110.434998 130.559998 -0.895000] 0.966716 0.000000 0.000000 -0.255851 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7700A015,  5749, 0x700A0000, 110.511, 154.313, -0.900003, 0.708356, 0, 0, -0.705856, False, '2005-02-09 10:00:00'); /* Volcano Heat */
/* @teleloc 0x700A0000 [110.511002 154.313004 -0.900003] 0.708356 0.000000 0.000000 -0.705856 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7700A016,  5749, 0x700A0000, 152.148, 178.705, 2.36443, -0.999801, 0, 0, -0.019966, False, '2005-02-09 10:00:00'); /* Volcano Heat */
/* @teleloc 0x700A0000 [152.147995 178.705002 2.364430] -0.999801 0.000000 0.000000 -0.019966 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7700A017, 73217237, 0x700A0021, 96.2394, 10.1175, -0.045, 0.88953, 0, 0, -0.456877, False, '2025-08-12 12:40:13'); /* Islandgolemgen */
/* @teleloc 0x700A0021 [96.239403 10.117500 -0.045000] 0.889530 0.000000 0.000000 -0.456877 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7700A018, 73217237, 0x700A0023, 114.429, 48.3042, -0.045, 0.999186, 0, 0, -0.040344, False, '2025-08-12 12:40:16'); /* Islandgolemgen */
/* @teleloc 0x700A0023 [114.429001 48.304199 -0.045000] 0.999186 0.000000 0.000000 -0.040344 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7700A019, 73217237, 0x700A002D, 125.629, 96.04, -0.045, 0.983538, 0, 0, -0.1807, False, '2025-08-12 12:40:20'); /* Islandgolemgen */
/* @teleloc 0x700A002D [125.628998 96.040001 -0.045000] 0.983538 0.000000 0.000000 -0.180700 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7700A01A, 73217237, 0x700A0036, 144.371, 123.299, -0.045, 0.880124, 0, 0, -0.474744, False, '2025-08-12 12:40:22'); /* Islandgolemgen */
/* @teleloc 0x700A0036 [144.371002 123.299004 -0.045000] 0.880124 0.000000 0.000000 -0.474744 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7700A01B, 73217237, 0x700A003E, 181.674, 141.273, 0.055, 0.798431, 0, 0, -0.602087, False, '2025-08-12 12:40:25'); /* Islandgolemgen */
/* @teleloc 0x700A003E [181.673996 141.272995 0.055000] 0.798431 0.000000 0.000000 -0.602087 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7700A01C, 83217237, 0x700A0019, 74.6359, 0.086006, -0.395, -0.783807, 0, 0, 0.621004, False, '2025-09-04 22:34:52'); /* Trophy Keeper of Honor */
/* @teleloc 0x700A0019 [74.635902 0.086006 -0.395000] -0.783807 0.000000 0.000000 0.621004 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7700A01D, 83217237, 0x700A0022, 106.814, 24.1078, -0.395, -0.986381, 0, 0, 0.164474, False, '2025-09-04 22:34:54'); /* Trophy Keeper of Honor */
/* @teleloc 0x700A0022 [106.814003 24.107800 -0.395000] -0.986381 0.000000 0.000000 0.164474 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7700A01E, 83217237, 0x700A0023, 116.104, 62.1787, -0.045, -0.993424, 0, 0, 0.114493, False, '2025-09-04 22:34:57'); /* Trophy Keeper of Honor */
/* @teleloc 0x700A0023 [116.103996 62.178699 -0.045000] -0.993424 0.000000 0.000000 0.114493 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7700A01F, 83217237, 0x700A002D, 128.709, 96.1205, -0.045, -0.936933, 0, 0, 0.34951, False, '2025-09-04 22:35:00'); /* Trophy Keeper of Honor */
/* @teleloc 0x700A002D [128.709000 96.120499 -0.045000] -0.936933 0.000000 0.000000 0.349510 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7700A020, 73217237, 0x700A0029, 122.599, 9.51962, 0.48808, -0.989084, 0, 0, 0.147354, False, '2025-09-06 18:57:52'); /* Islandgolemgen */
/* @teleloc 0x700A0029 [122.598999 9.519620 0.488080] -0.989084 0.000000 0.000000 0.147354 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7700A021, 73217237, 0x700A002B, 129.575, 49.0163, 0.852904, -0.973971, 0, 0, 0.226673, False, '2025-09-06 18:57:55'); /* Islandgolemgen */
/* @teleloc 0x700A002B [129.574997 49.016300 0.852904] -0.973971 0.000000 0.000000 0.226673 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7700A022, 73217237, 0x700A002C, 136.402, 81.0613, 0.666715, -0.973971, 0, 0, 0.226673, False, '2025-09-06 18:57:57'); /* Islandgolemgen */
/* @teleloc 0x700A002C [136.401993 81.061302 0.666715] -0.973971 0.000000 0.000000 0.226673 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7700A023, 73217237, 0x700A003E, 172.5521, 131.6496, 0.055, -0.855379, 0, 0, 0.518002, False, '2025-09-06 18:58:02'); /* Islandgolemgen */
/* @teleloc 0x700A003E [172.552094 131.649597 0.055000] -0.855379 0.000000 0.000000 0.518002 */
