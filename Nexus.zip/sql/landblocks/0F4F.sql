DELETE FROM `landblock_instance` WHERE `landblock` = 0x0F4F;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70F4F000, 1910466, 0x0F4F0039, 191.935, 14.9469, -0.395, 0.401152, 0, 0, 0.916012, False, '2025-07-16 15:08:05'); /* VRtree1 */
/* @teleloc 0x0F4F0039 [191.934998 14.946900 -0.395000] 0.401152 0.000000 0.000000 0.916012 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70F4F001, 1910466, 0x0F4F0039, 182.258, 8.73633, -0.045, -0.841665, 0, 0, 0.54, False, '2025-07-16 15:08:11'); /* VRtree1 */
/* @teleloc 0x0F4F0039 [182.257996 8.736330 -0.045000] -0.841665 0.000000 0.000000 0.540000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70F4F002, 5000216, 0x0F4F0039, 178.436, 1.28043, -0.395, 0.809394, 0, 0, 0.587267, False, '2025-07-16 15:09:50'); /* Gate */
/* @teleloc 0x0F4F0039 [178.436005 1.280430 -0.395000] 0.809394 0.000000 0.000000 0.587267 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70F4F003, 5000216, 0x0F4F0039, 178.919, 2.73707, -0.395, 0.857617, 0, 0, 0.514288, False, '2025-07-16 15:09:51'); /* Gate */
/* @teleloc 0x0F4F0039 [178.919006 2.737070 -0.395000] 0.857617 0.000000 0.000000 0.514288 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70F4F004, 5000216, 0x0F4F0039, 179.865, 4.31973, -0.395, 0.924842, 0, 0, 0.380353, False, '2025-07-16 15:09:51'); /* Gate */
/* @teleloc 0x0F4F0039 [179.865005 4.319730 -0.395000] 0.924842 0.000000 0.000000 0.380353 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70F4F005, 5000216, 0x0F4F0039, 180.737, 5.16189, -0.045, 0.961695, 0, 0, 0.274123, False, '2025-07-16 15:09:52'); /* Gate */
/* @teleloc 0x0F4F0039 [180.737000 5.161890 -0.045000] 0.961695 0.000000 0.000000 0.274123 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70F4F006, 5000216, 0x0F4F0039, 182.44, 6.21014, -0.045, 0.979531, 0, 0, 0.201293, False, '2025-07-16 15:09:52'); /* Gate */
/* @teleloc 0x0F4F0039 [182.440002 6.210140 -0.045000] 0.979531 0.000000 0.000000 0.201293 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70F4F007, 5000216, 0x0F4F0039, 185.126, 7.37222, -0.045, 0.961695, 0, 0, 0.274123, False, '2025-07-16 15:09:53'); /* Gate */
/* @teleloc 0x0F4F0039 [185.126007 7.372220 -0.045000] 0.961695 0.000000 0.000000 0.274123 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70F4F008, 5000216, 0x0F4F0039, 185.126, 7.37222, -0.045, 0.961695, 0, 0, 0.274123, False, '2025-07-16 15:09:53'); /* Gate */
/* @teleloc 0x0F4F0039 [185.126007 7.372220 -0.045000] 0.961695 0.000000 0.000000 0.274123 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70F4F009, 5000216, 0x0F4F0039, 188.129, 9.23585, -0.045, 0.961695, 0, 0, 0.274123, False, '2025-07-16 15:09:54'); /* Gate */
/* @teleloc 0x0F4F0039 [188.128998 9.235850 -0.045000] 0.961695 0.000000 0.000000 0.274123 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70F4F00A, 5000216, 0x0F4F0039, 188.1293, 9.235852, -0.045, 0.961695, 0, 0, 0.274123, False, '2025-07-16 15:09:55'); /* Gate */
/* @teleloc 0x0F4F0039 [188.129303 9.235852 -0.045000] 0.961695 0.000000 0.000000 0.274123 */
