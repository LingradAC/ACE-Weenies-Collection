DELETE FROM `landblock_instance` WHERE `landblock` = 0xA9B3;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7A9B3000,  2068, 0xA9B30000, 5.44567, 29.4682, 94.005, -0.445343, 0, 0, -0.89536, False, '2005-02-09 10:00:00'); /* Drudge Hideout */
/* @teleloc 0xA9B30000 [5.445670 29.468201 94.004997] -0.445343 0.000000 0.000000 -0.895360 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7A9B3001,   921, 0xA9B30000, 27.8337, 173.833, 93.0395, -0.965787, 0, 0, 0.259338, False, '2005-02-09 10:00:00'); /* Holtburg */
/* @teleloc 0xA9B30000 [27.833700 173.832993 93.039497] -0.965787 0.000000 0.000000 0.259338 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7A9B3002,  8127, 0xA9B30000, 11.7303, 157.581, 94.005, 0.009786, 0, 0, -0.999952, False, '2005-02-09 10:00:00'); /* Menhir Mana Field */
/* @teleloc 0xA9B30000 [11.730300 157.580994 94.004997] 0.009786 0.000000 0.000000 -0.999952 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7A9B3003,   143, 0xA9B30107, 178.525, 78.895, 119.055, 0.644791, 0, 0, 0.764359, False, '2005-02-09 10:00:00'); /* Chest */
/* @teleloc 0xA9B30107 [178.524994 78.894997 119.055000] 0.644791 0.000000 0.000000 0.764359 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7A9B3004,   412, 0xA9B30000, 180.2, 77.59, 116.01, 1, 0, 0, 0, False, '2005-02-09 10:00:00'); /* Door */
/* @teleloc 0xA9B30000 [180.199997 77.589996 116.010002] 1.000000 0.000000 0.000000 0.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7A9B3005,   412, 0xA9B30000, 184.695, 82.545, 115.995, 0.707107, 0, 0, 0.707107, False, '2005-02-09 10:00:00'); /* Door */
/* @teleloc 0xA9B30000 [184.695007 82.544998 115.995003] 0.707107 0.000000 0.000000 0.707107 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7A9B3006,   412, 0xA9B30000, 183.245, 83.895, 118.995, 1, 0, 0, 0, False, '2005-02-09 10:00:00'); /* Door */
/* @teleloc 0xA9B30000 [183.244995 83.894997 118.995003] 1.000000 0.000000 0.000000 0.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7A9B3007,   412, 0xA9B30000, 182.21, 80.19, 119, 0.707107, 0, 0, 0.707107, False, '2005-02-09 10:00:00'); /* Door */
/* @teleloc 0xA9B30000 [182.210007 80.190002 119.000000] 0.707107 0.000000 0.000000 0.707107 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7A9B300F,  6086, 0xA9B30111, 39.2339, 129.566, 87.66, 0.016272, 0, 0, 0.999868, False, '2005-02-09 10:00:00'); /* Portal to Neydisa Castle */
/* @teleloc 0xA9B30111 [39.233898 129.565994 87.660004] 0.016272 0.000000 0.000000 0.999868 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7A9B3011,  7923, 0xA9B3000E, 33.352, 125.221, 93.992, 0.707107, 0, 0, 0.707107, False, '2019-11-17 10:00:00'); /* Linkable Monster Generator ( 3 Min.) */
/* @teleloc 0xA9B3000E [33.352001 125.221001 93.991997] 0.707107 0.000000 0.000000 0.707107 */

INSERT INTO `landblock_instance_link` (`parent_GUID`, `child_GUID`, `last_Modified`)
VALUES (0x7A9B3011, 0x7A9B3012, '2019-11-17 10:00:00') /* The Chicken (25578) */;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7A9B3012, 25578, 0xA9B30006, 18.0792, 125.216, 93.992, 1, 0, 0, 0,  True, '2019-11-17 03:38:31'); /* The Chicken */
/* @teleloc 0xA9B30006 [18.079201 125.216003 93.991997] 1.000000 0.000000 0.000000 0.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7A9B3015, 129612, 0xA9B3000F, 40.3791, 159.116, 93.937, 0.050823, 0, 0, -0.998708, False, '2025-07-16 14:10:53'); /* Sanctum of Valor */
/* @teleloc 0xA9B3000F [40.379101 159.115997 93.936996] 0.050823 0.000000 0.000000 -0.998708 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7A9B3016, 129613, 0xA9B3000F, 36.8587, 158.757, 93.937, 0.050823, 0, 0, -0.998708, False, '2025-07-16 14:11:02'); /* Sanctum of Glory */
/* @teleloc 0xA9B3000F [36.858700 158.757004 93.936996] 0.050823 0.000000 0.000000 -0.998708 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7A9B3017, 29503, 0xA9B30028, 105.475, 168.072, 100.709, -0.172838, 0, 0, 0.98495, False, '2025-07-22 10:31:12'); /* Nexus Gambling Den */
/* @teleloc 0xA9B30028 [105.474998 168.072006 100.709000] -0.172838 0.000000 0.000000 0.984950 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7A9B301E, 129611, 0xA9B3000F, 44.7559, 158.984, 93.937, -0.999861, 0, 0, -0.016654, False, '2025-07-29 01:59:05'); /* Sanctum of Honor */
/* @teleloc 0xA9B3000F [44.755901 158.983994 93.936996] -0.999861 0.000000 0.000000 -0.016654 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7A9B301F, 129609, 0xA9B30017, 49.674, 159.149, 94.0765, -0.999861, 0, 0, -0.016654, False, '2025-07-29 01:59:17'); /* Sanctum of Greatness */
/* @teleloc 0xA9B30017 [49.674000 159.149002 94.076500] -0.999861 0.000000 0.000000 -0.016654 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7A9B3020, 86653875, 0xA9B30002, 8.00189, 29.0317, 94, -0.901182, 0, 0, -0.433441, False, '2025-08-13 21:03:27'); /* RED BALL OF LIGHT */
/* @teleloc 0xA9B30002 [8.001890 29.031700 94.000000] -0.901182 0.000000 0.000000 -0.433441 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7A9B3021, 86653875, 0xA9B30002, 5.85728, 26.3479, 94, -0.901182, 0, 0, -0.433441, False, '2025-08-13 21:03:30'); /* RED BALL OF LIGHT */
/* @teleloc 0xA9B30002 [5.857280 26.347900 94.000000] -0.901182 0.000000 0.000000 -0.433441 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7A9B3022, 86653875, 0xA9B30002, 2.7587, 28.8239, 94, -0.901182, 0, 0, -0.433441, False, '2025-08-13 21:03:32'); /* RED BALL OF LIGHT */
/* @teleloc 0xA9B30002 [2.758700 28.823900 94.000000] -0.901182 0.000000 0.000000 -0.433441 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7A9B3023, 86653875, 0xA9B30002, 4.61098, 32.40492, 94, -0.901182, 0, 0, -0.433441, False, '2025-08-13 21:03:34'); /* RED BALL OF LIGHT */
/* @teleloc 0xA9B30002 [4.610980 32.404919 94.000000] -0.901182 0.000000 0.000000 -0.433441 */
