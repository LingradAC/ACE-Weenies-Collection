DELETE FROM `landblock_instance` WHERE `landblock` = 0x0031;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70031001, 31314, 0x00310116, 73.6327, -50.0316, -65.995, 0.707832, 0, 0, 0.70638, False, '2024-05-26 19:09:10'); /* Surface */
/* @teleloc 0x00310116 [73.632698 -50.031601 -65.995003] 0.707832 0.000000 0.000000 0.706380 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70031002, 31314, 0x003102FC, 151.119, -198.619, -29.995, -0.324846, 0, 0, -0.945767, False, '2024-05-26 19:09:10'); /* Surface */
/* @teleloc 0x003102FC [151.119003 -198.619003 -29.995001] -0.324846 0.000000 0.000000 -0.945767 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70031003, 31314, 0x00310106, 193.64, -151.293, -90, 1, 0, 0, 0, False, '2024-05-26 19:09:10'); /* Surface */
/* @teleloc 0x00310106 [193.639999 -151.292999 -90.000000] 1.000000 0.000000 0.000000 0.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70031042, 5000837, 0x003102EF, 134.752, -143.722, -29.945, 0.946459, 0, 0, 0.322824, False, '2025-07-30 05:35:42'); /* CCAttack */
/* @teleloc 0x003102EF [134.751999 -143.722000 -29.945000] 0.946459 0.000000 0.000000 0.322824 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70031043, 5000837, 0x003102E4, 111.922, -117.54, -29.945, 0.992393, 0, 0, 0.123111, False, '2025-07-30 05:35:45'); /* CCAttack */
/* @teleloc 0x003102E4 [111.921997 -117.540001 -29.945000] 0.992393 0.000000 0.000000 0.123111 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70031044, 5000837, 0x003102D8, 81.0925, -93.5512, -29.945, 0.897561, 0, 0, 0.440891, False, '2025-07-30 05:35:49'); /* CCAttack */
/* @teleloc 0x003102D8 [81.092499 -93.551201 -29.945000] 0.897561 0.000000 0.000000 0.440891 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70031045, 5000839, 0x0031012F, 96.745, -89.8202, -65.945, 0.987646, 0, 0, -0.156705, False, '2025-07-30 05:35:59'); /* CCAttack */
/* @teleloc 0x0031012F [96.745003 -89.820198 -65.945000] 0.987646 0.000000 0.000000 -0.156705 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70031046, 2316917, 0x003102FE, 161.784, -186.102, -29.9445, -0.777492, 0, 0, -0.628893, False, '2025-08-03 20:45:49'); /* stompygene */
/* @teleloc 0x003102FE [161.783997 -186.102005 -29.944500] -0.777492 0.000000 0.000000 -0.628893 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70031047, 2316917, 0x003102E9, 118.033, -132.6, -29.9445, -0.949533, 0, 0, -0.313667, False, '2025-08-03 20:45:58'); /* stompygene */
/* @teleloc 0x003102E9 [118.032997 -132.600006 -29.944500] -0.949533 0.000000 0.000000 -0.313667 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70031048, 2316917, 0x003102D5, 68.1367, -112.888, -29.9445, -0.430344, 0, 0, -0.902665, False, '2025-08-03 20:46:06'); /* stompygene */
/* @teleloc 0x003102D5 [68.136703 -112.888000 -29.944500] -0.430344 0.000000 0.000000 -0.902665 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70031049, 2316917, 0x003102D7, 80.9522, -75.9311, -29.9445, -0.999234, 0, 0, -0.039125, False, '2025-08-03 20:46:15'); /* stompygene */
/* @teleloc 0x003102D7 [80.952202 -75.931099 -29.944500] -0.999234 0.000000 0.000000 -0.039125 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7003104A, 2316917, 0x003101FE, 29.6889, -188.853, -47.9445, 0.424103, 0, 0, -0.905614, False, '2025-08-03 20:46:28'); /* stompygene */
/* @teleloc 0x003101FE [29.688900 -188.852997 -47.944500] 0.424103 0.000000 0.000000 -0.905614 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7003104B, 2316917, 0x003101C5, 35.4233, -207.388, -53.9445, -0.065822, 0, 0, -0.997831, False, '2025-08-03 20:46:30'); /* stompygene */
/* @teleloc 0x003101C5 [35.423302 -207.388000 -53.944500] -0.065822 0.000000 0.000000 -0.997831 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7003104C, 2316917, 0x0031026F, 18.2139, -87.7008, -41.9445, -0.972313, 0, 0, -0.233685, False, '2025-08-03 20:46:42'); /* stompygene */
/* @teleloc 0x0031026F [18.213900 -87.700798 -41.944500] -0.972313 0.000000 0.000000 -0.233685 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7003104D, 2316917, 0x00310250, 4.94887, -77.4464, -41.9445, -0.948528, 0, 0, -0.316694, False, '2025-08-03 20:46:44'); /* stompygene */
/* @teleloc 0x00310250 [4.948870 -77.446404 -41.944500] -0.948528 0.000000 0.000000 -0.316694 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7003104E, 2316917, 0x003101D3, 75.6258, -23.8918, -53.9445, 0.131886, 0, 0, 0.991265, False, '2025-08-03 20:46:54'); /* stompygene */
/* @teleloc 0x003101D3 [75.625801 -23.891800 -53.944500] 0.131886 0.000000 0.000000 0.991265 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7003104F, 2316917, 0x003101C7, 54.8534, -53.8904, -53.9445, 0.332241, 0, 0, 0.943195, False, '2025-08-03 20:46:57'); /* stompygene */
/* @teleloc 0x003101C7 [54.853401 -53.890400 -53.944500] 0.332241 0.000000 0.000000 0.943195 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70031050, 2316917, 0x0031016D, 138.618, -109.113, -65.9445, -0.113814, 0, 0, -0.993502, False, '2025-08-03 20:47:11'); /* stompygene */
/* @teleloc 0x0031016D [138.617996 -109.112999 -65.944504] -0.113814 0.000000 0.000000 -0.993502 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70031051, 2316917, 0x0031016F, 139.671, -131.705, -65.9445, -0.267801, 0, 0, -0.963474, False, '2025-08-03 20:47:13'); /* stompygene */
/* @teleloc 0x0031016F [139.671005 -131.705002 -65.944504] -0.267801 0.000000 0.000000 -0.963474 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70031052, 2316917, 0x0031014C, 123.654, -130.611, -65.9445, -0.892413, 0, 0, -0.451221, False, '2025-08-03 20:47:15'); /* stompygene */
/* @teleloc 0x0031014C [123.653999 -130.610992 -65.944504] -0.892413 0.000000 0.000000 -0.451221 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70031053, 2316917, 0x0031013C, 109.625, -116.857, -65.9445, -0.994048, 0, 0, -0.108947, False, '2025-08-03 20:47:17'); /* stompygene */
/* @teleloc 0x0031013C [109.625000 -116.857002 -65.944504] -0.994048 0.000000 0.000000 -0.108947 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70031054, 2316917, 0x0031014A, 122.883, -109.857, -65.9445, -0.203226, 0, 0, 0.979132, False, '2025-08-03 20:47:21'); /* stompygene */
/* @teleloc 0x0031014A [122.883003 -109.857002 -65.944504] -0.203226 0.000000 0.000000 0.979132 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70031055, 2316917, 0x00310148, 118.391, -94.0626, -65.9445, 0.973958, 0, 0, 0.22673, False, '2025-08-03 20:47:23'); /* stompygene */
/* @teleloc 0x00310148 [118.390999 -94.062599 -65.944504] 0.973958 0.000000 0.000000 0.226730 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70031056, 2316917, 0x0031012F, 102.951, -90.5545, -65.9445, 0.90286, 0, 0, 0.429935, False, '2025-08-03 20:47:25'); /* stompygene */
/* @teleloc 0x0031012F [102.950996 -90.554497 -65.944504] 0.902860 0.000000 0.000000 0.429935 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70031057, 2316917, 0x00310120, 89.3719, -71.0818, -65.9445, 0.999177, 0, 0, 0.04057, False, '2025-08-03 20:47:27'); /* stompygene */
/* @teleloc 0x00310120 [89.371902 -71.081802 -65.944504] 0.999177 0.000000 0.000000 0.040570 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70031058, 2316917, 0x003102F5, 141.036, -153.606, -29.9445, 0.90095, 0, 0, -0.433922, False, '2025-08-03 20:48:01'); /* stompygene */
/* @teleloc 0x003102F5 [141.035995 -153.606003 -29.944500] 0.900950 0.000000 0.000000 -0.433922 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70031059, 2316917, 0x003102E2, 108.3, -101.247, -29.9445, 0.652101, 0, 0, 0.758132, False, '2025-08-03 20:48:07'); /* stompygene */
/* @teleloc 0x003102E2 [108.300003 -101.247002 -29.944500] 0.652101 0.000000 0.000000 0.758132 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7003105A, 31312, 0x00310101, 172.17, -161.186, -89.9964, 0.996798, 0, 0, -0.079958, False, '2025-08-03 20:50:53'); /* Darling */
/* @teleloc 0x00310101 [172.169998 -161.186005 -89.996399] 0.996798 0.000000 0.000000 -0.079958 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7003105B, 31312, 0x00310102, 182.46, -141.076, -89.9964, 0.995931, 0, 0, -0.090117, False, '2025-08-03 20:50:58'); /* Darling */
/* @teleloc 0x00310102 [182.460007 -141.076004 -89.996399] 0.995931 0.000000 0.000000 -0.090117 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7003105C, 31312, 0x00310104, 181.555, -155.03, -89.9964, -0.232546, 0, 0, 0.972586, False, '2025-08-03 20:51:00'); /* Darling */
/* @teleloc 0x00310104 [181.554993 -155.029999 -89.996399] -0.232546 0.000000 0.000000 0.972586 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7003105D, 2316917, 0x003101AB, 120.389, -22.8384, -59.9445, -0.99884, 0, 0, 0.048151, False, '2025-08-03 20:51:49'); /* stompygene */
/* @teleloc 0x003101AB [120.389000 -22.838400 -59.944500] -0.998840 0.000000 0.000000 0.048151 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7003105E, 931271771, 0x00310338, 150.537, -200.946, -17.94, 0.998492, 0, 0, -0.054907, False, '2025-08-25 07:02:35');
/* @teleloc 0x00310338 [150.537003 -200.945999 -17.940001] 0.998492 0.000000 0.000000 -0.054907 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7003105F, 931271771, 0x0031033A, 157.045, -198.626, -17.945, 0.897652, 0, 0, -0.440705, False, '2025-08-25 07:02:38');
/* @teleloc 0x0031033A [157.044998 -198.626007 -17.945000] 0.897652 0.000000 0.000000 -0.440705 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70031060, 931271771, 0x00310337, 151.474, -194.916, -17.945, 0.983469, 0, 0, 0.181076, False, '2025-08-25 07:02:40');
/* @teleloc 0x00310337 [151.473999 -194.916000 -17.945000] 0.983469 0.000000 0.000000 0.181076 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70031061, 931271771, 0x003102FB, 148.523, -187.772, -29.945, 0.999486, 0, 0, 0.032075, False, '2025-08-25 07:02:44');
/* @teleloc 0x003102FB [148.522995 -187.772003 -29.945000] 0.999486 0.000000 0.000000 0.032075 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70031062, 931271771, 0x003102FB, 152.745, -191.993, -29.945, 0.357301, 0, 0, -0.933989, False, '2025-08-25 07:02:46');
/* @teleloc 0x003102FB [152.744995 -191.992996 -29.945000] 0.357301 0.000000 0.000000 -0.933989 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70031063, 931271771, 0x003102FF, 155.878, -197.026, -29.945, 0.262273, 0, 0, -0.964994, False, '2025-08-25 07:02:47');
/* @teleloc 0x003102FF [155.878006 -197.026001 -29.945000] 0.262273 0.000000 0.000000 -0.964994 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70031064, 931271771, 0x003102FE, 161.657, -193.233, -29.945, 0.988822, 0, 0, -0.149103, False, '2025-08-25 07:02:48');
/* @teleloc 0x003102FE [161.656998 -193.233002 -29.945000] 0.988822 0.000000 0.000000 -0.149103 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70031065, 931271771, 0x003102FE, 161.244, -187.805, -29.945, 0.991165, 0, 0, 0.132634, False, '2025-08-25 07:02:49');
/* @teleloc 0x003102FE [161.244003 -187.804993 -29.945000] 0.991165 0.000000 0.000000 0.132634 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70031066, 931271771, 0x003102FA, 152.916, -181.252, -29.945, 0.962415, 0, 0, 0.271583, False, '2025-08-25 07:02:52');
/* @teleloc 0x003102FA [152.916000 -181.251999 -29.945000] 0.962415 0.000000 0.000000 0.271583 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70031067, 931271771, 0x003102FA, 148.891, -176.702, -29.945, 0.930494, 0, 0, 0.366307, False, '2025-08-25 07:02:53');
/* @teleloc 0x003102FA [148.891006 -176.701996 -29.945000] 0.930494 0.000000 0.000000 0.366307 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70031068, 931271771, 0x003102F7, 144.161, -172.89, -29.945, 0.93517, 0, 0, 0.354199, False, '2025-08-25 07:02:53');
/* @teleloc 0x003102F7 [144.160995 -172.889999 -29.945000] 0.935170 0.000000 0.000000 0.354199 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70031069, 931271771, 0x003102F7, 140.951, -167.337, -29.945, 0.979963, 0, 0, 0.199181, False, '2025-08-25 07:02:54');
/* @teleloc 0x003102F7 [140.951004 -167.337006 -29.945000] 0.979963 0.000000 0.000000 0.199181 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7003106A, 931271771, 0x003102F6, 139.367, -162.616, -29.945, 0.97668, 0, 0, 0.214701, False, '2025-08-25 07:02:56');
/* @teleloc 0x003102F6 [139.367004 -162.615997 -29.945000] 0.976680 0.000000 0.000000 0.214701 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7003106B, 931271771, 0x003102F6, 137.715, -157.657, -29.945, 0.996261, 0, 0, -0.086391, False, '2025-08-25 07:02:57');
/* @teleloc 0x003102F6 [137.714996 -157.656998 -29.945000] 0.996261 0.000000 0.000000 -0.086391 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7003106C, 931271771, 0x003102F5, 141.8182, -153.1128, -29.945, 0.729424, 0, 0, -0.684062, False, '2025-08-25 07:02:58');
/* @teleloc 0x003102F5 [141.818207 -153.112793 -29.945000] 0.729424 0.000000 0.000000 -0.684062 */
