DELETE FROM `landblock_instance` WHERE `landblock` = 0x01F8;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F83E8,  4219, 0x01F801D2, 9.16629, -91.7547, 0.005, -0.999897, 0, 0, -0.014386, False, '2021-11-01 00:00:00'); /* Linkable Monster Generator ( 7 Min.) */
/* @teleloc 0x01F801D2 [9.166290 -91.754700 0.005000] -0.999897 0.000000 0.000000 -0.014386 */

INSERT INTO `landblock_instance_link` (`parent_GUID`, `child_GUID`, `last_Modified`)
VALUES (0x701F83E8, 0x701F843E, '2021-11-01 00:00:00') /* Cow (5755) */;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F83E9,  4219, 0x01F801D2, 7.83524, -91.8064, 0.005, -0.999897, 0, 0, -0.014386, False, '2021-11-01 00:00:00'); /* Linkable Monster Generator ( 7 Min.) */
/* @teleloc 0x01F801D2 [7.835240 -91.806396 0.005000] -0.999897 0.000000 0.000000 -0.014386 */

INSERT INTO `landblock_instance_link` (`parent_GUID`, `child_GUID`, `last_Modified`)
VALUES (0x701F83E9, 0x701F8428, '2021-11-01 00:00:00') /* Gold Phyntos Wasp (217) */
     , (0x701F83E9, 0x701F8436, '2021-11-01 00:00:00') /* Alfrega the Reedshark (5687) */;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F83EA,  4219, 0x01F801D2, 8.49455, -91.7874, 0.005, -0.999897, 0, 0, -0.014386, False, '2021-11-01 00:00:00'); /* Linkable Monster Generator ( 7 Min.) */
/* @teleloc 0x01F801D2 [8.494550 -91.787399 0.005000] -0.999897 0.000000 0.000000 -0.014386 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F83EB,  7923, 0x01F801D2, 7.13658, -91.8132, 0.005, -0.999897, 0, 0, -0.014386, False, '2021-11-01 00:00:00'); /* Linkable Monster Generator ( 3 Min.) */
/* @teleloc 0x01F801D2 [7.136580 -91.813202 0.005000] -0.999897 0.000000 0.000000 -0.014386 */

INSERT INTO `landblock_instance_link` (`parent_GUID`, `child_GUID`, `last_Modified`)
VALUES (0x701F83EB, 0x701F83F4, '2021-11-01 00:00:00') /* Branith's Staff (2031) */
     , (0x701F83EB, 0x701F83F5, '2021-11-01 00:00:00') /* Branith's Shirt (2032) */;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F83ED,  1094, 0x01F801C0, 1.4461, -91.3579, 0.328929, 0.33843, 0, 0, -0.940992, False, '2021-11-01 00:00:00'); /* Surface */
/* @teleloc 0x01F801C0 [1.446100 -91.357903 0.328929] 0.338430 0.000000 0.000000 -0.940992 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F83EE,  1094, 0x01F8031E, 128.328, -120.629, 0, -0.407932, 0, 0, -0.913012, False, '2021-11-01 00:00:00'); /* Surface */
/* @teleloc 0x01F8031E [128.328003 -120.628998 0.000000] -0.407932 0.000000 0.000000 -0.913012 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F83EF,   278, 0x01F80380, 94.755, -60, 6, 0.707107, 0, 0, -0.707107, False, '2021-11-01 00:00:00'); /* Door */
/* @teleloc 0x01F80380 [94.754997 -60.000000 6.000000] 0.707107 0.000000 0.000000 -0.707107 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F83F0,  1292, 0x01F80391, 104.712, -40, 6, 0.707107, 0, 0, -0.707107, False, '2021-11-01 00:00:00'); /* Door */
/* @teleloc 0x01F80391 [104.711998 -40.000000 6.000000] 0.707107 0.000000 0.000000 -0.707107 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F83F1,   278, 0x01F80399, 100, -55.25, 6, 1, 0, 0, 0, False, '2021-11-01 00:00:00'); /* Door */
/* @teleloc 0x01F80399 [100.000000 -55.250000 6.000000] 1.000000 0.000000 0.000000 0.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F83F2, 22082, 0x01F803C1, 119.253, -15.511, 6.005, -0.737952, 0, 0, -0.674853, False, '2021-11-01 00:00:00'); /* Alia Dunolmad */
/* @teleloc 0x01F803C1 [119.252998 -15.511000 6.005000] -0.737952 0.000000 0.000000 -0.674853 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F83F3, 38034, 0x01F80374, 93, -12, 6.005, 0.707107, 0, 0, -0.707107, False, '2021-11-01 00:00:00'); /* Roderick */
/* @teleloc 0x01F80374 [93.000000 -12.000000 6.005000] 0.707107 0.000000 0.000000 -0.707107 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F83F4,  2031, 0x01F801BA, 231.274, -120.043, -5.969, 0, 0, 0, -1,  True, '2021-11-01 00:00:00'); /* Branith's Staff */
/* @teleloc 0x01F801BA [231.274002 -120.042999 -5.969000] 0.000000 0.000000 0.000000 -1.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F83F5,  2032, 0x01F8039A, 96.7816, -123.55, 6, 0.707107, 0, 0, -0.707107,  True, '2021-11-01 00:00:00'); /* Branith's Shirt */
/* @teleloc 0x01F8039A [96.781601 -123.550003 6.000000] 0.707107 0.000000 0.000000 -0.707107 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F8428,   217, 0x01F8029B, 81.03, -109.96, 0.012, 0, 0, 0, -1,  True, '2021-11-01 00:00:00'); /* Gold Phyntos Wasp */
/* @teleloc 0x01F8029B [81.029999 -109.959999 0.012000] 0.000000 0.000000 0.000000 -1.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F8436,  5687, 0x01F80391, 96.9792, -39.7254, 6.0014, 0.679441, 0, 0, -0.73373,  True, '2021-11-01 00:00:00'); /* Alfrega the Reedshark */
/* @teleloc 0x01F80391 [96.979202 -39.725399 6.001400] 0.679441 0.000000 0.000000 -0.733730 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F843E,  5755, 0x01F803C0, 116.6, -9.32981, 6.0085, 0.157835, 0, 0, -0.987466,  True, '2021-11-01 00:00:00'); /* Cow */
/* @teleloc 0x01F803C0 [116.599998 -9.329810 6.008500] 0.157835 0.000000 0.000000 -0.987466 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F8440, 3483357, 0x01F801C2, 0.471802, -109.547, -0.026482, 0.325413, 0, 0, 0.945572, False, '2025-07-19 00:03:47'); /* Blue Glow Mushroom */
/* @teleloc 0x01F801C2 [0.471802 -109.546997 -0.026482] 0.325413 0.000000 0.000000 0.945572 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F8441, 3483357, 0x01F801C2, 4.37736, -109.547, -0.02675, 0.09381, 0, 0, 0.99559, False, '2025-07-19 00:04:41'); /* Blue Glow Mushroom */
/* @teleloc 0x01F801C2 [4.377360 -109.546997 -0.026750] 0.093810 0.000000 0.000000 0.995590 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F8442, 3483357, 0x01F80200, 31.7563, -100.838, -0.02675, -0.231368, 0, 0, 0.972866, False, '2025-07-19 00:05:45'); /* Blue Glow Mushroom */
/* @teleloc 0x01F80200 [31.756300 -100.837997 -0.026750] -0.231368 0.000000 0.000000 0.972866 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F8443, 3483357, 0x01F8021D, 36.2702, -100.859, -0.02675, 0.593003, 0, 0, 0.8052, False, '2025-07-19 00:06:19'); /* Blue Glow Mushroom */
/* @teleloc 0x01F8021D [36.270199 -100.859001 -0.026750] 0.593003 0.000000 0.000000 0.805200 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F8444, 3483357, 0x01F801C0, 1.36462, -86.963, 2.06753, 0.369887, 0, 0, -0.929077, False, '2025-07-19 00:06:54'); /* Blue Glow Mushroom */
/* @teleloc 0x01F801C0 [1.364620 -86.962997 2.067530] 0.369887 0.000000 0.000000 -0.929077 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F8446, 3483357, 0x01F801C0, -1.74152, -88.8679, 1.85227, 0.620784, 0, 0, -0.783982, False, '2025-07-19 00:07:15'); /* Blue Glow Mushroom */
/* @teleloc 0x01F801C0 [-1.741520 -88.867897 1.852270] 0.620784 0.000000 0.000000 -0.783982 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F8447, 8729957, 0x01F801C2, 1.7608, -105.201, -0.01425, -0.133525, 0, 0, -0.991046, False, '2025-07-19 00:11:42'); /* Red Burning Mushroom */
/* @teleloc 0x01F801C2 [1.760800 -105.200996 -0.014250] -0.133525 0.000000 0.000000 -0.991046 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F8448, 8729957, 0x01F801C0, 1.03475, -89.5229, 0.416933, -0.575138, 0, 0, -0.818056, False, '2025-07-19 00:12:11'); /* Red Burning Mushroom */
/* @teleloc 0x01F801C0 [1.034750 -89.522903 0.416933] -0.575138 0.000000 0.000000 -0.818056 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F8449, 8729957, 0x01F801C0, -1.82112, -91.9468, 1.22336, -0.08766, 0, 0, -0.99615, False, '2025-07-19 00:12:16'); /* Red Burning Mushroom */
/* @teleloc 0x01F801C0 [-1.821120 -91.946800 1.223360] -0.087660 0.000000 0.000000 -0.996150 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F844A, 8729957, 0x01F801C0, 3.51541, -88.1335, 1.25061, 0.956865, 0, 0, 0.290534, False, '2025-07-19 00:12:23'); /* Red Burning Mushroom */
/* @teleloc 0x01F801C0 [3.515410 -88.133499 1.250610] 0.956865 0.000000 0.000000 0.290534 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F844B, 8729957, 0x01F801D4, 8.64632, -97.4429, -0.01425, 0.804773, 0, 0, -0.593583, False, '2025-07-19 00:12:27'); /* Red Burning Mushroom */
/* @teleloc 0x01F801D4 [8.646320 -97.442902 -0.014250] 0.804773 0.000000 0.000000 -0.593583 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F844C, 8729957, 0x01F801E6, 15.8519, -98.5756, -0.01425, -0.977673, 0, 0, 0.210131, False, '2025-07-19 00:12:37'); /* Red Burning Mushroom */
/* @teleloc 0x01F801E6 [15.851900 -98.575600 -0.014250] -0.977673 0.000000 0.000000 0.210131 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F844D, 8729957, 0x01F80219, 39.2032, -88.5581, -0.01425, -0.811706, 0, 0, 0.584066, False, '2025-07-19 00:12:46'); /* Red Burning Mushroom */
/* @teleloc 0x01F80219 [39.203201 -88.558098 -0.014250] -0.811706 0.000000 0.000000 0.584066 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F844E, 8729957, 0x01F80219, 40.2411, -88.8556, -0.01425, -0.984947, 0, 0, 0.172856, False, '2025-07-19 00:12:51'); /* Red Burning Mushroom */
/* @teleloc 0x01F80219 [40.241100 -88.855598 -0.014250] -0.984947 0.000000 0.000000 0.172856 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F844F, 851657, 0x01F801D4, 7.3893, -96.5584, 0.055, 0.852289, 0, 0, -0.523072, False, '2025-07-19 00:28:31'); /* The Black Breath */
/* @teleloc 0x01F801D4 [7.389300 -96.558403 0.055000] 0.852289 0.000000 0.000000 -0.523072 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F8450, 851657, 0x01F801D5, 8.76791, -109.874, 0.059131, 0.242892, 0, 0, -0.970054, False, '2025-07-19 00:28:36'); /* The Black Breath */
/* @teleloc 0x01F801D5 [8.767910 -109.874001 0.059131] 0.242892 0.000000 0.000000 -0.970054 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F8451, 851657, 0x01F80200, 31.791, -97.1038, 0.055, -0.893108, 0, 0, 0.449842, False, '2025-07-19 00:29:55'); /* The Black Breath */
/* @teleloc 0x01F80200 [31.791000 -97.103798 0.055000] -0.893108 0.000000 0.000000 0.449842 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F8452, 851657, 0x01F8027F, 70.1735, -122.547, 0.055, -0.992922, 0, 0, 0.118768, False, '2025-07-19 00:31:05'); /* The Black Breath */
/* @teleloc 0x01F8027F [70.173500 -122.546997 0.055000] -0.992922 0.000000 0.000000 0.118768 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F8453, 851657, 0x01F802E1, 99.9413, -76.862, 0.055, -0.99731, 0, 0, 0.073306, False, '2025-07-19 00:31:22'); /* The Black Breath */
/* @teleloc 0x01F802E1 [99.941299 -76.862000 0.055000] -0.997310 0.000000 0.000000 0.073306 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F8454, 851657, 0x01F80109, 118.491, -40.3596, -5.945, -0.875593, 0, 0, 0.48305, False, '2025-07-19 00:31:36'); /* The Black Breath */
/* @teleloc 0x01F80109 [118.490997 -40.359600 -5.945000] -0.875593 0.000000 0.000000 0.483050 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F8455, 851657, 0x01F801B7, 220.664, -122.805, -5.945, -0.70611, 0, 0, 0.708102, False, '2025-07-19 00:32:21'); /* The Black Breath */
/* @teleloc 0x01F801B7 [220.664001 -122.805000 -5.945000] -0.706110 0.000000 0.000000 0.708102 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F8456, 851657, 0x01F801B9, 228.407, -111.538, -5.945, -0.951632, 0, 0, 0.30724, False, '2025-07-19 00:32:24'); /* The Black Breath */
/* @teleloc 0x01F801B9 [228.406998 -111.538002 -5.945000] -0.951632 0.000000 0.000000 0.307240 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F8457, 851657, 0x01F801A0, 204.216, -131.549, -5.945, 0.428593, 0, 0, 0.903498, False, '2025-07-19 00:32:29'); /* The Black Breath */
/* @teleloc 0x01F801A0 [204.216003 -131.548996 -5.945000] 0.428593 0.000000 0.000000 0.903498 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F8458, 851657, 0x01F80191, 190.037, -137.719, -5.945, 0.834991, 0, 0, 0.550264, False, '2025-07-19 00:32:31'); /* The Black Breath */
/* @teleloc 0x01F80191 [190.037003 -137.718994 -5.945000] 0.834991 0.000000 0.000000 0.550264 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F8459, 851657, 0x01F8017C, 181.36, -121.51, -5.945, 0.988774, 0, 0, 0.149422, False, '2025-07-19 00:32:34'); /* The Black Breath */
/* @teleloc 0x01F8017C [181.360001 -121.510002 -5.945000] 0.988774 0.000000 0.000000 0.149422 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F845A, 851657, 0x01F8018E, 188.947, -108.172, -5.945, 0.950972, 0, 0, -0.309276, False, '2025-07-19 00:32:35'); /* The Black Breath */
/* @teleloc 0x01F8018E [188.947006 -108.171997 -5.945000] 0.950972 0.000000 0.000000 -0.309276 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F845B, 851657, 0x01F80167, 176.695, -24.3943, -5.945, -0.966794, 0, 0, -0.255557, False, '2025-07-19 00:32:55'); /* The Black Breath */
/* @teleloc 0x01F80167 [176.695007 -24.394300 -5.945000] -0.966794 0.000000 0.000000 -0.255557 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F845C, 851657, 0x01F8015E, 174.489, -22.0201, -5.945, -0.869982, 0, 0, -0.493084, False, '2025-07-19 00:32:56'); /* The Black Breath */
/* @teleloc 0x01F8015E [174.488998 -22.020100 -5.945000] -0.869982 0.000000 0.000000 -0.493084 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F845D, 851657, 0x01F80142, 154.754, -13.7167, -5.945, -0.923749, 0, 0, -0.382998, False, '2025-07-19 00:32:58'); /* The Black Breath */
/* @teleloc 0x01F80142 [154.753998 -13.716700 -5.945000] -0.923749 0.000000 0.000000 -0.382998 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F845E, 851657, 0x01F80307, 108.752, -75.2854, 0.055, -0.439624, 0, 0, -0.898182, False, '2025-07-19 00:33:25'); /* The Black Breath */
/* @teleloc 0x01F80307 [108.751999 -75.285400 0.055000] -0.439624 0.000000 0.000000 -0.898182 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F845F, 851657, 0x01F8021D, 40.2019, -97.0625, 0.055, 0.99951, 0, 0, -0.031299, False, '2025-07-19 00:35:43'); /* The Black Breath */
/* @teleloc 0x01F8021D [40.201900 -97.062500 0.055000] 0.999510 0.000000 0.000000 -0.031299 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F8460, 851657, 0x01F80432, 51.4612, -49.0042, 12.055, 0.002443, 0, 0, -0.999997, False, '2025-07-19 00:37:58'); /* The Black Breath */
/* @teleloc 0x01F80432 [51.461201 -49.004200 12.055000] 0.002443 0.000000 0.000000 -0.999997 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F8461, 851657, 0x01F80433, 46.2174, -64.5891, 12.055, -0.459867, 0, 0, -0.887988, False, '2025-07-19 00:38:01'); /* The Black Breath */
/* @teleloc 0x01F80433 [46.217400 -64.589104 12.055000] -0.459867 0.000000 0.000000 -0.887988 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F8462, 851657, 0x01F80435, 52.3038, -75.7187, 12.055, -0.017263, 0, 0, -0.999851, False, '2025-07-19 00:38:03'); /* The Black Breath */
/* @teleloc 0x01F80435 [52.303799 -75.718697 12.055000] -0.017263 0.000000 0.000000 -0.999851 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F8463, 851657, 0x01F80445, 60.8893, -68.7617, 12.6684, 0.974772, 0, 0, -0.223204, False, '2025-07-19 00:38:08'); /* The Black Breath */
/* @teleloc 0x01F80445 [60.889301 -68.761703 12.668400] 0.974772 0.000000 0.000000 -0.223204 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F8464, 851657, 0x01F80443, 63.535, -54.4502, 14.2558, 0.999446, 0, 0, -0.033271, False, '2025-07-19 00:38:11'); /* The Black Breath */
/* @teleloc 0x01F80443 [63.535000 -54.450199 14.255800] 0.999446 0.000000 0.000000 -0.033271 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F8465, 3102157, 0x01F801D4, 9.68047, -98.5296, 0, 0.899612, 0, 0, -0.436691, False, '2025-07-19 01:00:01'); /* Puffball Thrungus */
/* @teleloc 0x01F801D4 [9.680470 -98.529602 0.000000] 0.899612 0.000000 0.000000 -0.436691 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F8466, 3102157, 0x01F801D4, 8.91708, -98.8838, 0, 0.998935, 0, 0, -0.046133, False, '2025-07-19 01:00:25'); /* Puffball Thrungus */
/* @teleloc 0x01F801D4 [8.917080 -98.883797 0.000000] 0.998935 0.000000 0.000000 -0.046133 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F8467, 3102157, 0x01F801C2, 2.0302, -107.344, 0, 0.085203, 0, 0, 0.996364, False, '2025-07-19 01:00:55'); /* Puffball Thrungus */
/* @teleloc 0x01F801C2 [2.030200 -107.344002 0.000000] 0.085203 0.000000 0.000000 0.996364 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F8468, 3102157, 0x01F801C2, 2.94104, -106.621, 0, 0.085203, 0, 0, 0.996364, False, '2025-07-19 01:00:57'); /* Puffball Thrungus */
/* @teleloc 0x01F801C2 [2.941040 -106.621002 0.000000] 0.085203 0.000000 0.000000 0.996364 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F8469, 3483357, 0x01F80418, 40.8566, -69.1448, 11.9733, 0.665623, 0, 0, 0.746288, False, '2025-07-19 01:23:05'); /* Blue Glow Mushroom */
/* @teleloc 0x01F80418 [40.856602 -69.144798 11.973300] 0.665623 0.000000 0.000000 0.746288 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F846A, 3483357, 0x01F80417, 41.5677, -61.3895, 11.9733, 0.995084, 0, 0, 0.099038, False, '2025-07-19 01:23:12'); /* Blue Glow Mushroom */
/* @teleloc 0x01F80417 [41.567699 -61.389500 11.973300] 0.995084 0.000000 0.000000 0.099038 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F846B, 3483357, 0x01F80435, 50.6161, -80.7476, 11.9733, 0.4171, 0, 0, 0.90886, False, '2025-07-19 01:23:22'); /* Blue Glow Mushroom */
/* @teleloc 0x01F80435 [50.616100 -80.747597 11.973300] 0.417100 0.000000 0.000000 0.908860 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F846C, 3483357, 0x01F80446, 58.5717, -77.8516, 11.9733, 0.1736, 0, 0, 0.984816, False, '2025-07-19 01:23:31'); /* Blue Glow Mushroom */
/* @teleloc 0x01F80446 [58.571701 -77.851601 11.973300] 0.173600 0.000000 0.000000 0.984816 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F846D, 3483357, 0x01F80443, 59.184, -51.4352, 11.9733, 0.997343, 0, 0, -0.072851, False, '2025-07-19 01:23:40'); /* Blue Glow Mushroom */
/* @teleloc 0x01F80443 [59.183998 -51.435200 11.973300] 0.997343 0.000000 0.000000 -0.072851 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F846E, 3483357, 0x01F80443, 60.3475, -50.2619, 12.4582, 0.840324, 0, 0, -0.542084, False, '2025-07-19 01:23:44'); /* Blue Glow Mushroom */
/* @teleloc 0x01F80443 [60.347500 -50.261902 12.458200] 0.840324 0.000000 0.000000 -0.542084 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F846F, 3483357, 0x01F80433, 54.1664, -62.4232, 11.9733, 0.579822, 0, 0, -0.814743, False, '2025-07-19 01:24:12'); /* Blue Glow Mushroom */
/* @teleloc 0x01F80433 [54.166401 -62.423199 11.973300] 0.579822 0.000000 0.000000 -0.814743 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F8470, 8729957, 0x01F80444, 56.2349, -60.6945, 11.9858, 0.508273, 0, 0, 0.861196, False, '2025-07-19 01:24:36'); /* Red Burning Mushroom */
/* @teleloc 0x01F80444 [56.234901 -60.694500 11.985800] 0.508273 0.000000 0.000000 0.861196 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F8471, 8729957, 0x01F80444, 57.0944, -63.1089, 11.9858, 0.871464, 0, 0, 0.49046, False, '2025-07-19 01:24:43'); /* Red Burning Mushroom */
/* @teleloc 0x01F80444 [57.094398 -63.108898 11.985800] 0.871464 0.000000 0.000000 0.490460 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F8472, 8729957, 0x01F80434, 54.6937, -65.4832, 11.9858, 0.958989, 0, 0, -0.283443, False, '2025-07-19 01:24:46'); /* Red Burning Mushroom */
/* @teleloc 0x01F80434 [54.693699 -65.483200 11.985800] 0.958989 0.000000 0.000000 -0.283443 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F8473, 8729957, 0x01F80434, 52.4547, -65.0568, 11.9858, 0.883562, 0, 0, -0.468314, False, '2025-07-19 01:24:50'); /* Red Burning Mushroom */
/* @teleloc 0x01F80434 [52.454700 -65.056801 11.985800] 0.883562 0.000000 0.000000 -0.468314 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F8474, 8729957, 0x01F80433, 51.4134, -63.5218, 11.9858, 0.883562, 0, 0, -0.468314, False, '2025-07-19 01:24:53'); /* Red Burning Mushroom */
/* @teleloc 0x01F80433 [51.413399 -63.521801 11.985800] 0.883562 0.000000 0.000000 -0.468314 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F8475, 8729957, 0x01F80433, 51.5839, -61.1356, 11.9858, 0.464805, 0, 0, -0.885413, False, '2025-07-19 01:24:57'); /* Red Burning Mushroom */
/* @teleloc 0x01F80433 [51.583900 -61.135601 11.985800] 0.464805 0.000000 0.000000 -0.885413 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F8476, 8729957, 0x01F80433, 53.6548, -59.2179, 11.9858, 0.008414, 0, 0, -0.999965, False, '2025-07-19 01:25:02'); /* Red Burning Mushroom */
/* @teleloc 0x01F80433 [53.654800 -59.217899 11.985800] 0.008414 0.000000 0.000000 -0.999965 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F8477, 8729957, 0x01F80417, 42.2039, -63.4491, 11.9858, -0.611484, 0, 0, -0.791257, False, '2025-07-19 01:25:07'); /* Red Burning Mushroom */
/* @teleloc 0x01F80417 [42.203899 -63.449100 11.985800] -0.611484 0.000000 0.000000 -0.791257 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F8478, 8729957, 0x01F80446, 57.9399, -75.2915, 11.9858, 0.398911, 0, 0, -0.91699, False, '2025-07-19 01:25:10'); /* Red Burning Mushroom */
/* @teleloc 0x01F80446 [57.939899 -75.291496 11.985800] 0.398911 0.000000 0.000000 -0.916990 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F8479, 8729957, 0x01F80446, 58.5059, -75.7524, 11.9858, 0.552473, 0, 0, -0.833531, False, '2025-07-19 01:25:11'); /* Red Burning Mushroom */
/* @teleloc 0x01F80446 [58.505901 -75.752403 11.985800] 0.552473 0.000000 0.000000 -0.833531 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F847A, 8729957, 0x01F80446, 63.3089, -79.9308, 14.1465, 0.353484, 0, 0, -0.935441, False, '2025-07-19 01:25:14'); /* Red Burning Mushroom */
/* @teleloc 0x01F80446 [63.308899 -79.930801 14.146500] 0.353484 0.000000 0.000000 -0.935441 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F847B, 8729957, 0x01F80446, 61.0789, -79.1599, 12.778, 0.353484, 0, 0, -0.935441, False, '2025-07-19 01:25:17'); /* Red Burning Mushroom */
/* @teleloc 0x01F80446 [61.078899 -79.159897 12.778000] 0.353484 0.000000 0.000000 -0.935441 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F847C, 8729957, 0x01F80446, 61.4623, -79.7513, 13.008, 0.353484, 0, 0, -0.935441, False, '2025-07-19 01:25:17'); /* Red Burning Mushroom */
/* @teleloc 0x01F80446 [61.462299 -79.751297 13.008000] 0.353484 0.000000 0.000000 -0.935441 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F847D, 8729957, 0x01F80443, 57.306, -52.5419, 11.9858, 0.997428, 0, 0, 0.071678, False, '2025-07-19 01:25:22'); /* Red Burning Mushroom */
/* @teleloc 0x01F80443 [57.306000 -52.541901 11.985800] 0.997428 0.000000 0.000000 0.071678 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F847E, 8729957, 0x01F80418, 38.7741, -69.3234, 12.8663, -0.299618, 0, 0, 0.954059, False, '2025-07-19 01:25:28'); /* Red Burning Mushroom */
/* @teleloc 0x01F80418 [38.774101 -69.323402 12.866300] -0.299618 0.000000 0.000000 0.954059 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F847F, 8729957, 0x01F80416, 37.3457, -48.4138, 12.0956, 0.800121, 0, 0, 0.599838, False, '2025-07-19 01:25:39'); /* Red Burning Mushroom */
/* @teleloc 0x01F80416 [37.345699 -48.413799 12.095600] 0.800121 0.000000 0.000000 0.599838 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F8480, 8729957, 0x01F803E7, 20.6469, -50.0387, 11.9858, -0.016244, 0, 0, 0.999868, False, '2025-07-19 01:25:44'); /* Red Burning Mushroom */
/* @teleloc 0x01F803E7 [20.646900 -50.038700 11.985800] -0.016244 0.000000 0.000000 0.999868 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F8481, 8729957, 0x01F803EA, 19.446, -61.2422, 11.9858, 0.584776, 0, 0, 0.811195, False, '2025-07-19 01:25:55'); /* Red Burning Mushroom */
/* @teleloc 0x01F803EA [19.445999 -61.242199 11.985800] 0.584776 0.000000 0.000000 0.811195 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F8482, 8729957, 0x01F803DC, 9.43989, -68.5155, 12.4358, 0.928936, 0, 0, -0.370241, False, '2025-07-19 01:26:00'); /* Red Burning Mushroom */
/* @teleloc 0x01F803DC [9.439890 -68.515503 12.435800] 0.928936 0.000000 0.000000 -0.370241 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F8483, 8729957, 0x01F80348, 9.99445, -49.8313, 5.98575, 0.987904, 0, 0, -0.15507, False, '2025-07-19 01:26:08'); /* Red Burning Mushroom */
/* @teleloc 0x01F80348 [9.994450 -49.831299 5.985750] 0.987904 0.000000 0.000000 -0.155070 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F8484, 8729957, 0x01F8020D, 41.402, -39.9668, -0.01425, -0.036185, 0, 0, -0.999345, False, '2025-07-19 01:26:19'); /* Red Burning Mushroom */
/* @teleloc 0x01F8020D [41.402000 -39.966801 -0.014250] -0.036185 0.000000 0.000000 -0.999345 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F8485, 8729957, 0x01F801F0, 30.8596, -48.8121, -0.01425, -0.997987, 0, 0, 0.063425, False, '2025-07-19 01:26:26'); /* Red Burning Mushroom */
/* @teleloc 0x01F801F0 [30.859600 -48.812099 -0.014250] -0.997987 0.000000 0.000000 0.063425 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F8486, 3483357, 0x01F801CB, 8.90003, -69.3866, 0.44905, -0.734917, 0, 0, 0.678157, False, '2025-07-19 01:27:16'); /* Blue Glow Mushroom */
/* @teleloc 0x01F801CB [8.900030 -69.386597 0.449050] -0.734917 0.000000 0.000000 0.678157 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F8487, 3483357, 0x01F803FD, 29.6778, -49.2539, 11.9733, -0.150394, 0, 0, 0.988626, False, '2025-07-19 01:27:54'); /* Blue Glow Mushroom */
/* @teleloc 0x01F803FD [29.677799 -49.253899 11.973300] -0.150394 0.000000 0.000000 0.988626 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F8488, 3102157, 0x01F803EA, 19.9793, -58.1054, 12, 0.783754, 0, 0, -0.621072, False, '2025-07-19 01:28:46'); /* Puffball Thrungus */
/* @teleloc 0x01F803EA [19.979300 -58.105400 12.000000] 0.783754 0.000000 0.000000 -0.621072 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F8489, 3102157, 0x01F803EA, 20.6644, -58.1404, 12, 0.991325, 0, 0, 0.131433, False, '2025-07-19 01:28:53'); /* Puffball Thrungus */
/* @teleloc 0x01F803EA [20.664400 -58.140400 12.000000] 0.991325 0.000000 0.000000 0.131433 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F848A, 3102157, 0x01F803EA, 21.0132, -61.4137, 12, 0.991325, 0, 0, 0.131433, False, '2025-07-19 01:28:56'); /* Puffball Thrungus */
/* @teleloc 0x01F803EA [21.013201 -61.413700 12.000000] 0.991325 0.000000 0.000000 0.131433 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F848B, 3102157, 0x01F803FD, 32.437, -49.4756, 12, 0.95125, 0, 0, 0.30842, False, '2025-07-19 01:29:01'); /* Puffball Thrungus */
/* @teleloc 0x01F803FD [32.437000 -49.475601 12.000000] 0.951250 0.000000 0.000000 0.308420 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F848C, 3102157, 0x01F803FD, 31.6504, -48.8567, 12, 0.859202, 0, 0, 0.511636, False, '2025-07-19 01:29:03'); /* Puffball Thrungus */
/* @teleloc 0x01F803FD [31.650400 -48.856701 12.000000] 0.859202 0.000000 0.000000 0.511636 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F848D, 3102157, 0x01F803FD, 32.6465, -48.1015, 12, 0.992778, 0, 0, 0.11997, False, '2025-07-19 01:29:06'); /* Puffball Thrungus */
/* @teleloc 0x01F803FD [32.646500 -48.101501 12.000000] 0.992778 0.000000 0.000000 0.119970 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F848E, 3102157, 0x01F80416, 35.8822, -48.1309, 12, 0.802766, 0, 0, -0.596294, False, '2025-07-19 01:29:09'); /* Puffball Thrungus */
/* @teleloc 0x01F80416 [35.882198 -48.130901 12.000000] 0.802766 0.000000 0.000000 -0.596294 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F848F, 3102157, 0x01F80432, 51.4246, -46.6032, 13.4413, 0.999066, 0, 0, -0.043202, False, '2025-07-19 01:29:14'); /* Puffball Thrungus */
/* @teleloc 0x01F80432 [51.424599 -46.603199 13.441300] 0.999066 0.000000 0.000000 -0.043202 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F8490, 3102157, 0x01F80432, 52.3088, -46.0822, 14.0202, 0.842863, 0, 0, -0.538129, False, '2025-07-19 01:29:15'); /* Puffball Thrungus */
/* @teleloc 0x01F80432 [52.308800 -46.082199 14.020200] 0.842863 0.000000 0.000000 -0.538129 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F8491, 3102157, 0x01F80417, 40.1213, -63.8143, 12.002, -0.953376, 0, 0, -0.301785, False, '2025-07-19 01:29:22'); /* Puffball Thrungus */
/* @teleloc 0x01F80417 [40.121300 -63.814301 12.002000] -0.953376 0.000000 0.000000 -0.301785 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F8492, 3102157, 0x01F80417, 37.6264, -63.3729, 13.4989, -0.598511, 0, 0, -0.801114, False, '2025-07-19 01:29:23'); /* Puffball Thrungus */
/* @teleloc 0x01F80417 [37.626400 -63.372898 13.498900] -0.598511 0.000000 0.000000 -0.801114 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F8493, 3102157, 0x01F80446, 59.6521, -80.8018, 12.5559, 0.778938, 0, 0, -0.627102, False, '2025-07-19 01:29:28'); /* Puffball Thrungus */
/* @teleloc 0x01F80446 [59.652100 -80.801804 12.555900] 0.778938 0.000000 0.000000 -0.627102 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F8494, 3102157, 0x01F80436, 48.854, -81.8944, 12, -0.652947, 0, 0, 0.757404, False, '2025-07-19 01:29:39'); /* Puffball Thrungus */
/* @teleloc 0x01F80436 [48.854000 -81.894402 12.000000] -0.652947 0.000000 0.000000 0.757404 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F8495, 3102157, 0x01F803D1, 1.83602, -64.4138, 11.7231, -0.95253, 0, 0, 0.304446, False, '2025-07-19 01:29:58'); /* Puffball Thrungus */
/* @teleloc 0x01F803D1 [1.836020 -64.413803 11.723100] -0.952530 0.000000 0.000000 0.304446 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F8496, 3102157, 0x01F803D1, 1.91026, -61.0927, 9.73041, -0.997522, 0, 0, 0.070359, False, '2025-07-19 01:29:59'); /* Puffball Thrungus */
/* @teleloc 0x01F803D1 [1.910260 -61.092701 9.730410] -0.997522 0.000000 0.000000 0.070359 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F8497, 3102157, 0x01F80348, 11.188, -48.5149, 6, -0.216923, 0, 0, 0.976189, False, '2025-07-19 01:30:02'); /* Puffball Thrungus */
/* @teleloc 0x01F80348 [11.188000 -48.514900 6.000000] -0.216923 0.000000 0.000000 0.976189 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F8498, 3102157, 0x01F80348, 10.3304, -47.8286, 6, -0.216923, 0, 0, 0.976189, False, '2025-07-19 01:30:05'); /* Puffball Thrungus */
/* @teleloc 0x01F80348 [10.330400 -47.828602 6.000000] -0.216923 0.000000 0.000000 0.976189 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F8499, 3102157, 0x01F801EA, 29.9804, -29.5334, 0, -0.92319, 0, 0, -0.384344, False, '2025-07-19 01:30:10'); /* Puffball Thrungus */
/* @teleloc 0x01F801EA [29.980400 -29.533400 0.000000] -0.923190 0.000000 0.000000 -0.384344 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F849A, 3102157, 0x01F801E2, 15.2355, -78.1259, 0, 0.809287, 0, 0, -0.587413, False, '2025-07-19 01:30:26'); /* Puffball Thrungus */
/* @teleloc 0x01F801E2 [15.235500 -78.125900 0.000000] 0.809287 0.000000 0.000000 -0.587413 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F849B, 3102157, 0x01F801C2, -2.61633, -110.053, 1.69582, 0.394867, 0, 0, -0.918738, False, '2025-07-19 01:30:46'); /* Puffball Thrungus */
/* @teleloc 0x01F801C2 [-2.616330 -110.053001 1.695820] 0.394867 0.000000 0.000000 -0.918738 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F849C, 3102157, 0x01F801C2, 0.088371, -113.309, 2.05996, 0.390887, 0, 0, -0.920439, False, '2025-07-19 01:30:47'); /* Puffball Thrungus */
/* @teleloc 0x01F801C2 [0.088371 -113.308998 2.059960] 0.390887 0.000000 0.000000 -0.920439 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F849D, 3102157, 0x01F801C2, 2.96025, -113.479, 2.16194, 0.69084, 0, 0, -0.723008, False, '2025-07-19 01:30:48'); /* Puffball Thrungus */
/* @teleloc 0x01F801C2 [2.960250 -113.478996 2.161940] 0.690840 0.000000 0.000000 -0.723008 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F849E, 3102157, 0x01F801D5, 6.60071, -112.82, 1.76661, 0.76764, 0, 0, -0.640882, False, '2025-07-19 01:30:49'); /* Puffball Thrungus */
/* @teleloc 0x01F801D5 [6.600710 -112.820000 1.766610] 0.767640 0.000000 0.000000 -0.640882 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F849F, 3102157, 0x01F801D5, 7.08361, -111.138, 0.757778, 0.995784, 0, 0, 0.091725, False, '2025-07-19 01:30:51'); /* Puffball Thrungus */
/* @teleloc 0x01F801D5 [7.083610 -111.138000 0.757778] 0.995784 0.000000 0.000000 0.091725 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F84A0, 3102157, 0x01F801C2, 4.07433, -111.282, 0.844114, 0.599124, 0, 0, 0.800656, False, '2025-07-19 01:30:52'); /* Puffball Thrungus */
/* @teleloc 0x01F801C2 [4.074330 -111.281998 0.844114] 0.599124 0.000000 0.000000 0.800656 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F84A1, 3102157, 0x01F801C0, 4.6934, -87.3621, 1.65754, -0.97612, 0, 0, -0.217234, False, '2025-07-19 01:31:00'); /* Puffball Thrungus */
/* @teleloc 0x01F801C0 [4.693400 -87.362099 1.657540] -0.976120 0.000000 0.000000 -0.217234 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F84A2, 3102157, 0x01F801C1, 0.580428, -104.053, 0, -0.164535, 0, 0, -0.986371, False, '2025-07-19 01:31:06'); /* Puffball Thrungus */
/* @teleloc 0x01F801C1 [0.580428 -104.053001 0.000000] -0.164535 0.000000 0.000000 -0.986371 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F84A3, 3102157, 0x01F801E6, 16.8181, -97.3239, 0, -0.555035, 0, 0, -0.831827, False, '2025-07-19 01:31:28'); /* Puffball Thrungus */
/* @teleloc 0x01F801E6 [16.818100 -97.323898 0.000000] -0.555035 0.000000 0.000000 -0.831827 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F84A4, 3102157, 0x01F80200, 31.832, -103.581, 0, 0.935159, 0, 0, -0.354229, False, '2025-07-19 01:31:34'); /* Puffball Thrungus */
/* @teleloc 0x01F80200 [31.832001 -103.581001 0.000000] 0.935159 0.000000 0.000000 -0.354229 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F84A5, 3102157, 0x01F80224, 41.1866, -113.301, 0, 0.940989, 0, 0, -0.338438, False, '2025-07-19 01:31:42'); /* Puffball Thrungus */
/* @teleloc 0x01F80224 [41.186600 -113.301003 0.000000] 0.940989 0.000000 0.000000 -0.338438 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F84A6, 3102157, 0x01F80221, 41.1359, -111.008, 0, 0.13046, 0, 0, -0.991454, False, '2025-07-19 01:31:46'); /* Puffball Thrungus */
/* @teleloc 0x01F80221 [41.135899 -111.008003 0.000000] 0.130460 0.000000 0.000000 -0.991454 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F84A7, 3102157, 0x01F8040C, 33.7049, -110.907, 12, -0.131611, 0, 0, 0.991302, False, '2025-07-19 01:33:06'); /* Puffball Thrungus */
/* @teleloc 0x01F8040C [33.704899 -110.906998 12.000000] -0.131611 0.000000 0.000000 0.991302 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F84A8, 3102157, 0x01F80428, 39.3276, -117.425, 12, 0.174314, 0, 0, 0.98469, False, '2025-07-19 01:33:09'); /* Puffball Thrungus */
/* @teleloc 0x01F80428 [39.327599 -117.425003 12.000000] 0.174314 0.000000 0.000000 0.984690 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F84A9, 3102157, 0x01F80430, 39.7428, -127.4, 12, 0.124406, 0, 0, 0.992232, False, '2025-07-19 01:33:12'); /* Puffball Thrungus */
/* @teleloc 0x01F80430 [39.742802 -127.400002 12.000000] 0.124406 0.000000 0.000000 0.992232 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F84AA, 3102157, 0x01F80414, 29.4146, -127.542, 12, 0.708386, 0, 0, 0.705825, False, '2025-07-19 01:33:16'); /* Puffball Thrungus */
/* @teleloc 0x01F80414 [29.414600 -127.542000 12.000000] 0.708386 0.000000 0.000000 0.705825 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F84AB, 3102157, 0x01F803FA, 15.8577, -120.814, 12, 0.035772, 0, 0, 0.99936, False, '2025-07-19 01:33:20'); /* Puffball Thrungus */
/* @teleloc 0x01F803FA [15.857700 -120.814003 12.000000] 0.035772 0.000000 0.000000 0.999360 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F84AC, 3102157, 0x01F8034F, 31.0181, -124.968, 6.05589, -0.547681, 0, 0, 0.836687, False, '2025-07-19 01:33:26'); /* Puffball Thrungus */
/* @teleloc 0x01F8034F [31.018101 -124.968002 6.055890] -0.547681 0.000000 0.000000 0.836687 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F84AD, 3102157, 0x01F80299, 80.4594, -103.386, 0, 0.837013, 0, 0, -0.547183, False, '2025-07-19 01:33:54'); /* Puffball Thrungus */
/* @teleloc 0x01F80299 [80.459396 -103.386002 0.000000] 0.837013 0.000000 0.000000 -0.547183 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F84AE, 3102157, 0x01F80298, 80.5581, -92.2175, 0, 0.977026, 0, 0, 0.21312, False, '2025-07-19 01:34:09'); /* Puffball Thrungus */
/* @teleloc 0x01F80298 [80.558098 -92.217499 0.000000] 0.977026 0.000000 0.000000 0.213120 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F84AF, 3102157, 0x01F80290, 80.648, -77.023, 0, 0.861866, 0, 0, -0.507137, False, '2025-07-19 01:34:15'); /* Puffball Thrungus */
/* @teleloc 0x01F80290 [80.648003 -77.023003 0.000000] 0.861866 0.000000 0.000000 -0.507137 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F84B0, 3102157, 0x01F802DF, 100.426, -73.18, 0, 0.853207, 0, 0, -0.521572, False, '2025-07-19 01:34:21'); /* Puffball Thrungus */
/* @teleloc 0x01F802DF [100.426003 -73.180000 0.000000] 0.853207 0.000000 0.000000 -0.521572 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F84B1, 3102157, 0x01F802DC, 98.4926, -55.9956, 0, 0.979516, 0, 0, 0.201366, False, '2025-07-19 01:34:28'); /* Puffball Thrungus */
/* @teleloc 0x01F802DC [98.492599 -55.995602 0.000000] 0.979516 0.000000 0.000000 0.201366 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F84B2, 3102157, 0x01F802B7, 92.6226, -59.32, 0, 0.94474, 0, 0, 0.32782, False, '2025-07-19 01:34:32'); /* Puffball Thrungus */
/* @teleloc 0x01F802B7 [92.622597 -59.320000 0.000000] 0.944740 0.000000 0.000000 0.327820 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F84B3, 3102157, 0x01F8028B, 79.4823, -57.8326, 0, 0.609218, 0, 0, 0.793003, False, '2025-07-19 01:34:36'); /* Puffball Thrungus */
/* @teleloc 0x01F8028B [79.482300 -57.832600 0.000000] 0.609218 0.000000 0.000000 0.793003 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F84B4, 3102157, 0x01F80231, 49.9378, -49.9664, 0.155546, 0.851093, 0, 0, 0.525015, False, '2025-07-19 01:34:42'); /* Puffball Thrungus */
/* @teleloc 0x01F80231 [49.937801 -49.966400 0.155546] 0.851093 0.000000 0.000000 0.525015 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F84B5, 3102157, 0x01F80231, 51.0427, -48.1119, 1.20764, 0.94852, 0, 0, -0.316718, False, '2025-07-19 01:34:44'); /* Puffball Thrungus */
/* @teleloc 0x01F80231 [51.042702 -48.111900 1.207640] 0.948520 0.000000 0.000000 -0.316718 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F84B6, 3102157, 0x01F80231, 48.6867, -49.517, 1.08599, 0.461002, 0, 0, 0.887399, False, '2025-07-19 01:34:46'); /* Puffball Thrungus */
/* @teleloc 0x01F80231 [48.686699 -49.516998 1.085990] 0.461002 0.000000 0.000000 0.887399 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F84B7, 3102157, 0x01F80231, 47.2919, -51.6669, 1.69963, 0.26487, 0, 0, 0.964284, False, '2025-07-19 01:34:47'); /* Puffball Thrungus */
/* @teleloc 0x01F80231 [47.291901 -51.666901 1.699630] 0.264870 0.000000 0.000000 0.964284 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F84B8, 3102157, 0x01F801F4, 32.5283, -61.6027, 0, -0.525599, 0, 0, -0.850733, False, '2025-07-19 01:34:57'); /* Puffball Thrungus */
/* @teleloc 0x01F801F4 [32.528301 -61.602699 0.000000] -0.525599 0.000000 0.000000 -0.850733 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F84B9, 3102157, 0x01F801F6, 28.1255, -56.8232, 0, -0.948392, 0, 0, -0.317101, False, '2025-07-19 01:34:59'); /* Puffball Thrungus */
/* @teleloc 0x01F801F6 [28.125500 -56.823200 0.000000] -0.948392 0.000000 0.000000 -0.317101 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F84BA, 3102157, 0x01F803DC, 10.6483, -68.0252, 12.8876, 0.909548, 0, 0, 0.415598, False, '2025-07-19 01:35:16'); /* Puffball Thrungus */
/* @teleloc 0x01F803DC [10.648300 -68.025200 12.887600] 0.909548 0.000000 0.000000 0.415598 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F84BB, 3102157, 0x01F803DC, 11.087, -68.7293, 12.111, 0.961441, 0, 0, 0.27501, False, '2025-07-19 01:35:18'); /* Puffball Thrungus */
/* @teleloc 0x01F803DC [11.087000 -68.729301 12.111000] 0.961441 0.000000 0.000000 0.275010 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F84BC, 3102157, 0x01F802F5, 112.112, -18.1648, 0, -0.747271, 0, 0, 0.664519, False, '2025-07-19 01:35:54'); /* Puffball Thrungus */
/* @teleloc 0x01F802F5 [112.112000 -18.164801 0.000000] -0.747271 0.000000 0.000000 0.664519 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F84BD, 3102157, 0x01F802F5, 111.433, -18.2448, 0, -0.747271, 0, 0, 0.664519, False, '2025-07-19 01:35:55'); /* Puffball Thrungus */
/* @teleloc 0x01F802F5 [111.432999 -18.244801 0.000000] -0.747271 0.000000 0.000000 0.664519 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F84BE, 3102157, 0x01F802F5, 111.103, -18.9361, 0, -0.747271, 0, 0, 0.664519, False, '2025-07-19 01:35:57'); /* Puffball Thrungus */
/* @teleloc 0x01F802F5 [111.102997 -18.936100 0.000000] -0.747271 0.000000 0.000000 0.664519 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F84BF, 3102157, 0x01F80117, 131.57, -22.3357, -6, -0.305344, 0, 0, 0.952242, False, '2025-07-19 01:36:00'); /* Puffball Thrungus */
/* @teleloc 0x01F80117 [131.570007 -22.335699 -6.000000] -0.305344 0.000000 0.000000 0.952242 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F84C0, 3102157, 0x01F80133, 141.119, -27.7395, -6, -0.765199, 0, 0, 0.643794, False, '2025-07-19 01:36:02'); /* Puffball Thrungus */
/* @teleloc 0x01F80133 [141.119003 -27.739500 -6.000000] -0.765199 0.000000 0.000000 0.643794 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F84C1, 3102157, 0x01F80133, 141.896, -30.9687, -6, -0.088547, 0, 0, 0.996072, False, '2025-07-19 01:36:03'); /* Puffball Thrungus */
/* @teleloc 0x01F80133 [141.895996 -30.968700 -6.000000] -0.088547 0.000000 0.000000 0.996072 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F84C2, 3102157, 0x01F8012D, 138.241, -12.0765, -6, -0.98743, 0, 0, -0.15806, False, '2025-07-19 01:36:06'); /* Puffball Thrungus */
/* @teleloc 0x01F8012D [138.240997 -12.076500 -6.000000] -0.987430 0.000000 0.000000 -0.158060 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F84C3, 3102157, 0x01F8012D, 138.241, -12.0765, -6, -0.98743, 0, 0, -0.15806, False, '2025-07-19 01:36:08'); /* Puffball Thrungus */
/* @teleloc 0x01F8012D [138.240997 -12.076500 -6.000000] -0.987430 0.000000 0.000000 -0.158060 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F84C4, 3102157, 0x01F8012D, 140.458, -10.2542, -6, -0.343085, 0, 0, 0.939305, False, '2025-07-19 01:36:09'); /* Puffball Thrungus */
/* @teleloc 0x01F8012D [140.457993 -10.254200 -6.000000] -0.343085 0.000000 0.000000 0.939305 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F84C5, 3102157, 0x01F8012D, 141.967, -12.5956, -6, 0.26487, 0, 0, 0.964284, False, '2025-07-19 01:36:10'); /* Puffball Thrungus */
/* @teleloc 0x01F8012D [141.966995 -12.595600 -6.000000] 0.264870 0.000000 0.000000 0.964284 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F84C6, 3483357, 0x01F8015E, 170.598, -22.1746, -6.02675, 0.976826, 0, 0, 0.214034, False, '2025-07-19 01:36:45'); /* Blue Glow Mushroom */
/* @teleloc 0x01F8015E [170.598007 -22.174601 -6.026750] 0.976826 0.000000 0.000000 0.214034 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F84C7, 3483357, 0x01F8015E, 165.978, -21.6973, -6.02675, 0.970595, 0, 0, 0.240719, False, '2025-07-19 01:36:48'); /* Blue Glow Mushroom */
/* @teleloc 0x01F8015E [165.977997 -21.697300 -6.026750] 0.970595 0.000000 0.000000 0.240719 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F84C8, 3483357, 0x01F8015E, 169.561, -17.0996, -6.02675, -0.227822, 0, 0, -0.973703, False, '2025-07-19 01:36:52'); /* Blue Glow Mushroom */
/* @teleloc 0x01F8015E [169.561005 -17.099600 -6.026750] -0.227822 0.000000 0.000000 -0.973703 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F84C9, 3483357, 0x01F80156, 162.341, -39.9897, -5.76086, 0.986406, 0, 0, -0.164327, False, '2025-07-19 01:37:02'); /* Blue Glow Mushroom */
/* @teleloc 0x01F80156 [162.341003 -39.989700 -5.760860] 0.986406 0.000000 0.000000 -0.164327 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F84CA, 3483357, 0x01F80142, 152.15, -13.1096, -6.02675, 0.660854, 0, 0, 0.750514, False, '2025-07-19 01:37:14'); /* Blue Glow Mushroom */
/* @teleloc 0x01F80142 [152.149994 -13.109600 -6.026750] 0.660854 0.000000 0.000000 0.750514 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F84CB, 3483357, 0x01F8012D, 137.089, -8.60688, -6.02675, 0.935086, 0, 0, 0.354421, False, '2025-07-19 01:37:19'); /* Blue Glow Mushroom */
/* @teleloc 0x01F8012D [137.089005 -8.606880 -6.026750] 0.935086 0.000000 0.000000 0.354421 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F84CC, 8729957, 0x01F8015E, 166.753, -18.0115, -6.01425, 0.483577, 0, 0, -0.875302, False, '2025-07-19 01:37:51'); /* Red Burning Mushroom */
/* @teleloc 0x01F8015E [166.753006 -18.011499 -6.014250] 0.483577 0.000000 0.000000 -0.875302 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F84CD, 8729957, 0x01F8015E, 165.689, -19.705, -6.01425, 0.483577, 0, 0, -0.875302, False, '2025-07-19 01:37:55'); /* Red Burning Mushroom */
/* @teleloc 0x01F8015E [165.688995 -19.705000 -6.014250] 0.483577 0.000000 0.000000 -0.875302 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F84CE, 8729957, 0x01F80155, 162.905, -28.5565, -6.01425, -0.261881, 0, 0, -0.9651, False, '2025-07-19 01:38:00'); /* Red Burning Mushroom */
/* @teleloc 0x01F80155 [162.904999 -28.556499 -6.014250] -0.261881 0.000000 0.000000 -0.965100 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F84CF, 8729957, 0x01F80156, 164.05, -38.2301, -6.01425, 0.084927, 0, 0, -0.996387, False, '2025-07-19 01:38:03'); /* Red Burning Mushroom */
/* @teleloc 0x01F80156 [164.050003 -38.230099 -6.014250] 0.084927 0.000000 0.000000 -0.996387 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F84D0, 8729957, 0x01F80168, 177.104, -26.0376, -6.01425, 0.787453, 0, 0, -0.616375, False, '2025-07-19 01:38:07'); /* Red Burning Mushroom */
/* @teleloc 0x01F80168 [177.104004 -26.037600 -6.014250] 0.787453 0.000000 0.000000 -0.616375 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F84D1, 8729957, 0x01F8016B, 183.975, -41.5862, -5.90419, 0.577214, 0, 0, -0.816593, False, '2025-07-19 01:38:10'); /* Red Burning Mushroom */
/* @teleloc 0x01F8016B [183.975006 -41.586201 -5.904190] 0.577214 0.000000 0.000000 -0.816593 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F84D2, 8729957, 0x01F8016F, 184.947, -51.1583, -6.01425, -0.505835, 0, 0, -0.86263, False, '2025-07-19 01:38:14'); /* Red Burning Mushroom */
/* @teleloc 0x01F8016F [184.947006 -51.158298 -6.014250] -0.505835 0.000000 0.000000 -0.862630 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F84D3, 8729957, 0x01F80166, 168.413, -65.0464, -5.9018, -0.353777, 0, 0, -0.93533, False, '2025-07-19 01:38:17'); /* Red Burning Mushroom */
/* @teleloc 0x01F80166 [168.412994 -65.046402 -5.901800] -0.353777 0.000000 0.000000 -0.935330 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F84D4, 8729957, 0x01F80166, 168.413, -65.0464, -5.9018, -0.353777, 0, 0, -0.93533, False, '2025-07-19 01:38:18'); /* Red Burning Mushroom */
/* @teleloc 0x01F80166 [168.412994 -65.046402 -5.901800] -0.353777 0.000000 0.000000 -0.935330 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F84D5, 8729957, 0x01F801A9, 213.43, -73.0502, -6.01425, 0.219279, 0, 0, -0.975662, False, '2025-07-19 01:38:26'); /* Red Burning Mushroom */
/* @teleloc 0x01F801A9 [213.429993 -73.050201 -6.014250] 0.219279 0.000000 0.000000 -0.975662 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F84D6, 8729957, 0x01F8018D, 187.18, -103.184, -6.01425, -0.229261, 0, 0, -0.973365, False, '2025-07-19 01:38:33'); /* Red Burning Mushroom */
/* @teleloc 0x01F8018D [187.179993 -103.183998 -6.014250] -0.229261 0.000000 0.000000 -0.973365 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F84D7, 8729957, 0x01F8018D, 187.18, -103.184, -6.01425, -0.229261, 0, 0, -0.973365, False, '2025-07-19 01:38:35'); /* Red Burning Mushroom */
/* @teleloc 0x01F8018D [187.179993 -103.183998 -6.014250] -0.229261 0.000000 0.000000 -0.973365 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F84D8, 8729957, 0x01F8018F, 191.02, -116.338, -6.01425, -0.604479, 0, 0, -0.796621, False, '2025-07-19 01:38:38'); /* Red Burning Mushroom */
/* @teleloc 0x01F8018F [191.020004 -116.337997 -6.014250] -0.604479 0.000000 0.000000 -0.796621 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F84D9, 8729957, 0x01F8017C, 176.867, -116.91, -6.01425, -0.475694, 0, 0, -0.879611, False, '2025-07-19 01:38:42'); /* Red Burning Mushroom */
/* @teleloc 0x01F8017C [176.867004 -116.910004 -6.014250] -0.475694 0.000000 0.000000 -0.879611 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F84DA, 8729957, 0x01F8017D, 180.061, -128.806, -6.01425, 0.091136, 0, 0, -0.995839, False, '2025-07-19 01:38:44'); /* Red Burning Mushroom */
/* @teleloc 0x01F8017D [180.061005 -128.806000 -6.014250] 0.091136 0.000000 0.000000 -0.995839 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F84DB, 8729957, 0x01F80190, 191.294, -133.576, -6.01425, 0.574452, 0, 0, -0.818538, False, '2025-07-19 01:38:47'); /* Red Burning Mushroom */
/* @teleloc 0x01F80190 [191.294006 -133.576004 -6.014250] 0.574452 0.000000 0.000000 -0.818538 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F84DC, 8729957, 0x01F80191, 187.498, -142.261, -6.01425, -0.294681, 0, 0, -0.955596, False, '2025-07-19 01:38:49'); /* Red Burning Mushroom */
/* @teleloc 0x01F80191 [187.498001 -142.261002 -6.014250] -0.294681 0.000000 0.000000 -0.955596 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F84DD, 8729957, 0x01F801B4, 206.337, -124.954, -6.01425, 0.96118, 0, 0, -0.275922, False, '2025-07-19 01:38:52'); /* Red Burning Mushroom */
/* @teleloc 0x01F801B4 [206.337006 -124.954002 -6.014250] 0.961180 0.000000 0.000000 -0.275922 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F84DE, 8729957, 0x01F801BB, 228.26, -133.379, -6.01425, 0.709536, 0, 0, -0.70467, False, '2025-07-19 01:38:55'); /* Red Burning Mushroom */
/* @teleloc 0x01F801BB [228.259995 -133.378998 -6.014250] 0.709536 0.000000 0.000000 -0.704670 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F84DF, 8729957, 0x01F801B6, 219.783, -112.771, -6.01425, 0.876317, 0, 0, -0.481735, False, '2025-07-19 01:38:59'); /* Red Burning Mushroom */
/* @teleloc 0x01F801B6 [219.783005 -112.771004 -6.014250] 0.876317 0.000000 0.000000 -0.481735 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F84E0, 8729957, 0x01F801B9, 230.914, -107.371, -6.01425, 0.732516, 0, 0, -0.68075, False, '2025-07-19 01:39:02'); /* Red Burning Mushroom */
/* @teleloc 0x01F801B9 [230.914001 -107.371002 -6.014250] 0.732516 0.000000 0.000000 -0.680750 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F84E1, 8729957, 0x01F801BB, 233.862, -129.02, -6.01425, 0.166883, 0, 0, -0.985977, False, '2025-07-19 01:39:08'); /* Red Burning Mushroom */
/* @teleloc 0x01F801BB [233.862000 -129.020004 -6.014250] 0.166883 0.000000 0.000000 -0.985977 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F84E2, 3483357, 0x01F801B6, 222.938, -111.981, -6.02675, 0.999341, 0, 0, 0.036288, False, '2025-07-19 01:39:20'); /* Blue Glow Mushroom */
/* @teleloc 0x01F801B6 [222.938004 -111.981003 -6.026750] 0.999341 0.000000 0.000000 0.036288 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F84E3, 3483357, 0x01F801B9, 228.178, -109.045, -6.02675, 0.686811, 0, 0, -0.726836, False, '2025-07-19 01:39:25'); /* Blue Glow Mushroom */
/* @teleloc 0x01F801B9 [228.177994 -109.044998 -6.026750] 0.686811 0.000000 0.000000 -0.726836 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F84E4, 3483357, 0x01F801B9, 230.925, -111.519, -5.945, 0.964674, 0, 0, -0.263446, False, '2025-07-19 01:39:30'); /* Blue Glow Mushroom */
/* @teleloc 0x01F801B9 [230.925003 -111.518997 -5.945000] 0.964674 0.000000 0.000000 -0.263446 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F84E5, 3483357, 0x01F801BB, 232.123, -131.749, -6.02675, -0.282723, 0, 0, 0.959202, False, '2025-07-19 01:39:35'); /* Blue Glow Mushroom */
/* @teleloc 0x01F801BB [232.123001 -131.748993 -6.026750] -0.282723 0.000000 0.000000 0.959202 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F84E6, 3483357, 0x01F801B4, 210.721, -123.869, -6.02675, 0.964426, 0, 0, 0.264354, False, '2025-07-19 01:39:41'); /* Blue Glow Mushroom */
/* @teleloc 0x01F801B4 [210.720993 -123.869003 -6.026750] 0.964426 0.000000 0.000000 0.264354 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F84E7, 3483357, 0x01F801B5, 209.785, -133.363, -6.02675, 0.671299, 0, 0, 0.741187, False, '2025-07-19 01:39:45'); /* Blue Glow Mushroom */
/* @teleloc 0x01F801B5 [209.785004 -133.363007 -6.026750] 0.671299 0.000000 0.000000 0.741187 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F84E8, 3483357, 0x01F80191, 194.371, -143.314, -6.02675, 0.409171, 0, 0, 0.912458, False, '2025-07-19 01:39:50'); /* Blue Glow Mushroom */
/* @teleloc 0x01F80191 [194.371002 -143.313995 -6.026750] 0.409171 0.000000 0.000000 0.912458 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F84E9, 3483357, 0x01F80191, 186.793, -139.414, -6.02675, 0.668456, 0, 0, 0.743752, False, '2025-07-19 01:39:56'); /* Blue Glow Mushroom */
/* @teleloc 0x01F80191 [186.792999 -139.414001 -6.026750] 0.668456 0.000000 0.000000 0.743752 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F84EA, 3483357, 0x01F8017B, 179.486, -113.282, -6.02675, 0.473008, 0, 0, 0.881058, False, '2025-07-19 01:40:05'); /* Blue Glow Mushroom */
/* @teleloc 0x01F8017B [179.485992 -113.281998 -6.026750] 0.473008 0.000000 0.000000 0.881058 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F84EB, 3102157, 0x01F801B9, 227.4, -113.534, -6, -0.953344, 0, 0, -0.301886, False, '2025-07-19 01:40:45'); /* Puffball Thrungus */
/* @teleloc 0x01F801B9 [227.399994 -113.533997 -6.000000] -0.953344 0.000000 0.000000 -0.301886 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F84EC, 3102157, 0x01F801B9, 227.427, -112.179, -6, -0.970541, 0, 0, 0.240936, False, '2025-07-19 01:40:48'); /* Puffball Thrungus */
/* @teleloc 0x01F801B9 [227.427002 -112.179001 -6.000000] -0.970541 0.000000 0.000000 0.240936 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F84ED, 3102157, 0x01F801B9, 226.39, -111.865, -6, -0.970541, 0, 0, 0.240936, False, '2025-07-19 01:40:49'); /* Puffball Thrungus */
/* @teleloc 0x01F801B9 [226.389999 -111.864998 -6.000000] -0.970541 0.000000 0.000000 0.240936 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F84EE, 3102157, 0x01F801B9, 225.173, -112.5, -6, -0.970541, 0, 0, 0.240936, False, '2025-07-19 01:40:51'); /* Puffball Thrungus */
/* @teleloc 0x01F801B9 [225.173004 -112.500000 -6.000000] -0.970541 0.000000 0.000000 0.240936 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F84EF, 3102157, 0x01F801B9, 225.001, -112.825, -6, -0.970541, 0, 0, 0.240936, False, '2025-07-19 01:40:52'); /* Puffball Thrungus */
/* @teleloc 0x01F801B9 [225.001007 -112.824997 -6.000000] -0.970541 0.000000 0.000000 0.240936 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F84F0, 3102157, 0x01F801B6, 220.782, -113.967, -6, -0.998753, 0, 0, -0.049917, False, '2025-07-19 01:40:55'); /* Puffball Thrungus */
/* @teleloc 0x01F801B6 [220.781998 -113.967003 -6.000000] -0.998753 0.000000 0.000000 -0.049917 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F84F1, 3102157, 0x01F801B6, 219.12, -114.472, -6, -0.912644, 0, 0, -0.408755, False, '2025-07-19 01:40:58'); /* Puffball Thrungus */
/* @teleloc 0x01F801B6 [219.119995 -114.472000 -6.000000] -0.912644 0.000000 0.000000 -0.408755 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F84F2, 3102157, 0x01F801B6, 217.115, -113.567, -6, -0.953742, 0, 0, 0.300627, False, '2025-07-19 01:41:02'); /* Puffball Thrungus */
/* @teleloc 0x01F801B6 [217.115005 -113.567001 -6.000000] -0.953742 0.000000 0.000000 0.300627 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F84F3, 3102157, 0x01F801B4, 210.554, -121.75, -6, 0.57878, 0, 0, 0.815484, False, '2025-07-19 01:41:07'); /* Puffball Thrungus */
/* @teleloc 0x01F801B4 [210.554001 -121.750000 -6.000000] 0.578780 0.000000 0.000000 0.815484 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F84F4, 3102157, 0x01F801BB, 227.886, -131.948, -6, -0.791959, 0, 0, 0.610574, False, '2025-07-19 01:41:13'); /* Puffball Thrungus */
/* @teleloc 0x01F801BB [227.886002 -131.947998 -6.000000] -0.791959 0.000000 0.000000 0.610574 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F84F5, 3102157, 0x01F801BB, 227.886, -131.948, -6, -0.791959, 0, 0, 0.610574, False, '2025-07-19 01:41:14'); /* Puffball Thrungus */
/* @teleloc 0x01F801BB [227.886002 -131.947998 -6.000000] -0.791959 0.000000 0.000000 0.610574 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F84F6, 3102157, 0x01F801BB, 227.886, -131.948, -6, -0.791959, 0, 0, 0.610574, False, '2025-07-19 01:41:15'); /* Puffball Thrungus */
/* @teleloc 0x01F801BB [227.886002 -131.947998 -6.000000] -0.791959 0.000000 0.000000 0.610574 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F84F7, 3102157, 0x01F801BB, 229.939, -130.522, -6, -0.886169, 0, 0, 0.463362, False, '2025-07-19 01:41:16'); /* Puffball Thrungus */
/* @teleloc 0x01F801BB [229.938995 -130.522003 -6.000000] -0.886169 0.000000 0.000000 0.463362 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F84F8, 3102157, 0x01F801BB, 229.939, -130.522, -6, -0.886169, 0, 0, 0.463362, False, '2025-07-19 01:41:18'); /* Puffball Thrungus */
/* @teleloc 0x01F801BB [229.938995 -130.522003 -6.000000] -0.886169 0.000000 0.000000 0.463362 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F84F9, 3102157, 0x01F801BB, 229.939, -130.522, -6, -0.886169, 0, 0, 0.463362, False, '2025-07-19 01:41:19'); /* Puffball Thrungus */
/* @teleloc 0x01F801BB [229.938995 -130.522003 -6.000000] -0.886169 0.000000 0.000000 0.463362 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F84FA, 3102157, 0x01F801BB, 229.939, -130.522, -6, -0.886169, 0, 0, 0.463362, False, '2025-07-19 01:41:20'); /* Puffball Thrungus */
/* @teleloc 0x01F801BB [229.938995 -130.522003 -6.000000] -0.886169 0.000000 0.000000 0.463362 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F84FB, 3102157, 0x01F801BA, 234.505, -123.102, -6, -0.999732, 0, 0, 0.023132, False, '2025-07-19 01:41:21'); /* Puffball Thrungus */
/* @teleloc 0x01F801BA [234.505005 -123.101997 -6.000000] -0.999732 0.000000 0.000000 0.023132 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F84FC, 3102157, 0x01F801BA, 234.505, -123.102, -6, -0.999732, 0, 0, 0.023132, False, '2025-07-19 01:41:23'); /* Puffball Thrungus */
/* @teleloc 0x01F801BA [234.505005 -123.101997 -6.000000] -0.999732 0.000000 0.000000 0.023132 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F84FD, 3102157, 0x01F801BA, 234.505, -123.102, -6, -0.999732, 0, 0, 0.023132, False, '2025-07-19 01:41:24'); /* Puffball Thrungus */
/* @teleloc 0x01F801BA [234.505005 -123.101997 -6.000000] -0.999732 0.000000 0.000000 0.023132 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F84FE, 3102157, 0x01F801BA, 234.505, -123.102, -6, -0.999732, 0, 0, 0.023132, False, '2025-07-19 01:41:25'); /* Puffball Thrungus */
/* @teleloc 0x01F801BA [234.505005 -123.101997 -6.000000] -0.999732 0.000000 0.000000 0.023132 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F84FF, 3102157, 0x01F801BA, 233.295, -121.617, -6, 0.926638, 0, 0, -0.375955, False, '2025-07-19 01:41:41'); /* Puffball Thrungus */
/* @teleloc 0x01F801BA [233.294998 -121.616997 -6.000000] 0.926638 0.000000 0.000000 -0.375955 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F8500, 3102157, 0x01F801BA, 234.065, -119.544, -6, 0.999872, 0, 0, 0.016012, False, '2025-07-19 01:41:43'); /* Puffball Thrungus */
/* @teleloc 0x01F801BA [234.065002 -119.543999 -6.000000] 0.999872 0.000000 0.000000 0.016012 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F8501, 3102157, 0x01F801BA, 233.985, -117.045, -6, 0.999872, 0, 0, 0.016012, False, '2025-07-19 01:41:46'); /* Puffball Thrungus */
/* @teleloc 0x01F801BA [233.985001 -117.044998 -6.000000] 0.999872 0.000000 0.000000 0.016012 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F8502, 3102157, 0x01F801B9, 233.88, -113.759, -6, 0.999872, 0, 0, 0.016012, False, '2025-07-19 01:41:48'); /* Puffball Thrungus */
/* @teleloc 0x01F801B9 [233.880005 -113.759003 -6.000000] 0.999872 0.000000 0.000000 0.016012 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F8503, 3102157, 0x01F801B7, 224.124, -124.344, -6, 0.511557, 0, 0, 0.859249, False, '2025-07-19 01:41:53'); /* Puffball Thrungus */
/* @teleloc 0x01F801B7 [224.123993 -124.344002 -6.000000] 0.511557 0.000000 0.000000 0.859249 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F8504, 3102157, 0x01F801B7, 221.249, -120.214, -6, 0.990208, 0, 0, 0.1396, False, '2025-07-19 01:41:55'); /* Puffball Thrungus */
/* @teleloc 0x01F801B7 [221.248993 -120.213997 -6.000000] 0.990208 0.000000 0.000000 0.139600 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F8505, 3102157, 0x01F801B8, 219.785, -130.744, -6, 0.193931, 0, 0, 0.981015, False, '2025-07-19 01:41:57'); /* Puffball Thrungus */
/* @teleloc 0x01F801B8 [219.785004 -130.744003 -6.000000] 0.193931 0.000000 0.000000 0.981015 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F8506, 3102157, 0x01F801A1, 196.918, -138.012, -6, 0.485726, 0, 0, 0.874111, False, '2025-07-19 01:42:01'); /* Puffball Thrungus */
/* @teleloc 0x01F801A1 [196.917999 -138.011993 -6.000000] 0.485726 0.000000 0.000000 0.874111 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F8507, 3102157, 0x01F80191, 190.393, -139.932, -6, 0.610897, 0, 0, 0.79171, False, '2025-07-19 01:42:03'); /* Puffball Thrungus */
/* @teleloc 0x01F80191 [190.393005 -139.932007 -6.000000] 0.610897 0.000000 0.000000 0.791710 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F8508, 3102157, 0x01F80190, 186.695, -129.345, -6, 0.999983, 0, 0, 0.005906, False, '2025-07-19 01:42:06'); /* Puffball Thrungus */
/* @teleloc 0x01F80190 [186.695007 -129.345001 -6.000000] 0.999983 0.000000 0.000000 0.005906 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F8509, 3102157, 0x01F8017C, 176.661, -123.126, -6, 0.669583, 0, 0, 0.742737, False, '2025-07-19 01:42:09'); /* Puffball Thrungus */
/* @teleloc 0x01F8017C [176.660995 -123.125999 -6.000000] 0.669583 0.000000 0.000000 0.742737 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F850A, 3102157, 0x01F8018D, 186.41, -97.6771, -6, 0.885693, 0, 0, 0.464271, False, '2025-07-19 01:42:15'); /* Puffball Thrungus */
/* @teleloc 0x01F8018D [186.410004 -97.677101 -6.000000] 0.885693 0.000000 0.000000 0.464271 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F850B, 3102157, 0x01F8018D, 186.454, -96.5631, -6, 0.927618, 0, 0, 0.37353, False, '2025-07-19 01:42:16'); /* Puffball Thrungus */
/* @teleloc 0x01F8018D [186.453995 -96.563103 -6.000000] 0.927618 0.000000 0.000000 0.373530 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F850C, 3102157, 0x01F8018D, 187.079, -96.2783, -6, 0.927618, 0, 0, 0.37353, False, '2025-07-19 01:42:19'); /* Puffball Thrungus */
/* @teleloc 0x01F8018D [187.078995 -96.278297 -6.000000] 0.927618 0.000000 0.000000 0.373530 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F850D, 3102157, 0x01F8018D, 186.513, -99.8019, -6, 0.096014, 0, 0, 0.99538, False, '2025-07-19 01:42:22'); /* Puffball Thrungus */
/* @teleloc 0x01F8018D [186.513000 -99.801903 -6.000000] 0.096014 0.000000 0.000000 0.995380 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F850E, 3102157, 0x01F801B1, 208.853, -111.074, -6, -0.704159, 0, 0, 0.710043, False, '2025-07-19 01:42:26'); /* Puffball Thrungus */
/* @teleloc 0x01F801B1 [208.852997 -111.073997 -6.000000] -0.704159 0.000000 0.000000 0.710043 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F850F, 3102157, 0x01F801B1, 208.853, -111.074, -6, -0.704159, 0, 0, 0.710043, False, '2025-07-19 01:42:28'); /* Puffball Thrungus */
/* @teleloc 0x01F801B1 [208.852997 -111.073997 -6.000000] -0.704159 0.000000 0.000000 0.710043 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F8510, 3102157, 0x01F801B1, 208.853, -111.074, -6, -0.704159, 0, 0, 0.710043, False, '2025-07-19 01:42:29'); /* Puffball Thrungus */
/* @teleloc 0x01F801B1 [208.852997 -111.073997 -6.000000] -0.704159 0.000000 0.000000 0.710043 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F8511, 3102157, 0x01F801B1, 210.773, -106.784, -6, -0.834536, 0, 0, -0.550954, False, '2025-07-19 01:42:31'); /* Puffball Thrungus */
/* @teleloc 0x01F801B1 [210.772995 -106.783997 -6.000000] -0.834536 0.000000 0.000000 -0.550954 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F8514,   556, 0x01F80319, 115.031, -110.004, 0.055, 0.707107, 0, 0, 0.707107, False, '2025-07-19 01:50:28'); /* Door */
/* @teleloc 0x01F80319 [115.030998 -110.003998 0.055000] 0.707107 0.000000 0.000000 0.707107 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F8544, 28678, 0x01F80151, 146.001, -75.2782, -6, -0.554372, 0, 0, 0.832269, False, '2025-07-19 02:03:11'); /* Beefsteak Thrungus */
/* @teleloc 0x01F80151 [146.001007 -75.278198 -6.000000] -0.554372 0.000000 0.000000 0.832269 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F8545, 28678, 0x01F80151, 146.001, -75.2782, -6, -0.554372, 0, 0, 0.832269, False, '2025-07-19 02:03:13'); /* Beefsteak Thrungus */
/* @teleloc 0x01F80151 [146.001007 -75.278198 -6.000000] -0.554372 0.000000 0.000000 0.832269 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F8546, 28678, 0x01F80140, 143.211, -75.6463, -6, -0.678569, 0, 0, -0.734537, False, '2025-07-19 02:03:15'); /* Beefsteak Thrungus */
/* @teleloc 0x01F80140 [143.210999 -75.646301 -6.000000] -0.678569 0.000000 0.000000 -0.734537 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F8547, 28678, 0x01F80140, 137.943, -76.6826, -6, -0.999922, 0, 0, 0.012511, False, '2025-07-19 02:03:20'); /* Beefsteak Thrungus */
/* @teleloc 0x01F80140 [137.942993 -76.682602 -6.000000] -0.999922 0.000000 0.000000 0.012511 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F8566, 1235757, 0x01F80200, 29.5728, -97.6453, 0.055, 0.08355, 0, 0, 0.996504, False, '2025-07-20 00:06:18');
/* @teleloc 0x01F80200 [29.572800 -97.645302 0.055000] 0.083550 0.000000 0.000000 0.996504 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F8567, 1235757, 0x01F80216, 40.2258, -76.6114, 0.055, -0.999903, 0, 0, -0.013925, False, '2025-07-20 00:11:38');
/* @teleloc 0x01F80216 [40.225800 -76.611397 0.055000] -0.999903 0.000000 0.000000 -0.013925 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F8568, 1235757, 0x01F801CD, 9.85012, -65.2743, 0.055, 0.133606, 0, 0, 0.991035, False, '2025-07-20 00:11:55');
/* @teleloc 0x01F801CD [9.850120 -65.274300 0.055000] 0.133606 0.000000 0.000000 0.991035 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F8569, 1235757, 0x01F801F0, 30.6238, -51.924, 0.055, -0.820151, 0, 0, 0.572147, False, '2025-07-20 00:13:21');
/* @teleloc 0x01F801F0 [30.623800 -51.924000 0.055000] -0.820151 0.000000 0.000000 0.572147 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F856A, 1235757, 0x01F80231, 52.1697, -54.7628, 0.055, -0.914764, 0, 0, 0.403989, False, '2025-07-20 00:16:18');
/* @teleloc 0x01F80231 [52.169701 -54.762798 0.055000] -0.914764 0.000000 0.000000 0.403989 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F856B, 12345757, 0x01F80232, 53.104, -58.6127, 0.055, -0.75452, 0, 0, 0.656277, False, '2025-07-20 00:18:50');
/* @teleloc 0x01F80232 [53.104000 -58.612701 0.055000] -0.754520 0.000000 0.000000 0.656277 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F856C, 12345757, 0x01F802B6, 90.5087, -61.7279, 0.055, -0.812759, 0, 0, 0.582601, False, '2025-07-20 00:28:06');
/* @teleloc 0x01F802B6 [90.508698 -61.727901 0.055000] -0.812759 0.000000 0.000000 0.582601 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F856D, 12345757, 0x01F802F9, 110.847, -32.3327, 0.055, -0.963128, 0, 0, 0.269043, False, '2025-07-20 00:28:15');
/* @teleloc 0x01F802F9 [110.847000 -32.332699 0.055000] -0.963128 0.000000 0.000000 0.269043 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F856E, 12345757, 0x01F8022E, 49.8607, -20.8322, 0.055, -0.899279, 0, 0, 0.437375, False, '2025-07-20 00:28:44');
/* @teleloc 0x01F8022E [49.860699 -20.832199 0.055000] -0.899279 0.000000 0.000000 0.437375 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F856F, 1235757, 0x01F80347, 12.8693, -41.5911, 6.055, -0.327428, 0, 0, -0.944876, False, '2025-07-20 00:29:26');
/* @teleloc 0x01F80347 [12.869300 -41.591099 6.055000] -0.327428 0.000000 0.000000 -0.944876 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F8570, 1235757, 0x01F803DC, 13.1371, -70.1429, 12.055, 0.73654, 0, 0, -0.676394, False, '2025-07-20 00:29:40');
/* @teleloc 0x01F803DC [13.137100 -70.142899 12.055000] 0.736540 0.000000 0.000000 -0.676394 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F8571, 1235757, 0x01F80434, 47.3045, -67.4226, 12.055, -0.678054, 0, 0, -0.735012, False, '2025-07-20 00:30:07');
/* @teleloc 0x01F80434 [47.304501 -67.422600 12.055000] -0.678054 0.000000 0.000000 -0.735012 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F8572, 1235757, 0x01F80445, 61.1729, -70.4388, 12.8385, -0.736075, 0, 0, 0.6769, False, '2025-07-20 00:30:13');
/* @teleloc 0x01F80445 [61.172901 -70.438797 12.838500] -0.736075 0.000000 0.000000 0.676900 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F8573, 12345757, 0x01F80444, 59.5416, -59.4856, 12.055, -0.934429, 0, 0, -0.35615, False, '2025-07-20 00:30:20');
/* @teleloc 0x01F80444 [59.541599 -59.485600 12.055000] -0.934429 0.000000 0.000000 -0.356150 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F8574, 12345757, 0x01F80433, 46.8586, -62.1749, 12.055, -0.271013, 0, 0, -0.962576, False, '2025-07-20 00:30:25');
/* @teleloc 0x01F80433 [46.858601 -62.174900 12.055000] -0.271013 0.000000 0.000000 -0.962576 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F8575, 12345757, 0x01F80447, 59.8557, -99.8845, 12.055, -0.753359, 0, 0, 0.657609, False, '2025-07-20 00:30:48');
/* @teleloc 0x01F80447 [59.855701 -99.884499 12.055000] -0.753359 0.000000 0.000000 0.657609 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F8576, 12345757, 0x01F8044B, 60.8778, -109.972, 12.055, 0.172418, 0, 0, 0.985024, False, '2025-07-20 00:30:59');
/* @teleloc 0x01F8044B [60.877800 -109.972000 12.055000] 0.172418 0.000000 0.000000 0.985024 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F8577, 12345757, 0x01F8045A, 59.5977, -140.476, 12.055, 0.997267, 0, 0, 0.073884, False, '2025-07-20 00:31:12');
/* @teleloc 0x01F8045A [59.597698 -140.475998 12.055000] 0.997267 0.000000 0.000000 0.073884 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F8578, 12345757, 0x01F803FA, 18.3133, -117.236, 12.055, 0.344919, 0, 0, 0.938633, False, '2025-07-20 00:31:32');
/* @teleloc 0x01F803FA [18.313299 -117.236000 12.055000] 0.344919 0.000000 0.000000 0.938633 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F8579, 12345757, 0x01F80350, 28.1609, -126.634, 6.055, -0.916936, 0, 0, 0.399034, False, '2025-07-20 00:31:49');
/* @teleloc 0x01F80350 [28.160900 -126.634003 6.055000] -0.916936 0.000000 0.000000 0.399034 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F857A, 1235757, 0x01F80243, 50.8375, -122.405, 0.055, 0.791776, 0, 0, -0.610811, False, '2025-07-20 00:32:16');
/* @teleloc 0x01F80243 [50.837502 -122.404999 0.055000] 0.791776 0.000000 0.000000 -0.610811 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F857B, 1235757, 0x01F8023D, 49.1071, -110.091, 0.055, 0.546666, 0, 0, 0.837351, False, '2025-07-20 00:32:32');
/* @teleloc 0x01F8023D [49.107101 -110.091003 0.055000] 0.546666 0.000000 0.000000 0.837351 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F857C, 1235757, 0x01F8029B, 79.8833, -113.251, 0.055, -0.006231, 0, 0, 0.999981, False, '2025-07-20 00:32:42');
/* @teleloc 0x01F8029B [79.883301 -113.250999 0.055000] -0.006231 0.000000 0.000000 0.999981 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F857D, 1235757, 0x01F8030D, 112.751, -110.376, 0.055, -0.753788, 0, 0, 0.657118, False, '2025-07-20 00:33:03');
/* @teleloc 0x01F8030D [112.750999 -110.375999 0.055000] -0.753788 0.000000 0.000000 0.657118 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F857E, 123455757, 0x01F80319, 123.7, -105.26, 0.055, 0.586121, 0, 0, -0.810224, False, '2025-07-20 00:43:45');
/* @teleloc 0x01F80319 [123.699997 -105.260002 0.055000] 0.586121 0.000000 0.000000 -0.810224 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F857F, 12345757, 0x01F802E9, 97.93, -98.017, 0.055, -0.891617, 0, 0, 0.452792, False, '2025-07-20 00:44:29');
/* @teleloc 0x01F802E9 [97.930000 -98.016998 0.055000] -0.891617 0.000000 0.000000 0.452792 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F8580, 12345757, 0x01F80251, 61.7679, -72.6251, 0.055, -0.970628, 0, 0, 0.240584, False, '2025-07-20 00:44:54');
/* @teleloc 0x01F80251 [61.767899 -72.625099 0.055000] -0.970628 0.000000 0.000000 0.240584 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F8581, 12345757, 0x01F8026E, 69.2941, -74.6649, 0.427015, -0.423632, 0, 0, 0.905834, False, '2025-07-20 00:44:56');
/* @teleloc 0x01F8026E [69.294098 -74.664902 0.427015] -0.423632 0.000000 0.000000 0.905834 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F8582, 12345757, 0x01F80315, 120.398, -71.9971, 0.055, 0.946261, 0, 0, -0.323406, False, '2025-07-20 00:45:23');
/* @teleloc 0x01F80315 [120.398003 -71.997101 0.055000] 0.946261 0.000000 0.000000 -0.323406 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F8583, 12345757, 0x01F80109, 121.619, -41.5426, -5.945, 0.966865, 0, 0, -0.255289, False, '2025-07-20 00:45:55');
/* @teleloc 0x01F80109 [121.619003 -41.542599 -5.945000] 0.966865 0.000000 0.000000 -0.255289 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F8584, 12345757, 0x01F80133, 139.018, -29.0204, -5.945, 0.950986, 0, 0, -0.309234, False, '2025-07-20 00:46:06');
/* @teleloc 0x01F80133 [139.018005 -29.020399 -5.945000] 0.950986 0.000000 0.000000 -0.309234 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F8585, 12345757, 0x01F80168, 181.106, -26.4251, -5.57936, 0.824542, 0, 0, -0.565801, False, '2025-07-20 00:46:43');
/* @teleloc 0x01F80168 [181.106003 -26.425100 -5.579360] 0.824542 0.000000 0.000000 -0.565801 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F8586, 12345757, 0x01F80155, 164.007, -32.7986, -5.945, 0.90843, 0, 0, 0.418038, False, '2025-07-20 00:46:49');
/* @teleloc 0x01F80155 [164.007004 -32.798599 -5.945000] 0.908430 0.000000 0.000000 0.418038 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F8587, 12345757, 0x01F80152, 158.19, -13.6685, -5.945, 0.889063, 0, 0, 0.457785, False, '2025-07-20 00:46:53');
/* @teleloc 0x01F80152 [158.190002 -13.668500 -5.945000] 0.889063 0.000000 0.000000 0.457785 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F8588, 1234565757, 0x01F80178, 180.083, -80.2015, -5.945, 0.740774, 0, 0, 0.671754, False, '2025-07-20 00:50:28');
/* @teleloc 0x01F80178 [180.082993 -80.201500 -5.945000] 0.740774 0.000000 0.000000 0.671754 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F8589, 1234565757, 0x01F801A9, 210.631, -70.9947, -5.945, -0.914683, 0, 0, 0.404171, False, '2025-07-20 00:50:40');
/* @teleloc 0x01F801A9 [210.630997 -70.994698 -5.945000] -0.914683 0.000000 0.000000 0.404171 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F858A, 1234565757, 0x01F8018E, 190, -105.092, -5.945, 0.202054, 0, 0, 0.979374, False, '2025-07-20 00:50:54');
/* @teleloc 0x01F8018E [190.000000 -105.092003 -5.945000] 0.202054 0.000000 0.000000 0.979374 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F858B, 1234565757, 0x01F80191, 191.193, -136.679, -5.945, -0.346411, 0, 0, 0.938083, False, '2025-07-20 00:51:04');
/* @teleloc 0x01F80191 [191.192993 -136.679001 -5.945000] -0.346411 0.000000 0.000000 0.938083 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F858C, 112345757, 0x01F801B7, 221.234, -122.158, -5.945, 0.707918, 0, 0, -0.706294, False, '2025-07-20 01:21:00');
/* @teleloc 0x01F801B7 [221.233994 -122.157997 -5.945000] 0.707918 0.000000 0.000000 -0.706294 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F858D, 1234565757, 0x01F801B7, 222.347, -124.228, -5.945, 0.826334, 0, 0, -0.563181, False, '2025-07-20 01:32:46');
/* @teleloc 0x01F801B7 [222.347000 -124.227997 -5.945000] 0.826334 0.000000 0.000000 -0.563181 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F858E, 1234565757, 0x01F801B7, 221.869, -116.426, -5.945, 0.86621, 0, 0, -0.499681, False, '2025-07-20 01:32:50');
/* @teleloc 0x01F801B7 [221.869003 -116.426003 -5.945000] 0.866210 0.000000 0.000000 -0.499681 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F858F, 1234565757, 0x01F8039A, 99.2588, -119.614, 6.055, 0.67336, 0, 0, -0.739315, False, '2025-07-20 01:40:11');
/* @teleloc 0x01F8039A [99.258797 -119.613998 6.055000] 0.673360 0.000000 0.000000 -0.739315 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701F8590, 1234565757, 0x01F803BC, 105.4846, -139.9743, 6.055, 0.740585, 0, 0, -0.671962, False, '2025-07-20 01:40:24');
/* @teleloc 0x01F803BC [105.484596 -139.974304 6.055000] 0.740585 0.000000 0.000000 -0.671962 */
