DELETE FROM `landblock_instance` WHERE `landblock` = 0x018E;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7018E000, 35352111, 0x018E024C, 29.0763, -149.517, -5.945, 0.632602, 0, 0, -0.774477, False, '2025-09-04 22:13:01'); /* Corrupted Fiun Generator */
/* @teleloc 0x018E024C [29.076300 -149.516998 -5.945000] 0.632602 0.000000 0.000000 -0.774477 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7018E001, 35352111, 0x018E0260, 40.0981, -149.384, -5.945, 0.70338, 0, 0, -0.710814, False, '2025-09-04 22:13:06'); /* Corrupted Fiun Generator */
/* @teleloc 0x018E0260 [40.098099 -149.384003 -5.945000] 0.703380 0.000000 0.000000 -0.710814 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7018E002, 35352111, 0x018E0274, 48.8685, -151.063, -5.945, 0.554963, 0, 0, -0.831875, False, '2025-09-04 22:13:07'); /* Corrupted Fiun Generator */
/* @teleloc 0x018E0274 [48.868500 -151.063004 -5.945000] 0.554963 0.000000 0.000000 -0.831875 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7018E003, 35352111, 0x018E0276, 51.3394, -156.356, -5.945, 0.069998, 0, 0, -0.997547, False, '2025-09-04 22:13:08'); /* Corrupted Fiun Generator */
/* @teleloc 0x018E0276 [51.339401 -156.356003 -5.945000] 0.069998 0.000000 0.000000 -0.997547 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7018E004, 35352111, 0x018E028E, 55.0039, -161.165, -5.945, 0.518047, 0, 0, -0.855353, False, '2025-09-04 22:13:09'); /* Corrupted Fiun Generator */
/* @teleloc 0x018E028E [55.003899 -161.164993 -5.945000] 0.518047 0.000000 0.000000 -0.855353 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7018E005, 35352111, 0x018E0288, 60.8413, -151.091, -5.945, 0.993272, 0, 0, 0.115802, False, '2025-09-04 22:13:10'); /* Corrupted Fiun Generator */
/* @teleloc 0x018E0288 [60.841301 -151.091003 -5.945000] 0.993272 0.000000 0.000000 0.115802 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7018E006, 35352111, 0x018E0286, 60.3438, -144.417, -5.945, 0.97817, 0, 0, 0.207805, False, '2025-09-04 22:13:12'); /* Corrupted Fiun Generator */
/* @teleloc 0x018E0286 [60.343800 -144.417007 -5.945000] 0.978170 0.000000 0.000000 0.207805 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7018E007, 35352111, 0x018E026F, 51.8224, -139.686, -5.945, 0.603223, 0, 0, 0.797573, False, '2025-09-04 22:13:13'); /* Corrupted Fiun Generator */
/* @teleloc 0x018E026F [51.822399 -139.686005 -5.945000] 0.603223 0.000000 0.000000 0.797573 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7018E008, 35352111, 0x018E02A7, 72.3107, -150.327, -5.945, -0.751193, 0, 0, 0.660083, False, '2025-09-04 22:13:17'); /* Corrupted Fiun Generator */
/* @teleloc 0x018E02A7 [72.310699 -150.326996 -5.945000] -0.751193 0.000000 0.000000 0.660083 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7018E009, 35352111, 0x018E02C7, 79.3431, -153.077, -5.945, -0.445643, 0, 0, 0.895211, False, '2025-09-04 22:13:18'); /* Corrupted Fiun Generator */
/* @teleloc 0x018E02C7 [79.343102 -153.076996 -5.945000] -0.445643 0.000000 0.000000 0.895211 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7018E00A, 35352111, 0x018E02C7, 81.0622, -149.057, -5.945, -0.99869, 0, 0, -0.051165, False, '2025-09-04 22:13:20'); /* Corrupted Fiun Generator */
/* @teleloc 0x018E02C7 [81.062202 -149.057007 -5.945000] -0.998690 0.000000 0.000000 -0.051165 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7018E00B, 35352111, 0x018E02C5, 80.1931, -139.963, -5.945, -0.990127, 0, 0, 0.140173, False, '2025-09-04 22:13:21'); /* Corrupted Fiun Generator */
/* @teleloc 0x018E02C5 [80.193100 -139.962997 -5.945000] -0.990127 0.000000 0.000000 0.140173 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7018E00C, 35352111, 0x018E02F9, 89.1208, -141.08, -5.945, -0.586946, 0, 0, 0.809626, False, '2025-09-04 22:13:22'); /* Corrupted Fiun Generator */
/* @teleloc 0x018E02F9 [89.120796 -141.080002 -5.945000] -0.586946 0.000000 0.000000 0.809626 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7018E00D, 35352111, 0x018E02FA, 90.7799, -148.654, -5.945, -0.030166, 0, 0, 0.999545, False, '2025-09-04 22:13:24'); /* Corrupted Fiun Generator */
/* @teleloc 0x018E02FA [90.779900 -148.654007 -5.945000] -0.030166 0.000000 0.000000 0.999545 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7018E00E, 35352111, 0x018E0323, 98.5029, -150.17, -5.945, -0.679099, 0, 0, 0.734047, False, '2025-09-04 22:13:27'); /* Corrupted Fiun Generator */
/* @teleloc 0x018E0323 [98.502899 -150.169998 -5.945000] -0.679099 0.000000 0.000000 0.734047 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7018E00F, 35352111, 0x018E0348, 111.169, -153.767, -5.945, -0.617662, 0, 0, 0.786444, False, '2025-09-04 22:13:29'); /* Corrupted Fiun Generator */
/* @teleloc 0x018E0348 [111.168999 -153.766998 -5.945000] -0.617662 0.000000 0.000000 0.786444 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7018E010, 35352111, 0x018E035C, 118.42, -141.443, -5.945, -0.330141, 0, 0, 0.943932, False, '2025-09-04 22:13:32'); /* Corrupted Fiun Generator */
/* @teleloc 0x018E035C [118.419998 -141.442993 -5.945000] -0.330141 0.000000 0.000000 0.943932 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7018E011, 35352111, 0x018E035F, 120.33, -155.604, -5.945, -0.413998, 0, 0, 0.910278, False, '2025-09-04 22:13:34'); /* Corrupted Fiun Generator */
/* @teleloc 0x018E035F [120.330002 -155.604004 -5.945000] -0.413998 0.000000 0.000000 0.910278 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7018E012, 35352111, 0x018E0363, 131.026, -143.711, -5.945, -0.927944, 0, 0, 0.372721, False, '2025-09-04 22:13:36'); /* Corrupted Fiun Generator */
/* @teleloc 0x018E0363 [131.026001 -143.710999 -5.945000] -0.927944 0.000000 0.000000 0.372721 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7018E013, 35352111, 0x018E020F, 160.185, -129.818, -11.945, -0.734821, 0, 0, 0.678261, False, '2025-09-04 22:13:39'); /* Corrupted Fiun Generator */
/* @teleloc 0x018E020F [160.184998 -129.817993 -11.945000] -0.734821 0.000000 0.000000 0.678261 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7018E014, 35352111, 0x018E0210, 162.942, -135.311, -11.945, -0.112668, 0, 0, 0.993633, False, '2025-09-04 22:13:41'); /* Corrupted Fiun Generator */
/* @teleloc 0x018E0210 [162.942001 -135.311005 -11.945000] -0.112668 0.000000 0.000000 0.993633 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7018E015, 35352111, 0x018E021E, 176.646, -140.241, -11.945, -0.869286, 0, 0, 0.494309, False, '2025-09-04 22:13:42'); /* Corrupted Fiun Generator */
/* @teleloc 0x018E021E [176.645996 -140.240997 -11.945000] -0.869286 0.000000 0.000000 0.494309 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7018E016, 35352111, 0x018E021D, 180.663, -129.377, -11.945, -0.982605, 0, 0, -0.18571, False, '2025-09-04 22:13:44'); /* Corrupted Fiun Generator */
/* @teleloc 0x018E021D [180.662994 -129.376999 -11.945000] -0.982605 0.000000 0.000000 -0.185710 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7018E017, 35352111, 0x018E0215, 173.64, -120.887, -11.945, -0.841663, 0, 0, -0.540003, False, '2025-09-04 22:13:45'); /* Corrupted Fiun Generator */
/* @teleloc 0x018E0215 [173.639999 -120.887001 -11.945000] -0.841663 0.000000 0.000000 -0.540003 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7018E018, 35352111, 0x018E0231, 198.635, -130.231, -11.945, -0.743083, 0, 0, 0.669199, False, '2025-09-04 22:13:48'); /* Corrupted Fiun Generator */
/* @teleloc 0x018E0231 [198.634995 -130.231003 -11.945000] -0.743083 0.000000 0.000000 0.669199 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7018E019, 35352111, 0x018E022A, 190.452, -139.999, -11.945, -0.026354, 0, 0, 0.999653, False, '2025-09-04 22:13:50'); /* Corrupted Fiun Generator */
/* @teleloc 0x018E022A [190.451996 -139.998993 -11.945000] -0.026354 0.000000 0.000000 0.999653 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7018E01A, 35352111, 0x018E017E, 198.769, -89.7985, -17.945, 0.990315, 0, 0, 0.138838, False, '2025-09-04 22:13:57'); /* Corrupted Fiun Generator */
/* @teleloc 0x018E017E [198.768997 -89.798500 -17.945000] 0.990315 0.000000 0.000000 0.138838 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7018E01B, 35352111, 0x018E014E, 192.57, -80.1314, -17.945, 0.982588, 0, 0, 0.185798, False, '2025-09-04 22:13:58'); /* Corrupted Fiun Generator */
/* @teleloc 0x018E014E [192.570007 -80.131401 -17.945000] 0.982588 0.000000 0.000000 0.185798 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7018E01C, 35352111, 0x018E014D, 189.389, -66.0977, -17.945, 0.997127, 0, 0, 0.075755, False, '2025-09-04 22:14:00'); /* Corrupted Fiun Generator */
/* @teleloc 0x018E014D [189.389008 -66.097702 -17.945000] 0.997127 0.000000 0.000000 0.075755 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7018E01D, 35352111, 0x018E012A, 174.062, -60.3467, -17.945, 0.577102, 0, 0, 0.816672, False, '2025-09-04 22:14:01'); /* Corrupted Fiun Generator */
/* @teleloc 0x018E012A [174.061996 -60.346699 -17.945000] 0.577102 0.000000 0.000000 0.816672 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7018E01E, 35352111, 0x018E0126, 163.009, -68.9354, -17.945, 0.331842, 0, 0, 0.943335, False, '2025-09-04 22:14:03'); /* Corrupted Fiun Generator */
/* @teleloc 0x018E0126 [163.009003 -68.935402 -17.945000] 0.331842 0.000000 0.000000 0.943335 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7018E01F, 35352111, 0x018E017C, 201.899, -38.9133, -17.945, -0.713468, 0, 0, 0.700687, False, '2025-09-04 22:14:08'); /* Corrupted Fiun Generator */
/* @teleloc 0x018E017C [201.899002 -38.913300 -17.945000] -0.713468 0.000000 0.000000 0.700687 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7018E020, 35352111, 0x018E01A5, 211.5, -36.6521, -17.945, -0.93504, 0, 0, 0.354544, False, '2025-09-04 22:14:09'); /* Corrupted Fiun Generator */
/* @teleloc 0x018E01A5 [211.500000 -36.652100 -17.945000] -0.935040 0.000000 0.000000 0.354544 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7018E021, 35352111, 0x018E0107, 209.162, -20.4322, -23.945, -0.927997, 0, 0, -0.372588, False, '2025-09-04 22:14:11'); /* Corrupted Fiun Generator */
/* @teleloc 0x018E0107 [209.162003 -20.432199 -23.945000] -0.927997 0.000000 0.000000 -0.372588 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7018E022, 35352111, 0x018E010C, 221.161, -10.7229, -23.945, -0.9976, 0, 0, -0.069236, False, '2025-09-04 22:14:14'); /* Corrupted Fiun Generator */
/* @teleloc 0x018E010C [221.160995 -10.722900 -23.945000] -0.997600 0.000000 0.000000 -0.069236 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7018E023, 35352111, 0x018E0111, 229.325, -2.63493, -23.945, -0.629548, 0, 0, 0.776962, False, '2025-09-04 22:14:15'); /* Corrupted Fiun Generator */
/* @teleloc 0x018E0111 [229.324997 -2.634930 -23.945000] -0.629548 0.000000 0.000000 0.776962 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7018E024, 35352111, 0x018E021D, 180.913, -134.172, -11.945, 0.620224, 0, 0, 0.784425, False, '2025-09-04 22:14:31'); /* Corrupted Fiun Generator */
/* @teleloc 0x018E021D [180.912994 -134.171997 -11.945000] 0.620224 0.000000 0.000000 0.784425 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7018E025, 35352111, 0x018E024F, 30.6274, -162.91, -5.945, -0.025576, 0, 0, -0.999673, False, '2025-09-04 22:15:16'); /* Corrupted Fiun Generator */
/* @teleloc 0x018E024F [30.627399 -162.910004 -5.945000] -0.025576 0.000000 0.000000 -0.999673 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7018E026, 35352111, 0x018E0262, 41.1798, -178.607, -5.945, 0.049406, 0, 0, -0.998779, False, '2025-09-04 22:15:18'); /* Corrupted Fiun Generator */
/* @teleloc 0x018E0262 [41.179798 -178.606995 -5.945000] 0.049406 0.000000 0.000000 -0.998779 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7018E027, 35352111, 0x018E0278, 51.0411, -189.92, -5.945, 0.670229, 0, 0, -0.742155, False, '2025-09-04 22:15:20'); /* Corrupted Fiun Generator */
/* @teleloc 0x018E0278 [51.041100 -189.919998 -5.945000] 0.670229 0.000000 0.000000 -0.742155 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7018E028, 35352111, 0x018E027D, 51.0182, -199.589, -5.945, 0.254285, 0, 0, -0.967129, False, '2025-09-04 22:15:22'); /* Corrupted Fiun Generator */
/* @teleloc 0x018E027D [51.018200 -199.589005 -5.945000] 0.254285 0.000000 0.000000 -0.967129 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7018E029, 35352111, 0x018E0295, 60.314, -200.321, -5.945, 0.741288, 0, 0, -0.671187, False, '2025-09-04 22:15:23'); /* Corrupted Fiun Generator */
/* @teleloc 0x018E0295 [60.313999 -200.320999 -5.945000] 0.741288 0.000000 0.000000 -0.671187 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7018E02A, 35352111, 0x018E02A8, 68.7305, -189.929, -5.945, 0.653649, 0, 0, -0.756798, False, '2025-09-04 22:15:26'); /* Corrupted Fiun Generator */
/* @teleloc 0x018E02A8 [68.730499 -189.929001 -5.945000] 0.653649 0.000000 0.000000 -0.756798 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7018E02B, 35352111, 0x018E02FF, 87.033, -189.47, -5.945, 0.719623, 0, 0, -0.694365, False, '2025-09-04 22:15:27'); /* Corrupted Fiun Generator */
/* @teleloc 0x018E02FF [87.032997 -189.470001 -5.945000] 0.719623 0.000000 0.000000 -0.694365 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7018E02C, 35352111, 0x018E0303, 90.3094, -199.888, -5.945, -0.036147, 0, 0, -0.999347, False, '2025-09-04 22:15:29'); /* Corrupted Fiun Generator */
/* @teleloc 0x018E0303 [90.309402 -199.888000 -5.945000] -0.036147 0.000000 0.000000 -0.999347 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7018E02D, 35352111, 0x018E0308, 90.052, -209.324, -5.945, 0.004229, 0, 0, -0.999991, False, '2025-09-04 22:15:30'); /* Corrupted Fiun Generator */
/* @teleloc 0x018E0308 [90.052002 -209.324005 -5.945000] 0.004229 0.000000 0.000000 -0.999991 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7018E02E, 35352111, 0x018E0329, 101.021, -209.583, -5.945, 0.785052, 0, 0, -0.61943, False, '2025-09-04 22:15:31'); /* Corrupted Fiun Generator */
/* @teleloc 0x018E0329 [101.021004 -209.582993 -5.945000] 0.785052 0.000000 0.000000 -0.619430 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7018E02F, 35352111, 0x018E0350, 109.35, -209.74, -5.945, 0.799424, 0, 0, -0.600768, False, '2025-09-04 22:15:32'); /* Corrupted Fiun Generator */
/* @teleloc 0x018E0350 [109.349998 -209.740005 -5.945000] 0.799424 0.000000 0.000000 -0.600768 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7018E030, 35352111, 0x018E034C, 108.119, -200.278, -5.945, 0.927752, 0, 0, 0.373198, False, '2025-09-04 22:15:34'); /* Corrupted Fiun Generator */
/* @teleloc 0x018E034C [108.119003 -200.278000 -5.945000] 0.927752 0.000000 0.000000 0.373198 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7018E031, 35352111, 0x018E02D4, 79.8598, -220.673, -5.945, -0.049592, 0, 0, 0.99877, False, '2025-09-04 22:15:39'); /* Corrupted Fiun Generator */
/* @teleloc 0x018E02D4 [79.859802 -220.673004 -5.945000] -0.049592 0.000000 0.000000 0.998770 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7018E032, 35352111, 0x018E02D9, 80.3902, -230.321, -5.945, -0.075022, 0, 0, 0.997182, False, '2025-09-04 22:15:40'); /* Corrupted Fiun Generator */
/* @teleloc 0x018E02D9 [80.390198 -230.320999 -5.945000] -0.075022 0.000000 0.000000 0.997182 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7018E033, 35352111, 0x018E030D, 91.9899, -230.115, -5.945, -0.723421, 0, 0, 0.690408, False, '2025-09-04 22:15:42'); /* Corrupted Fiun Generator */
/* @teleloc 0x018E030D [91.989899 -230.115005 -5.945000] -0.723421 0.000000 0.000000 0.690408 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7018E034, 35352111, 0x018E0332, 100.986, -239.03, -5.945, 0.072435, 0, 0, 0.997373, False, '2025-09-04 22:15:44'); /* Corrupted Fiun Generator */
/* @teleloc 0x018E0332 [100.986000 -239.029999 -5.945000] 0.072435 0.000000 0.000000 0.997373 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7018E035, 35352111, 0x018E0337, 99.2058, -249.348, -5.945, 0.251496, 0, 0, 0.967858, False, '2025-09-04 22:15:45'); /* Corrupted Fiun Generator */
/* @teleloc 0x018E0337 [99.205803 -249.348007 -5.945000] 0.251496 0.000000 0.000000 0.967858 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7018E036, 35352111, 0x018E02E2, 83.7746, -250.084, -5.945, 0.67165, 0, 0, 0.740869, False, '2025-09-04 22:15:47'); /* Corrupted Fiun Generator */
/* @teleloc 0x018E02E2 [83.774597 -250.084000 -5.945000] 0.671650 0.000000 0.000000 0.740869 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7018E037, 35352111, 0x018E01F9, 95.0095, -228.828, -11.945, 0.790158, 0, 0, -0.612904, False, '2025-09-04 22:15:55'); /* Corrupted Fiun Generator */
/* @teleloc 0x018E01F9 [95.009499 -228.828003 -11.945000] 0.790158 0.000000 0.000000 -0.612904 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7018E038, 35352111, 0x018E01FB, 112.661, -229.512, -11.945, 0.717363, 0, 0, -0.696699, False, '2025-09-04 22:15:56'); /* Corrupted Fiun Generator */
/* @teleloc 0x018E01FB [112.661003 -229.511993 -11.945000] 0.717363 0.000000 0.000000 -0.696699 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7018E039, 35352111, 0x018E0200, 118.24, -242.462, -16.8858, -0.868121, 0, 0, -0.496352, False, '2025-09-04 22:15:59'); /* Corrupted Fiun Generator */
/* @teleloc 0x018E0200 [118.239998 -242.462006 -16.885799] -0.868121 0.000000 0.000000 -0.496352 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7018E03A, 35352111, 0x018E0117, 110.082, -256.294, -17.945, -0.053314, 0, 0, -0.998578, False, '2025-09-04 22:16:02'); /* Corrupted Fiun Generator */
/* @teleloc 0x018E0117 [110.082001 -256.294006 -17.945000] -0.053314 0.000000 0.000000 -0.998578 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7018E03B, 35352111, 0x018E011C, 118.901, -281.696, -17.945, 0.15658, 0, 0, -0.987665, False, '2025-09-04 22:16:05'); /* Corrupted Fiun Generator */
/* @teleloc 0x018E011C [118.901001 -281.696014 -17.945000] 0.156580 0.000000 0.000000 -0.987665 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7018E03C, 35352111, 0x018E011F, 126.661, -285.286, -17.945, 0.806935, 0, 0, -0.59064, False, '2025-09-04 22:16:06'); /* Corrupted Fiun Generator */
/* @teleloc 0x018E011F [126.661003 -285.286011 -17.945000] 0.806935 0.000000 0.000000 -0.590640 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7018E03D, 35352111, 0x018E0121, 148.427, -280.313, -17.945, 0.655915, 0, 0, -0.754835, False, '2025-09-04 22:16:08'); /* Corrupted Fiun Generator */
/* @teleloc 0x018E0121 [148.427002 -280.312988 -17.945000] 0.655915 0.000000 0.000000 -0.754835 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7018E03E, 35352111, 0x018E0128, 158.811, -291.74, -17.945, 0.648995, 0, 0, -0.760793, False, '2025-09-04 22:16:10'); /* Corrupted Fiun Generator */
/* @teleloc 0x018E0128 [158.811005 -291.739990 -17.945000] 0.648995 0.000000 0.000000 -0.760793 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7018E03F, 35352111, 0x018E012F, 165.194, -296.145, -17.945, 0.636471, 0, 0, -0.771301, False, '2025-09-04 22:16:11'); /* Corrupted Fiun Generator */
/* @teleloc 0x018E012F [165.194000 -296.144989 -17.945000] 0.636471 0.000000 0.000000 -0.771301 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7018E040, 35352111, 0x018E012E, 168.898, -291.829, -17.945, 0.979466, 0, 0, -0.201612, False, '2025-09-04 22:16:12'); /* Corrupted Fiun Generator */
/* @teleloc 0x018E012E [168.897995 -291.829010 -17.945000] 0.979466 0.000000 0.000000 -0.201612 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7018E041, 35352111, 0x018E013D, 180.572, -284.893, -17.945, 0.997629, 0, 0, -0.068822, False, '2025-09-04 22:16:14'); /* Corrupted Fiun Generator */
/* @teleloc 0x018E013D [180.572006 -284.893005 -17.945000] 0.997629 0.000000 0.000000 -0.068822 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7018E042, 35352111, 0x018E016E, 190.561, -274.988, -17.945, 0.99912, 0, 0, -0.04194, False, '2025-09-04 22:16:16'); /* Corrupted Fiun Generator */
/* @teleloc 0x018E016E [190.561005 -274.988007 -17.945000] 0.999120 0.000000 0.000000 -0.041940 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7018E043, 35352111, 0x018E013A, 184.402, -269.352, -17.945, 0.861265, 0, 0, 0.508156, False, '2025-09-04 22:16:17'); /* Corrupted Fiun Generator */
/* @teleloc 0x018E013A [184.401993 -269.351990 -17.945000] 0.861265 0.000000 0.000000 0.508156 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7018E044, 35352111, 0x018E016A, 185.165, -259.63, -17.945, 0.798046, 0, 0, -0.602597, False, '2025-09-04 22:16:19'); /* Corrupted Fiun Generator */
/* @teleloc 0x018E016A [185.164993 -259.630005 -17.945000] 0.798046 0.000000 0.000000 -0.602597 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7018E045, 35352111, 0x018E0169, 190.703, -256.851, -17.945, 0.893811, 0, 0, -0.448444, False, '2025-09-04 22:16:20'); /* Corrupted Fiun Generator */
/* @teleloc 0x018E0169 [190.703003 -256.851013 -17.945000] 0.893811 0.000000 0.000000 -0.448444 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7018E046, 35352111, 0x018E018F, 200.001, -262.879, -17.945, 0.290015, 0, 0, -0.957022, False, '2025-09-04 22:16:21'); /* Corrupted Fiun Generator */
/* @teleloc 0x018E018F [200.001007 -262.878998 -17.945000] 0.290015 0.000000 0.000000 -0.957022 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7018E047, 35352111, 0x018E019A, 200.482, -283.957, -17.945, 0.508267, 0, 0, -0.861199, False, '2025-09-04 22:16:25'); /* Corrupted Fiun Generator */
/* @teleloc 0x018E019A [200.481995 -283.957001 -17.945000] 0.508267 0.000000 0.000000 -0.861199 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7018E048, 35352111, 0x018E01B2, 210.856, -280.359, -17.945, 0.651179, 0, 0, -0.758925, False, '2025-09-04 22:16:27'); /* Corrupted Fiun Generator */
/* @teleloc 0x018E01B2 [210.856003 -280.359009 -17.945000] 0.651179 0.000000 0.000000 -0.758925 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7018E049, 35352111, 0x018E01B4, 213.673, -290.269, -17.945, 0.368508, 0, 0, -0.929624, False, '2025-09-04 22:16:29'); /* Corrupted Fiun Generator */
/* @teleloc 0x018E01B4 [213.673004 -290.269012 -17.945000] 0.368508 0.000000 0.000000 -0.929624 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7018E04A, 35352111, 0x018E01BF, 218.398, -293.858, -17.945, 0.290928, 0, 0, -0.956745, False, '2025-09-04 22:16:29'); /* Corrupted Fiun Generator */
/* @teleloc 0x018E01BF [218.397995 -293.858002 -17.945000] 0.290928 0.000000 0.000000 -0.956745 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7018E04B, 35352111, 0x018E01C0, 224.069, -297.547, -17.945, 0.64127, 0, 0, -0.767316, False, '2025-09-04 22:16:30'); /* Corrupted Fiun Generator */
/* @teleloc 0x018E01C0 [224.069000 -297.546997 -17.945000] 0.641270 0.000000 0.000000 -0.767316 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7018E04C, 35352111, 0x018E01D3, 228.797, -295.738, -17.945, 0.929221, 0, 0, -0.369525, False, '2025-09-04 22:16:31'); /* Corrupted Fiun Generator */
/* @teleloc 0x018E01D3 [228.796997 -295.738007 -17.945000] 0.929221 0.000000 0.000000 -0.369525 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7018E04D, 35352111, 0x018E01D2, 229.894, -291.148, -17.945, 0.998372, 0, 0, 0.057042, False, '2025-09-04 22:16:32'); /* Corrupted Fiun Generator */
/* @teleloc 0x018E01D2 [229.893997 -291.148010 -17.945000] 0.998372 0.000000 0.000000 0.057042 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7018E04E, 35352111, 0x018E01E5, 241.026, -283.833, -17.945, 0.999641, 0, 0, 0.026782, False, '2025-09-04 22:16:34'); /* Corrupted Fiun Generator */
/* @teleloc 0x018E01E5 [241.026001 -283.833008 -17.945000] 0.999641 0.000000 0.000000 0.026782 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7018E04F, 35352111, 0x018E01F2, 256.52, -279.35, -17.945, 0.707907, 0, 0, -0.706306, False, '2025-09-04 22:16:36'); /* Corrupted Fiun Generator */
/* @teleloc 0x018E01F2 [256.519989 -279.350006 -17.945000] 0.707907 0.000000 0.000000 -0.706306 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7018E050, 35352111, 0x018E01F2, 263.903, -279.333, -17.945, 0.707907, 0, 0, -0.706306, False, '2025-09-04 22:16:37'); /* Corrupted Fiun Generator */
/* @teleloc 0x018E01F2 [263.903015 -279.333008 -17.945000] 0.707907 0.000000 0.000000 -0.706306 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7018E051, 35352111, 0x018E01F5, 267.833, -287.795, -17.945, -0.270152, 0, 0, -0.962818, False, '2025-09-04 22:16:39'); /* Corrupted Fiun Generator */
/* @teleloc 0x018E01F5 [267.833008 -287.795013 -17.945000] -0.270152 0.000000 0.000000 -0.962818 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7018E052, 35352111, 0x018E01F3, 261.743, -287.189, -17.945, -0.80522, 0, 0, -0.592977, False, '2025-09-04 22:16:40'); /* Corrupted Fiun Generator */
/* @teleloc 0x018E01F3 [261.743011 -287.188995 -17.945000] -0.805220 0.000000 0.000000 -0.592977 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7018E053, 35352111, 0x018E0103, 179.494, -329.708, -23.945, 0.031248, 0, 0, -0.999512, False, '2025-09-04 22:16:52'); /* Corrupted Fiun Generator */
/* @teleloc 0x018E0103 [179.494003 -329.708008 -23.945000] 0.031248 0.000000 0.000000 -0.999512 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7018E054, 35352111, 0x018E0166, 188.796, -247.576, -17.945, 0.999893, 0, 0, -0.014649, False, '2025-09-04 22:17:10'); /* Corrupted Fiun Generator */
/* @teleloc 0x018E0166 [188.796005 -247.576004 -17.945000] 0.999893 0.000000 0.000000 -0.014649 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7018E055, 35352111, 0x018E018B, 201.008, -239.017, -17.945, 0.848111, 0, 0, -0.529819, False, '2025-09-04 22:17:12'); /* Corrupted Fiun Generator */
/* @teleloc 0x018E018B [201.007996 -239.016998 -17.945000] 0.848111 0.000000 0.000000 -0.529819 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7018E056, 35352111, 0x018E0186, 200.311, -224.919, -17.945, 0.996986, 0, 0, 0.077586, False, '2025-09-04 22:17:14'); /* Corrupted Fiun Generator */
/* @teleloc 0x018E0186 [200.311005 -224.919006 -17.945000] 0.996986 0.000000 0.000000 0.077586 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7018E057, 35352111, 0x018E0158, 191.135, -216.856, -17.945, 0.966915, 0, 0, 0.2551, False, '2025-09-04 22:17:15'); /* Corrupted Fiun Generator */
/* @teleloc 0x018E0158 [191.134995 -216.856003 -17.945000] 0.966915 0.000000 0.000000 0.255100 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7018E058, 35352111, 0x018E0152, 189.959, -202.066, -17.945, 0.99999, 0, 0, -0.004544, False, '2025-09-04 22:17:16'); /* Corrupted Fiun Generator */
/* @teleloc 0x018E0152 [189.959000 -202.065994 -17.945000] 0.999990 0.000000 0.000000 -0.004544 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7018E059, 35352111, 0x018E0131, 182.67, -193.687, -17.945, 0.788005, 0, 0, 0.615669, False, '2025-09-04 22:17:18'); /* Corrupted Fiun Generator */
/* @teleloc 0x018E0131 [182.669998 -193.686996 -17.945000] 0.788005 0.000000 0.000000 0.615669 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7018E05A, 35352111, 0x018E012D, 171.033, -195.017, -17.1861, 0.35045, 0, 0, 0.936581, False, '2025-09-04 22:17:19'); /* Corrupted Fiun Generator */
/* @teleloc 0x018E012D [171.033005 -195.016998 -17.186100] 0.350450 0.000000 0.000000 0.936581 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7018E05B, 35352111, 0x018E01A7, 209.99, -209.768, -17.945, -0.684876, 0, 0, 0.72866, False, '2025-09-04 22:17:23'); /* Corrupted Fiun Generator */
/* @teleloc 0x018E01A7 [209.990005 -209.768005 -17.945000] -0.684876 0.000000 0.000000 0.728660 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7018E05C, 35352111, 0x018E01B8, 221.37, -202.144, -17.945, -0.999962, 0, 0, 0.008685, False, '2025-09-04 22:17:25'); /* Corrupted Fiun Generator */
/* @teleloc 0x018E01B8 [221.369995 -202.143997 -17.945000] -0.999962 0.000000 0.000000 0.008685 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7018E05D, 35352111, 0x018E01D4, 235.825, -194.995, -17.945, -0.930848, 0, 0, 0.365406, False, '2025-09-04 22:17:27'); /* Corrupted Fiun Generator */
/* @teleloc 0x018E01D4 [235.824997 -194.994995 -17.945000] -0.930848 0.000000 0.000000 0.365406 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7018E05E, 35352111, 0x018E01D4, 236.291, -194.493, -17.945, -0.997258, 0, 0, 0.074001, False, '2025-09-04 22:17:27'); /* Corrupted Fiun Generator */
/* @teleloc 0x018E01D4 [236.291000 -194.492996 -17.945000] -0.997258 0.000000 0.000000 0.074001 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7018E05F, 35352111, 0x018E01CA, 229.272, -215.073, -17.945, -0.045363, 0, 0, -0.998971, False, '2025-09-04 22:17:32'); /* Corrupted Fiun Generator */
/* @teleloc 0x018E01CA [229.272003 -215.072998 -17.945000] -0.045363 0.000000 0.000000 -0.998971 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7018E060, 35352111, 0x018E01CF, 229.167, -225.024, -17.945, -0.004994, 0, 0, -0.999988, False, '2025-09-04 22:17:33'); /* Corrupted Fiun Generator */
/* @teleloc 0x018E01CF [229.167007 -225.024002 -17.945000] -0.004994 0.000000 0.000000 -0.999988 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7018E061, 35352111, 0x018E01DD, 242.489, -233.542, -17.945, -0.367737, 0, 0, -0.92993, False, '2025-09-04 22:17:36'); /* Corrupted Fiun Generator */
/* @teleloc 0x018E01DD [242.488998 -233.542007 -17.945000] -0.367737 0.000000 0.000000 -0.929930 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7018E062, 35352111, 0x018E01ED, 250.361, -245.096, -17.945, 0.090614, 0, 0, -0.995886, False, '2025-09-04 22:17:38'); /* Corrupted Fiun Generator */
/* @teleloc 0x018E01ED [250.360992 -245.095993 -17.945000] 0.090614 0.000000 0.000000 -0.995886 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7018E063, 35352111, 0x018E01EE, 252.512, -257.741, -17.933, 0.492334, 0, 0, -0.870406, False, '2025-09-04 22:17:39'); /* Corrupted Fiun Generator */
/* @teleloc 0x018E01EE [252.511993 -257.740997 -17.933001] 0.492334 0.000000 0.000000 -0.870406 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7018E064, 35352111, 0x018E01F1, 258.572, -258.239, -17.945, 0.893313, 0, 0, -0.449435, False, '2025-09-04 22:17:40'); /* Corrupted Fiun Generator */
/* @teleloc 0x018E01F1 [258.571991 -258.239014 -17.945000] 0.893313 0.000000 0.000000 -0.449435 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7018E065, 931271771, 0x018E011B, 119.713, -272.609, -17.945, -0.999879, 0, 0, -0.015545, False, '2025-09-05 20:39:38'); /* pvp trap */
/* @teleloc 0x018E011B [119.712997 -272.609009 -17.945000] -0.999879 0.000000 0.000000 -0.015545 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7018E066, 931271771, 0x018E024C, 25.9786, -149.809, -5.945, 0.716641, 0, 0, 0.697442, False, '2025-09-05 20:40:04'); /* pvp trap */
/* @teleloc 0x018E024C [25.978600 -149.809006 -5.945000] 0.716641 0.000000 0.000000 0.697442 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7018E067, 931271771, 0x018E037B, 12.5615, -149.825, 0.055, 0.70294, 0, 0, 0.71125, False, '2025-09-05 20:40:07'); /* pvp trap */
/* @teleloc 0x018E037B [12.561500 -149.824997 0.055000] 0.702940 0.000000 0.000000 0.711250 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7018E068, 931271771, 0x018E0272, 46.2118, -150.041, -5.945, 0.709336, 0, 0, -0.704871, False, '2025-09-05 20:40:14'); /* pvp trap */
/* @teleloc 0x018E0272 [46.211800 -150.041000 -5.945000] 0.709336 0.000000 0.000000 -0.704871 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7018E069, 931271771, 0x018E0248, 26.1201, -129.363, -5.945, -0.894427, 0, 0, 0.447215, False, '2025-09-05 20:40:18'); /* pvp trap */
/* @teleloc 0x018E0248 [26.120100 -129.363007 -5.945000] -0.894427 0.000000 0.000000 0.447215 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7018E06A, 931271771, 0x018E0250, 29.54846, -169.0672, -5.945, -0.133199, 0, 0, 0.991089, False, '2025-09-05 20:40:23'); /* pvp trap */
/* @teleloc 0x018E0250 [29.548460 -169.067200 -5.945000] -0.133199 0.000000 0.000000 0.991089 */
