DELETE FROM `landblock_instance` WHERE `landblock` = 0x04FC;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x704FC000, 4200152, 0x04FC0001, 2.169988, 7.478887, 0.055, -0.778571, 0, 0, 0.627556, False, '2025-07-07 04:01:38'); /* Gate */
/* @teleloc 0x04FC0001 [2.169988 7.478887 0.055000] -0.778571 0.000000 0.000000 0.627556 */
