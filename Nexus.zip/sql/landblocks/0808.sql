DELETE FROM `landblock_instance` WHERE `landblock` = 0x0808;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70808000, 25939, 0x08080000, 106.431, 149.94, 24.9022, -0.807097, 0, 0, 0.590419, False, '2021-11-01 00:00:00'); /* Central Singularity Caul Gen */
/* @teleloc 0x08080000 [106.431000 149.940002 24.902201] -0.807097 0.000000 0.000000 0.590419 */
