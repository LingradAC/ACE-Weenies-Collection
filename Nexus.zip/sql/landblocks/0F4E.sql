DELETE FROM `landblock_instance` WHERE `landblock` = 0x0F4E;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70F4E000, 1910466, 0x0F4E0040, 178.846, 174.437, -0.395, -0.004771, 0, 0, -0.999989, False, '2025-07-16 15:07:21'); /* VRtree1 */
/* @teleloc 0x0F4E0040 [178.845993 174.436996 -0.395000] -0.004771 0.000000 0.000000 -0.999989 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70F4E001, 1910466, 0x0F4E003F, 179.797, 160.967, -0.395, 0.107521, 0, 0, -0.994203, False, '2025-07-16 15:07:23'); /* VRtree1 */
/* @teleloc 0x0F4E003F [179.796997 160.966995 -0.395000] 0.107521 0.000000 0.000000 -0.994203 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70F4E002, 1910466, 0x0F4E003F, 181.361, 146.895, -0.045, -0.014872, 0, 0, -0.999889, False, '2025-07-16 15:07:26'); /* VRtree1 */
/* @teleloc 0x0F4E003F [181.360992 146.895004 -0.045000] -0.014872 0.000000 0.000000 -0.999889 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70F4E003, 1910466, 0x0F4E003E, 182.3, 132.16, -0.045, 0.436808, 0, 0, -0.899555, False, '2025-07-16 15:07:29'); /* VRtree1 */
/* @teleloc 0x0F4E003E [182.300003 132.160004 -0.045000] 0.436808 0.000000 0.000000 -0.899555 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70F4E004, 1910466, 0x0F4E003E, 189.162, 125.357, -0.395, 0.44542, 0, 0, -0.895322, False, '2025-07-16 15:07:30'); /* VRtree1 */
/* @teleloc 0x0F4E003E [189.162003 125.357002 -0.395000] 0.445420 0.000000 0.000000 -0.895322 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70F4E005, 1910466, 0x0F4E0040, 175.145, 188.602, -0.395, 0.089422, 0, 0, 0.995994, False, '2025-07-16 15:08:06'); /* VRtree1 */
/* @teleloc 0x0F4E0040 [175.145004 188.602005 -0.395000] 0.089422 0.000000 0.000000 0.995994 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70F4E006, 5000216, 0x0F4E0040, 181.098, 168.059, -0.045, 0.629274, 0, 0, 0.777184, False, '2025-07-16 15:09:39'); /* Gate */
/* @teleloc 0x0F4E0040 [181.098007 168.059006 -0.045000] 0.629274 0.000000 0.000000 0.777184 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70F4E007, 5000216, 0x0F4E0040, 181.098, 168.059, -0.045, 0.629274, 0, 0, 0.777184, False, '2025-07-16 15:09:44'); /* Gate */
/* @teleloc 0x0F4E0040 [181.098007 168.059006 -0.045000] 0.629274 0.000000 0.000000 0.777184 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70F4E008, 5000216, 0x0F4E0040, 180.271, 172.013, -0.045, 0.712545, 0, 0, 0.701627, False, '2025-07-16 15:09:45'); /* Gate */
/* @teleloc 0x0F4E0040 [180.270996 172.013000 -0.045000] 0.712545 0.000000 0.000000 0.701627 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70F4E009, 5000216, 0x0F4E0040, 180.295, 174.827, -0.045, 0.657969, 0, 0, 0.753045, False, '2025-07-16 15:09:45'); /* Gate */
/* @teleloc 0x0F4E0040 [180.294998 174.826996 -0.045000] 0.657969 0.000000 0.000000 0.753045 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70F4E00A, 5000216, 0x0F4E0040, 179.337, 181.903, -0.395, 0.657969, 0, 0, 0.753045, False, '2025-07-16 15:09:47'); /* Gate */
/* @teleloc 0x0F4E0040 [179.337006 181.903000 -0.395000] 0.657969 0.000000 0.000000 0.753045 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70F4E00B, 5000216, 0x0F4E0040, 178.863, 185.406, -0.395, 0.657969, 0, 0, 0.753045, False, '2025-07-16 15:09:48'); /* Gate */
/* @teleloc 0x0F4E0040 [178.863007 185.406006 -0.395000] 0.657969 0.000000 0.000000 0.753045 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70F4E00C, 5000216, 0x0F4E0040, 178.388, 188.912, -0.395, 0.657969, 0, 0, 0.753045, False, '2025-07-16 15:09:49'); /* Gate */
/* @teleloc 0x0F4E0040 [178.388000 188.912003 -0.395000] 0.657969 0.000000 0.000000 0.753045 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70F4E00D, 5000216, 0x0F4E0040, 178.163, 190.81, -0.395, 0.738349, 0, 0, 0.674419, False, '2025-07-16 15:09:50'); /* Gate */
/* @teleloc 0x0F4E0040 [178.162994 190.809998 -0.395000] 0.738349 0.000000 0.000000 0.674419 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70F4E00E, 5000216, 0x0F4E003F, 181.21, 151.625, -0.045, -0.62843, 0, 0, -0.777867, False, '2025-07-16 15:14:37'); /* Gate */
/* @teleloc 0x0F4E003F [181.210007 151.625000 -0.045000] -0.628430 0.000000 0.000000 -0.777867 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70F4E00F, 5000216, 0x0F4E003F, 183.108, 145.952, -0.045, -0.666521, 0, 0, -0.745486, False, '2025-07-16 15:14:38'); /* Gate */
/* @teleloc 0x0F4E003F [183.108002 145.951996 -0.045000] -0.666521 0.000000 0.000000 -0.745486 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70F4E010, 5000216, 0x0F4E003E, 183.315, 143.963, -0.045, -0.729118, 0, 0, -0.684388, False, '2025-07-16 15:14:39'); /* Gate */
/* @teleloc 0x0F4E003E [183.315002 143.962997 -0.045000] -0.729118 0.000000 0.000000 -0.684388 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70F4E011, 5000216, 0x0F4E003E, 183.162, 140.942, -0.045, -0.608789, 0, 0, -0.793333, False, '2025-07-16 15:14:40'); /* Gate */
/* @teleloc 0x0F4E003E [183.162003 140.942001 -0.045000] -0.608789 0.000000 0.000000 -0.793333 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70F4E012, 5000216, 0x0F4E003E, 183.162, 140.942, -0.045, -0.608789, 0, 0, -0.793333, False, '2025-07-16 15:14:40'); /* Gate */
/* @teleloc 0x0F4E003E [183.162003 140.942001 -0.045000] -0.608789 0.000000 0.000000 -0.793333 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70F4E013, 5000216, 0x0F4E003E, 184.158, 137.338, -0.045, -0.537131, 0, 0, -0.843499, False, '2025-07-16 15:14:41'); /* Gate */
/* @teleloc 0x0F4E003E [184.158005 137.337997 -0.045000] -0.537131 0.000000 0.000000 -0.843499 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70F4E014, 5000216, 0x0F4E003E, 184.158, 137.338, -0.045, -0.537131, 0, 0, -0.843499, False, '2025-07-16 15:14:41'); /* Gate */
/* @teleloc 0x0F4E003E [184.158005 137.337997 -0.045000] -0.537131 0.000000 0.000000 -0.843499 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70F4E015, 5000216, 0x0F4E003E, 184.158, 137.338, -0.045, -0.537131, 0, 0, -0.843499, False, '2025-07-16 15:14:42'); /* Gate */
/* @teleloc 0x0F4E003E [184.158005 137.337997 -0.045000] -0.537131 0.000000 0.000000 -0.843499 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70F4E016, 5000216, 0x0F4E003E, 185.609, 134.227, -0.045, -0.537131, 0, 0, -0.843499, False, '2025-07-16 15:14:42'); /* Gate */
/* @teleloc 0x0F4E003E [185.608994 134.227005 -0.045000] -0.537131 0.000000 0.000000 -0.843499 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70F4E017, 5000216, 0x0F4E003E, 186.567, 132.285, -0.045, -0.439042, 0, 0, -0.898466, False, '2025-07-16 15:14:42'); /* Gate */
/* @teleloc 0x0F4E003E [186.567001 132.285004 -0.045000] -0.439042 0.000000 0.000000 -0.898466 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70F4E018, 5000216, 0x0F4E003E, 186.567, 132.285, -0.045, -0.439042, 0, 0, -0.898466, False, '2025-07-16 15:14:43'); /* Gate */
/* @teleloc 0x0F4E003E [186.567001 132.285004 -0.045000] -0.439042 0.000000 0.000000 -0.898466 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70F4E019, 5000216, 0x0F4E003E, 188.384, 130.051, -0.395, -0.299847, 0, 0, -0.953987, False, '2025-07-16 15:14:43'); /* Gate */
/* @teleloc 0x0F4E003E [188.384003 130.050995 -0.395000] -0.299847 0.000000 0.000000 -0.953987 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70F4E01A, 5000216, 0x0F4E003E, 188.384, 130.051, -0.395, -0.299847, 0, 0, -0.953987, False, '2025-07-16 15:14:44'); /* Gate */
/* @teleloc 0x0F4E003E [188.384003 130.050995 -0.395000] -0.299847 0.000000 0.000000 -0.953987 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70F4E01B, 5000216, 0x0F4E003E, 191.4184, 127.9344, -0.395, -0.299847, 0, 0, -0.953987, False, '2025-07-16 15:14:44'); /* Gate */
/* @teleloc 0x0F4E003E [191.418396 127.934402 -0.395000] -0.299847 0.000000 0.000000 -0.953987 */
