DELETE FROM `landblock_instance` WHERE `landblock` = 0xE4CE;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E4CE000, 4200152, 0xE4CE0039, 184.896, 1.34976, -0.845, -0.555599, 0, 0, 0.83145, False, '2025-07-19 10:39:06'); /* Gate */
/* @teleloc 0xE4CE0039 [184.895996 1.349760 -0.845000] -0.555599 0.000000 0.000000 0.831450 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E4CE001, 91737171, 0xE4CE003D, 191.661, 119.547, -0.845, -0.683851, 0, 0, -0.729622, False, '2025-07-27 14:45:10');
/* @teleloc 0xE4CE003D [191.660995 119.546997 -0.845000] -0.683851 0.000000 0.000000 -0.729622 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E4CE002, 91737171, 0xE4CE0026, 111.1947, 138.6024, -0.845, -0.263292, 0, 0, 0.964716, False, '2025-07-27 14:45:25');
/* @teleloc 0xE4CE0026 [111.194702 138.602402 -0.845000] -0.263292 0.000000 0.000000 0.964716 */
