DELETE FROM `landblock_instance` WHERE `landblock` = 0x01B7;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701B7000,  4146, 0x01B701AC, 10, 0, 0, 0, 0, 0, -1, False, '2005-02-09 10:00:00'); /* Surface */
/* @teleloc 0x01B701AC [10.000000 0.000000 0.000000] 0.000000 0.000000 0.000000 -1.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701B7002, 28674, 0x01B701CA, 28.265, -27.1863, 0.011, 0.707107, 0, 0, -0.707107,  True, '2005-02-09 10:00:00'); /* Enoki Thrungus */
/* @teleloc 0x01B701CA [28.264999 -27.186300 0.011000] 0.707107 0.000000 0.000000 -0.707107 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701B7003, 28674, 0x01B701CA, 29.6155, -30.9664, 0.011, 0.707107, 0, 0, -0.707107,  True, '2005-02-09 10:00:00'); /* Enoki Thrungus */
/* @teleloc 0x01B701CA [29.615499 -30.966400 0.011000] 0.707107 0.000000 0.000000 -0.707107 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701B7006, 28674, 0x01B701CA, 26.6382, -29.2533, 0.011, 0.707107, 0, 0, -0.707107,  True, '2005-02-09 10:00:00'); /* Enoki Thrungus */
/* @teleloc 0x01B701CA [26.638201 -29.253300 0.011000] 0.707107 0.000000 0.000000 -0.707107 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701B700B, 28674, 0x01B701E3, 47.6707, -29.9403, 0.004, -0.707107, 0, 0, -0.707107,  True, '2005-02-09 10:00:00'); /* Enoki Thrungus */
/* @teleloc 0x01B701E3 [47.670700 -29.940300 0.004000] -0.707107 0.000000 0.000000 -0.707107 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701B7012, 30496, 0x01B70100, -1.91505, -18.1044, -23.995, 0.488206, 0, 0, -0.872728,  True, '2005-02-09 10:00:00'); /* Lou Ka's Trident */
/* @teleloc 0x01B70100 [-1.915050 -18.104401 -23.995001] 0.488206 0.000000 0.000000 -0.872728 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701B7013, 28674, 0x01B70100, -1.85741, -21.7164, -23.995, 0.993596, 0, 0, -0.112987,  True, '2005-02-09 10:00:00'); /* Enoki Thrungus */
/* @teleloc 0x01B70100 [-1.857410 -21.716400 -23.995001] 0.993596 0.000000 0.000000 -0.112987 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701B7014, 28674, 0x01B70100, -1.67483, -17.7174, -23.995, 0.599713, 0, 0, -0.800215,  True, '2005-02-09 10:00:00'); /* Enoki Thrungus */
/* @teleloc 0x01B70100 [-1.674830 -17.717400 -23.995001] 0.599713 0.000000 0.000000 -0.800215 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701B7015, 28674, 0x01B70103, 10, 0, -23.995, 0.020795, 0, 0, 0.999784,  True, '2005-02-09 10:00:00'); /* Enoki Thrungus */
/* @teleloc 0x01B70103 [10.000000 0.000000 -23.995001] 0.020795 0.000000 0.000000 0.999784 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701B7016, 32593, 0x01B70120, 27.7187, -18.0811, -23.988, 0, 0, 0, -1,  True, '2005-02-09 10:00:00'); /* False Morel Thrungus */
/* @teleloc 0x01B70120 [27.718700 -18.081100 -23.988001] 0.000000 0.000000 0.000000 -1.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701B7017, 28674, 0x01B70121, 28.265, -27.1863, -23.989, 0.707107, 0, 0, -0.707107,  True, '2005-02-09 10:00:00'); /* Enoki Thrungus */
/* @teleloc 0x01B70121 [28.264999 -27.186300 -23.989000] 0.707107 0.000000 0.000000 -0.707107 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701B7018, 28674, 0x01B70121, 29.6155, -30.9664, -23.989, 0.707107, 0, 0, -0.707107,  True, '2005-02-09 10:00:00'); /* Enoki Thrungus */
/* @teleloc 0x01B70121 [29.615499 -30.966400 -23.989000] 0.707107 0.000000 0.000000 -0.707107 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701B7019,  4109, 0x01B70121, 26.6382, -29.2533, -23.989, 0.707107, 0, 0, -0.707107,  True, '2005-02-09 10:00:00'); /* Carrion Shreth */
/* @teleloc 0x01B70121 [26.638201 -29.253300 -23.989000] 0.707107 0.000000 0.000000 -0.707107 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701B701A,  5189, 0x01B70121, 27.8579, -26.2321, -24, 1, 0, 0, 0, False, '2005-02-09 10:00:00'); /* Chest */
/* @teleloc 0x01B70121 [27.857901 -26.232100 -24.000000] 1.000000 0.000000 0.000000 0.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701B701B, 32593, 0x01B70129, 41.089, -16.7643, -23.94, 0, 0, 0, -1,  True, '2005-02-09 10:00:00'); /* False Morel Thrungus */
/* @teleloc 0x01B70129 [41.089001 -16.764299 -23.940001] 0.000000 0.000000 0.000000 -1.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701B701C,   568, 0x01B7012F, 40, -25.25, -24, 1, 0, 0, 0, False, '2005-02-09 10:00:00'); /* Door */
/* @teleloc 0x01B7012F [40.000000 -25.250000 -24.000000] 1.000000 0.000000 0.000000 0.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701B701D,  1930, 0x01B7013A, 46.3707, -29.8247, -24, -0.707107, 0, 0, -0.707107, False, '2005-02-09 10:00:00'); /* Chest */
/* @teleloc 0x01B7013A [46.370701 -29.824699 -24.000000] -0.707107 0.000000 0.000000 -0.707107 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701B701E, 28674, 0x01B7013A, 47.6707, -29.9403, -23.9951, 0.816642, 0, 0, -0.577145,  True, '2005-02-09 10:00:00'); /* Enoki Thrungus */
/* @teleloc 0x01B7013A [47.670700 -29.940300 -23.995100] 0.816642 0.000000 0.000000 -0.577145 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701B701F, 28674, 0x01B7013A, 50.6541, -32.0063, -23.995, -0.909864, 0, 0, 0.414906,  True, '2005-02-09 10:00:00'); /* Enoki Thrungus */
/* @teleloc 0x01B7013A [50.654099 -32.006302 -23.995001] -0.909864 0.000000 0.000000 0.414906 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701B7020, 28674, 0x01B7013A, 52.1197, -28.3409, -23.995, -0.629453, 0, 0, 0.777039,  True, '2005-02-09 10:00:00'); /* Enoki Thrungus */
/* @teleloc 0x01B7013A [52.119701 -28.340900 -23.995001] -0.629453 0.000000 0.000000 0.777039 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701B7021, 32593, 0x01B7013D, 60.8018, -14.4823, -23.988, 1, 0, 0, 0,  True, '2005-02-09 10:00:00'); /* False Morel Thrungus */
/* @teleloc 0x01B7013D [60.801800 -14.482300 -23.988001] 1.000000 0.000000 0.000000 0.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701B7022, 28674, 0x01B70141, 59.0862, -30.2614, -23.9951, 0.400349, 0, 0, -0.916363,  True, '2005-02-09 10:00:00'); /* Enoki Thrungus */
/* @teleloc 0x01B70141 [59.086201 -30.261400 -23.995100] 0.400349 0.000000 0.000000 -0.916363 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701B7023, 28674, 0x01B70141, 61.4571, -28.1105, -23.9951, 0.096606, 0, 0, -0.995323,  True, '2005-02-09 10:00:00'); /* Enoki Thrungus */
/* @teleloc 0x01B70141 [61.457100 -28.110500 -23.995100] 0.096606 0.000000 0.000000 -0.995323 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701B7024, 28674, 0x01B70141, 61.7727, -32.8345, -23.9951, 0.94275, 0, 0, -0.333499,  True, '2005-02-09 10:00:00'); /* Enoki Thrungus */
/* @teleloc 0x01B70141 [61.772701 -32.834499 -23.995100] 0.942750 0.000000 0.000000 -0.333499 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701B7025, 32593, 0x01B70143, 73.324, -16.9759, -23.988, -0.744894, 0, 0, -0.667183,  True, '2005-02-09 10:00:00'); /* False Morel Thrungus */
/* @teleloc 0x01B70143 [73.323997 -16.975901 -23.988001] -0.744894 0.000000 0.000000 -0.667183 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701B7026, 30493, 0x01B7013A, 45.9577, -25.7679, -22.395, 0.687641, 0, 0, 0.726051,  True, '2005-02-09 10:00:00'); /* Bai Den's Ring */
/* @teleloc 0x01B7013A [45.957699 -25.767900 -22.395000] 0.687641 0.000000 0.000000 0.726051 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701B7027, 28674, 0x01B70156, 28674.1, -3.05063, -11.995, -0.32329, 0, 0, 0.9463,  True, '2005-02-09 10:00:00'); /* Enoki Thrungus */
/* @teleloc 0x01B70156 [28674.099609 -3.050630 -11.995000] -0.323290 0.000000 0.000000 0.946300 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701B7028, 30497, 0x01B70156, 11.8922, 1.7426, -11.9, -0.267354, 0, 0, -0.963598,  True, '2005-02-09 10:00:00'); /* Lou Ka's Katar */
/* @teleloc 0x01B70156 [11.892200 1.742600 -11.900000] -0.267354 0.000000 0.000000 -0.963598 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701B7029, 125757, 0x01B70173, 27.7187, -18.0811, -11.988, 0, 0, 0, -1,  True, '2005-02-09 10:00:00');
/* @teleloc 0x01B70173 [27.718700 -18.081100 -11.988000] 0.000000 0.000000 0.000000 -1.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701B702A, 28674, 0x01B70174, 26.6382, -29.2533, -11.989, 0.707107, 0, 0, -0.707107,  True, '2005-02-09 10:00:00'); /* Enoki Thrungus */
/* @teleloc 0x01B70174 [26.638201 -29.253300 -11.989000] 0.707107 0.000000 0.000000 -0.707107 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701B702B, 28674, 0x01B70174, 28.265, -27.1863, -11.989, 0.707107, 0, 0, -0.707107,  True, '2005-02-09 10:00:00'); /* Enoki Thrungus */
/* @teleloc 0x01B70174 [28.264999 -27.186300 -11.989000] 0.707107 0.000000 0.000000 -0.707107 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701B702C, 28674, 0x01B70174, 29.6155, -30.9664, -11.989, 0.707107, 0, 0, -0.707107,  True, '2005-02-09 10:00:00'); /* Enoki Thrungus */
/* @teleloc 0x01B70174 [29.615499 -30.966400 -11.989000] 0.707107 0.000000 0.000000 -0.707107 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701B702D,  5185, 0x01B70174, 27.8579, -26.2321, -125757, 1, 0, 0, 0, False, '2005-02-09 10:00:00'); /* Old Chest */
/* @teleloc 0x01B70174 [27.857901 -26.232100 -125757.000000] 1.000000 0.000000 0.000000 0.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701B702E, 125757, 0x01B7017C, 41.089, -16.7643, -11.94, 0, 0, 0, -1,  True, '2005-02-09 10:00:00');
/* @teleloc 0x01B7017C [41.089001 -16.764299 -11.940000] 0.000000 0.000000 0.000000 -1.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701B702F,   568, 0x01B70182, 40, -25.25, -125757, 1, 0, 0, 0, False, '2005-02-09 10:00:00'); /* Door */
/* @teleloc 0x01B70182 [40.000000 -25.250000 -125757.000000] 1.000000 0.000000 0.000000 0.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701B7030, 32593, 0x01B7018D, 47.6707, -29.9403, -11.9951, -0.707107, 0, 0, -0.707107,  True, '2005-02-09 10:00:00'); /* False Morel Thrungus */
/* @teleloc 0x01B7018D [47.670700 -29.940300 -11.995100] -0.707107 0.000000 0.000000 -0.707107 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701B7031, 30495, 0x01B7018D, 46.3707, -29.8247, -11.9578, -0.707107, 0, 0, -0.707107,  True, '2005-02-09 10:00:00'); /* Bai Den's Necklace */
/* @teleloc 0x01B7018D [46.370701 -29.824699 -11.957800] -0.707107 0.000000 0.000000 -0.707107 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701B7032, 125757, 0x01B7018F, 63.0206, -11.1559, -11.988, 1, 0, 0, 0,  True, '2005-02-09 10:00:00');
/* @teleloc 0x01B7018F [63.020599 -11.155900 -11.988000] 1.000000 0.000000 0.000000 0.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701B7033, 28674, 0x01B70194, 61.4653, -28.1211, -11.9956, 0.096606, 0, 0, -0.995323,  True, '2005-02-09 10:00:00'); /* Enoki Thrungus */
/* @teleloc 0x01B70194 [61.465302 -28.121099 -11.995600] 0.096606 0.000000 0.000000 -0.995323 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701B7034, 28674, 0x01B70194, 61.7727, -32.8345, -11.9956, 0.94275, 0, 0, -0.333499,  True, '2005-02-09 10:00:00'); /* Enoki Thrungus */
/* @teleloc 0x01B70194 [61.772701 -32.834499 -11.995600] 0.942750 0.000000 0.000000 -0.333499 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701B7035, 28674, 0x01B70194, 59.0992, -30.2644, -11.9956, 0.400349, 0, 0, -0.916363,  True, '2005-02-09 10:00:00'); /* Enoki Thrungus */
/* @teleloc 0x01B70194 [59.099201 -30.264400 -11.995600] 0.400349 0.000000 0.000000 -0.916363 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701B7036, 125757, 0x01B70196, 73.324, -16.9759, -11.988, -0.744894, 0, 0, -0.667183,  True, '2005-02-09 10:00:00');
/* @teleloc 0x01B70196 [73.323997 -16.975901 -11.988000] -0.744894 0.000000 0.000000 -0.667183 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701B7037,  4219, 0x01B701AF, 10, -10, 0.005, 1, 0, 0, 0, False, '2005-02-09 10:00:00'); /* Linkable Monster Generator ( 7 Min.) */
/* @teleloc 0x01B701AF [10.000000 -10.000000 0.005000] 1.000000 0.000000 0.000000 0.000000 */

INSERT INTO `landblock_instance_link` (`parent_GUID`, `child_GUID`, `last_Modified`)
VALUES (0x701B7037, 0x701B7002, '2005-02-09 10:00:00') /* Enoki Thrungus (28674) */
     , (0x701B7037, 0x701B7003, '2005-02-09 10:00:00') /* Enoki Thrungus (28674) */
     , (0x701B7037, 0x701B7006, '2005-02-09 10:00:00') /* Enoki Thrungus (28674) */
     , (0x701B7037, 0x701B700B, '2005-02-09 10:00:00') /* Enoki Thrungus (28674) */
     , (0x701B7037, 0x701B7013, '2005-02-09 10:00:00') /* Enoki Thrungus (28674) */
     , (0x701B7037, 0x701B7014, '2005-02-09 10:00:00') /* Enoki Thrungus (28674) */
     , (0x701B7037, 0x701B7015, '2005-02-09 10:00:00') /* Enoki Thrungus (28674) */
     , (0x701B7037, 0x701B7016, '2005-02-09 10:00:00') /* False Morel Thrungus (32593) */
     , (0x701B7037, 0x701B7017, '2005-02-09 10:00:00') /* Enoki Thrungus (28674) */
     , (0x701B7037, 0x701B7018, '2005-02-09 10:00:00') /* Enoki Thrungus (28674) */
     , (0x701B7037, 0x701B7019, '2005-02-09 10:00:00') /* Carrion Shreth (4109) */
     , (0x701B7037, 0x701B701B, '2005-02-09 10:00:00') /* False Morel Thrungus (32593) */
     , (0x701B7037, 0x701B701E, '2005-02-09 10:00:00') /* Enoki Thrungus (28674) */
     , (0x701B7037, 0x701B701F, '2005-02-09 10:00:00') /* Enoki Thrungus (28674) */
     , (0x701B7037, 0x701B7020, '2005-02-09 10:00:00') /* Enoki Thrungus (28674) */
     , (0x701B7037, 0x701B7021, '2005-02-09 10:00:00') /* False Morel Thrungus (32593) */
     , (0x701B7037, 0x701B7022, '2005-02-09 10:00:00') /* Enoki Thrungus (28674) */
     , (0x701B7037, 0x701B7023, '2005-02-09 10:00:00') /* Enoki Thrungus (28674) */
     , (0x701B7037, 0x701B7024, '2005-02-09 10:00:00') /* Enoki Thrungus (28674) */
     , (0x701B7037, 0x701B7025, '2005-02-09 10:00:00') /* False Morel Thrungus (32593) */
     , (0x701B7037, 0x701B7027, '2005-02-09 10:00:00') /* Enoki Thrungus (28674) */
     , (0x701B7037, 0x701B7029, '2005-02-09 10:00:00')
     , (0x701B7037, 0x701B702A, '2005-02-09 10:00:00') /* Enoki Thrungus (28674) */
     , (0x701B7037, 0x701B702B, '2005-02-09 10:00:00') /* Enoki Thrungus (28674) */
     , (0x701B7037, 0x701B702C, '2005-02-09 10:00:00') /* Enoki Thrungus (28674) */
     , (0x701B7037, 0x701B702E, '2005-02-09 10:00:00')
     , (0x701B7037, 0x701B7030, '2005-02-09 10:00:00') /* False Morel Thrungus (32593) */
     , (0x701B7037, 0x701B7032, '2005-02-09 10:00:00')
     , (0x701B7037, 0x701B7033, '2005-02-09 10:00:00') /* Enoki Thrungus (28674) */
     , (0x701B7037, 0x701B7034, '2005-02-09 10:00:00') /* Enoki Thrungus (28674) */
     , (0x701B7037, 0x701B7035, '2005-02-09 10:00:00') /* Enoki Thrungus (28674) */
     , (0x701B7037, 0x701B7036, '2005-02-09 10:00:00')
     , (0x701B7037, 0x701B7039, '2005-02-09 10:00:00')
     , (0x701B7037, 0x701B703A, '2005-02-09 10:00:00')
     , (0x701B7037, 0x701B703D, '2005-02-09 10:00:00')
     , (0x701B7037, 0x701B703F, '2005-02-09 10:00:00') /* Enoki Thrungus (28674) */
     , (0x701B7037, 0x701B7040, '2005-02-09 10:00:00') /* Enoki Thrungus (28674) */
     , (0x701B7037, 0x701B7042, '2005-02-09 10:00:00')
     , (0x701B7037, 0x701B7043, '2005-02-09 10:00:00')
     , (0x701B7037, 0x701B7044, '2005-02-09 10:00:00');

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701B7038,  5085, 0x01B701AF, 12, -10, 0.005, 1, 0, 0, 0, False, '2005-02-09 10:00:00'); /* Linkable Item Gen - 25 seconds */
/* @teleloc 0x01B701AF [12.000000 -10.000000 0.005000] 1.000000 0.000000 0.000000 0.000000 */

INSERT INTO `landblock_instance_link` (`parent_GUID`, `child_GUID`, `last_Modified`)
VALUES (0x701B7038, 0x701B7012, '2005-02-09 10:00:00') /* Lou Ka's Trident (30496) */
     , (0x701B7038, 0x701B7026, '2005-02-09 10:00:00') /* Bai Den's Ring (30493) */
     , (0x701B7038, 0x701B7028, '2005-02-09 10:00:00') /* Lou Ka's Katar (30497) */
     , (0x701B7038, 0x701B7031, '2005-02-09 10:00:00') /* Bai Den's Necklace (30495) */
     , (0x701B7038, 0x701B703C, '2005-02-09 10:00:00') /* Lou Ka's Shouken (30498) */
     , (0x701B7038, 0x701B7041, '2005-02-09 10:00:00') /* Bai Den's Bracelet (30494) */;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701B7039, 125757, 0x01B701BB, 24.7806, -10.7803, 0.055, -0.444781, 0, 0, -0.895639,  True, '2005-02-09 10:00:00');
/* @teleloc 0x01B701BB [24.780600 -10.780300 0.055000] -0.444781 0.000000 0.000000 -0.895639 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701B703A, 125757, 0x01B701C9, 27.7187, -18.0811, 0.012, 0, 0, 0, -1,  True, '2005-02-09 10:00:00');
/* @teleloc 0x01B701C9 [27.718700 -18.081100 0.012000] 0.000000 0.000000 0.000000 -1.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701B703B,  1930, 0x01B701CA, 27.8579, -26.2321, 0, 1, 0, 0, 0, False, '2005-02-09 10:00:00'); /* Chest */
/* @teleloc 0x01B701CA [27.857901 -26.232100 0.000000] 1.000000 0.000000 0.000000 0.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701B703C, 30498, 0x01B701CA, 26.9579, -27.3834, 0.15, 0.475732, 0, 0, -0.87959,  True, '2005-02-09 10:00:00'); /* Lou Ka's Shouken */
/* @teleloc 0x01B701CA [26.957899 -27.383400 0.150000] 0.475732 0.000000 0.000000 -0.879590 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701B703D, 125757, 0x01B701D2, 41.089, -16.7643, 0.06, 0, 0, 0, -1,  True, '2005-02-09 10:00:00');
/* @teleloc 0x01B701D2 [41.089001 -16.764299 0.060000] 0.000000 0.000000 0.000000 -1.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701B703E,   568, 0x01B701D8, 40, -25.25, 0, 1, 0, 0, 0, False, '2005-02-09 10:00:00'); /* Door */
/* @teleloc 0x01B701D8 [40.000000 -25.250000 0.000000] 1.000000 0.000000 0.000000 0.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701B703F, 28674, 0x01B701E3, 49.452, -28.3693, 0.005, 0.88989, 0, 0, -0.456175,  True, '2005-02-09 10:00:00'); /* Enoki Thrungus */
/* @teleloc 0x01B701E3 [49.452000 -28.369301 0.005000] 0.889890 0.000000 0.000000 -0.456175 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701B7040, 28674, 0x01B701E3, 52.2788, -32.3354, 0.005, 0.459847, 0, 0, -0.887998,  True, '2005-02-09 10:00:00'); /* Enoki Thrungus */
/* @teleloc 0x01B701E3 [52.278801 -32.335400 0.005000] 0.459847 0.000000 0.000000 -0.887998 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701B7041, 30494, 0x01B701E3, 46.3707, -29.8247, 0.03886, -0.707107, 0, 0, -0.707107,  True, '2005-02-09 10:00:00'); /* Bai Den's Bracelet */
/* @teleloc 0x01B701E3 [46.370701 -29.824699 0.038860] -0.707107 0.000000 0.000000 -0.707107 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701B7042, 125757, 0x01B701E9, 60.2512, -15.9802, 0.012, -0.881388, 0, 0, -0.472393,  True, '2005-02-09 10:00:00');
/* @teleloc 0x01B701E9 [60.251202 -15.980200 0.012000] -0.881388 0.000000 0.000000 -0.472393 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701B7043, 125757, 0x01B701EB, 66.4955, -14.613, 0.055, -0.510931, 0, 0, 0.859622,  True, '2005-02-09 10:00:00');
/* @teleloc 0x01B701EB [66.495499 -14.613000 0.055000] -0.510931 0.000000 0.000000 0.859622 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701B7044, 125757, 0x01B701EC, 73.324, -16.9759, 0.012, -0.744894, 0, 0, -0.667183,  True, '2005-02-09 10:00:00');
/* @teleloc 0x01B701EC [73.323997 -16.975901 0.012000] -0.744894 0.000000 0.000000 -0.667183 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701B7046, 3483357, 0x01B701EE, 79.7155, -10.0318, -0.02675, 0.541732, 0, 0, 0.840552, False, '2025-07-21 14:17:35'); /* Blue Glow Mushroom */
/* @teleloc 0x01B701EE [79.715500 -10.031800 -0.026750] 0.541732 0.000000 0.000000 0.840552 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701B7047, 3483357, 0x01B701EE, 82.5562, -6.6371, -0.02675, -0.687668, 0, 0, 0.726025, False, '2025-07-21 14:17:42'); /* Blue Glow Mushroom */
/* @teleloc 0x01B701EE [82.556198 -6.637100 -0.026750] -0.687668 0.000000 0.000000 0.726025 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701B7048, 3483357, 0x01B701F0, 82.7023, -30.4573, -0.02675, 0.068115, 0, 0, 0.997678, False, '2025-07-21 14:17:45'); /* Blue Glow Mushroom */
/* @teleloc 0x01B701F0 [82.702301 -30.457300 -0.026750] 0.068115 0.000000 0.000000 0.997678 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701B7049, 3483357, 0x01B701E3, 48.1402, -33.3629, -0.02675, 0.69343, 0, 0, 0.720524, False, '2025-07-21 14:17:48'); /* Blue Glow Mushroom */
/* @teleloc 0x01B701E3 [48.140202 -33.362900 -0.026750] 0.693430 0.000000 0.000000 0.720524 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701B704A, 3483357, 0x01B701A6, 1.8447, -12.1313, -0.02675, -0.423067, 0, 0, 0.906099, False, '2025-07-21 14:22:08'); /* Blue Glow Mushroom */
/* @teleloc 0x01B701A6 [1.844700 -12.131300 -0.026750] -0.423067 0.000000 0.000000 0.906099 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701B704B, 3483357, 0x01B701AF, 11.8125, -12.2492, -0.02675, -0.392332, 0, 0, 0.919824, False, '2025-07-21 14:22:14'); /* Blue Glow Mushroom */
/* @teleloc 0x01B701AF [11.812500 -12.249200 -0.026750] -0.392332 0.000000 0.000000 0.919824 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701B704C, 3483357, 0x01B701B5, 12.445, -17.6593, -0.02675, -0.98141, 0, 0, 0.191922, False, '2025-07-21 14:22:18'); /* Blue Glow Mushroom */
/* @teleloc 0x01B701B5 [12.445000 -17.659300 -0.026750] -0.981410 0.000000 0.000000 0.191922 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701B704D, 3483357, 0x01B70156, 8.04995, 2.04771, -12.0267, -0.946204, 0, 0, -0.32357, False, '2025-07-21 14:22:25'); /* Blue Glow Mushroom */
/* @teleloc 0x01B70156 [8.049950 2.047710 -12.026700] -0.946204 0.000000 0.000000 -0.323570 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701B704E, 3483357, 0x01B7015F, 9.69086, -17.4895, -12.0267, -0.998806, 0, 0, 0.048844, False, '2025-07-21 14:22:57'); /* Blue Glow Mushroom */
/* @teleloc 0x01B7015F [9.690860 -17.489500 -12.026700] -0.998806 0.000000 0.000000 0.048844 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701B704F, 3483357, 0x01B70198, 81.7138, -7.4342, -12.0267, 0.870852, 0, 0, -0.491545, False, '2025-07-21 14:23:20'); /* Blue Glow Mushroom */
/* @teleloc 0x01B70198 [81.713799 -7.434200 -12.026700] 0.870852 0.000000 0.000000 -0.491545 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701B7050, 3483357, 0x01B70198, 81.6393, -11.4898, -12.0267, 0.870852, 0, 0, -0.491545, False, '2025-07-21 14:23:23'); /* Blue Glow Mushroom */
/* @teleloc 0x01B70198 [81.639297 -11.489800 -12.026700] 0.870852 0.000000 0.000000 -0.491545 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701B7051, 3483357, 0x01B70198, 76.9725, -7.82485, -12.0267, 0.870852, 0, 0, -0.491545, False, '2025-07-21 14:23:25'); /* Blue Glow Mushroom */
/* @teleloc 0x01B70198 [76.972504 -7.824850 -12.026700] 0.870852 0.000000 0.000000 -0.491545 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701B7052, 3483357, 0x01B70195, 73.3401, -7.72502, -12.0267, 0.870852, 0, 0, -0.491545, False, '2025-07-21 14:23:25'); /* Blue Glow Mushroom */
/* @teleloc 0x01B70195 [73.340103 -7.725020 -12.026700] 0.870852 0.000000 0.000000 -0.491545 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701B7053, 3483357, 0x01B7019A, 81.4101, -30.8796, -12.0267, -0.039678, 0, 0, -0.999213, False, '2025-07-21 14:23:31'); /* Blue Glow Mushroom */
/* @teleloc 0x01B7019A [81.410103 -30.879601 -12.026700] -0.039678 0.000000 0.000000 -0.999213 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701B7054, 3483357, 0x01B7018D, 47.7587, -33.3629, -12.0267, -0.999679, 0, 0, -0.025338, False, '2025-07-21 14:23:36'); /* Blue Glow Mushroom */
/* @teleloc 0x01B7018D [47.758701 -33.362900 -12.026700] -0.999679 0.000000 0.000000 -0.025338 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701B7055, 3483357, 0x01B7018D, 49.1542, -26.6371, -12.0267, -0.769257, 0, 0, -0.638939, False, '2025-07-21 14:23:40'); /* Blue Glow Mushroom */
/* @teleloc 0x01B7018D [49.154202 -26.637100 -12.026700] -0.769257 0.000000 0.000000 -0.638939 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701B7056, 3483357, 0x01B70106, 11.9571, -12.2708, -24.0268, -0.614329, 0, 0, 0.78905, False, '2025-07-21 14:23:55'); /* Blue Glow Mushroom */
/* @teleloc 0x01B70106 [11.957100 -12.270800 -24.026800] -0.614329 0.000000 0.000000 0.789050 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701B7057, 3483357, 0x01B70147, 82.1387, -30.1966, -24.0268, -0.051432, 0, 0, 0.998677, False, '2025-07-21 14:24:05'); /* Blue Glow Mushroom */
/* @teleloc 0x01B70147 [82.138702 -30.196600 -24.026800] -0.051432 0.000000 0.000000 0.998677 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701B7058, 3483357, 0x01B70147, 77.2121, -29.7238, -24.0268, 0.795418, 0, 0, 0.606061, False, '2025-07-21 14:24:07'); /* Blue Glow Mushroom */
/* @teleloc 0x01B70147 [77.212097 -29.723801 -24.026800] 0.795418 0.000000 0.000000 0.606061 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701B7059, 3483357, 0x01B70147, 79.5569, -32.9339, -24.0268, -0.658446, 0, 0, 0.752628, False, '2025-07-21 14:24:10'); /* Blue Glow Mushroom */
/* @teleloc 0x01B70147 [79.556900 -32.933899 -24.026800] -0.658446 0.000000 0.000000 0.752628 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701B705A, 3483357, 0x01B7013A, 47.1258, -33.3629, -24.0268, -0.742818, 0, 0, -0.669494, False, '2025-07-21 14:24:14'); /* Blue Glow Mushroom */
/* @teleloc 0x01B7013A [47.125801 -33.362900 -24.026800] -0.742818 0.000000 0.000000 -0.669494 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701B705B, 3483357, 0x01B7013A, 47.4714, -33.3629, -24.0268, -0.976661, 0, 0, 0.214786, False, '2025-07-21 14:24:15'); /* Blue Glow Mushroom */
/* @teleloc 0x01B7013A [47.471401 -33.362900 -24.026800] -0.976661 0.000000 0.000000 0.214786 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701B705C, 8729957, 0x01B70147, 75.2758, -31.6547, -24.0142, 0.159621, 0, 0, -0.987178, False, '2025-07-21 14:24:36'); /* Red Burning Mushroom */
/* @teleloc 0x01B70147 [75.275803 -31.654699 -24.014200] 0.159621 0.000000 0.000000 -0.987178 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701B705D, 8729957, 0x01B70147, 76.5439, -25.8571, -24.0142, 0.159621, 0, 0, -0.987178, False, '2025-07-21 14:24:38'); /* Red Burning Mushroom */
/* @teleloc 0x01B70147 [76.543900 -25.857100 -24.014200] 0.159621 0.000000 0.000000 -0.987178 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701B705E, 8729957, 0x01B70147, 78.8304, -27.7539, -24.0142, 0.256914, 0, 0, -0.966434, False, '2025-07-21 14:24:39'); /* Red Burning Mushroom */
/* @teleloc 0x01B70147 [78.830399 -27.753901 -24.014200] 0.256914 0.000000 0.000000 -0.966434 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701B705F, 8729957, 0x01B70147, 80.9497, -27.2516, -24.0142, 0.901942, 0, 0, -0.431856, False, '2025-07-21 14:24:40'); /* Red Burning Mushroom */
/* @teleloc 0x01B70147 [80.949699 -27.251600 -24.014200] 0.901942 0.000000 0.000000 -0.431856 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701B7060, 8729957, 0x01B70143, 71.2393, -21.1775, -24.0142, 0.708629, 0, 0, 0.705582, False, '2025-07-21 14:24:41'); /* Red Burning Mushroom */
/* @teleloc 0x01B70143 [71.239304 -21.177500 -24.014200] 0.708629 0.000000 0.000000 0.705582 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701B7061, 8729957, 0x01B70145, 77.6251, -14.6292, -24.0142, 0.953638, 0, 0, -0.300957, False, '2025-07-21 14:24:43'); /* Red Burning Mushroom */
/* @teleloc 0x01B70145 [77.625099 -14.629200 -24.014200] 0.953638 0.000000 0.000000 -0.300957 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701B7062, 8729957, 0x01B70145, 78.3873, -7.37464, -24.0142, 0.859941, 0, 0, 0.510394, False, '2025-07-21 14:24:44'); /* Red Burning Mushroom */
/* @teleloc 0x01B70145 [78.387299 -7.374640 -24.014200] 0.859941 0.000000 0.000000 0.510394 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701B7063, 8729957, 0x01B7013D, 58.974, -14.4073, -24.0142, 0.604464, 0, 0, 0.796632, False, '2025-07-21 14:24:48'); /* Red Burning Mushroom */
/* @teleloc 0x01B7013D [58.973999 -14.407300 -24.014200] 0.604464 0.000000 0.000000 0.796632 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701B7064, 8729957, 0x01B7010C, 10.2898, -21.3053, -24.0142, 0.402281, 0, 0, 0.915516, False, '2025-07-21 14:24:55'); /* Red Burning Mushroom */
/* @teleloc 0x01B7010C [10.289800 -21.305300 -24.014200] 0.402281 0.000000 0.000000 0.915516 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701B7065, 8729957, 0x01B70106, 9.52427, -11.1052, -24.0142, 0.860249, 0, 0, -0.509875, False, '2025-07-21 14:25:00'); /* Red Burning Mushroom */
/* @teleloc 0x01B70106 [9.524270 -11.105200 -24.014200] 0.860249 0.000000 0.000000 -0.509875 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701B7066, 8729957, 0x01B7015F, 13.6279, -23.5665, -12.0142, -0.495709, 0, 0, 0.868489, False, '2025-07-21 14:25:06'); /* Red Burning Mushroom */
/* @teleloc 0x01B7015F [13.627900 -23.566500 -12.014200] -0.495709 0.000000 0.000000 0.868489 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701B7067, 8729957, 0x01B70159, 12.4652, -6.57222, -12.0142, -0.84375, 0, 0, 0.536737, False, '2025-07-21 14:25:09'); /* Red Burning Mushroom */
/* @teleloc 0x01B70159 [12.465200 -6.572220 -12.014200] -0.843750 0.000000 0.000000 0.536737 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701B7068, 8729957, 0x01B70198, 76.0182, -10.213, -12.0142, -0.841154, 0, 0, 0.540796, False, '2025-07-21 14:25:16'); /* Red Burning Mushroom */
/* @teleloc 0x01B70198 [76.018204 -10.213000 -12.014200] -0.841154 0.000000 0.000000 0.540796 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701B7069, 8729957, 0x01B70198, 76.0182, -10.213, -12.0142, -0.841154, 0, 0, 0.540796, False, '2025-07-21 14:25:16'); /* Red Burning Mushroom */
/* @teleloc 0x01B70198 [76.018204 -10.213000 -12.014200] -0.841154 0.000000 0.000000 0.540796 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701B706A, 8729957, 0x01B70198, 78.8171, -11.2962, -12.0142, -0.458958, 0, 0, 0.888458, False, '2025-07-21 14:25:17'); /* Red Burning Mushroom */
/* @teleloc 0x01B70198 [78.817101 -11.296200 -12.014200] -0.458958 0.000000 0.000000 0.888458 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701B706B, 8729957, 0x01B70198, 80.1266, -14.6212, -12.0142, -0.17874, 0, 0, 0.983896, False, '2025-07-21 14:25:18'); /* Red Burning Mushroom */
/* @teleloc 0x01B70198 [80.126602 -14.621200 -12.014200] -0.178740 0.000000 0.000000 0.983896 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701B706C, 8729957, 0x01B70199, 81.8142, -15.2807, -12.0142, -0.978556, 0, 0, -0.20598, False, '2025-07-21 14:25:19'); /* Red Burning Mushroom */
/* @teleloc 0x01B70199 [81.814201 -15.280700 -12.014200] -0.978556 0.000000 0.000000 -0.205980 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701B706D, 8729957, 0x01B70195, 72.6449, -9.56897, -12.0142, -0.94141, 0, 0, -0.337266, False, '2025-07-21 14:25:21'); /* Red Burning Mushroom */
/* @teleloc 0x01B70195 [72.644897 -9.568970 -12.014200] -0.941410 0.000000 0.000000 -0.337266 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701B706E, 8729957, 0x01B70195, 69.4978, -7.47741, -12.0142, -0.860577, 0, 0, -0.50932, False, '2025-07-21 14:25:22'); /* Red Burning Mushroom */
/* @teleloc 0x01B70195 [69.497803 -7.477410 -12.014200] -0.860577 0.000000 0.000000 -0.509320 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701B706F, 8729957, 0x01B70195, 67.7622, -6.52472, -12.0142, -0.860577, 0, 0, -0.50932, False, '2025-07-21 14:25:22'); /* Red Burning Mushroom */
/* @teleloc 0x01B70195 [67.762199 -6.524720 -12.014200] -0.860577 0.000000 0.000000 -0.509320 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701B7070, 8729957, 0x01B70195, 68.2642, -12.9629, -12.0142, 0.223232, 0, 0, -0.974765, False, '2025-07-21 14:25:24'); /* Red Burning Mushroom */
/* @teleloc 0x01B70195 [68.264198 -12.962900 -12.014200] 0.223232 0.000000 0.000000 -0.974765 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701B7071, 8729957, 0x01B70196, 69.4159, -15.3456, -12.0142, 0.223232, 0, 0, -0.974765, False, '2025-07-21 14:25:25'); /* Red Burning Mushroom */
/* @teleloc 0x01B70196 [69.415901 -15.345600 -12.014200] 0.223232 0.000000 0.000000 -0.974765 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701B7072, 8729957, 0x01B70197, 68.7884, -31.5518, -12.0142, -0.57519, 0, 0, -0.81802, False, '2025-07-21 14:25:26'); /* Red Burning Mushroom */
/* @teleloc 0x01B70197 [68.788399 -31.551800 -12.014200] -0.575190 0.000000 0.000000 -0.818020 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701B7073, 8729957, 0x01B7018D, 50.0988, -28.9326, -12.0142, -0.864947, 0, 0, -0.501864, False, '2025-07-21 14:25:28'); /* Red Burning Mushroom */
/* @teleloc 0x01B7018D [50.098801 -28.932600 -12.014200] -0.864947 0.000000 0.000000 -0.501864 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701B7074, 8729957, 0x01B70199, 75.8439, -20.5579, -12.0142, 0.958135, 0, 0, -0.286316, False, '2025-07-21 14:25:31'); /* Red Burning Mushroom */
/* @teleloc 0x01B70199 [75.843903 -20.557899 -12.014200] 0.958135 0.000000 0.000000 -0.286316 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701B7075, 8729957, 0x01B701B5, 12.8752, -23.6279, -0.01425, -0.43828, 0, 0, 0.898839, False, '2025-07-21 14:25:47'); /* Red Burning Mushroom */
/* @teleloc 0x01B701B5 [12.875200 -23.627899 -0.014250] -0.438280 0.000000 0.000000 0.898839 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701B7076, 8729957, 0x01B701AF, 8.56346, -6.55034, -0.01425, -0.717651, 0, 0, -0.696403, False, '2025-07-21 14:25:51'); /* Red Burning Mushroom */
/* @teleloc 0x01B701AF [8.563460 -6.550340 -0.014250] -0.717651 0.000000 0.000000 -0.696403 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701B7077, 8729957, 0x01B701EE, 76.5473, -8.18391, -0.01425, 0.912979, 0, 0, -0.408007, False, '2025-07-21 14:26:01'); /* Red Burning Mushroom */
/* @teleloc 0x01B701EE [76.547302 -8.183910 -0.014250] 0.912979 0.000000 0.000000 -0.408007 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701B7078, 8729957, 0x01B701EE, 77.4478, -10.8636, -0.01425, -0.031676, 0, 0, -0.999498, False, '2025-07-21 14:26:03'); /* Red Burning Mushroom */
/* @teleloc 0x01B701EE [77.447800 -10.863600 -0.014250] -0.031676 0.000000 0.000000 -0.999498 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701B7079, 8729957, 0x01B701EE, 82.4961, -13.6779, -0.01425, 0.822018, 0, 0, -0.569462, False, '2025-07-21 14:26:04'); /* Red Burning Mushroom */
/* @teleloc 0x01B701EE [82.496101 -13.677900 -0.014250] 0.822018 0.000000 0.000000 -0.569462 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701B707A, 8729957, 0x01B701F0, 79.3822, -30.3002, -0.01425, 0.007738, 0, 0, -0.99997, False, '2025-07-21 14:26:06'); /* Red Burning Mushroom */
/* @teleloc 0x01B701F0 [79.382202 -30.300200 -0.014250] 0.007738 0.000000 0.000000 -0.999970 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701B707B, 8729957, 0x01B701F0, 80.0911, -31.0785, -0.01425, -0.05137, 0, 0, -0.99868, False, '2025-07-21 14:26:07'); /* Red Burning Mushroom */
/* @teleloc 0x01B701F0 [80.091103 -31.078501 -0.014250] -0.051370 0.000000 0.000000 -0.998680 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701B707C, 8729957, 0x01B701E3, 49.2518, -31.1547, -0.01425, -0.678424, 0, 0, -0.73467, False, '2025-07-21 14:26:10'); /* Red Burning Mushroom */
/* @teleloc 0x01B701E3 [49.251801 -31.154699 -0.014250] -0.678424 0.000000 0.000000 -0.734670 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701B707D, 8729957, 0x01B701E3, 51.1228, -33.8879, -0.01425, -0.887887, 0, 0, -0.460061, False, '2025-07-21 14:26:14'); /* Red Burning Mushroom */
/* @teleloc 0x01B701E3 [51.122799 -33.887901 -0.014250] -0.887887 0.000000 0.000000 -0.460061 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701B707E, 3102157, 0x01B701B5, 11.5497, -23.9319, 0, 0.32207, 0, 0, -0.946716, False, '2025-07-21 14:27:43'); /* Puffball Thrungus */
/* @teleloc 0x01B701B5 [11.549700 -23.931900 0.000000] 0.322070 0.000000 0.000000 -0.946716 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701B707F, 3102157, 0x01B701B5, 10.3702, -23.4836, 0, 0.32207, 0, 0, -0.946716, False, '2025-07-21 14:27:45'); /* Puffball Thrungus */
/* @teleloc 0x01B701B5 [10.370200 -23.483601 0.000000] 0.322070 0.000000 0.000000 -0.946716 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701B7080, 3102157, 0x01B701B5, 11.5739, -23.1892, 0, 0.754148, 0, 0, -0.656705, False, '2025-07-21 14:27:46'); /* Puffball Thrungus */
/* @teleloc 0x01B701B5 [11.573900 -23.189199 0.000000] 0.754148 0.000000 0.000000 -0.656705 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701B7081, 3102157, 0x01B701B5, 12.563, -22.2355, 0, 0.843816, 0, 0, -0.536633, False, '2025-07-21 14:27:47'); /* Puffball Thrungus */
/* @teleloc 0x01B701B5 [12.563000 -22.235500 0.000000] 0.843816 0.000000 0.000000 -0.536633 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701B7082, 3102157, 0x01B701C1, 25.2686, -8.89793, 0, 0.965468, 0, 0, -0.260522, False, '2025-07-21 14:27:49'); /* Puffball Thrungus */
/* @teleloc 0x01B701C1 [25.268600 -8.897930 0.000000] 0.965468 0.000000 0.000000 -0.260522 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701B7083, 3102157, 0x01B701C1, 25.2686, -8.89793, 0, 0.965468, 0, 0, -0.260522, False, '2025-07-21 14:27:50'); /* Puffball Thrungus */
/* @teleloc 0x01B701C1 [25.268600 -8.897930 0.000000] 0.965468 0.000000 0.000000 -0.260522 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701B7084, 3102157, 0x01B701CD, 37.5402, -10.923, 0, 0.739767, 0, 0, -0.672863, False, '2025-07-21 14:27:51'); /* Puffball Thrungus */
/* @teleloc 0x01B701CD [37.540199 -10.923000 0.000000] 0.739767 0.000000 0.000000 -0.672863 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701B7085, 3102157, 0x01B701DA, 45.3965, -8.99768, 0, 0.835991, 0, 0, -0.548744, False, '2025-07-21 14:27:52'); /* Puffball Thrungus */
/* @teleloc 0x01B701DA [45.396500 -8.997680 0.000000] 0.835991 0.000000 0.000000 -0.548744 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701B7086, 3102157, 0x01B701E4, 56.4214, -9.26736, 0, 0.794865, 0, 0, -0.606787, False, '2025-07-21 14:27:54'); /* Puffball Thrungus */
/* @teleloc 0x01B701E4 [56.421398 -9.267360 0.000000] 0.794865 0.000000 0.000000 -0.606787 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701B7087, 3102157, 0x01B701E7, 62.2665, -16.6935, 0, 0.306099, 0, 0, -0.952, False, '2025-07-21 14:27:55'); /* Puffball Thrungus */
/* @teleloc 0x01B701E7 [62.266499 -16.693501 0.000000] 0.306099 0.000000 0.000000 -0.952000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701B7088, 3102157, 0x01B701ED, 71.3452, -25.0288, 0, 0.516963, 0, 0, -0.856008, False, '2025-07-21 14:27:56'); /* Puffball Thrungus */
/* @teleloc 0x01B701ED [71.345200 -25.028799 0.000000] 0.516963 0.000000 0.000000 -0.856008 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701B7089, 3102157, 0x01B701ED, 71.3452, -25.0288, 0, 0.516963, 0, 0, -0.856008, False, '2025-07-21 14:27:57'); /* Puffball Thrungus */
/* @teleloc 0x01B701ED [71.345200 -25.028799 0.000000] 0.516963 0.000000 0.000000 -0.856008 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701B708A, 3102157, 0x01B701EF, 77.7786, -24.9283, 0, 0.871471, 0, 0, -0.490447, False, '2025-07-21 14:27:58'); /* Puffball Thrungus */
/* @teleloc 0x01B701EF [77.778603 -24.928301 0.000000] 0.871471 0.000000 0.000000 -0.490447 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701B708B, 3102157, 0x01B701EE, 77.4822, -12.2618, 0, 0.960208, 0, 0, 0.279285, False, '2025-07-21 14:28:00'); /* Puffball Thrungus */
/* @teleloc 0x01B701EE [77.482201 -12.261800 0.000000] 0.960208 0.000000 0.000000 0.279285 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701B708C, 3102157, 0x01B701EE, 78.9143, -12.7749, 0, 0.816068, 0, 0, 0.577956, False, '2025-07-21 14:28:02'); /* Puffball Thrungus */
/* @teleloc 0x01B701EE [78.914299 -12.774900 0.000000] 0.816068 0.000000 0.000000 0.577956 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701B708D, 3102157, 0x01B701EE, 79.0733, -14.8371, 0, -0.03724, 0, 0, 0.999306, False, '2025-07-21 14:28:03'); /* Puffball Thrungus */
/* @teleloc 0x01B701EE [79.073303 -14.837100 0.000000] -0.037240 0.000000 0.000000 0.999306 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701B708E, 3102157, 0x01B701EF, 79.0897, -15.0561, 0, -0.03724, 0, 0, 0.999306, False, '2025-07-21 14:28:04'); /* Puffball Thrungus */
/* @teleloc 0x01B701EF [79.089699 -15.056100 0.000000] -0.037240 0.000000 0.000000 0.999306 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701B708F, 3102157, 0x01B701EF, 79.0897, -15.0561, 0, -0.03724, 0, 0, 0.999306, False, '2025-07-21 14:28:04'); /* Puffball Thrungus */
/* @teleloc 0x01B701EF [79.089699 -15.056100 0.000000] -0.037240 0.000000 0.000000 0.999306 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701B7090, 3102157, 0x01B701EF, 78.6985, -20.3392, 0, -0.113443, 0, 0, 0.993545, False, '2025-07-21 14:28:05'); /* Puffball Thrungus */
/* @teleloc 0x01B701EF [78.698502 -20.339199 0.000000] -0.113443 0.000000 0.000000 0.993545 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701B7091, 3102157, 0x01B701EC, 69.7789, -24.3336, 0, 0.791621, 0, 0, -0.611013, False, '2025-07-21 14:28:12'); /* Puffball Thrungus */
/* @teleloc 0x01B701EC [69.778900 -24.333599 0.000000] 0.791621 0.000000 0.000000 -0.611013 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701B7092, 3102157, 0x01B7019B, 1.67241, -8.84222, -8.84972, 0.975511, 0, 0, -0.21995, False, '2025-07-21 14:28:24'); /* Puffball Thrungus */
/* @teleloc 0x01B7019B [1.672410 -8.842220 -8.849720] 0.975511 0.000000 0.000000 -0.219950 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701B7093, 3102157, 0x01B7019C, -1.17948, -8.82496, -9, 0.832405, 0, 0, 0.554168, False, '2025-07-21 14:28:25'); /* Puffball Thrungus */
/* @teleloc 0x01B7019C [-1.179480 -8.824960 -9.000000] 0.832405 0.000000 0.000000 0.554168 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701B7094, 3102157, 0x01B70159, 10.3815, -7.32955, -12, 0.81229, 0, 0, -0.583253, False, '2025-07-21 14:28:28'); /* Puffball Thrungus */
/* @teleloc 0x01B70159 [10.381500 -7.329550 -12.000000] 0.812290 0.000000 0.000000 -0.583253 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701B7095, 3102157, 0x01B70159, 10.3815, -7.32955, -12, 0.81229, 0, 0, -0.583253, False, '2025-07-21 14:28:30'); /* Puffball Thrungus */
/* @teleloc 0x01B70159 [10.381500 -7.329550 -12.000000] 0.812290 0.000000 0.000000 -0.583253 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701B7096, 3102157, 0x01B70165, 21.9548, -12.8984, -12, 0.869088, 0, 0, -0.494657, False, '2025-07-21 14:28:32'); /* Puffball Thrungus */
/* @teleloc 0x01B70165 [21.954800 -12.898400 -12.000000] 0.869088 0.000000 0.000000 -0.494657 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701B7097, 3102157, 0x01B70177, 38.7188, -10.2818, -12, 0.7113, 0, 0, -0.702889, False, '2025-07-21 14:28:37'); /* Puffball Thrungus */
/* @teleloc 0x01B70177 [38.718800 -10.281800 -12.000000] 0.711300 0.000000 0.000000 -0.702889 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701B7098, 3102157, 0x01B70185, 49.7284, -11.2152, -12, 0.766615, 0, 0, -0.642107, False, '2025-07-21 14:28:39'); /* Puffball Thrungus */
/* @teleloc 0x01B70185 [49.728401 -11.215200 -12.000000] 0.766615 0.000000 0.000000 -0.642107 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701B7099, 3102157, 0x01B70195, 68.9762, -10.9412, -12, 0.712311, 0, 0, -0.701864, False, '2025-07-21 14:28:42'); /* Puffball Thrungus */
/* @teleloc 0x01B70195 [68.976196 -10.941200 -12.000000] 0.712311 0.000000 0.000000 -0.701864 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701B709A, 3102157, 0x01B70199, 75.6197, -15.2369, -12, 0.319766, 0, 0, -0.947497, False, '2025-07-21 14:28:43'); /* Puffball Thrungus */
/* @teleloc 0x01B70199 [75.619698 -15.236900 -12.000000] 0.319766 0.000000 0.000000 -0.947497 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701B709B, 3102157, 0x01B70199, 75.6197, -15.2369, -12, 0.319766, 0, 0, -0.947497, False, '2025-07-21 14:28:44'); /* Puffball Thrungus */
/* @teleloc 0x01B70199 [75.619698 -15.236900 -12.000000] 0.319766 0.000000 0.000000 -0.947497 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701B709C, 3102157, 0x01B70199, 82.8227, -24.3831, -12, -0.027873, 0, 0, -0.999612, False, '2025-07-21 14:28:45'); /* Puffball Thrungus */
/* @teleloc 0x01B70199 [82.822701 -24.383101 -12.000000] -0.027873 0.000000 0.000000 -0.999612 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701B709D, 3102157, 0x01B7019A, 76.0072, -31.9747, -12, -0.236204, 0, 0, -0.971704, False, '2025-07-21 14:28:48'); /* Puffball Thrungus */
/* @teleloc 0x01B7019A [76.007202 -31.974701 -12.000000] -0.236204 0.000000 0.000000 -0.971704 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701B709E, 3102157, 0x01B7019A, 78.5531, -25.2949, -12, 0.994398, 0, 0, -0.105697, False, '2025-07-21 14:28:51'); /* Puffball Thrungus */
/* @teleloc 0x01B7019A [78.553101 -25.294901 -12.000000] 0.994398 0.000000 0.000000 -0.105697 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701B709F, 3102157, 0x01B7019A, 78.5531, -25.2949, -12, 0.994398, 0, 0, -0.105697, False, '2025-07-21 14:28:52'); /* Puffball Thrungus */
/* @teleloc 0x01B7019A [78.553101 -25.294901 -12.000000] 0.994398 0.000000 0.000000 -0.105697 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701B70A0, 3102157, 0x01B7019A, 78.0081, -27.1171, -12, -0.676865, 0, 0, 0.736107, False, '2025-07-21 14:28:53'); /* Puffball Thrungus */
/* @teleloc 0x01B7019A [78.008102 -27.117100 -12.000000] -0.676865 0.000000 0.000000 0.736107 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701B70A1, 3102157, 0x01B70111, 17.7748, -10.924, -24, 0.522037, 0, 0, -0.852923, False, '2025-07-21 14:29:14'); /* Puffball Thrungus */
/* @teleloc 0x01B70111 [17.774799 -10.924000 -24.000000] 0.522037 0.000000 0.000000 -0.852923 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701B70A2, 3102157, 0x01B70112, 24.9892, -9.16271, -24, 0.978126, 0, 0, -0.208016, False, '2025-07-21 14:29:16'); /* Puffball Thrungus */
/* @teleloc 0x01B70112 [24.989201 -9.162710 -24.000000] 0.978126 0.000000 0.000000 -0.208016 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701B70A3, 3102157, 0x01B70112, 24.9892, -9.16271, -24, 0.978126, 0, 0, -0.208016, False, '2025-07-21 14:29:17'); /* Puffball Thrungus */
/* @teleloc 0x01B70112 [24.989201 -9.162710 -24.000000] 0.978126 0.000000 0.000000 -0.208016 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701B70A4, 3102157, 0x01B70125, 35.448, -9.03462, -24, 0.913431, 0, 0, -0.406993, False, '2025-07-21 14:29:19'); /* Puffball Thrungus */
/* @teleloc 0x01B70125 [35.448002 -9.034620 -24.000000] 0.913431 0.000000 0.000000 -0.406993 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701B70A5, 3102157, 0x01B70131, 47.1601, -9.31396, -24, 0.883986, 0, 0, -0.467514, False, '2025-07-21 14:29:21'); /* Puffball Thrungus */
/* @teleloc 0x01B70131 [47.160099 -9.313960 -24.000000] 0.883986 0.000000 0.000000 -0.467514 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701B70A6, 3102157, 0x01B7013B, 55.3628, -9.32754, -24, 0.874129, 0, 0, -0.485693, False, '2025-07-21 14:29:23'); /* Puffball Thrungus */
/* @teleloc 0x01B7013B [55.362801 -9.327540 -24.000000] 0.874129 0.000000 0.000000 -0.485693 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701B70A7, 3102157, 0x01B70142, 73.3502, -7.31324, -24, -0.920981, 0, 0, 0.389608, False, '2025-07-21 14:29:30'); /* Puffball Thrungus */
/* @teleloc 0x01B70142 [73.350197 -7.313240 -24.000000] -0.920981 0.000000 0.000000 0.389608 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701B70A8, 3102157, 0x01B70145, 76.8224, -9.0419, -24, -0.437058, 0, 0, 0.899434, False, '2025-07-21 14:29:31'); /* Puffball Thrungus */
/* @teleloc 0x01B70145 [76.822403 -9.041900 -24.000000] -0.437058 0.000000 0.000000 0.899434 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701B70A9, 3102157, 0x01B70145, 76.8224, -9.0419, -24, -0.437058, 0, 0, 0.899434, False, '2025-07-21 14:29:32'); /* Puffball Thrungus */
/* @teleloc 0x01B70145 [76.822403 -9.041900 -24.000000] -0.437058 0.000000 0.000000 0.899434 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701B70AA, 3102157, 0x01B70146, 81.0417, -17.1228, -24, -0.036941, 0, 0, 0.999318, False, '2025-07-21 14:29:34'); /* Puffball Thrungus */
/* @teleloc 0x01B70146 [81.041702 -17.122801 -24.000000] -0.036941 0.000000 0.000000 0.999318 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701B70AB, 3102157, 0x01B70146, 81.5674, -23.6203, -24, -0.036941, 0, 0, 0.999318, False, '2025-07-21 14:29:35'); /* Puffball Thrungus */
/* @teleloc 0x01B70146 [81.567398 -23.620300 -24.000000] -0.036941 0.000000 0.000000 0.999318 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701B70AC, 3102157, 0x01B70146, 81.5169, -23.9942, -24, -0.036941, 0, 0, 0.999318, False, '2025-07-21 14:29:36'); /* Puffball Thrungus */
/* @teleloc 0x01B70146 [81.516899 -23.994200 -24.000000] -0.036941 0.000000 0.000000 0.999318 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701B70AD, 3102157, 0x01B70146, 81.5169, -23.9942, -24, -0.036941, 0, 0, 0.999318, False, '2025-07-21 14:29:37'); /* Puffball Thrungus */
/* @teleloc 0x01B70146 [81.516899 -23.994200 -24.000000] -0.036941 0.000000 0.000000 0.999318 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701B70AE, 3102157, 0x01B70146, 77.6066, -23.8322, -24, 0.728366, 0, 0, 0.685188, False, '2025-07-21 14:29:38'); /* Puffball Thrungus */
/* @teleloc 0x01B70146 [77.606598 -23.832199 -24.000000] 0.728366 0.000000 0.000000 0.685188 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701B70AF, 3102157, 0x01B70144, 69.9824, -33.6355, -24, 0.154728, 0, 0, 0.987957, False, '2025-07-21 14:29:41'); /* Puffball Thrungus */
/* @teleloc 0x01B70144 [69.982399 -33.635502 -24.000000] 0.154728 0.000000 0.000000 0.987957 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701B70B0, 3102157, 0x01B70144, 69.7628, -34.0806, -24, 0.154728, 0, 0, 0.987957, False, '2025-07-21 14:29:42'); /* Puffball Thrungus */
/* @teleloc 0x01B70144 [69.762802 -34.080601 -24.000000] 0.154728 0.000000 0.000000 0.987957 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701B70B1, 3102157, 0x01B70144, 65.2489, -34.3299, -24, 0.729018, 0, 0, 0.684495, False, '2025-07-21 14:29:43'); /* Puffball Thrungus */
/* @teleloc 0x01B70144 [65.248901 -34.329899 -24.000000] 0.729018 0.000000 0.000000 0.684495 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701B70B2, 3102157, 0x01B7013A, 49.3441, -34.1255, -24, 0.653045, 0, 0, 0.757319, False, '2025-07-21 14:29:45'); /* Puffball Thrungus */
/* @teleloc 0x01B7013A [49.344101 -34.125500 -24.000000] 0.653045 0.000000 0.000000 0.757319 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701B70B3, 3102157, 0x01B7013A, 50.9214, -33.2797, -24, 0.929471, 0, 0, -0.368896, False, '2025-07-21 14:29:47'); /* Puffball Thrungus */
/* @teleloc 0x01B7013A [50.921398 -33.279701 -24.000000] 0.929471 0.000000 0.000000 -0.368896 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701B70B4, 3102157, 0x01B7013A, 50.9214, -33.2797, -24, 0.929471, 0, 0, -0.368896, False, '2025-07-21 14:29:48'); /* Puffball Thrungus */
/* @teleloc 0x01B7013A [50.921398 -33.279701 -24.000000] 0.929471 0.000000 0.000000 -0.368896 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701B70B5, 851657, 0x01B70141, 60.5215, -29.9646, -23.945, -0.745614, 0, 0, -0.666378, False, '2025-07-21 14:33:42'); /* The Black Breath */
/* @teleloc 0x01B70141 [60.521500 -29.964600 -23.945000] -0.745614 0.000000 0.000000 -0.666378 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701B70B6, 851657, 0x01B70144, 69.3153, -29.0162, -23.945, -0.734641, 0, 0, 0.678456, False, '2025-07-21 14:33:45'); /* The Black Breath */
/* @teleloc 0x01B70144 [69.315300 -29.016199 -23.945000] -0.734641 0.000000 0.000000 0.678456 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701B70B7, 851657, 0x01B70142, 74.2768, -11.75, -23.945, -0.911634, 0, 0, -0.411003, False, '2025-07-21 14:33:48'); /* The Black Breath */
/* @teleloc 0x01B70142 [74.276802 -11.750000 -23.945000] -0.911634 0.000000 0.000000 -0.411003 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701B70B8, 851657, 0x01B7013D, 59.496, -13.203, -23.945, -0.577771, 0, 0, -0.816199, False, '2025-07-21 14:33:53'); /* The Black Breath */
/* @teleloc 0x01B7013D [59.495998 -13.203000 -23.945000] -0.577771 0.000000 0.000000 -0.816199 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701B70B9, 851657, 0x01B70128, 42.7837, -11.7586, -23.945, -0.361027, 0, 0, -0.932556, False, '2025-07-21 14:33:57'); /* The Black Breath */
/* @teleloc 0x01B70128 [42.783699 -11.758600 -23.945000] -0.361027 0.000000 0.000000 -0.932556 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701B70BA, 851657, 0x01B70117, 28.3738, -12.859, -23.945, -0.571878, 0, 0, -0.820339, False, '2025-07-21 14:33:59'); /* The Black Breath */
/* @teleloc 0x01B70117 [28.373800 -12.859000 -23.945000] -0.571878 0.000000 0.000000 -0.820339 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701B70BB, 851657, 0x01B70115, 17.0661, -17.0089, -23.945, -0.737573, 0, 0, -0.675267, False, '2025-07-21 14:34:01'); /* The Black Breath */
/* @teleloc 0x01B70115 [17.066099 -17.008900 -23.945000] -0.737573 0.000000 0.000000 -0.675267 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701B70BC, 851657, 0x01B7010C, 6.03955, -16.0258, -23.945, -0.919564, 0, 0, -0.39294, False, '2025-07-21 14:34:04'); /* The Black Breath */
/* @teleloc 0x01B7010C [6.039550 -16.025801 -23.945000] -0.919564 0.000000 0.000000 -0.392940 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701B70BD, 851657, 0x01B70106, 6.01463, -5.98859, -23.945, -0.906837, 0, 0, -0.421482, False, '2025-07-21 14:34:07'); /* The Black Breath */
/* @teleloc 0x01B70106 [6.014630 -5.988590 -23.945000] -0.906837 0.000000 0.000000 -0.421482 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701B70BE, 851657, 0x01B70154, -0.214231, -19.6833, -14.945, 0.014273, 0, 0, -0.999898, False, '2025-07-21 14:34:10'); /* The Black Breath */
/* @teleloc 0x01B70154 [-0.214231 -19.683300 -14.945000] 0.014273 0.000000 0.000000 -0.999898 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701B70BF, 851657, 0x01B7015F, 11.8881, -20.022, -11.945, 0.779628, 0, 0, -0.626243, False, '2025-07-21 14:34:12'); /* The Black Breath */
/* @teleloc 0x01B7015F [11.888100 -20.021999 -11.945000] 0.779628 0.000000 0.000000 -0.626243 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701B70C0, 851657, 0x01B70159, 9.14948, -10.0781, -11.945, 0.998765, 0, 0, 0.049694, False, '2025-07-21 14:34:14'); /* The Black Breath */
/* @teleloc 0x01B70159 [9.149480 -10.078100 -11.945000] 0.998765 0.000000 0.000000 0.049694 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701B70C1, 851657, 0x01B70171, 29.6153, -18.295, -11.945, -0.880528, 0, 0, 0.473995, False, '2025-07-21 14:34:21'); /* The Black Breath */
/* @teleloc 0x01B70171 [29.615299 -18.295000 -11.945000] -0.880528 0.000000 0.000000 0.473995 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701B70C2, 851657, 0x01B70179, 38.9506, -13.1936, -11.945, -0.289604, 0, 0, 0.957147, False, '2025-07-21 14:34:24'); /* The Black Breath */
/* @teleloc 0x01B70179 [38.950600 -13.193600 -11.945000] -0.289604 0.000000 0.000000 0.957147 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701B70C3, 851657, 0x01B7018A, 51.1563, -15.0829, -11.945, -0.287311, 0, 0, 0.957837, False, '2025-07-21 14:34:26'); /* The Black Breath */
/* @teleloc 0x01B7018A [51.156300 -15.082900 -11.945000] -0.287311 0.000000 0.000000 0.957837 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701B70C4, 851657, 0x01B7018F, 61.5648, -14.353, -11.945, -0.873373, 0, 0, 0.487052, False, '2025-07-21 14:34:28'); /* The Black Breath */
/* @teleloc 0x01B7018F [61.564800 -14.353000 -11.945000] -0.873373 0.000000 0.000000 0.487052 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701B70C5, 851657, 0x01B70195, 70.8494, -9.99101, -11.945, -0.448404, 0, 0, 0.893831, False, '2025-07-21 14:34:30'); /* The Black Breath */
/* @teleloc 0x01B70195 [70.849403 -9.991010 -11.945000] -0.448404 0.000000 0.000000 0.893831 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701B70C6, 851657, 0x01B70199, 78.3137, -23.0072, -11.945, 0.125072, 0, 0, 0.992148, False, '2025-07-21 14:34:32'); /* The Black Breath */
/* @teleloc 0x01B70199 [78.313698 -23.007200 -11.945000] 0.125072 0.000000 0.000000 0.992148 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701B70C7, 851657, 0x01B7018D, 54.743, -31.3234, -11.945, 0.722963, 0, 0, 0.690886, False, '2025-07-21 14:34:35'); /* The Black Breath */
/* @teleloc 0x01B7018D [54.743000 -31.323400 -11.945000] 0.722963 0.000000 0.000000 0.690886 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701B70C8, 851657, 0x01B7017D, 44.98, -19.6754, -11.945, 0.633432, 0, 0, 0.773798, False, '2025-07-21 14:34:42'); /* The Black Breath */
/* @teleloc 0x01B7017D [44.980000 -19.675400 -11.945000] 0.633432 0.000000 0.000000 0.773798 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701B70C9, 851657, 0x01B701AA, -0.612672, -19.1633, -2.945, -0.016887, 0, 0, 0.999857, False, '2025-07-21 14:34:51'); /* The Black Breath */
/* @teleloc 0x01B701AA [-0.612672 -19.163300 -2.945000] -0.016887 0.000000 0.000000 0.999857 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701B70CA, 851657, 0x01B701B5, 10.568, -16.4921, 0.055, -0.972474, 0, 0, 0.233013, False, '2025-07-21 14:34:53'); /* The Black Breath */
/* @teleloc 0x01B701B5 [10.568000 -16.492100 0.055000] -0.972474 0.000000 0.000000 0.233013 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701B70CB, 851657, 0x01B701B5, 10.568, -16.4921, 0.055, -0.972474, 0, 0, 0.233013, False, '2025-07-21 14:34:55'); /* The Black Breath */
/* @teleloc 0x01B701B5 [10.568000 -16.492100 0.055000] -0.972474 0.000000 0.000000 0.233013 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701B70CC, 851657, 0x01B701BB, 21.6509, -14.0431, 0.055, -0.681321, 0, 0, 0.731985, False, '2025-07-21 14:34:57'); /* The Black Breath */
/* @teleloc 0x01B701BB [21.650900 -14.043100 0.055000] -0.681321 0.000000 0.000000 0.731985 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701B70CD, 851657, 0x01B701C6, 33.9008, -18.6239, 0.055, -0.637996, 0, 0, 0.77004, False, '2025-07-21 14:35:03'); /* The Black Breath */
/* @teleloc 0x01B701C6 [33.900799 -18.623899 0.055000] -0.637996 0.000000 0.000000 0.770040 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701B70CE, 851657, 0x01B701D0, 44.3513, -9.00183, 0.055, -0.77675, 0, 0, 0.629809, False, '2025-07-21 14:35:05'); /* The Black Breath */
/* @teleloc 0x01B701D0 [44.351299 -9.001830 0.055000] -0.776750 0.000000 0.000000 0.629809 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701B70CF, 851657, 0x01B701E8, 56.8106, -19.9651, 0.055, -0.731321, 0, 0, 0.682034, False, '2025-07-21 14:35:07'); /* The Black Breath */
/* @teleloc 0x01B701E8 [56.810600 -19.965099 0.055000] -0.731321 0.000000 0.000000 0.682034 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701B70D0, 851657, 0x01B701EB, 65.9795, -9.32119, 0.055, -0.874308, 0, 0, 0.485371, False, '2025-07-21 14:35:09'); /* The Black Breath */
/* @teleloc 0x01B701EB [65.979500 -9.321190 0.055000] -0.874308 0.000000 0.000000 0.485371 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701B70D1, 851657, 0x01B701EE, 76.0801, -10.4537, 0.055, -0.565496, 0, 0, 0.824751, False, '2025-07-21 14:35:10'); /* The Black Breath */
/* @teleloc 0x01B701EE [76.080101 -10.453700 0.055000] -0.565496 0.000000 0.000000 0.824751 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701B70D2, 851657, 0x01B701F0, 77.1976, -29.4649, 0.055, -0.057734, 0, 0, 0.998332, False, '2025-07-21 14:35:12'); /* The Black Breath */
/* @teleloc 0x01B701F0 [77.197601 -29.464899 0.055000] -0.057734 0.000000 0.000000 0.998332 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701B70D3, 851657, 0x01B701E3, 49.0872, -29.7524, 0.055, 0.679112, 0, 0, 0.734035, False, '2025-07-21 14:35:15'); /* The Black Breath */
/* @teleloc 0x01B701E3 [49.087200 -29.752399 0.055000] 0.679112 0.000000 0.000000 0.734035 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701B70D4, 851657, 0x01B701A6, -1.46923, -10.2996, 0.055, -0.497211, 0, 0, -0.86763, False, '2025-07-21 14:35:56'); /* The Black Breath */
/* @teleloc 0x01B701A6 [-1.469230 -10.299600 0.055000] -0.497211 0.000000 0.000000 -0.867630 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701B70D5, 851657, 0x01B701AF, 10.46738, -6.744148, 0.055, 0.970595, 0, 0, -0.240719, False, '2025-07-21 14:36:01'); /* The Black Breath */
/* @teleloc 0x01B701AF [10.467380 -6.744148 0.055000] 0.970595 0.000000 0.000000 -0.240719 */
