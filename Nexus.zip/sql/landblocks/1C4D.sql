DELETE FROM `landblock_instance` WHERE `landblock` = 0x1C4D;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x71C4D000,  6795, 0x1C4D0000, 98.5533, 49.5871, 0.219443, -0.73015, 0, 0, -0.683287, False, '2005-02-09 10:00:00'); /* Nexus Portal */
/* @teleloc 0x1C4D0000 [98.553299 49.587101 0.219443] -0.730150 0.000000 0.000000 -0.683287 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x71C4D001, 13217238, 0x1C4D001B, 86.33675, 53.38309, 0.385591, 0.954049, 0, 0, 0.299652, False, '2025-08-12 17:58:01');
/* @teleloc 0x1C4D001B [86.336746 53.383091 0.385591] 0.954049 0.000000 0.000000 0.299652 */
