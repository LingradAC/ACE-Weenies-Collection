DELETE FROM `landblock_instance` WHERE `landblock` = 0x8D4D;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x78D4D000, 86653879, 0x8D4D0100, 86.1158, 14.7408, 9.705, -0.137695, 0, 0, -0.990475, False, '2025-07-29 13:19:53'); /* BLUE BALL OF LIGHT */
/* @teleloc 0x8D4D0100 [86.115799 14.740800 9.705000] -0.137695 0.000000 0.000000 -0.990475 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x78D4D001, 89235757, 0x8D4D0019, 94.2937, 4.41034, 10.055, 0.933452, 0, 0, -0.358702, False, '2025-08-29 13:58:27');
/* @teleloc 0x8D4D0019 [94.293701 4.410340 10.055000] 0.933452 0.000000 0.000000 -0.358702 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x78D4D002, 89235757, 0x8D4D0021, 98.3794, 16.7502, 10.055, 0.967386, 0, 0, 0.253307, False, '2025-08-29 13:58:29');
/* @teleloc 0x8D4D0021 [98.379402 16.750200 10.055000] 0.967386 0.000000 0.000000 0.253307 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x78D4D003, 89235757, 0x8D4D001A, 92.1712, 25.3202, 10.165, 0.822524, 0, 0, 0.568731, False, '2025-08-29 13:58:30');
/* @teleloc 0x8D4D001A [92.171204 25.320200 10.165000] 0.822524 0.000000 0.000000 0.568731 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x78D4D004, 89235757, 0x8D4D0012, 71.6402, 28.948, 10.8497, 0.666202, 0, 0, 0.745772, False, '2025-08-29 13:58:31');
/* @teleloc 0x8D4D0012 [71.640198 28.948000 10.849700] 0.666202 0.000000 0.000000 0.745772 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x78D4D005, 89235757, 0x8D4D0011, 60.99469, 20.83193, 12.80633, 0.155337, 0, 0, 0.987862, False, '2025-08-29 13:58:34');
/* @teleloc 0x8D4D0011 [60.994690 20.831930 12.806330] 0.155337 0.000000 0.000000 0.987862 */
