DELETE FROM `landblock_instance` WHERE `landblock` = 0x41E7;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x741E7001,  1032, 0x41E70036, 155.901, 130.344, 160.005, 0.720696, 0, 0, -0.693251, False, '2022-04-12 04:33:53'); /* Portal to Zaikhal */
/* @teleloc 0x41E70036 [155.901001 130.343994 160.005005] 0.720696 0.000000 0.000000 -0.693251 */
