DELETE FROM `landblock_instance` WHERE `landblock` = 0xF2D7;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F2D7008, 5000295, 0xF2D7000A, 37.0275, 32.6364, 0.055, -0.831261, 0, 0, 0.555883, False, '2020-01-13 01:41:45'); /* Plant */
/* @teleloc 0xF2D7000A [37.027500 32.636398 0.055000] -0.831261 0.000000 0.000000 0.555883 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F2D7009, 5000295, 0xF2D70012, 50.1009, 46.3607, 0.055, -0.71645, 0, 0, -0.697639, False, '2020-01-13 01:41:46'); /* Plant */
/* @teleloc 0xF2D70012 [50.100899 46.360699 0.055000] -0.716450 0.000000 0.000000 -0.697639 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F2D700A, 5000295, 0xF2D7000B, 41.4756, 48.2155, 0.055, -0.917661, 0, 0, -0.397363, False, '2020-01-13 01:41:47'); /* Plant */
/* @teleloc 0xF2D7000B [41.475601 48.215500 0.055000] -0.917661 0.000000 0.000000 -0.397363 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F2D700B, 5000661, 0xF2D7001A, 72.4053, 47.0057, 0.055, -0.594525, 0, 0, 0.804077, False, '2020-01-13 01:41:50'); /* Plant */
/* @teleloc 0xF2D7001A [72.405296 47.005699 0.055000] -0.594525 0.000000 0.000000 0.804077 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F2D700C, 5000294, 0xF2D7001A, 80.819, 44.4266, 0.055, -0.594525, 0, 0, 0.804077, False, '2020-01-13 01:41:51'); /* Plant */
/* @teleloc 0xF2D7001A [80.819000 44.426601 0.055000] -0.594525 0.000000 0.000000 0.804077 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F2D700D, 5000662, 0xF2D7001B, 88.9401, 48.2454, 0.055, -0.982563, 0, 0, 0.185932, False, '2020-01-13 01:41:52'); /* Plant */
/* @teleloc 0xF2D7001B [88.940102 48.245399 0.055000] -0.982563 0.000000 0.000000 0.185932 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F2D700E, 5000295, 0xF2D70034, 158.183, 74.0005, 0.055, -0.626503, 0, 0, 0.779419, False, '2020-01-13 01:42:00'); /* Plant */
/* @teleloc 0xF2D70034 [158.182999 74.000504 0.055000] -0.626503 0.000000 0.000000 0.779419 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F2D700F, 5000295, 0xF2D70034, 158.183, 74.0005, 0.055, -0.626503, 0, 0, 0.779419, False, '2020-01-13 01:42:01'); /* Plant */
/* @teleloc 0xF2D70034 [158.182999 74.000504 0.055000] -0.626503 0.000000 0.000000 0.779419 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F2D7010, 5000296, 0xF2D70034, 165.521, 83.3459, 0.055, -0.967105, 0, 0, -0.254376, False, '2020-01-13 01:42:02'); /* Plant */
/* @teleloc 0xF2D70034 [165.520996 83.345901 0.055000] -0.967105 0.000000 0.000000 -0.254376 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F2D7011, 5000294, 0xF2D70034, 158.764, 83.5114, 0.055, 0.995213, 0, 0, -0.097733, False, '2020-01-13 01:42:07'); /* Plant */
/* @teleloc 0xF2D70034 [158.764008 83.511398 0.055000] 0.995213 0.000000 0.000000 -0.097733 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F2D7012, 5000294, 0xF2D70038, 164.515, 176.415, 0.055, 0.953561, 0, 0, 0.301199, False, '2020-01-13 01:42:15'); /* Plant */
/* @teleloc 0xF2D70038 [164.514999 176.414993 0.055000] 0.953561 0.000000 0.000000 0.301199 */
