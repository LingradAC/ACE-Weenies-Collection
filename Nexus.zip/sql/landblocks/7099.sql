DELETE FROM `landblock_instance` WHERE `landblock` = 0x7099;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x77099000, 4200152, 0x70990008, 5.165531, 180.3172, 233.6906, 0.403541, 0, 0, -0.914962, False, '2025-09-10 21:52:32'); /* Gate */
/* @teleloc 0x70990008 [5.165531 180.317200 233.690598] 0.403541 0.000000 0.000000 -0.914962 */
