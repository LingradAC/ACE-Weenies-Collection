DELETE FROM `landblock_instance` WHERE `landblock` = 0xCD41;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7CD41000,   722, 0xCD410000, 149.623, 108.552, 54, 0.706876, 0, 0, -0.707338, False, '2005-02-09 10:00:00'); /* Door */
/* @teleloc 0xCD410000 [149.623001 108.552002 54.000000] 0.706876 0.000000 0.000000 -0.707338 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7CD41001,   721, 0xCD410000, 149.621, 106.552, 54, -0.707338, 0, 0, -0.706876, False, '2005-02-09 10:00:00'); /* Door */
/* @teleloc 0xCD410000 [149.621002 106.552002 54.000000] -0.707338 0.000000 0.000000 -0.706876 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7CD41002,   720, 0xCD410000, 131.05, 125.256, 54, 0.707107, 0, 0, -0.707107, False, '2005-02-09 10:00:00'); /* Sliding Door */
/* @teleloc 0xCD410000 [131.050003 125.255997 54.000000] 0.707107 0.000000 0.000000 -0.707107 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7CD41003,   143, 0xCD410119, 129.71, 77.3559, 56.55, 0.001964, 0, 0, -0.999998, False, '2005-02-09 10:00:00'); /* Chest */
/* @teleloc 0xCD410119 [129.710007 77.355904 56.549999] 0.001964 0.000000 0.000000 -0.999998 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7CD41004,   720, 0xCD41011A, 134.881, 82.3652, 56.5, -0.999999, 0, 0, 0.001527, False, '2005-02-09 10:00:00'); /* Sliding Door */
/* @teleloc 0xCD41011A [134.880997 82.365196 56.500000] -0.999999 0.000000 0.000000 0.001527 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7CD41005,   720, 0xCD41011D, 134.892, 87.8652, 56.5, -0.999999, 0, 0, 0.001527, False, '2005-02-09 10:00:00'); /* Sliding Door */
/* @teleloc 0xCD41011D [134.891998 87.865196 56.500000] -0.999999 0.000000 0.000000 0.001527 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7CD41006,   720, 0xCD410000, 140.359, 85.0984, 54, -0.708186, 0, 0, -0.706026, False, '2005-02-09 10:00:00'); /* Sliding Door */
/* @teleloc 0xCD410000 [140.358994 85.098396 54.000000] -0.708186 0.000000 0.000000 -0.706026 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7CD41007,   720, 0xCD410130, 84.7106, 137.53, 54, 0, 0, 0, -1, False, '2005-02-09 10:00:00'); /* Sliding Door */
/* @teleloc 0xCD410130 [84.710602 137.529999 54.000000] 0.000000 0.000000 0.000000 -1.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7CD41008,   720, 0xCD410131, 84.8006, 122.99, 54, 1, 0, 0, 0, False, '2005-02-09 10:00:00'); /* Sliding Door */
/* @teleloc 0xCD410131 [84.800598 122.989998 54.000000] 1.000000 0.000000 0.000000 0.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7CD41009,   720, 0xCD410132, 80.0256, 127.77, 54, 0.707107, 0, 0, 0.707107, False, '2005-02-09 10:00:00'); /* Sliding Door */
/* @teleloc 0xCD410132 [80.025597 127.769997 54.000000] 0.707107 0.000000 0.000000 0.707107 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7CD4100A,   720, 0xCD410133, 89.4656, 132.695, 54, -0.707107, 0, 0, 0.707107, False, '2005-02-09 10:00:00'); /* Sliding Door */
/* @teleloc 0xCD410133 [89.465599 132.695007 54.000000] -0.707107 0.000000 0.000000 0.707107 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7CD4100B,   720, 0xCD41013A, 92.0206, 130.27, 59.6, 0.707107, 0, 0, 0.707107, False, '2005-02-09 10:00:00'); /* Sliding Door */
/* @teleloc 0xCD41013A [92.020599 130.270004 59.599998] 0.707107 0.000000 0.000000 0.707107 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7CD4100C,   720, 0xCD41013B, 77.4956, 130.185, 59.6, 0.707107, 0, 0, -0.707107, False, '2005-02-09 10:00:00'); /* Sliding Door */
/* @teleloc 0xCD41013B [77.495598 130.184998 59.599998] 0.707107 0.000000 0.000000 -0.707107 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7CD4100D,   720, 0xCD41013C, 84.7106, 137.52, 59.6, 0, 0, 0, -1, False, '2005-02-09 10:00:00'); /* Sliding Door */
/* @teleloc 0xCD41013C [84.710602 137.520004 59.599998] 0.000000 0.000000 0.000000 -1.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7CD4100E,   720, 0xCD41013D, 84.7906, 122.975, 59.6, 1, 0, 0, 0, False, '2005-02-09 10:00:00'); /* Sliding Door */
/* @teleloc 0xCD41013D [84.790604 122.974998 59.599998] 1.000000 0.000000 0.000000 0.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7CD4100F,   720, 0xCD410000, 65.5162, 89.2697, 54.025, 1, 0, 0, 0, False, '2005-02-09 10:00:00'); /* Sliding Door */
/* @teleloc 0xCD410000 [65.516197 89.269699 54.025002] 1.000000 0.000000 0.000000 0.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7CD41010,   720, 0xCD410000, 65.5162, 94.3347, 54.025, 1, 0, 0, 0, False, '2005-02-09 10:00:00'); /* Sliding Door */
/* @teleloc 0xCD410000 [65.516197 94.334702 54.025002] 1.000000 0.000000 0.000000 0.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7CD41011,   720, 0xCD410000, 57.9912, 80.6347, 54.025, 1, 0, 0, 0, False, '2005-02-09 10:00:00'); /* Sliding Door */
/* @teleloc 0xCD410000 [57.991199 80.634697 54.025002] 1.000000 0.000000 0.000000 0.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7CD41012,   720, 0xCD410000, 90.8508, 58.17, 54, -0.999999, 0, 0, 0.001529, False, '2005-02-09 10:00:00'); /* Sliding Door */
/* @teleloc 0xCD410000 [90.850800 58.169998 54.000000] -0.999999 0.000000 0.000000 0.001529 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7CD41013,   720, 0xCD41015C, 113.441, 87.9571, 54, 0.707107, 0, 0, 0.707107, False, '2005-02-09 10:00:00'); /* Sliding Door */
/* @teleloc 0xCD41015C [113.441002 87.957100 54.000000] 0.707107 0.000000 0.000000 0.707107 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7CD41014,   720, 0xCD41015D, 102.541, 80.0321, 54, 0.707107, 0, 0, -0.707107, False, '2005-02-09 10:00:00'); /* Sliding Door */
/* @teleloc 0xCD41015D [102.541000 80.032097 54.000000] 0.707107 0.000000 0.000000 -0.707107 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7CD41015,   722, 0xCD410000, 108, 78.475, 54, 1, 0, 0, 0, False, '2005-02-09 10:00:00'); /* Door */
/* @teleloc 0xCD410000 [108.000000 78.474998 54.000000] 1.000000 0.000000 0.000000 0.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7CD41016,   722, 0xCD410000, 108, 89.525, 54, 0, 0, 0, -1, False, '2005-02-09 10:00:00'); /* Door */
/* @teleloc 0xCD410000 [108.000000 89.525002 54.000000] 0.000000 0.000000 0.000000 -1.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7CD41017,   720, 0xCD41016A, 60.025, 159, 54, 0.707107, 0, 0, -0.707107, False, '2005-02-09 10:00:00'); /* Sliding Door */
/* @teleloc 0xCD41016A [60.025002 159.000000 54.000000] 0.707107 0.000000 0.000000 -0.707107 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7CD41018,   720, 0xCD41016A, 60.025, 153, 54, 0.707107, 0, 0, -0.707107, False, '2005-02-09 10:00:00'); /* Sliding Door */
/* @teleloc 0xCD41016A [60.025002 153.000000 54.000000] 0.707107 0.000000 0.000000 -0.707107 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7CD41019,  5621, 0xCD41016A, 64.42, 156.08, 55.76, 1, 0, 0, 0, False, '2005-02-09 10:00:00'); /* Hot Air */
/* @teleloc 0xCD41016A [64.419998 156.080002 55.759998] 1.000000 0.000000 0.000000 0.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7CD4101A,   143, 0xCD410177, 50.65, 165.47, 55.24, 0.995725, 0, 0, 0.092371, False, '2005-02-09 10:00:00'); /* Chest */
/* @teleloc 0xCD410177 [50.650002 165.470001 55.240002] 0.995725 0.000000 0.000000 0.092371 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7CD4101B,   721, 0xCD410000, 49.225, 153, 54, 0.707107, 0, 0, 0.707107, False, '2005-02-09 10:00:00'); /* Door */
/* @teleloc 0xCD410000 [49.224998 153.000000 54.000000] 0.707107 0.000000 0.000000 0.707107 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7CD4101C,   722, 0xCD410000, 49.225, 159, 54, 0.707107, 0, 0, -0.707107, False, '2005-02-09 10:00:00'); /* Door */
/* @teleloc 0xCD410000 [49.224998 159.000000 54.000000] 0.707107 0.000000 0.000000 -0.707107 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7CD4101D,  2257, 0xCD410140, 56.2398, 91.6337, 54.005, 0.726181, 0, 0, -0.687504, False, '2005-02-09 10:00:00'); /* Nuru Misho the Jeweler */
/* @teleloc 0xCD410140 [56.239799 91.633698 54.005001] 0.726181 0.000000 0.000000 -0.687504 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7CD4101E,  2271, 0xCD410000, 61.0094, 85.4873, 54.005, 0.702456, 0, 0, 0.711727, False, '2005-02-09 10:00:00'); /* Jeweler Shop */
/* @teleloc 0xCD410000 [61.009399 85.487297 54.005001] 0.702456 0.000000 0.000000 0.711727 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7CD4101F,  2266, 0xCD410000, 69.7677, 163.256, 54.005, -0.702788, 0, 0, -0.711399, False, '2005-02-09 10:00:00'); /* Blade's Heart Forge */
/* @teleloc 0xCD410000 [69.767700 163.255997 54.005001] -0.702788 0.000000 0.000000 -0.711399 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7CD41020,  2261, 0xCD41016A, 67.7695, 159.129, 54.005, -0.731566, 0, 0, 0.68177, False, '2005-02-09 10:00:00'); /* Shen Ai-Shen the Weaponsmith */
/* @teleloc 0xCD41016A [67.769501 159.128998 54.005001] -0.731566 0.000000 0.000000 0.681770 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7CD41021,  2251, 0xCD41016A, 67.7673, 152.535, 54.005, -0.731566, 0, 0, 0.68177, False, '2005-02-09 10:00:00'); /* Lobu Shui the Armorer */
/* @teleloc 0xCD41016A [67.767303 152.535004 54.005001] -0.731566 0.000000 0.000000 0.681770 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7CD41022,  2272, 0xCD410000, 147.181, 111.967, 54.005, -0.691189, 0, 0, 0.722674, False, '2005-02-09 10:00:00'); /* The Flaming Phoenix */
/* @teleloc 0xCD410000 [147.181000 111.967003 54.005001] -0.691189 0.000000 0.000000 0.722674 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7CD41023,  2252, 0xCD410100, 162.438, 111.823, 54.005, -0.250755, 0, 0, -0.968051, False, '2005-02-09 10:00:00'); /* Kiun Baicho the Barkeeper */
/* @teleloc 0xCD410100 [162.438004 111.822998 54.005001] -0.250755 0.000000 0.000000 -0.968051 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7CD41024,  4782, 0xCD41012B, 81.2236, 133.273, 54.005, 0.607365, 0, 0, -0.794423, False, '2005-02-09 10:00:00'); /* Sho Leather Crafter Gen */
/* @teleloc 0xCD41012B [81.223602 133.272995 54.005001] 0.607365 0.000000 0.000000 -0.794423 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7CD41025,  2258, 0xCD410158, 101.421, 87.3466, 54.005, -0.721649, 0, 0, 0.692259, False, '2005-02-09 10:00:00'); /* Denki Sokuto the Scribe */
/* @teleloc 0xCD410158 [101.420998 87.346603 54.005001] -0.721649 0.000000 0.000000 0.692259 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7CD41026,  2273, 0xCD410000, 104.789, 77.701, 54.005, 0.999903, 0, 0, -0.01393, False, '2005-02-09 10:00:00'); /* Scribe Shop */
/* @teleloc 0xCD410000 [104.789001 77.700996 54.005001] 0.999903 0.000000 0.000000 -0.013930 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7CD41027,  2275, 0xCD410000, 87.5098, 138.291, 54.005, -0.042533, 0, 0, 0.999095, False, '2005-02-09 10:00:00'); /* Weaver Zhoyong */
/* @teleloc 0xCD410000 [87.509804 138.291000 54.005001] -0.042533 0.000000 0.000000 0.999095 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7CD41028,  2260, 0xCD41012B, 87.4791, 129.59, 54.005, -0.992343, 0, 0, -0.123516, False, '2005-02-09 10:00:00'); /* Tailor Zhoyong Wa-son */
/* @teleloc 0xCD41012B [87.479103 129.589996 54.005001] -0.992343 0.000000 0.000000 -0.123516 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7CD41029,  2259, 0xCD41010E, 138.283, 134.095, 54.005, -0.000226, 0, 0, -1, False, '2005-02-09 10:00:00'); /* Shopkeep Ginan Wah */
/* @teleloc 0xCD41010E [138.283005 134.095001 54.005001] -0.000226 0.000000 0.000000 -1.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7CD4102A,  2267, 0xCD410000, 85.965, 63.2355, 54.005, 0.029315, 0, 0, -0.99957, False, '2005-02-09 10:00:00'); /* The Soaring Shaft */
/* @teleloc 0xCD410000 [85.964996 63.235500 54.005001] 0.029315 0.000000 0.000000 -0.999570 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7CD4102B,  2254, 0xCD410150, 82.0726, 65.3352, 54.005, -0.764917, 0, 0, 0.644129, False, '2005-02-09 10:00:00'); /* Bowyer Jyi Zhente */
/* @teleloc 0xCD410150 [82.072601 65.335197 54.005001] -0.764917 0.000000 0.000000 0.644129 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7CD4102C,  2274, 0xCD410000, 136.089, 130.153, 54.005, 0.654527, 0, 0, 0.756039, False, '2005-02-09 10:00:00'); /* Ginan's Goods */
/* @teleloc 0xCD410000 [136.089005 130.153000 54.005001] 0.654527 0.000000 0.000000 0.756039 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7CD4102D,  2255, 0xCD410169, 116.066, 159.346, 55.605, 0.704235, 0, 0, 0.709967, False, '2005-02-09 10:00:00'); /* Muoyen Han the Grocer */
/* @teleloc 0xCD410169 [116.066002 159.345993 55.605000] 0.704235 0.000000 0.000000 0.709967 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7CD4102E,  2269, 0xCD410000, 101.685, 151.995, 54.005, 0.999944, 0, 0, -0.010549, False, '2005-02-09 10:00:00'); /* The Laden Bushel */
/* @teleloc 0xCD410000 [101.684998 151.994995 54.005001] 0.999944 0.000000 0.000000 -0.010549 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7CD4102F,  2270, 0xCD410000, 140.827, 82.8542, 54.005, 0.652508, 0, 0, 0.757782, False, '2005-02-09 10:00:00'); /* Physician */
/* @teleloc 0xCD410000 [140.826996 82.854202 54.005001] 0.652508 0.000000 0.000000 0.757782 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7CD41030,  2256, 0xCD41011E, 126.851, 77.6538, 52.805, -0.945495, 0, 0, 0.325638, False, '2005-02-09 10:00:00'); /* Healer Fan Lun-Kou */
/* @teleloc 0xCD41011E [126.850998 77.653801 52.805000] -0.945495 0.000000 0.000000 0.325638 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7CD41031,  4776, 0xCD410000, 77.5197, 115.593, 54.005, 0.054789, 0, 0, -0.998498, False, '2005-02-09 10:00:00'); /* Sho Wing Collector Gen */
/* @teleloc 0xCD410000 [77.519699 115.593002 54.005001] 0.054789 0.000000 0.000000 -0.998498 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7CD41032,  4771, 0xCD410105, 154.506, 103.725, 59.605, -0.502071, 0, 0, 0.864827, False, '2005-02-09 10:00:00'); /* Sho Jewel Collector Gen */
/* @teleloc 0xCD410105 [154.505997 103.724998 59.605000] -0.502071 0.000000 0.000000 0.864827 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7CD41034,  6082, 0xCD410168, 101.059, 155.621, 55.605, 0.813278, 0, 0, -0.581876, False, '2005-02-09 10:00:00'); /* Spice Merchant Chiani */
/* @teleloc 0xCD410168 [101.058998 155.621002 55.605000] 0.813278 0.000000 0.000000 -0.581876 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7CD41036,  8377, 0xCD410100, 158.741, 115.385, 54.44, -0.714136, 0, 0, -0.700007, False, '2005-02-09 10:00:00'); /* Beer Keg */
/* @teleloc 0xCD410100 [158.740997 115.385002 54.439999] -0.714136 0.000000 0.000000 -0.700007 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7CD41039,   412, 0xCD410000, 126.697, 62.5506, 54, 0, 0, 0, -1, False, '2005-02-09 10:00:00'); /* Door */
/* @teleloc 0xCD410000 [126.696999 62.550598 54.000000] 0.000000 0.000000 0.000000 -1.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7CD4103A, 12050, 0xCD410184, 134.499, 56.0372, 54.005, 0.471677, 0, 0, 0.881771,  True, '2005-02-09 10:00:00'); /* Agent of the Arcanum */
/* @teleloc 0xCD410184 [134.498993 56.037201 54.005001] 0.471677 0.000000 0.000000 0.881771 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7CD4103B,  7923, 0xCD410184, 136.084, 56.4128, 54.005, -0.705256, 0, 0, -0.708953, False, '2005-02-09 10:00:00'); /* Linkable Monster Generator ( 3 Min.) */
/* @teleloc 0xCD410184 [136.084000 56.412800 54.005001] -0.705256 0.000000 0.000000 -0.708953 */

INSERT INTO `landblock_instance_link` (`parent_GUID`, `child_GUID`, `last_Modified`)
VALUES (0x7CD4103B, 0x7CD4103A, '2005-02-09 10:00:00') /* Agent of the Arcanum (12050) */;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7CD4103C, 12304, 0xCD410000, 136.567, 64.836, 54.005, -0.000999, 0, 0, 0.999999, False, '2005-02-09 10:00:00'); /* Agent of the Arcanum  */
/* @teleloc 0xCD410000 [136.567001 64.835999 54.005001] -0.000999 0.000000 0.000000 0.999999 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7CD4103D,  2276, 0xCD410000, 64.7103, 102.576, 54, 0.742379, 0, 0, 0.66998, False, '2005-02-09 10:00:00'); /* Welcome to Baishi Sign */
/* @teleloc 0xCD410000 [64.710297 102.575996 54.000000] 0.742379 0.000000 0.000000 0.669980 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7CD4103E,   174, 0xCD410000, 113.749, 133.969, 54.005, -0.996224, 0, 0, 0.086823, False, '2005-02-09 10:00:00'); /* Well */
/* @teleloc 0xCD410000 [113.749001 133.968994 54.005001] -0.996224 0.000000 0.000000 0.086823 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7CD41046, 16919, 0xCD410000, 108.942, 105.945, 54, -0.058326, 0, 0, -0.998298, False, '2005-02-09 10:00:00'); /* Pedestal Weak Spot */
/* @teleloc 0xCD410000 [108.942001 105.945000 54.000000] -0.058326 0.000000 0.000000 -0.998298 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7CD41049, 19457, 0xCD410000, 108.983, 110.212, 61, 0.680414, 0, 0, -0.732828, False, '2005-02-09 10:00:00'); /* Fireworks Generator */
/* @teleloc 0xCD410000 [108.983002 110.211998 61.000000] 0.680414 0.000000 0.000000 -0.732828 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7CD4104C, 15811, 0xCD410125, 89.7945, 134.528, 62.405, -0.272557, 0, 0, -0.96214,  True, '2005-02-09 10:00:00'); /* Lia Tze */
/* @teleloc 0xCD410125 [89.794502 134.528000 62.404999] -0.272557 0.000000 0.000000 -0.962140 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7CD4104D,  7923, 0xCD410125, 89.5465, 133.569, 62.405, -0.963839, 0, 0, -0.266487, False, '2005-02-09 10:00:00'); /* Linkable Monster Generator ( 3 Min.) */
/* @teleloc 0xCD410125 [89.546501 133.569000 62.404999] -0.963839 0.000000 0.000000 -0.266487 */

INSERT INTO `landblock_instance_link` (`parent_GUID`, `child_GUID`, `last_Modified`)
VALUES (0x7CD4104D, 0x7CD4104C, '2005-02-09 10:00:00') /* Lia Tze (15811) */;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7CD4104E, 19197, 0xCD410000, 110.043, 109.545, 60.83, -0.72484, 0, 0, -0.688917, False, '2005-02-09 10:00:00'); /* Nullified Statue of a Golem */
/* @teleloc 0xCD410000 [110.042999 109.544998 60.830002] -0.724840 0.000000 0.000000 -0.688917 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7CD4104F, 19716, 0xCD41018A, 110.874, 122.611, 48.805, -0.997996, 0, 0, 0.063282, False, '2005-02-09 10:00:00'); /* Mammet Foundry Portal */
/* @teleloc 0xCD41018A [110.874001 122.611000 48.805000] -0.997996 0.000000 0.000000 0.063282 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7CD41050, 19380, 0xCD410000, 84.0774, 167.168, 54.005, -0.994069, 0, 0, 0.108752, False, '2005-02-09 10:00:00'); /* Atrium Residential Halls */
/* @teleloc 0xCD410000 [84.077400 167.167999 54.005001] -0.994069 0.000000 0.000000 0.108752 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7CD41051, 19358, 0xCD410000, 84.4934, 169.047, 54.005, -0.994069, 0, 0, 0.108752, False, '2005-02-09 10:00:00'); /* Atrium Residential Halls Portal */
/* @teleloc 0xCD410000 [84.493401 169.046997 54.005001] -0.994069 0.000000 0.000000 0.108752 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7CD41053, 23631, 0xCD410000, 109.887, 121.492, 152.804, 0.999921, 0, 0, 0.012589, False, '2005-02-09 10:00:00'); /* April 2003 Raining Mad Cows Gen */
/* @teleloc 0xCD410000 [109.887001 121.491997 152.804001] 0.999921 0.000000 0.000000 0.012589 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7CD41054,   720, 0xCD41019E, 154.562, 185.124, 54, 0, 0, 0, -1, False, '2005-02-09 10:00:00'); /* Sliding Door */
/* @teleloc 0xCD41019E [154.561996 185.123993 54.000000] 0.000000 0.000000 0.000000 -1.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7CD41055,   720, 0xCD41019F, 154.652, 170.584, 54, 1, 0, 0, 0, False, '2005-02-09 10:00:00'); /* Sliding Door */
/* @teleloc 0xCD41019F [154.651993 170.584000 54.000000] 1.000000 0.000000 0.000000 0.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7CD41056,   720, 0xCD4101A0, 149.877, 175.364, 54, 0.707107, 0, 0, 0.707107, False, '2005-02-09 10:00:00'); /* Sliding Door */
/* @teleloc 0xCD4101A0 [149.876999 175.363998 54.000000] 0.707107 0.000000 0.000000 0.707107 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7CD41057,   720, 0xCD4101A1, 159.317, 180.289, 54, -0.707107, 0, 0, 0.707107, False, '2005-02-09 10:00:00'); /* Sliding Door */
/* @teleloc 0xCD4101A1 [159.317001 180.289001 54.000000] -0.707107 0.000000 0.000000 0.707107 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7CD41058,   720, 0xCD4101A8, 161.872, 177.864, 59.6, 0.707107, 0, 0, 0.707107, False, '2005-02-09 10:00:00'); /* Sliding Door */
/* @teleloc 0xCD4101A8 [161.871994 177.863998 59.599998] 0.707107 0.000000 0.000000 0.707107 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7CD41059,   720, 0xCD4101A9, 147.347, 177.779, 59.6, 0.707107, 0, 0, -0.707107, False, '2005-02-09 10:00:00'); /* Sliding Door */
/* @teleloc 0xCD4101A9 [147.347000 177.779007 59.599998] 0.707107 0.000000 0.000000 -0.707107 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7CD4105A,   720, 0xCD4101AA, 154.562, 185.114, 59.6, 0, 0, 0, -1, False, '2005-02-09 10:00:00'); /* Sliding Door */
/* @teleloc 0xCD4101AA [154.561996 185.113998 59.599998] 0.000000 0.000000 0.000000 -1.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7CD4105B,   720, 0xCD4101AB, 154.642, 170.569, 59.6, 1, 0, 0, 0, False, '2005-02-09 10:00:00'); /* Sliding Door */
/* @teleloc 0xCD4101AB [154.641998 170.569000 59.599998] 1.000000 0.000000 0.000000 0.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7CD4105C,   509, 0xCD410000, 83.5755, 84.0811, 54.005, 0.430868, 0, 0, 0.902415, False, '2005-02-09 10:00:00'); /* Life Stone */
/* @teleloc 0xCD410000 [83.575500 84.081100 54.005001] 0.430868 0.000000 0.000000 0.902415 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7CD4105D,  6091, 0xCD41018E, 56.0944, 126.787, 56.005, -0.720881, 0, 0, -0.693059, False, '2005-02-09 10:00:00'); /* Baishi Meeting Hall Portal */
/* @teleloc 0xCD41018E [56.094398 126.787003 56.005001] -0.720881 0.000000 0.000000 -0.693059 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7CD4105E, 27547, 0xCD410000, 59.4721, 116.82, 54.005, -0.967645, 0, 0, -0.252316, False, '2005-02-09 10:00:00'); /* Bind Stone */
/* @teleloc 0xCD410000 [59.472099 116.820000 54.005001] -0.967645 0.000000 0.000000 -0.252316 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7CD41063, 31652, 0xCD41001E, 93.87, 126.178, 54.005, 0.95726, 0, 0, -0.289229, False, '2019-03-23 02:20:17'); /* Fergal the Dire */
/* @teleloc 0xCD41001E [93.870003 126.178001 54.005001] 0.957260 0.000000 0.000000 -0.289229 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7CD4106C, 43067, 0xCD410026, 108.321, 125.145, 54.198, -0.99982, 0, 0, -0.018984, False, '2020-06-12 04:19:15'); /* Portal to Town Network */
/* @teleloc 0xCD410026 [108.320999 125.144997 54.198002] -0.999820 0.000000 0.000000 -0.018984 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7CD4106E, 5000843, 0xCD410034, 149.838, 86.0592, 54.055, 0.926557, 0, 0, 0.376154, False, '2020-06-18 15:31:55'); /* BaishiAttack */
/* @teleloc 0xCD410034 [149.837997 86.059196 54.055000] 0.926557 0.000000 0.000000 0.376154 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7CD41071, 5000845, 0xCD410025, 96.8109, 102.125, 54.055, -0.61335, 0, 0, -0.789811, False, '2020-06-18 15:32:17'); /* BaishiAttack */
/* @teleloc 0xCD410025 [96.810898 102.125000 54.055000] -0.613350 0.000000 0.000000 -0.789811 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7CD41072, 5000845, 0xCD410013, 67.8518, 70.2763, 54.055, -0.449369, 0, 0, -0.893346, False, '2020-06-18 15:32:21'); /* BaishiAttack */
/* @teleloc 0xCD410013 [67.851799 70.276299 54.055000] -0.449369 0.000000 0.000000 -0.893346 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7CD41073, 5000845, 0xCD410015, 67.6373, 110.452, 54.055, -0.956071, 0, 0, -0.293136, False, '2020-06-18 15:32:26'); /* BaishiAttack */
/* @teleloc 0xCD410015 [67.637299 110.452003 54.055000] -0.956071 0.000000 0.000000 -0.293136 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7CD41082, 5000981, 0xCD410025, 100.625, 99.8031, 54.055, -0.593632, 0, 0, -0.804737, False, '2020-07-17 01:15:43'); /* BaishiAttack2 */
/* @teleloc 0xCD410025 [100.625000 99.803101 54.055000] -0.593632 0.000000 0.000000 -0.804737 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7CD41085, 5000981, 0xCD410034, 151.285, 83.8191, 54.055, 0.995114, 0, 0, 0.098732, False, '2020-07-17 01:15:54'); /* BaishiAttack2 */
/* @teleloc 0xCD410034 [151.285004 83.819099 54.055000] 0.995114 0.000000 0.000000 0.098732 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7CD41086, 5000981, 0xCD410016, 65.8867, 121.294, 54.055, 0.999244, 0, 0, -0.038882, False, '2020-07-17 01:16:11'); /* BaishiAttack2 */
/* @teleloc 0xCD410016 [65.886703 121.293999 54.055000] 0.999244 0.000000 0.000000 -0.038882 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7CD41087, 24415757, 0xCD410027, 118.462, 156.346, 54, 0.679175, 0, 0, -0.733977, False, '2025-07-23 16:01:41'); /* Mycelorn the Withered */
/* @teleloc 0xCD410027 [118.461998 156.345993 54.000000] 0.679175 0.000000 0.000000 -0.733977 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7CD41088, 40897, 0xCD410105, 156.821, 111.289, 59.605, 0.309835, 0, 0, 0.95079, False, '2025-08-04 20:51:13'); /* Ries Woron */
/* @teleloc 0xCD410105 [156.820999 111.289001 59.605000] 0.309835 0.000000 0.000000 0.950790 */
