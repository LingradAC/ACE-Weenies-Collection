DELETE FROM `landblock_instance` WHERE `landblock` = 0xE724;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E724000, 24411, 0xE7240019, 95.4451, 0.175812, -0.045, 0.967594, 0, 0, 0.25251, False, '2025-08-14 11:19:44'); /* Asheron Invasion Extreme Generators */
/* @teleloc 0xE7240019 [95.445099 0.175812 -0.045000] 0.967594 0.000000 0.000000 0.252510 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E724001, 24411, 0xE7240013, 68.3737, 48.5113, -0.045, 0.967594, 0, 0, 0.25251, False, '2025-08-14 11:19:48'); /* Asheron Invasion Extreme Generators */
/* @teleloc 0xE7240013 [68.373703 48.511299 -0.045000] 0.967594 0.000000 0.000000 0.252510 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E724002, 24411, 0xE7240006, 23.8834, 133.2493, 0.055, 0.977, 0, 0, 0.213239, False, '2025-08-14 11:19:53'); /* Asheron Invasion Extreme Generators */
/* @teleloc 0xE7240006 [23.883400 133.249298 0.055000] 0.977000 0.000000 0.000000 0.213239 */
