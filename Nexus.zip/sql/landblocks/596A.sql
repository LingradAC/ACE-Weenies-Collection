DELETE FROM `landblock_instance` WHERE `landblock` = 0x596A;
