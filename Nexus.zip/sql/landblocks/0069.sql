DELETE FROM `landblock_instance` WHERE `landblock` = 0x0069;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70069001, 41232334, 0x00690153, 60.4815, -40.1061, -11.945, 0.397902, 0, 0, 0.917428, False, '2025-07-25 15:33:31'); /* BaelZharonsMinionsGen */
/* @teleloc 0x00690153 [60.481499 -40.106098 -11.945000] 0.397902 0.000000 0.000000 0.917428 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70069003, 41232334, 0x00690150, 57.7103, -60.308, -17.945, 0.756248, 0, 0, -0.654285, False, '2025-07-25 15:35:16'); /* BaelZharonsMinionsGen */
/* @teleloc 0x00690150 [57.710300 -60.307999 -17.945000] 0.756248 0.000000 0.000000 -0.654285 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70069006, 41232334, 0x00690149, 41.1447, -58.8866, -23.945, 0.995351, 0, 0, 0.096309, False, '2025-07-25 15:35:51'); /* BaelZharonsMinionsGen */
/* @teleloc 0x00690149 [41.144699 -58.886600 -23.945000] 0.995351 0.000000 0.000000 0.096309 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70069009, 41232311, 0x00690113, 9.95914, -20.0725, -47.988, -0.690719, 0, 0, 0.723124, False, '2025-07-26 18:33:19'); /* Bael'Zharon */
/* @teleloc 0x00690113 [9.959140 -20.072500 -47.987999] -0.690719 0.000000 0.000000 0.723124 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7006900A, 32948324, 0x0069013C, 40.0872, -20.9983, -29.945, -0.012231, 0, 0, -0.999925, False, '2025-08-01 19:15:55'); /* vision of asheron gen */
/* @teleloc 0x0069013C [40.087200 -20.998301 -29.945000] -0.012231 0.000000 0.000000 -0.999925 */
