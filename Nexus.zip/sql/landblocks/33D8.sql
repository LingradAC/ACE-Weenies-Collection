DELETE FROM `landblock_instance` WHERE `landblock` = 0x33D8;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x733D8015,  1154, 0x33D80100, 37.4247, 109.169, 58.005, -0.971556, 0, 0, -0.236808, False, '2021-11-01 00:00:00'); /* Linkable Monster Generator */
/* @teleloc 0x33D80100 [37.424702 109.168999 58.005001] -0.971556 0.000000 0.000000 -0.236808 */

INSERT INTO `landblock_instance_link` (`parent_GUID`, `child_GUID`, `last_Modified`)
VALUES (0x733D8015, 0x733D8016, '2021-11-01 00:00:00') /* Seneschal Dalmour (29051) */;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x733D8016, 29051, 0x33D80100, 37.4247, 109.169, 58.005, -0.971556, 0, 0, -0.236808,  True, '2021-11-01 00:00:00'); /* Seneschal Dalmour */
/* @teleloc 0x33D80100 [37.424702 109.168999 58.005001] -0.971556 0.000000 0.000000 -0.236808 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x733D8017, 32948884, 0x33D8000D, 38.5556, 111.24, 73.205, -0.223664, 0, 0, -0.974666, False, '2025-08-08 05:39:26'); /* Disgraced Archmage */
/* @teleloc 0x33D8000D [38.555599 111.239998 73.205002] -0.223664 0.000000 0.000000 -0.974666 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x733D8018, 62323283, 0x33D8000D, 44.44387, 106.2762, 57.937, 0.999905, 0, 0, -0.013811, False, '2025-08-09 04:09:49'); /* Between BSD and a Hard Place */
/* @teleloc 0x33D8000D [44.443871 106.276199 57.937000] 0.999905 0.000000 0.000000 -0.013811 */
