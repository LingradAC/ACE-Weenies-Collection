DELETE FROM `landblock_instance` WHERE `landblock` = 0x0100;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70100000, 31024, 0x01000103, 29.9647, -158.253, 0.0055, 0.250794, 0, 0, -0.968041,  True, '2005-02-09 10:00:00'); /* Mudwort Thrungus */
/* @teleloc 0x01000103 [29.964701 -158.253006 0.005500] 0.250794 0.000000 0.000000 -0.968041 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70100001, 2348257, 0x01000103, 28.6271, -158.996, 0.0055, 0.250794, 0, 0, -0.968041,  True, '2005-02-09 10:00:00'); /* Infected Olthoi Warrior */
/* @teleloc 0x01000103 [28.627100 -158.996002 0.005500] 0.250794 0.000000 0.000000 -0.968041 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70100002, 2348257, 0x01000112, 41.1953, -178.763, 0.0055, 0.020154, 0, 0, 0.999797,  True, '2005-02-09 10:00:00'); /* Infected Olthoi Warrior */
/* @teleloc 0x01000112 [41.195301 -178.763000 0.005500] 0.020154 0.000000 0.000000 0.999797 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70100003, 2348257, 0x01000112, 39.3638, -179.623, 0.0055, -0.011459, 0, 0, 0.999934,  True, '2005-02-09 10:00:00'); /* Infected Olthoi Warrior */
/* @teleloc 0x01000112 [39.363800 -179.623001 0.005500] -0.011459 0.000000 0.000000 0.999934 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70100004, 31024, 0x01000112, 39.3235, -177.868, 0.0055, -0.011459, 0, 0, 0.999934,  True, '2005-02-09 10:00:00'); /* Mudwort Thrungus */
/* @teleloc 0x01000112 [39.323502 -177.867996 0.005500] -0.011459 0.000000 0.000000 0.999934 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70100005,  3955, 0x01000113, 40, -190, 0.005, 1, 0, 0, 0, False, '2005-02-09 10:00:00'); /* Linkable Monster Gen (15 min.) */
/* @teleloc 0x01000113 [40.000000 -190.000000 0.005000] 1.000000 0.000000 0.000000 0.000000 */

INSERT INTO `landblock_instance_link` (`parent_GUID`, `child_GUID`, `last_Modified`)
VALUES (0x70100005, 0x7010005C, '2005-02-09 10:00:00') /* Infected Killer Wasp (4179757) */
     , (0x70100005, 0x7010006A, '2005-02-09 10:00:00') /* Infected Olthoi Warrior (2348257) */
     , (0x70100005, 0x7010006B, '2005-02-09 10:00:00') /* Infected Olthoi Warrior (2348257) */
     , (0x70100005, 0x7010006C, '2005-02-09 10:00:00') /* Infected Olthoi Warrior (2348257) */;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70100006, 792357, 0x01000113, 41.9496, -191.037, 0.005, 1, 0, 0, 0, False, '2005-02-09 10:00:00'); /* linkmonstergen90sec */
/* @teleloc 0x01000113 [41.949600 -191.037003 0.005000] 1.000000 0.000000 0.000000 0.000000 */

INSERT INTO `landblock_instance_link` (`parent_GUID`, `child_GUID`, `last_Modified`)
VALUES (0x70100006, 0x70100000, '2005-02-09 10:00:00') /* Mudwort Thrungus (31024) */
     , (0x70100006, 0x70100001, '2005-02-09 10:00:00') /* Infected Olthoi Warrior (2348257) */
     , (0x70100006, 0x70100002, '2005-02-09 10:00:00') /* Infected Olthoi Warrior (2348257) */
     , (0x70100006, 0x70100003, '2005-02-09 10:00:00') /* Infected Olthoi Warrior (2348257) */
     , (0x70100006, 0x70100004, '2005-02-09 10:00:00') /* Mudwort Thrungus (31024) */
     , (0x70100006, 0x70100008, '2005-02-09 10:00:00') /* Mudwort Thrungus (31024) */
     , (0x70100006, 0x70100009, '2005-02-09 10:00:00') /* Infected Killer Wasp (4179757) */
     , (0x70100006, 0x7010000A, '2005-02-09 10:00:00') /* Mudwort Thrungus (31024) */
     , (0x70100006, 0x7010000B, '2005-02-09 10:00:00') /* Mudwort Thrungus (31024) */
     , (0x70100006, 0x7010000C, '2005-02-09 10:00:00') /* Infected Olthoi Warrior (2348257) */
     , (0x70100006, 0x7010000D, '2005-02-09 10:00:00') /* Mudwort Thrungus (31024) */
     , (0x70100006, 0x7010000E, '2005-02-09 10:00:00') /* Infected Olthoi Warrior (2348257) */
     , (0x70100006, 0x7010000F, '2005-02-09 10:00:00') /* Infected Olthoi Warrior (2348257) */
     , (0x70100006, 0x70100010, '2005-02-09 10:00:00') /* Mudwort Thrungus (31024) */
     , (0x70100006, 0x70100011, '2005-02-09 10:00:00') /* Infected Killer Wasp (4179757) */
     , (0x70100006, 0x70100012, '2005-02-09 10:00:00') /* Mudwort Thrungus (31024) */
     , (0x70100006, 0x70100014, '2005-02-09 10:00:00') /* Infected Killer Wasp (4179757) */
     , (0x70100006, 0x70100015, '2005-02-09 10:00:00') /* Infected Killer Wasp (4179757) */
     , (0x70100006, 0x70100016, '2005-02-09 10:00:00') /* Mudwort Thrungus (31024) */
     , (0x70100006, 0x70100017, '2005-02-09 10:00:00') /* Mudwort Thrungus (31024) */
     , (0x70100006, 0x70100018, '2005-02-09 10:00:00') /* Infected Killer Wasp (4179757) */
     , (0x70100006, 0x70100019, '2005-02-09 10:00:00') /* Mudwort Thrungus (31024) */
     , (0x70100006, 0x7010001A, '2005-02-09 10:00:00') /* Mudwort Thrungus (31024) */
     , (0x70100006, 0x7010001B, '2005-02-09 10:00:00') /* Mudwort Thrungus (31024) */
     , (0x70100006, 0x7010001C, '2005-02-09 10:00:00') /* Mudwort Thrungus (31024) */
     , (0x70100006, 0x7010001D, '2005-02-09 10:00:00') /* Infected Olthoi Warrior (2348257) */
     , (0x70100006, 0x7010001E, '2005-02-09 10:00:00') /* Infected Olthoi Warrior (2348257) */
     , (0x70100006, 0x7010001F, '2005-02-09 10:00:00') /* Mudwort Thrungus (31024) */
     , (0x70100006, 0x70100020, '2005-02-09 10:00:00') /* Infected Olthoi Warrior (2348257) */
     , (0x70100006, 0x70100021, '2005-02-09 10:00:00') /* Mudwort Thrungus (31024) */
     , (0x70100006, 0x70100022, '2005-02-09 10:00:00') /* Infected Olthoi Warrior (2348257) */
     , (0x70100006, 0x70100023, '2005-02-09 10:00:00') /* Infected Olthoi Warrior (2348257) */
     , (0x70100006, 0x70100024, '2005-02-09 10:00:00') /* Infected Killer Wasp (4179757) */
     , (0x70100006, 0x70100025, '2005-02-09 10:00:00') /* Mudwort Thrungus (31024) */
     , (0x70100006, 0x70100026, '2005-02-09 10:00:00') /* Infected Olthoi Warrior (2348257) */
     , (0x70100006, 0x70100027, '2005-02-09 10:00:00') /* Mudwort Thrungus (31024) */
     , (0x70100006, 0x70100028, '2005-02-09 10:00:00') /* Infected Olthoi Warrior (2348257) */
     , (0x70100006, 0x70100029, '2005-02-09 10:00:00') /* Infected Killer Wasp (4179757) */
     , (0x70100006, 0x7010002A, '2005-02-09 10:00:00') /* Infected Olthoi Warrior (2348257) */
     , (0x70100006, 0x7010002B, '2005-02-09 10:00:00') /* Mudwort Thrungus (31024) */
     , (0x70100006, 0x7010002C, '2005-02-09 10:00:00') /* Infected Olthoi Warrior (2348257) */
     , (0x70100006, 0x7010002D, '2005-02-09 10:00:00') /* Infected Olthoi Warrior (2348257) */
     , (0x70100006, 0x7010002E, '2005-02-09 10:00:00') /* Infected Olthoi Warrior (2348257) */
     , (0x70100006, 0x7010002F, '2005-02-09 10:00:00') /* Infected Olthoi Warrior (2348257) */
     , (0x70100006, 0x70100030, '2005-02-09 10:00:00') /* Infected Olthoi Warrior (2348257) */
     , (0x70100006, 0x70100031, '2005-02-09 10:00:00') /* Mudwort Thrungus (31024) */
     , (0x70100006, 0x70100032, '2005-02-09 10:00:00') /* Infected Olthoi Warrior (2348257) */
     , (0x70100006, 0x70100033, '2005-02-09 10:00:00') /* Infected Olthoi Warrior (2348257) */
     , (0x70100006, 0x70100034, '2005-02-09 10:00:00') /* Mudwort Thrungus (31024) */
     , (0x70100006, 0x70100035, '2005-02-09 10:00:00') /* Mudwort Thrungus (31024) */
     , (0x70100006, 0x70100036, '2005-02-09 10:00:00') /* Infected Killer Wasp (4179757) */
     , (0x70100006, 0x70100037, '2005-02-09 10:00:00') /* Infected Killer Wasp (4179757) */
     , (0x70100006, 0x70100038, '2005-02-09 10:00:00') /* Mudwort Thrungus (31024) */
     , (0x70100006, 0x70100039, '2005-02-09 10:00:00') /* Infected Olthoi Warrior (2348257) */
     , (0x70100006, 0x7010003B, '2005-02-09 10:00:00') /* Mudwort Thrungus (31024) */
     , (0x70100006, 0x7010003C, '2005-02-09 10:00:00') /* Mudwort Thrungus (31024) */
     , (0x70100006, 0x7010003D, '2005-02-09 10:00:00') /* Infected Olthoi Warrior (2348257) */
     , (0x70100006, 0x7010003E, '2005-02-09 10:00:00') /* Infected Olthoi Warrior (2348257) */
     , (0x70100006, 0x7010003F, '2005-02-09 10:00:00') /* Infected Killer Wasp (4179757) */
     , (0x70100006, 0x70100040, '2005-02-09 10:00:00') /* Infected Killer Wasp (4179757) */
     , (0x70100006, 0x70100041, '2005-02-09 10:00:00') /* Mudwort Thrungus (31024) */
     , (0x70100006, 0x70100042, '2005-02-09 10:00:00') /* Mudwort Thrungus (31024) */
     , (0x70100006, 0x70100043, '2005-02-09 10:00:00') /* Mudwort Thrungus (31024) */
     , (0x70100006, 0x70100044, '2005-02-09 10:00:00') /* Mudwort Thrungus (31024) */
     , (0x70100006, 0x70100045, '2005-02-09 10:00:00') /* Infected Olthoi Warrior (2348257) */
     , (0x70100006, 0x70100046, '2005-02-09 10:00:00') /* Infected Olthoi Warrior (2348257) */
     , (0x70100006, 0x70100047, '2005-02-09 10:00:00') /* Infected Olthoi Warrior (2348257) */
     , (0x70100006, 0x70100048, '2005-02-09 10:00:00') /* Mudwort Thrungus (31024) */
     , (0x70100006, 0x70100049, '2005-02-09 10:00:00') /* Infected Killer Wasp (4179757) */
     , (0x70100006, 0x7010004A, '2005-02-09 10:00:00') /* Infected Olthoi Warrior (2348257) */
     , (0x70100006, 0x7010004B, '2005-02-09 10:00:00') /* Mudwort Thrungus (31024) */
     , (0x70100006, 0x7010004C, '2005-02-09 10:00:00') /* Mudwort Thrungus (31024) */
     , (0x70100006, 0x7010004D, '2005-02-09 10:00:00') /* Infected Olthoi Warrior (2348257) */
     , (0x70100006, 0x7010004E, '2005-02-09 10:00:00') /* Infected Olthoi Warrior (2348257) */
     , (0x70100006, 0x7010004F, '2005-02-09 10:00:00') /* Infected Killer Wasp (4179757) */
     , (0x70100006, 0x70100050, '2005-02-09 10:00:00') /* Mudwort Thrungus (31024) */
     , (0x70100006, 0x70100051, '2005-02-09 10:00:00') /* Mudwort Thrungus (31024) */
     , (0x70100006, 0x70100052, '2005-02-09 10:00:00') /* Spore Thrungus (858357) */
     , (0x70100006, 0x70100053, '2005-02-09 10:00:00') /* Spore Thrungus (858357) */
     , (0x70100006, 0x70100054, '2005-02-09 10:00:00') /* Spore Thrungus (858357) */
     , (0x70100006, 0x70100055, '2005-02-09 10:00:00') /* Spore Thrungus (858357) */
     , (0x70100006, 0x70100056, '2005-02-09 10:00:00') /* Infected Killer Wasp (4179757) */
     , (0x70100006, 0x70100059, '2005-02-09 10:00:00') /* Mudwort Thrungus (31024) */
     , (0x70100006, 0x7010005A, '2005-02-09 10:00:00') /* Mudwort Thrungus (31024) */
     , (0x70100006, 0x7010005B, '2005-02-09 10:00:00') /* Mudwort Thrungus (31024) */
     , (0x70100006, 0x7010005D, '2005-02-09 10:00:00') /* Infected Killer Wasp (4179757) */
     , (0x70100006, 0x7010005E, '2005-02-09 10:00:00') /* Infected Killer Wasp (4179757) */
     , (0x70100006, 0x70100060, '2005-02-09 10:00:00') /* Mudwort Thrungus (31024) */
     , (0x70100006, 0x70100061, '2005-02-09 10:00:00') /* Mudwort Thrungus (31024) */
     , (0x70100006, 0x70100062, '2005-02-09 10:00:00') /* Mudwort Thrungus (31024) */
     , (0x70100006, 0x70100063, '2005-02-09 10:00:00') /* Mudwort Thrungus (31024) */
     , (0x70100006, 0x70100064, '2005-02-09 10:00:00') /* Infected Olthoi Warrior (2348257) */
     , (0x70100006, 0x70100065, '2005-02-09 10:00:00') /* Infected Olthoi Warrior (2348257) */
     , (0x70100006, 0x70100066, '2005-02-09 10:00:00') /* Infected Killer Wasp (4179757) */
     , (0x70100006, 0x70100067, '2005-02-09 10:00:00') /* Mudwort Thrungus (31024) */
     , (0x70100006, 0x70100068, '2005-02-09 10:00:00') /* Mudwort Thrungus (31024) */
     , (0x70100006, 0x70100069, '2005-02-09 10:00:00') /* Mudwort Thrungus (31024) */
     , (0x70100006, 0x7010006D, '2005-02-09 10:00:00') /* Infected Killer Wasp (4179757) */
     , (0x70100006, 0x7010006E, '2005-02-09 10:00:00') /* Infected Killer Wasp (4179757) */
     , (0x70100006, 0x7010006F, '2005-02-09 10:00:00') /* Infected Killer Wasp (4179757) */
     , (0x70100006, 0x70100071, '2005-02-09 10:00:00') /* Puffball Thrungus (31021) */
     , (0x70100006, 0x70100072, '2005-02-09 10:00:00') /* Puffball Thrungus (31021) */
     , (0x70100006, 0x70100073, '2005-02-09 10:00:00') /* Infected Olthoi Warrior (2348257) */
     , (0x70100006, 0x70100075, '2005-02-09 10:00:00') /* Infected Olthoi Warrior (2348257) */
     , (0x70100006, 0x70100076, '2005-02-09 10:00:00') /* Infected Olthoi Warrior (2348257) */
     , (0x70100006, 0x70100077, '2005-02-09 10:00:00') /* Infected Killer Wasp (4179757) */
     , (0x70100006, 0x70100078, '2005-02-09 10:00:00') /* Puffball Thrungus (31021) */
     , (0x70100006, 0x70100079, '2005-02-09 10:00:00') /* Puffball Thrungus (31021) */
     , (0x70100006, 0x7010007A, '2005-02-09 10:00:00') /* Puffball Thrungus (31021) */
     , (0x70100006, 0x7010007B, '2005-02-09 10:00:00') /* Infected Olthoi Warrior (2348257) */
     , (0x70100006, 0x7010007C, '2005-02-09 10:00:00') /* Infected Olthoi Warrior (2348257) */
     , (0x70100006, 0x7010007D, '2005-02-09 10:00:00') /* Puffball Thrungus (31021) */
     , (0x70100006, 0x7010007E, '2005-02-09 10:00:00') /* Puffball Thrungus (31021) */
     , (0x70100006, 0x7010007F, '2005-02-09 10:00:00') /* Puffball Thrungus (31021) */
     , (0x70100006, 0x70100080, '2005-02-09 10:00:00') /* Puffball Thrungus (31021) */
     , (0x70100006, 0x70100081, '2005-02-09 10:00:00') /* Puffball Thrungus (31021) */
     , (0x70100006, 0x70100082, '2005-02-09 10:00:00') /* Infected Killer Wasp (4179757) */
     , (0x70100006, 0x70100083, '2005-02-09 10:00:00') /* Infected Killer Wasp (4179757) */
     , (0x70100006, 0x70100084, '2005-02-09 10:00:00') /* Infected Olthoi Warrior (2348257) */
     , (0x70100006, 0x70100085, '2005-02-09 10:00:00') /* Puffball Thrungus (31021) */
     , (0x70100006, 0x70100086, '2005-02-09 10:00:00') /* Puffball Thrungus (31021) */
     , (0x70100006, 0x70100087, '2005-02-09 10:00:00') /* Puffball Thrungus (31021) */
     , (0x70100006, 0x70100088, '2005-02-09 10:00:00') /* Puffball Thrungus (31021) */
     , (0x70100006, 0x70100089, '2005-02-09 10:00:00') /* Puffball Thrungus (31021) */
     , (0x70100006, 0x7010008A, '2005-02-09 10:00:00') /* Puffball Thrungus (31021) */
     , (0x70100006, 0x7010008B, '2005-02-09 10:00:00') /* Puffball Thrungus (31021) */
     , (0x70100006, 0x7010008C, '2005-02-09 10:00:00') /* Spore Thrungus (858357) */
     , (0x70100006, 0x7010008D, '2005-02-09 10:00:00') /* Spore Thrungus (858357) */
     , (0x70100006, 0x7010008E, '2005-02-09 10:00:00') /* Puffball Thrungus (31021) */
     , (0x70100006, 0x7010008F, '2005-02-09 10:00:00') /* Infected Killer Wasp (4179757) */
     , (0x70100006, 0x70100090, '2005-02-09 10:00:00') /* Puffball Thrungus (31021) */
     , (0x70100006, 0x70100091, '2005-02-09 10:00:00') /* Puffball Thrungus (31021) */
     , (0x70100006, 0x70100092, '2005-02-09 10:00:00') /* Infected Killer Wasp (4179757) */
     , (0x70100006, 0x70100093, '2005-02-09 10:00:00') /* Infected Killer Wasp (4179757) */
     , (0x70100006, 0x70100094, '2005-02-09 10:00:00') /* Infected Killer Wasp (4179757) */
     , (0x70100006, 0x70100095, '2005-02-09 10:00:00') /* Puffball Thrungus (31021) */
     , (0x70100006, 0x70100096, '2005-02-09 10:00:00') /* Puffball Thrungus (31021) */
     , (0x70100006, 0x70100097, '2005-02-09 10:00:00') /* Puffball Thrungus (31021) */
     , (0x70100006, 0x70100099, '2005-02-09 10:00:00') /* Spore Thrungus (858357) */
     , (0x70100006, 0x7010009A, '2005-02-09 10:00:00') /* Spore Thrungus (858357) */
     , (0x70100006, 0x7010009B, '2005-02-09 10:00:00') /* Puffball Thrungus (31021) */
     , (0x70100006, 0x7010009C, '2005-02-09 10:00:00') /* Puffball Thrungus (31021) */
     , (0x70100006, 0x7010009D, '2005-02-09 10:00:00') /* Infected Killer Wasp (4179757) */
     , (0x70100006, 0x7010009E, '2005-02-09 10:00:00') /* Infected Killer Wasp (4179757) */
     , (0x70100006, 0x7010009F, '2005-02-09 10:00:00') /* Puffball Thrungus (31021) */
     , (0x70100006, 0x701000A0, '2005-02-09 10:00:00') /* Puffball Thrungus (31021) */
     , (0x70100006, 0x701000A1, '2005-02-09 10:00:00') /* Puffball Thrungus (31021) */
     , (0x70100006, 0x701000A2, '2005-02-09 10:00:00') /* Puffball Thrungus (31021) */
     , (0x70100006, 0x701000A3, '2005-02-09 10:00:00') /* Puffball Thrungus (31021) */
     , (0x70100006, 0x701000A4, '2005-02-09 10:00:00') /* Infected Olthoi Warrior (2348257) */
     , (0x70100006, 0x701000A5, '2005-02-09 10:00:00') /* Infected Killer Wasp (4179757) */
     , (0x70100006, 0x701000A6, '2005-02-09 10:00:00') /* Infected Killer Wasp (4179757) */
     , (0x70100006, 0x701000A7, '2005-02-09 10:00:00') /* Puffball Thrungus (31021) */
     , (0x70100006, 0x701000A8, '2005-02-09 10:00:00') /* Puffball Thrungus (31021) */
     , (0x70100006, 0x701000A9, '2005-02-09 10:00:00') /* Puffball Thrungus (31021) */
     , (0x70100006, 0x701000AA, '2005-02-09 10:00:00') /* Puffball Thrungus (31021) */
     , (0x70100006, 0x701000AB, '2005-02-09 10:00:00') /* Infected Killer Wasp (4179757) */
     , (0x70100006, 0x701000AC, '2005-02-09 10:00:00') /* Puffball Thrungus (31021) */
     , (0x70100006, 0x701000AD, '2005-02-09 10:00:00') /* Infected Killer Wasp (4179757) */
     , (0x70100006, 0x701000AE, '2005-02-09 10:00:00') /* Infected Killer Wasp (4179757) */
     , (0x70100006, 0x701000AF, '2005-02-09 10:00:00') /* Infected Killer Wasp (4179757) */
     , (0x70100006, 0x701000B0, '2005-02-09 10:00:00') /* Infected Killer Wasp (4179757) */
     , (0x70100006, 0x701000B1, '2005-02-09 10:00:00') /* Infected Killer Wasp (4179757) */
     , (0x70100006, 0x701000B2, '2005-02-09 10:00:00') /* Puffball Thrungus (31021) */
     , (0x70100006, 0x701000B3, '2005-02-09 10:00:00') /* Puffball Thrungus (31021) */
     , (0x70100006, 0x701000B4, '2005-02-09 10:00:00') /* Puffball Thrungus (31021) */
     , (0x70100006, 0x701000B5, '2005-02-09 10:00:00') /* Puffball Thrungus (31021) */
     , (0x70100006, 0x701000B6, '2005-02-09 10:00:00') /* Puffball Thrungus (31021) */
     , (0x70100006, 0x701000B7, '2005-02-09 10:00:00') /* Infected Killer Wasp (4179757) */
     , (0x70100006, 0x701000B8, '2005-02-09 10:00:00') /* Infected Killer Wasp (4179757) */
     , (0x70100006, 0x701000B9, '2005-02-09 10:00:00') /* Puffball Thrungus (31021) */
     , (0x70100006, 0x701000BA, '2005-02-09 10:00:00') /* Puffball Thrungus (31021) */
     , (0x70100006, 0x701000BB, '2005-02-09 10:00:00') /* Puffball Thrungus (31021) */
     , (0x70100006, 0x701000BC, '2005-02-09 10:00:00') /* Infected Killer Wasp (4179757) */
     , (0x70100006, 0x701000BD, '2005-02-09 10:00:00') /* Infected Killer Wasp (4179757) */
     , (0x70100006, 0x701000BE, '2005-02-09 10:00:00') /* Puffball Thrungus (31021) */
     , (0x70100006, 0x701000BF, '2005-02-09 10:00:00') /* Puffball Thrungus (31021) */
     , (0x70100006, 0x701000C0, '2005-02-09 10:00:00') /* Infected Olthoi Warrior (2348257) */
     , (0x70100006, 0x701000C1, '2005-02-09 10:00:00') /* Infected Olthoi Warrior (2348257) */
     , (0x70100006, 0x701000C2, '2005-02-09 10:00:00') /* Infected Olthoi Warrior (2348257) */
     , (0x70100006, 0x701000C3, '2005-02-09 10:00:00') /* Infected Olthoi Warrior (2348257) */
     , (0x70100006, 0x701000C4, '2005-02-09 10:00:00') /* Infected Olthoi Warrior (2348257) */
     , (0x70100006, 0x701000C5, '2005-02-09 10:00:00') /* Spore Thrungus (858357) */
     , (0x70100006, 0x701000C6, '2005-02-09 10:00:00') /* Spore Thrungus (858357) */
     , (0x70100006, 0x701000C7, '2005-02-09 10:00:00') /* Spore Thrungus (858357) */
     , (0x70100006, 0x701000C8, '2005-02-09 10:00:00') /* Infected Olthoi Warrior (2348257) */
     , (0x70100006, 0x701000C9, '2005-02-09 10:00:00') /* Puffball Thrungus (31021) */
     , (0x70100006, 0x701000CA, '2005-02-09 10:00:00') /* Puffball Thrungus (31021) */
     , (0x70100006, 0x701000CB, '2005-02-09 10:00:00') /* Puffball Thrungus (31021) */
     , (0x70100006, 0x701000CC, '2005-02-09 10:00:00') /* Puffball Thrungus (31021) */
     , (0x70100006, 0x701000CD, '2005-02-09 10:00:00') /* Puffball Thrungus (31021) */
     , (0x70100006, 0x701000CE, '2005-02-09 10:00:00') /* Puffball Thrungus (31021) */
     , (0x70100006, 0x701000CF, '2005-02-09 10:00:00') /* Puffball Thrungus (31021) */
     , (0x70100006, 0x701000D0, '2005-02-09 10:00:00') /* Infected Olthoi Warrior (2348257) */
     , (0x70100006, 0x701000D1, '2005-02-09 10:00:00') /* Infected Olthoi Warrior (2348257) */
     , (0x70100006, 0x701000D2, '2005-02-09 10:00:00') /* Infected Olthoi Warrior (2348257) */
     , (0x70100006, 0x701000D3, '2005-02-09 10:00:00') /* Puffball Thrungus (31021) */
     , (0x70100006, 0x701000D4, '2005-02-09 10:00:00') /* Puffball Thrungus (31021) */
     , (0x70100006, 0x701000D5, '2005-02-09 10:00:00') /* Puffball Thrungus (31021) */
     , (0x70100006, 0x701000D6, '2005-02-09 10:00:00') /* Puffball Thrungus (31021) */
     , (0x70100006, 0x701000D7, '2005-02-09 10:00:00') /* Puffball Thrungus (31021) */
     , (0x70100006, 0x701000D8, '2005-02-09 10:00:00') /* Puffball Thrungus (31021) */
     , (0x70100006, 0x701000D9, '2005-02-09 10:00:00') /* Puffball Thrungus (31021) */
     , (0x70100006, 0x701000DA, '2005-02-09 10:00:00') /* Puffball Thrungus (31021) */
     , (0x70100006, 0x701000DB, '2005-02-09 10:00:00') /* Puffball Thrungus (31021) */
     , (0x70100006, 0x701000DC, '2005-02-09 10:00:00') /* Puffball Thrungus (31021) */
     , (0x70100006, 0x701000DD, '2005-02-09 10:00:00') /* Puffball Thrungus (31021) */
     , (0x70100006, 0x701000DE, '2005-02-09 10:00:00') /* Puffball Thrungus (31021) */;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70100007,  7253, 0x01000115, 40, -213.123, 0.005, 1, 0, 0, 0, False, '2005-02-09 10:00:00'); /* Surface Portal */
/* @teleloc 0x01000115 [40.000000 -213.123001 0.005000] 1.000000 0.000000 0.000000 0.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70100008, 31024, 0x0100013D, 47.6575, -138.795, 6.0055, -0.738701, 0, 0, -0.674033,  True, '2005-02-09 10:00:00'); /* Mudwort Thrungus */
/* @teleloc 0x0100013D [47.657501 -138.794998 6.005500] -0.738701 0.000000 0.000000 -0.674033 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70100009, 4179757, 0x0100013D, 48.5193, -140.877, 6.0055, -0.857886, 0, 0, -0.51384,  True, '2005-02-09 10:00:00'); /* Infected Killer Wasp */
/* @teleloc 0x0100013D [48.519299 -140.876999 6.005500] -0.857886 0.000000 0.000000 -0.513840 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7010000A, 31024, 0x0100013E, 45.968, -140.546, 6.0055, -0.661493, 0, 0, -0.749951,  True, '2005-02-09 10:00:00'); /* Mudwort Thrungus */
/* @teleloc 0x0100013E [45.967999 -140.546005 6.005500] -0.661493 0.000000 0.000000 -0.749951 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7010000B, 31024, 0x0100013E, 45.8707, -138.631, 6.0055, -0.738701, 0, 0, -0.674033,  True, '2005-02-09 10:00:00'); /* Mudwort Thrungus */
/* @teleloc 0x0100013E [45.870701 -138.630997 6.005500] -0.738701 0.000000 0.000000 -0.674033 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7010000C, 2348257, 0x01000147, 60, -30, 6.0055, 0.362358, 0, 0, -0.932039,  True, '2005-02-09 10:00:00'); /* Infected Olthoi Warrior */
/* @teleloc 0x01000147 [60.000000 -30.000000 6.005500] 0.362358 0.000000 0.000000 -0.932039 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7010000D, 31024, 0x01000147, 58.8017, -30.1205, 6.0055, 0.159499, 0, 0, -0.987198,  True, '2005-02-09 10:00:00'); /* Mudwort Thrungus */
/* @teleloc 0x01000147 [58.801701 -30.120501 6.005500] 0.159499 0.000000 0.000000 -0.987198 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7010000E, 2348257, 0x01000150, 60.7502, -50.0198, 6.0055, 0.547296, 0, 0, -0.836939,  True, '2005-02-09 10:00:00'); /* Infected Olthoi Warrior */
/* @teleloc 0x01000150 [60.750198 -50.019798 6.005500] 0.547296 0.000000 0.000000 -0.836939 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7010000F, 2348257, 0x01000150, 58.4845, -51.0511, 6.0055, 0.588441, 0, 0, -0.80854,  True, '2005-02-09 10:00:00'); /* Infected Olthoi Warrior */
/* @teleloc 0x01000150 [58.484501 -51.051102 6.005500] 0.588441 0.000000 0.000000 -0.808540 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70100010, 31024, 0x01000150, 57.8906, -48.2804, 6.0055, 0.502038, 0, 0, -0.864846,  True, '2005-02-09 10:00:00'); /* Mudwort Thrungus */
/* @teleloc 0x01000150 [57.890598 -48.280399 6.005500] 0.502038 0.000000 0.000000 -0.864846 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70100011, 4179757, 0x01000162, 60, -110, 6.0055, 0.431176, 0, 0, -0.902268,  True, '2005-02-09 10:00:00'); /* Infected Killer Wasp */
/* @teleloc 0x01000162 [60.000000 -110.000000 6.005500] 0.431176 0.000000 0.000000 -0.902268 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70100012, 31024, 0x01000163, 62.3606, -119.029, 6.0055, 0.446856, 0, 0, -0.894606,  True, '2005-02-09 10:00:00'); /* Mudwort Thrungus */
/* @teleloc 0x01000163 [62.360600 -119.028999 6.005500] 0.446856 0.000000 0.000000 -0.894606 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70100014, 4179757, 0x0100016F, 69.7216, -22.2487, 6.0055, 0.026324, 0, 0, 0.999653,  True, '2005-02-09 10:00:00'); /* Infected Killer Wasp */
/* @teleloc 0x0100016F [69.721603 -22.248699 6.005500] 0.026324 0.000000 0.000000 0.999653 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70100015, 4179757, 0x0100016F, 70.1416, -23.5212, 6.0055, 0.00966, 0, 0, 0.999953,  True, '2005-02-09 10:00:00'); /* Infected Killer Wasp */
/* @teleloc 0x0100016F [70.141602 -23.521200 6.005500] 0.009660 0.000000 0.000000 0.999953 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70100016, 31024, 0x01000171, 70.8073, -29.6991, 6.0055, -0.054737, 0, 0, 0.998501,  True, '2005-02-09 10:00:00'); /* Mudwort Thrungus */
/* @teleloc 0x01000171 [70.807297 -29.699100 6.005500] -0.054737 0.000000 0.000000 0.998501 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70100017, 31024, 0x01000171, 68.7509, -28.808, 6.0055, 0.067488, 0, 0, 0.99772,  True, '2005-02-09 10:00:00'); /* Mudwort Thrungus */
/* @teleloc 0x01000171 [68.750900 -28.808001 6.005500] 0.067488 0.000000 0.000000 0.997720 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70100018, 4179757, 0x01000191, 70, -100, 6.0055, 0.04578, 0, 0, 0.998952,  True, '2005-02-09 10:00:00'); /* Infected Killer Wasp */
/* @teleloc 0x01000191 [70.000000 -100.000000 6.005500] 0.045780 0.000000 0.000000 0.998952 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70100019, 31024, 0x01000191, 68.2372, -102.424, 6.0055, 0.11022, 0, 0, 0.993907,  True, '2005-02-09 10:00:00'); /* Mudwort Thrungus */
/* @teleloc 0x01000191 [68.237198 -102.424004 6.005500] 0.110220 0.000000 0.000000 0.993907 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7010001A, 31024, 0x01000191, 71.5873, -103.375, 6.0055, -0.009884, 0, 0, 0.999951,  True, '2005-02-09 10:00:00'); /* Mudwort Thrungus */
/* @teleloc 0x01000191 [71.587303 -103.375000 6.005500] -0.009884 0.000000 0.000000 0.999951 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7010001B, 31024, 0x01000193, 71.6714, -118.093, 6.0055, -0.143764, 0, 0, -0.989612,  True, '2005-02-09 10:00:00'); /* Mudwort Thrungus */
/* @teleloc 0x01000193 [71.671402 -118.093002 6.005500] -0.143764 0.000000 0.000000 -0.989612 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7010001C, 31024, 0x01000193, 68.1034, -118.564, 6.0055, 0.07234, 0, 0, -0.99738,  True, '2005-02-09 10:00:00'); /* Mudwort Thrungus */
/* @teleloc 0x01000193 [68.103401 -118.564003 6.005500] 0.072340 0.000000 0.000000 -0.997380 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7010001D, 2348257, 0x01000194, 68.6984, -126.468, 6.0055, 0.018927, 0, 0, -0.999821,  True, '2005-02-09 10:00:00'); /* Infected Olthoi Warrior */
/* @teleloc 0x01000194 [68.698402 -126.468002 6.005500] 0.018927 0.000000 0.000000 -0.999821 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7010001E, 2348257, 0x01000194, 71.6825, -127.102, 6.0055, 0.03906, 0, 0, -0.999237,  True, '2005-02-09 10:00:00'); /* Infected Olthoi Warrior */
/* @teleloc 0x01000194 [71.682503 -127.101997 6.005500] 0.039060 0.000000 0.000000 -0.999237 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7010001F, 31024, 0x0100019D, 80, -30, 6.0055, -0.254407, 0, 0, -0.967097,  True, '2005-02-09 10:00:00'); /* Mudwort Thrungus */
/* @teleloc 0x0100019D [80.000000 -30.000000 6.005500] -0.254407 0.000000 0.000000 -0.967097 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70100020, 2348257, 0x0100019D, 79.3048, -29.0531, 6.0055, 0.630121, 0, 0, 0.776497,  True, '2005-02-09 10:00:00'); /* Infected Olthoi Warrior */
/* @teleloc 0x0100019D [79.304802 -29.053101 6.005500] 0.630121 0.000000 0.000000 0.776497 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70100021, 31024, 0x010001AB, 79.822, -58.8359, 6.0055, -0.205879, 0, 0, -0.978577,  True, '2005-02-09 10:00:00'); /* Mudwort Thrungus */
/* @teleloc 0x010001AB [79.821999 -58.835899 6.005500] -0.205879 0.000000 0.000000 -0.978577 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70100022, 2348257, 0x010001AB, 80.5268, -61.2864, 6.0055, 0.021108, 0, 0, 0.999777,  True, '2005-02-09 10:00:00'); /* Infected Olthoi Warrior */
/* @teleloc 0x010001AB [80.526802 -61.286400 6.005500] 0.021108 0.000000 0.000000 0.999777 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70100023, 2348257, 0x010001AB, 78.0223, -61.7889, 6.0055, -0.115739, 0, 0, 0.99328,  True, '2005-02-09 10:00:00'); /* Infected Olthoi Warrior */
/* @teleloc 0x010001AB [78.022301 -61.788898 6.005500] -0.115739 0.000000 0.000000 0.993280 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70100024, 4179757, 0x010001B8, 80.582, -109.48, 6.0055, 0.408488, 0, 0, 0.912764,  True, '2005-02-09 10:00:00'); /* Infected Killer Wasp */
/* @teleloc 0x010001B8 [80.582001 -109.480003 6.005500] 0.408488 0.000000 0.000000 0.912764 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70100025, 31024, 0x010001B9, 75.3596, -119.416, 6.055, 0.501552, 0, 0, 0.865127,  True, '2005-02-09 10:00:00'); /* Mudwort Thrungus */
/* @teleloc 0x010001B9 [75.359596 -119.416000 6.055000] 0.501552 0.000000 0.000000 0.865127 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70100026, 2348257, 0x010001BA, 83.7103, -159.548, 6.0055, -0.698126, 0, 0, -0.715975,  True, '2005-02-09 10:00:00'); /* Infected Olthoi Warrior */
/* @teleloc 0x010001BA [83.710297 -159.548004 6.005500] -0.698126 0.000000 0.000000 -0.715975 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70100027, 31024, 0x010001BC, 91.5023, -154.15, 6.0055, -0.688102, 0, 0, -0.725614,  True, '2005-02-09 10:00:00'); /* Mudwort Thrungus */
/* @teleloc 0x010001BC [91.502296 -154.149994 6.005500] -0.688102 0.000000 0.000000 -0.725614 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70100028, 2348257, 0x010001BC, 88.7875, -151.756, 6.0055, -0.783846, 0, 0, -0.620955,  True, '2005-02-09 10:00:00'); /* Infected Olthoi Warrior */
/* @teleloc 0x010001BC [88.787498 -151.755997 6.005500] -0.783846 0.000000 0.000000 -0.620955 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70100029, 4179757, 0x010001BD, 93.458, -159.675, 6.0055, -0.679952, 0, 0, -0.733257,  True, '2005-02-09 10:00:00'); /* Infected Killer Wasp */
/* @teleloc 0x010001BD [93.458000 -159.675003 6.005500] -0.679952 0.000000 0.000000 -0.733257 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7010002A, 2348257, 0x010001BD, 88.4408, -164.11, 6.0055, -0.753185, 0, 0, -0.657808,  True, '2005-02-09 10:00:00'); /* Infected Olthoi Warrior */
/* @teleloc 0x010001BD [88.440804 -164.110001 6.005500] -0.753185 0.000000 0.000000 -0.657808 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7010002B, 31024, 0x010001BE, 91.2397, -166.235, 6.0055, -0.710074, 0, 0, -0.704127,  True, '2005-02-09 10:00:00'); /* Mudwort Thrungus */
/* @teleloc 0x010001BE [91.239700 -166.235001 6.005500] -0.710074 0.000000 0.000000 -0.704127 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7010002C, 2348257, 0x010001C4, 110.458, -129.552, 6.0055, -0.033164, 0, 0, 0.99945,  True, '2005-02-09 10:00:00'); /* Infected Olthoi Warrior */
/* @teleloc 0x010001C4 [110.458000 -129.552002 6.005500] -0.033164 0.000000 0.000000 0.999450 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7010002D, 2348257, 0x010001C4, 108.896, -131.222, 6.0055, 0.175924, 0, 0, 0.984404,  True, '2005-02-09 10:00:00'); /* Infected Olthoi Warrior */
/* @teleloc 0x010001C4 [108.896004 -131.222000 6.005500] 0.175924 0.000000 0.000000 0.984404 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7010002E, 2348257, 0x010001CB, 120.488, -142.99, 6.055, -0.010648, 0, 0, 0.999943,  True, '2005-02-09 10:00:00'); /* Infected Olthoi Warrior */
/* @teleloc 0x010001CB [120.487999 -142.990005 6.055000] -0.010648 0.000000 0.000000 0.999943 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7010002F, 2348257, 0x010001CC, 119.614, -144.67, 6.055, 0.082345, 0, 0, 0.996604,  True, '2005-02-09 10:00:00'); /* Infected Olthoi Warrior */
/* @teleloc 0x010001CC [119.613998 -144.669998 6.055000] 0.082345 0.000000 0.000000 0.996604 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70100030, 2348257, 0x010001D3, 131.699, -118.883, 6.0055, 0.667998, 0, 0, 0.744163,  True, '2005-02-09 10:00:00'); /* Infected Olthoi Warrior */
/* @teleloc 0x010001D3 [131.699005 -118.883003 6.005500] 0.667998 0.000000 0.000000 0.744163 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70100031, 31024, 0x010001D3, 131.252, -121.244, 6.0055, 0.651175, 0, 0, 0.758928,  True, '2005-02-09 10:00:00'); /* Mudwort Thrungus */
/* @teleloc 0x010001D3 [131.251999 -121.244003 6.005500] 0.651175 0.000000 0.000000 0.758928 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70100032, 2348257, 0x010001DC, 139.166, -182.624, 6.0055, -0.99999, 0, 0, -0.004515,  True, '2005-02-09 10:00:00'); /* Infected Olthoi Warrior */
/* @teleloc 0x010001DC [139.166000 -182.623993 6.005500] -0.999990 0.000000 0.000000 -0.004515 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70100033, 2348257, 0x010001DC, 140.112, -182.962, 6.0055, -0.999685, 0, 0, 0.025078,  True, '2005-02-09 10:00:00'); /* Infected Olthoi Warrior */
/* @teleloc 0x010001DC [140.112000 -182.962006 6.005500] -0.999685 0.000000 0.000000 0.025078 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70100034, 31024, 0x010001E1, 139.202, -186.616, 6.0055, -0.99999, 0, 0, -0.004515,  True, '2005-02-09 10:00:00'); /* Mudwort Thrungus */
/* @teleloc 0x010001E1 [139.201996 -186.615997 6.005500] -0.999990 0.000000 0.000000 -0.004515 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70100035, 31024, 0x010001E2, 141.316, -199.45, 6.0055, 0.985663, 0, 0, 0.168727,  True, '2005-02-09 10:00:00'); /* Mudwort Thrungus */
/* @teleloc 0x010001E2 [141.315994 -199.449997 6.005500] 0.985663 0.000000 0.000000 0.168727 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70100036, 4179757, 0x010001E2, 142.34, -201.23, 6.0055, 0.983086, 0, 0, 0.183147,  True, '2005-02-09 10:00:00'); /* Infected Killer Wasp */
/* @teleloc 0x010001E2 [142.339996 -201.229996 6.005500] 0.983086 0.000000 0.000000 0.183147 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70100037, 4179757, 0x010001EA, 139.95, -219.945, 6.0055, 0.999156, 0, 0, 0.041068,  True, '2005-02-09 10:00:00'); /* Infected Killer Wasp */
/* @teleloc 0x010001EA [139.949997 -219.945007 6.005500] 0.999156 0.000000 0.000000 0.041068 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70100038, 31024, 0x010001EA, 138.904, -219.237, 6.0055, 0.9818, 0, 0, 0.189919,  True, '2005-02-09 10:00:00'); /* Mudwort Thrungus */
/* @teleloc 0x010001EA [138.904007 -219.237000 6.005500] 0.981800 0.000000 0.000000 0.189919 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70100039, 2348257, 0x010001EA, 141.494, -218.667, 6.0055, 0.995748, 0, 0, -0.092123,  True, '2005-02-09 10:00:00'); /* Infected Olthoi Warrior */
/* @teleloc 0x010001EA [141.494003 -218.667007 6.005500] 0.995748 0.000000 0.000000 -0.092123 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7010003B, 31024, 0x0100020B, 148.917, -221.945, 6.0055, -0.709206, 0, 0, -0.705001,  True, '2005-02-09 10:00:00'); /* Mudwort Thrungus */
/* @teleloc 0x0100020B [148.917007 -221.945007 6.005500] -0.709206 0.000000 0.000000 -0.705001 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7010003C, 31024, 0x0100020B, 151, -221.957, 6.0055, -0.709206, 0, 0, -0.705001,  True, '2005-02-09 10:00:00'); /* Mudwort Thrungus */
/* @teleloc 0x0100020B [151.000000 -221.957001 6.005500] -0.709206 0.000000 0.000000 -0.705001 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7010003D, 2348257, 0x0100020B, 148.155, -220.044, 6.0055, -0.721245, 0, 0, -0.69268,  True, '2005-02-09 10:00:00'); /* Infected Olthoi Warrior */
/* @teleloc 0x0100020B [148.154999 -220.044006 6.005500] -0.721245 0.000000 0.000000 -0.692680 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7010003E, 2348257, 0x0100020B, 149.905, -220.114, 6.0055, -0.721245, 0, 0, -0.69268,  True, '2005-02-09 10:00:00'); /* Infected Olthoi Warrior */
/* @teleloc 0x0100020B [149.904999 -220.113998 6.005500] -0.721245 0.000000 0.000000 -0.692680 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7010003F, 4179757, 0x0100020F, 150.672, -227.955, 6.0055, -0.988945, 0, 0, -0.148282,  True, '2005-02-09 10:00:00'); /* Infected Killer Wasp */
/* @teleloc 0x0100020F [150.671997 -227.955002 6.005500] -0.988945 0.000000 0.000000 -0.148282 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70100040, 4179757, 0x0100020F, 149.759, -227.716, 6.0055, -0.992147, 0, 0, -0.12508,  True, '2005-02-09 10:00:00'); /* Infected Killer Wasp */
/* @teleloc 0x0100020F [149.759003 -227.716003 6.005500] -0.992147 0.000000 0.000000 -0.125080 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70100041, 31024, 0x01000216, 156.984, -151.71, 6.0055, -0.785167, 0, 0, -0.619284,  True, '2005-02-09 10:00:00'); /* Mudwort Thrungus */
/* @teleloc 0x01000216 [156.983994 -151.710007 6.005500] -0.785167 0.000000 0.000000 -0.619284 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70100042, 31024, 0x01000216, 157.495, -150.116, 6.0055, -0.607036, 0, 0, -0.794675,  True, '2005-02-09 10:00:00'); /* Mudwort Thrungus */
/* @teleloc 0x01000216 [157.494995 -150.115997 6.005500] -0.607036 0.000000 0.000000 -0.794675 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70100043, 31024, 0x01000224, 180.43, -159.606, 6.0055, -0.998232, 0, 0, 0.059446,  True, '2005-02-09 10:00:00'); /* Mudwort Thrungus */
/* @teleloc 0x01000224 [180.429993 -159.606003 6.005500] -0.998232 0.000000 0.000000 0.059446 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70100044, 31024, 0x01000224, 179.495, -157.768, 6.0055, -0.999084, 0, 0, -0.042786,  True, '2005-02-09 10:00:00'); /* Mudwort Thrungus */
/* @teleloc 0x01000224 [179.494995 -157.768005 6.005500] -0.999084 0.000000 0.000000 -0.042786 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70100045, 2348257, 0x01000226, 190.018, -139.988, 6.0055, 0.475732, 0, 0, 0.87959,  True, '2005-02-09 10:00:00'); /* Infected Olthoi Warrior */
/* @teleloc 0x01000226 [190.018005 -139.988007 6.005500] 0.475732 0.000000 0.000000 0.879590 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70100046, 2348257, 0x01000226, 191.81, -138.816, 6.0055, 0.475732, 0, 0, 0.87959,  True, '2005-02-09 10:00:00'); /* Infected Olthoi Warrior */
/* @teleloc 0x01000226 [191.809998 -138.815994 6.005500] 0.475732 0.000000 0.000000 0.879590 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70100047, 2348257, 0x01000231, 199.364, -148.733, 6.0055, 0.732707, 0, 0, 0.680544,  True, '2005-02-09 10:00:00'); /* Infected Olthoi Warrior */
/* @teleloc 0x01000231 [199.363998 -148.733002 6.005500] 0.732707 0.000000 0.000000 0.680544 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70100048, 31024, 0x01000231, 199.957, -152.151, 6.0055, 0.547139, 0, 0, 0.837042,  True, '2005-02-09 10:00:00'); /* Mudwort Thrungus */
/* @teleloc 0x01000231 [199.957001 -152.151001 6.005500] 0.547139 0.000000 0.000000 0.837042 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70100049, 4179757, 0x01000231, 202.742, -150.143, 6.0055, 0.742822, 0, 0, 0.669489,  True, '2005-02-09 10:00:00'); /* Infected Killer Wasp */
/* @teleloc 0x01000231 [202.742004 -150.143005 6.005500] 0.742822 0.000000 0.000000 0.669489 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7010004A, 2348257, 0x01000239, 4179760, -140, 6.0055, 0.561168, 0, 0, 0.827702,  True, '2005-02-09 10:00:00'); /* Infected Olthoi Warrior */
/* @teleloc 0x01000239 [4179760.000000 -140.000000 6.005500] 0.561168 0.000000 0.000000 0.827702 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7010004B, 31024, 0x0100023E, 208.517, -160.765, 6.0055, -0.783494, 0, 0, -0.621399,  True, '2005-02-09 10:00:00'); /* Mudwort Thrungus */
/* @teleloc 0x0100023E [208.516998 -160.764999 6.005500] -0.783494 0.000000 0.000000 -0.621399 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7010004C, 31024, 0x0100023E, 206.861, -159.769, 6.0055, -0.654878, 0, 0, -0.755734,  True, '2005-02-09 10:00:00'); /* Mudwort Thrungus */
/* @teleloc 0x0100023E [206.860992 -159.768997 6.005500] -0.654878 0.000000 0.000000 -0.755734 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7010004D, 2348257, 0x01000242, 220.714, -141.451, 6.0055, 0.354578, 0, 0, 0.935026,  True, '2005-02-09 10:00:00'); /* Infected Olthoi Warrior */
/* @teleloc 0x01000242 [220.714005 -141.451004 6.005500] 0.354578 0.000000 0.000000 0.935026 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7010004E, 2348257, 0x01000242, 221.012, -139.763, 6.0055, 0.533271, 0, 0, 0.845944,  True, '2005-02-09 10:00:00'); /* Infected Olthoi Warrior */
/* @teleloc 0x01000242 [221.011993 -139.763000 6.005500] 0.533271 0.000000 0.000000 0.845944 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7010004F, 4179757, 0x01000244, 221.126, -149.459, 6.0055, 0.763589, 0, 0, 0.645703,  True, '2005-02-09 10:00:00'); /* Infected Killer Wasp */
/* @teleloc 0x01000244 [221.126007 -149.459000 6.005500] 0.763589 0.000000 0.000000 0.645703 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70100050, 31024, 0x01000244, 220.141, -150.627, 6.0055, 0.690353, 0, 0, 0.723473,  True, '2005-02-09 10:00:00'); /* Mudwort Thrungus */
/* @teleloc 0x01000244 [220.141006 -150.626999 6.005500] 0.690353 0.000000 0.000000 0.723473 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70100051, 31024, 0x01000244, 219.499, -148.865, 6.0055, 0.705182, 0, 0, 0.709027,  True, '2005-02-09 10:00:00'); /* Mudwort Thrungus */
/* @teleloc 0x01000244 [219.498993 -148.865005 6.005500] 0.705182 0.000000 0.000000 0.709027 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70100052, 858357, 0x0100024C, 51.457, -0.253133, 12.0077, -0.747858, 0, 0, 0.663858,  True, '2005-02-09 10:00:00'); /* Spore Thrungus */
/* @teleloc 0x0100024C [51.457001 -0.253133 12.007700] -0.747858 0.000000 0.000000 0.663858 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70100053, 858357, 0x0100024E, 53.0258, -1.25674, 12.0077, -0.697028, 0, 0, 0.717044,  True, '2005-02-09 10:00:00'); /* Spore Thrungus */
/* @teleloc 0x0100024E [53.025799 -1.256740 12.007700] -0.697028 0.000000 0.000000 0.717044 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70100054, 858357, 0x0100025C, 150.738, -241.216, 12.0077, -0.0292, 0, 0, 0.999574,  True, '2005-02-09 10:00:00'); /* Spore Thrungus */
/* @teleloc 0x0100025C [150.738007 -241.216003 12.007700] -0.029200 0.000000 0.000000 0.999574 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70100055, 858357, 0x0100025C, 148.44, -239.017, 12.0077, -0.049065, 0, 0, 0.998796,  True, '2005-02-09 10:00:00'); /* Spore Thrungus */
/* @teleloc 0x0100025C [148.440002 -239.016998 12.007700] -0.049065 0.000000 0.000000 0.998796 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70100056, 4179757, 0x01000264, 2348260, -89.9636, 12.0055, 0.714421, 0, 0, -0.699716,  True, '2005-02-09 10:00:00'); /* Infected Killer Wasp */
/* @teleloc 0x01000264 [2348260.000000 -89.963600 12.005500] 0.714421 0.000000 0.000000 -0.699716 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70100059, 31024, 0x01000269, 217.388, -128.408, 12.0055, 0.812528, 0, 0, -0.582923,  True, '2005-02-09 10:00:00'); /* Mudwort Thrungus */
/* @teleloc 0x01000269 [217.388000 -128.408005 12.005500] 0.812528 0.000000 0.000000 -0.582923 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7010005A, 31024, 0x01000269, 217.225, -131.038, 12.0055, 0.867529, 0, 0, -0.497387,  True, '2005-02-09 10:00:00'); /* Mudwort Thrungus */
/* @teleloc 0x01000269 [217.225006 -131.037994 12.005500] 0.867529 0.000000 0.000000 -0.497387 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7010005B, 31024, 0x01000269, 216.252, -130.121, 12.0055, 0.817433, 0, 0, -0.576024,  True, '2005-02-09 10:00:00'); /* Mudwort Thrungus */
/* @teleloc 0x01000269 [216.251999 -130.121002 12.005500] 0.817433 0.000000 0.000000 -0.576024 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7010005C, 4179757, 0x0100026A, 230.075, -70.9484, 12.0066, 0.054103, 0, 0, 0.998535,  True, '2005-02-09 10:00:00'); /* Infected Killer Wasp */
/* @teleloc 0x0100026A [230.074997 -70.948402 12.006600] 0.054103 0.000000 0.000000 0.998535 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7010005D, 4179757, 0x0100026A, 228.696, -73.0938, 12.0055, 0.062422, 0, 0, 0.99805,  True, '2005-02-09 10:00:00'); /* Infected Killer Wasp */
/* @teleloc 0x0100026A [228.695999 -73.093803 12.005500] 0.062422 0.000000 0.000000 0.998050 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7010005E, 4179757, 0x0100026A, 233.291, -73.9324, 12.0055, -0.084186, 0, 0, 0.99645,  True, '2005-02-09 10:00:00'); /* Infected Killer Wasp */
/* @teleloc 0x0100026A [233.291000 -73.932404 12.005500] -0.084186 0.000000 0.000000 0.996450 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70100060, 31024, 0x0100026C, 231.568, -91.2767, 12.0055, 0.126473, 0, 0, -0.99197,  True, '2005-02-09 10:00:00'); /* Mudwort Thrungus */
/* @teleloc 0x0100026C [231.567993 -91.276703 12.005500] 0.126473 0.000000 0.000000 -0.991970 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70100061, 31024, 0x0100026C, 226.977, -91.2706, 12.0055, -0.275949, 0, 0, -0.961172,  True, '2005-02-09 10:00:00'); /* Mudwort Thrungus */
/* @teleloc 0x0100026C [226.977005 -91.270599 12.005500] -0.275949 0.000000 0.000000 -0.961172 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70100062, 31024, 0x0100026C, 227.48, -88.1371, 12.0055, -0.079493, 0, 0, -0.996835,  True, '2005-02-09 10:00:00'); /* Mudwort Thrungus */
/* @teleloc 0x0100026C [227.479996 -88.137100 12.005500] -0.079493 0.000000 0.000000 -0.996835 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70100063, 31024, 0x0100026C, 230.776, -88.0993, 12.0055, -0.01235, 0, 0, -0.999924,  True, '2005-02-09 10:00:00'); /* Mudwort Thrungus */
/* @teleloc 0x0100026C [230.776001 -88.099297 12.005500] -0.012350 0.000000 0.000000 -0.999924 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70100064, 2348257, 0x0100026E, 228.887, -107.514, 12.0055, 0.042719, 0, 0, -0.999087,  True, '2005-02-09 10:00:00'); /* Infected Olthoi Warrior */
/* @teleloc 0x0100026E [228.886993 -107.514000 12.005500] 0.042719 0.000000 0.000000 -0.999087 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70100065, 2348257, 0x0100026E, 231.48, -108.229, 12.0055, 0.057088, 0, 0, -0.998369,  True, '2005-02-09 10:00:00'); /* Infected Olthoi Warrior */
/* @teleloc 0x0100026E [231.479996 -108.228996 12.005500] 0.057088 0.000000 0.000000 -0.998369 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70100066, 4179757, 0x0100027E, 250, -89.1662, 12.0055, -0.684709, 0, 0, -0.728817,  True, '2005-02-09 10:00:00'); /* Infected Killer Wasp */
/* @teleloc 0x0100027E [250.000000 -89.166199 12.005500] -0.684709 0.000000 0.000000 -0.728817 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70100067, 31024, 0x01000282, 249.339, -135.301, 12.055, 0.003306, 0, 0, -0.999995,  True, '2005-02-09 10:00:00'); /* Mudwort Thrungus */
/* @teleloc 0x01000282 [249.339005 -135.300995 12.055000] 0.003306 0.000000 0.000000 -0.999995 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70100068, 31024, 0x01000282, 251.326, -137.781, 12.0055, 0.093342, 0, 0, -0.995634,  True, '2005-02-09 10:00:00'); /* Mudwort Thrungus */
/* @teleloc 0x01000282 [251.326004 -137.781006 12.005500] 0.093342 0.000000 0.000000 -0.995634 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70100069, 31024, 0x01000282, 250.888, -135.467, 12.055, 0.093342, 0, 0, -0.995634,  True, '2005-02-09 10:00:00'); /* Mudwort Thrungus */
/* @teleloc 0x01000282 [250.888000 -135.466995 12.055000] 0.093342 0.000000 0.000000 -0.995634 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7010006A, 2348257, 0x0100028A, 7.25288, -322.598, 18.0093, -0.919907, 0, 0, 0.392136,  True, '2005-02-09 10:00:00'); /* Infected Olthoi Warrior */
/* @teleloc 0x0100028A [7.252880 -322.597992 18.009300] -0.919907 0.000000 0.000000 0.392136 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7010006B, 2348257, 0x0100028A, 7.19056, -319.976, 18.0071, -0.356604, 0, 0, 0.934256,  True, '2005-02-09 10:00:00'); /* Infected Olthoi Warrior */
/* @teleloc 0x0100028A [7.190560 -319.976013 18.007099] -0.356604 0.000000 0.000000 0.934256 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7010006C, 2348257, 0x0100028A, 8.3836, -319.875, 18.0071, -0.11438, 0, 0, 0.993437,  True, '2005-02-09 10:00:00'); /* Infected Olthoi Warrior */
/* @teleloc 0x0100028A [8.383600 -319.875000 18.007099] -0.114380 0.000000 0.000000 0.993437 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7010006D, 4179757, 0x0100028F, 20, -180, 18.0077, 0.962425, 0, 0, -0.271547,  True, '2005-02-09 10:00:00'); /* Infected Killer Wasp */
/* @teleloc 0x0100028F [20.000000 -180.000000 18.007700] 0.962425 0.000000 0.000000 -0.271547 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7010006E, 4179757, 0x01000293, 21.9227, -189.857, 18.0077, -0.89646, 0, 0, 0.443124,  True, '2005-02-09 10:00:00'); /* Infected Killer Wasp */
/* @teleloc 0x01000293 [21.922701 -189.856995 18.007700] -0.896460 0.000000 0.000000 0.443124 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7010006F, 4179757, 0x01000297, 19.0839, -201.172, 18.0754, 0.999787, 0, 0, -0.020626,  True, '2005-02-09 10:00:00'); /* Infected Killer Wasp */
/* @teleloc 0x01000297 [19.083900 -201.171997 18.075399] 0.999787 0.000000 0.000000 -0.020626 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70100071, 31021, 0x010002A2, 21.4843, -311.132, 18.0077, 0.34, 0, 0, -0.940425,  True, '2005-02-09 10:00:00'); /* Puffball Thrungus */
/* @teleloc 0x010002A2 [21.484301 -311.131989 18.007700] 0.340000 0.000000 0.000000 -0.940425 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70100072, 31021, 0x010002A2, 17.9786, -310.325, 18.0077, 0.304912, 0, 0, -0.95238,  True, '2005-02-09 10:00:00'); /* Puffball Thrungus */
/* @teleloc 0x010002A2 [17.978600 -310.325012 18.007700] 0.304912 0.000000 0.000000 -0.952380 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70100073, 2348257, 0x010002A3, 19.003, -321.387, 18.0093, 0.836459, 0, 0, -0.54803,  True, '2005-02-09 10:00:00'); /* Infected Olthoi Warrior */
/* @teleloc 0x010002A3 [19.003000 -321.386993 18.009300] 0.836459 0.000000 0.000000 -0.548030 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70100075, 2348257, 0x010002A5, 30.2736, -151.062, 18.0093, -0.677403, 0, 0, 0.735612,  True, '2005-02-09 10:00:00'); /* Infected Olthoi Warrior */
/* @teleloc 0x010002A5 [30.273600 -151.061996 18.009300] -0.677403 0.000000 0.000000 0.735612 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70100076, 2348257, 0x010002A5, 30.6922, -148.192, 18.0093, -0.758961, 0, 0, 0.651137,  True, '2005-02-09 10:00:00'); /* Infected Olthoi Warrior */
/* @teleloc 0x010002A5 [30.692200 -148.192001 18.009300] -0.758961 0.000000 0.000000 0.651137 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70100077, 4179757, 0x010002B0, 33.8619, -190.617, 18.055, 0.963982, 0, 0, 0.265968,  True, '2005-02-09 10:00:00'); /* Infected Killer Wasp */
/* @teleloc 0x010002B0 [33.861900 -190.617004 18.055000] 0.963982 0.000000 0.000000 0.265968 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70100078, 31021, 0x010002BF, 29.2729, -218.835, 18.0077, 1, 0, 0, -0.000561,  True, '2005-02-09 10:00:00'); /* Puffball Thrungus */
/* @teleloc 0x010002BF [29.272900 -218.835007 18.007700] 1.000000 0.000000 0.000000 -0.000561 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70100079, 31021, 0x010002BF, 30.3645, -220.382, 18.0077, 0.993431, 0, 0, 0.114435,  True, '2005-02-09 10:00:00'); /* Puffball Thrungus */
/* @teleloc 0x010002BF [30.364500 -220.382004 18.007700] 0.993431 0.000000 0.000000 0.114435 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7010007A, 31021, 0x010002BF, 29.5037, -221.77, 18.0077, 0.999947, 0, 0, -0.010314,  True, '2005-02-09 10:00:00'); /* Puffball Thrungus */
/* @teleloc 0x010002BF [29.503700 -221.770004 18.007700] 0.999947 0.000000 0.000000 -0.010314 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7010007B, 2348257, 0x010002C4, 27.4379, -322.306, 18.0093, 0.829366, 0, 0, -0.558706,  True, '2005-02-09 10:00:00'); /* Infected Olthoi Warrior */
/* @teleloc 0x010002C4 [27.437901 -322.306000 18.009300] 0.829366 0.000000 0.000000 -0.558706 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7010007C, 2348257, 0x010002C4, 26.0182, -319.61, 18.0093, 0.734612, 0, 0, -0.678488,  True, '2005-02-09 10:00:00'); /* Infected Olthoi Warrior */
/* @teleloc 0x010002C4 [26.018200 -319.609985 18.009300] 0.734612 0.000000 0.000000 -0.678488 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7010007D, 31021, 0x010002D3, 39.2227, -108.331, 18.0077, 0.979978, 0, 0, -0.199106,  True, '2005-02-09 10:00:00'); /* Puffball Thrungus */
/* @teleloc 0x010002D3 [39.222698 -108.331001 18.007700] 0.979978 0.000000 0.000000 -0.199106 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7010007E, 31021, 0x010002D5, 38.6178, -105.49, 18.055, 0.954939, 0, 0, -0.296802,  True, '2005-02-09 10:00:00'); /* Puffball Thrungus */
/* @teleloc 0x010002D5 [38.617802 -105.489998 18.055000] 0.954939 0.000000 0.000000 -0.296802 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7010007F, 31021, 0x010002D6, 38.8692, -148.728, 18.0077, -0.753312, 0, 0, 0.657664,  True, '2005-02-09 10:00:00'); /* Puffball Thrungus */
/* @teleloc 0x010002D6 [38.869202 -148.727997 18.007700] -0.753312 0.000000 0.000000 0.657664 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70100080, 31021, 0x010002D6, 39.6712, -151.157, 18.0077, -0.718722, 0, 0, 0.695298,  True, '2005-02-09 10:00:00'); /* Puffball Thrungus */
/* @teleloc 0x010002D6 [39.671200 -151.156998 18.007700] -0.718722 0.000000 0.000000 0.695298 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70100081, 31021, 0x010002D6, 40.8825, -149.025, 18.0077, -0.774102, 0, 0, 0.633061,  True, '2005-02-09 10:00:00'); /* Puffball Thrungus */
/* @teleloc 0x010002D6 [40.882500 -149.024994 18.007700] -0.774102 0.000000 0.000000 0.633061 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70100082, 4179757, 0x010002DE, 38.848, -201.673, 18.0077, 0.936365, 0, 0, 0.351029,  True, '2005-02-09 10:00:00'); /* Infected Killer Wasp */
/* @teleloc 0x010002DE [38.848000 -201.673004 18.007700] 0.936365 0.000000 0.000000 0.351029 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70100083, 4179757, 0x010002ED, 39.8293, -247.377, 18.0077, -0.999885, 0, 0, 0.015134,  True, '2005-02-09 10:00:00'); /* Infected Killer Wasp */
/* @teleloc 0x010002ED [39.829300 -247.376999 18.007700] -0.999885 0.000000 0.000000 0.015134 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70100084, 2348257, 0x010002F1, 41.2236, -256.15, 18.055, 0.999932, 0, 0, 0.011696,  True, '2005-02-09 10:00:00'); /* Infected Olthoi Warrior */
/* @teleloc 0x010002F1 [41.223598 -256.149994 18.055000] 0.999932 0.000000 0.000000 0.011696 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70100085, 31021, 0x010002F9, 40.744, -280.422, 18.0077, 0.998351, 0, 0, 0.057414,  True, '2005-02-09 10:00:00'); /* Puffball Thrungus */
/* @teleloc 0x010002F9 [40.743999 -280.421997 18.007700] 0.998351 0.000000 0.000000 0.057414 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70100086, 31021, 0x010002F9, 41.6655, -281.533, 18.0077, 0.999444, 0, 0, -0.033356,  True, '2005-02-09 10:00:00'); /* Puffball Thrungus */
/* @teleloc 0x010002F9 [41.665501 -281.532990 18.007700] 0.999444 0.000000 0.000000 -0.033356 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70100087, 31021, 0x010002F9, 39.2048, -281.543, 18.0077, 0.998448, 0, 0, 0.055697,  True, '2005-02-09 10:00:00'); /* Puffball Thrungus */
/* @teleloc 0x010002F9 [39.204800 -281.542999 18.007700] 0.998448 0.000000 0.000000 0.055697 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70100088, 31021, 0x01000300, 42.3468, -319.212, 18.0077, 0.738277, 0, 0, -0.674498,  True, '2005-02-09 10:00:00'); /* Puffball Thrungus */
/* @teleloc 0x01000300 [42.346802 -319.212006 18.007700] 0.738277 0.000000 0.000000 -0.674498 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70100089, 31021, 0x01000300, 42.6002, -320.883, 18.0077, 0.625453, 0, 0, -0.780262,  True, '2005-02-09 10:00:00'); /* Puffball Thrungus */
/* @teleloc 0x01000300 [42.600201 -320.882996 18.007700] 0.625453 0.000000 0.000000 -0.780262 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7010008A, 31021, 0x01000300, 40.3581, -320.383, 18.0077, 0.700224, 0, 0, -0.713923,  True, '2005-02-09 10:00:00'); /* Puffball Thrungus */
/* @teleloc 0x01000300 [40.358101 -320.382996 18.007700] 0.700224 0.000000 0.000000 -0.713923 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7010008B, 31021, 0x01000300, 40.437, -318.976, 18.0077, 0.717852, 0, 0, -0.696196,  True, '2005-02-09 10:00:00'); /* Puffball Thrungus */
/* @teleloc 0x01000300 [40.437000 -318.976013 18.007700] 0.717852 0.000000 0.000000 -0.696196 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7010008C, 858357, 0x01000302, 49.826, -27.056, 18.0077, -0.999204, 0, 0, -0.039905,  True, '2005-02-09 10:00:00'); /* Spore Thrungus */
/* @teleloc 0x01000302 [49.826000 -27.056000 18.007700] -0.999204 0.000000 0.000000 -0.039905 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7010008D, 858357, 0x01000302, 51.7042, -28.2185, 18.0077, -0.999425, 0, 0, -0.033893,  True, '2005-02-09 10:00:00'); /* Spore Thrungus */
/* @teleloc 0x01000302 [51.704201 -28.218500 18.007700] -0.999425 0.000000 0.000000 -0.033893 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7010008E, 31021, 0x01000302, 49.3703, -29.1678, 18.0077, -0.997622, 0, 0, 0.068924,  True, '2005-02-09 10:00:00'); /* Puffball Thrungus */
/* @teleloc 0x01000302 [49.370300 -29.167801 18.007700] -0.997622 0.000000 0.000000 0.068924 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7010008F, 4179757, 0x01000306, 49.5519, -61.9122, 18.0077, 0.937319, 0, 0, -0.348474,  True, '2005-02-09 10:00:00'); /* Infected Killer Wasp */
/* @teleloc 0x01000306 [49.551899 -61.912201 18.007700] 0.937319 0.000000 0.000000 -0.348474 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70100090, 31021, 0x0100030E, 50, -76.9095, 18.0077, 1, 0, 0, 0,  True, '2005-02-09 10:00:00'); /* Puffball Thrungus */
/* @teleloc 0x0100030E [50.000000 -76.909500 18.007700] 1.000000 0.000000 0.000000 0.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70100091, 31021, 0x0100030E, 50, -78.661, 18.0077, 1, 0, 0, 0,  True, '2005-02-09 10:00:00'); /* Puffball Thrungus */
/* @teleloc 0x0100030E [50.000000 -78.661003 18.007700] 1.000000 0.000000 0.000000 0.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70100092, 4179757, 0x01000329, 47.1805, -231.398, 18.055, 0.855325, 0, 0, 0.518092,  True, '2005-02-09 10:00:00'); /* Infected Killer Wasp */
/* @teleloc 0x01000329 [47.180500 -231.397995 18.055000] 0.855325 0.000000 0.000000 0.518092 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70100093, 4179757, 0x01000331, 50.6867, -253.115, 18.0077, -0.984304, 0, 0, -0.17648,  True, '2005-02-09 10:00:00'); /* Infected Killer Wasp */
/* @teleloc 0x01000331 [50.686699 -253.115005 18.007700] -0.984304 0.000000 0.000000 -0.176480 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70100094, 4179757, 0x01000331, 49.207, -247.827, 18.0077, 0.984727, 0, 0, 0.174108,  True, '2005-02-09 10:00:00'); /* Infected Killer Wasp */
/* @teleloc 0x01000331 [49.207001 -247.826996 18.007700] 0.984727 0.000000 0.000000 0.174108 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70100095, 31021, 0x0100033F, 50, -280, 18.0077, 1, 0, 0, 0,  True, '2005-02-09 10:00:00'); /* Puffball Thrungus */
/* @teleloc 0x0100033F [50.000000 -280.000000 18.007700] 1.000000 0.000000 0.000000 0.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70100096, 31021, 0x0100033F, 50.7343, -281.461, 18.0077, 0.998107, 0, 0, -0.0615,  True, '2005-02-09 10:00:00'); /* Puffball Thrungus */
/* @teleloc 0x0100033F [50.734299 -281.460999 18.007700] 0.998107 0.000000 0.000000 -0.061500 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70100097, 31021, 0x0100033F, 48.0287, -281.376, 18.0077, 0.997149, 0, 0, 0.07546,  True, '2005-02-09 10:00:00'); /* Puffball Thrungus */
/* @teleloc 0x0100033F [48.028702 -281.376007 18.007700] 0.997149 0.000000 0.000000 0.075460 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70100099, 858357, 0x0100034B, 48.654, -315.357, 18.055, 0.999454, 0, 0, 0.033028,  True, '2005-02-09 10:00:00'); /* Spore Thrungus */
/* @teleloc 0x0100034B [48.653999 -315.356995 18.055000] 0.999454 0.000000 0.000000 0.033028 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7010009A, 858357, 0x0100034B, 50.549, -315.334, 18.055, 0.999305, 0, 0, -0.03728,  True, '2005-02-09 10:00:00'); /* Spore Thrungus */
/* @teleloc 0x0100034B [50.549000 -315.334015 18.055000] 0.999305 0.000000 0.000000 -0.037280 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7010009B, 31021, 0x01000351, 61.3807, -57.285, 18.0077, 0.999975, 0, 0, 0.007106,  True, '2005-02-09 10:00:00'); /* Puffball Thrungus */
/* @teleloc 0x01000351 [61.380699 -57.285000 18.007700] 0.999975 0.000000 0.000000 0.007106 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7010009C, 31021, 0x01000351, 58.691, -56.6484, 18.0077, 0.998387, 0, 0, 0.056776,  True, '2005-02-09 10:00:00'); /* Puffball Thrungus */
/* @teleloc 0x01000351 [58.691002 -56.648399 18.007700] 0.998387 0.000000 0.000000 0.056776 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7010009D, 4179757, 0x0100035B, 58.788, -80.8535, 18.055, -0.997764, 0, 0, -0.06683,  True, '2005-02-09 10:00:00'); /* Infected Killer Wasp */
/* @teleloc 0x0100035B [58.787998 -80.853500 18.055000] -0.997764 0.000000 0.000000 -0.066830 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7010009E, 4179757, 0x0100035B, 61.0609, -79.147, 18.0077, 0.999902, 0, 0, -0.014026,  True, '2005-02-09 10:00:00'); /* Infected Killer Wasp */
/* @teleloc 0x0100035B [61.060902 -79.147003 18.007700] 0.999902 0.000000 0.000000 -0.014026 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7010009F, 31021, 0x01000361, 60, -100.931, 18.0077, 1, 0, 0, 0,  True, '2005-02-09 10:00:00'); /* Puffball Thrungus */
/* @teleloc 0x01000361 [60.000000 -100.931000 18.007700] 1.000000 0.000000 0.000000 0.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701000A0, 31021, 0x01000361, 62.3275, -100.846, 18.0754, 0.999967, 0, 0, -0.008093,  True, '2005-02-09 10:00:00'); /* Puffball Thrungus */
/* @teleloc 0x01000361 [62.327499 -100.846001 18.075399] 0.999967 0.000000 0.000000 -0.008093 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701000A1, 31021, 0x01000369, 60, -120, 18.0077, 1, 0, 0, 0,  True, '2005-02-09 10:00:00'); /* Puffball Thrungus */
/* @teleloc 0x01000369 [60.000000 -120.000000 18.007700] 1.000000 0.000000 0.000000 0.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701000A2, 31021, 0x01000372, 61.6826, -146.321, 18.0077, 0.99994, 0, 0, 0.010949,  True, '2005-02-09 10:00:00'); /* Puffball Thrungus */
/* @teleloc 0x01000372 [61.682598 -146.320999 18.007700] 0.999940 0.000000 0.000000 0.010949 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701000A3, 31021, 0x01000372, 58.6954, -146.668, 18.0077, 0.993469, 0, 0, 0.114101,  True, '2005-02-09 10:00:00'); /* Puffball Thrungus */
/* @teleloc 0x01000372 [58.695400 -146.667999 18.007700] 0.993469 0.000000 0.000000 0.114101 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701000A4, 2348257, 0x01000372, 60, -151.546, 18.0093, 1, 0, 0, 0,  True, '2005-02-09 10:00:00'); /* Infected Olthoi Warrior */
/* @teleloc 0x01000372 [60.000000 -151.546005 18.009300] 1.000000 0.000000 0.000000 0.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701000A5, 4179757, 0x0100037A, 60, -190, 18.0077, 0.974794, 0, 0, -0.223106,  True, '2005-02-09 10:00:00'); /* Infected Killer Wasp */
/* @teleloc 0x0100037A [60.000000 -190.000000 18.007700] 0.974794 0.000000 0.000000 -0.223106 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701000A6, 4179757, 0x0100037A, 59.2585, -191.535, 18.0077, 0.974794, 0, 0, -0.223106,  True, '2005-02-09 10:00:00'); /* Infected Killer Wasp */
/* @teleloc 0x0100037A [59.258499 -191.535004 18.007700] 0.974794 0.000000 0.000000 -0.223106 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701000A7, 31021, 0x01000389, 56.4934, -240.369, 18.0077, -0.32191, 0, 0, -0.94677,  True, '2005-02-09 10:00:00'); /* Puffball Thrungus */
/* @teleloc 0x01000389 [56.493401 -240.369003 18.007700] -0.321910 0.000000 0.000000 -0.946770 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701000A8, 31021, 0x01000389, 57.5508, -238.994, 18.0077, -0.32191, 0, 0, -0.94677,  True, '2005-02-09 10:00:00'); /* Puffball Thrungus */
/* @teleloc 0x01000389 [57.550800 -238.994003 18.007700] -0.321910 0.000000 0.000000 -0.946770 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701000A9, 31021, 0x01000389, 63.1575, -239.873, 18.0077, 0.411657, 0, 0, -0.911339,  True, '2005-02-09 10:00:00'); /* Puffball Thrungus */
/* @teleloc 0x01000389 [63.157501 -239.873001 18.007700] 0.411657 0.000000 0.000000 -0.911339 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701000AA, 31021, 0x01000389, 61.9891, -238.844, 18.0077, 0.411657, 0, 0, -0.911339,  True, '2005-02-09 10:00:00'); /* Puffball Thrungus */
/* @teleloc 0x01000389 [61.989101 -238.843994 18.007700] 0.411657 0.000000 0.000000 -0.911339 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701000AB, 4179757, 0x01000396, 69.2232, -61.2275, 18.0077, -0.862331, 0, 0, -0.506346,  True, '2005-02-09 10:00:00'); /* Infected Killer Wasp */
/* @teleloc 0x01000396 [69.223198 -61.227501 18.007700] -0.862331 0.000000 0.000000 -0.506346 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701000AC, 31021, 0x0100039E, 70.3284, -82.2018, 18.0077, -0.98318, 0, 0, -0.18264,  True, '2005-02-09 10:00:00'); /* Puffball Thrungus */
/* @teleloc 0x0100039E [70.328400 -82.201797 18.007700] -0.983180 0.000000 0.000000 -0.182640 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701000AD, 4179757, 0x010003B1, 70, -119.945, 18.0077, 0.997189, 0, 0, 0.074929,  True, '2005-02-09 10:00:00'); /* Infected Killer Wasp */
/* @teleloc 0x010003B1 [70.000000 -119.945000 18.007700] 0.997189 0.000000 0.000000 0.074929 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701000AE, 4179757, 0x010003B1, 69.7498, -118.29, 18.0077, 0.997189, 0, 0, 0.074929,  True, '2005-02-09 10:00:00'); /* Infected Killer Wasp */
/* @teleloc 0x010003B1 [69.749802 -118.290001 18.007700] 0.997189 0.000000 0.000000 0.074929 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701000AF, 4179757, 0x010003B1, 68.247, -120.123, 18.0077, 0.980067, 0, 0, -0.198669,  True, '2005-02-09 10:00:00'); /* Infected Killer Wasp */
/* @teleloc 0x010003B1 [68.247002 -120.123001 18.007700] 0.980067 0.000000 0.000000 -0.198669 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701000B0, 4179757, 0x010003C3, 71.6689, -209.444, 18.0077, 0.997855, 0, 0, 0.065462,  True, '2005-02-09 10:00:00'); /* Infected Killer Wasp */
/* @teleloc 0x010003C3 [71.668900 -209.444000 18.007700] 0.997855 0.000000 0.000000 0.065462 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701000B1, 4179757, 0x010003C3, 66.4172, -209.191, 18.0077, 0.966511, 0, 0, -0.256625,  True, '2005-02-09 10:00:00'); /* Infected Killer Wasp */
/* @teleloc 0x010003C3 [66.417198 -209.190994 18.007700] 0.966511 0.000000 0.000000 -0.256625 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701000B2, 31021, 0x010003CD, 69.0453, -229.313, 18.0077, 0.997104, 0, 0, 0.076048,  True, '2005-02-09 10:00:00'); /* Puffball Thrungus */
/* @teleloc 0x010003CD [69.045303 -229.313004 18.007700] 0.997104 0.000000 0.000000 0.076048 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701000B3, 31021, 0x010003CD, 71.1926, -231.231, 18.0077, 0.979731, 0, 0, 0.200317,  True, '2005-02-09 10:00:00'); /* Puffball Thrungus */
/* @teleloc 0x010003CD [71.192596 -231.231003 18.007700] 0.979731 0.000000 0.000000 0.200317 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701000B4, 31021, 0x010003D7, 70, -260.78, 18.0077, 1, 0, 0, 0,  True, '2005-02-09 10:00:00'); /* Puffball Thrungus */
/* @teleloc 0x010003D7 [70.000000 -260.779999 18.007700] 1.000000 0.000000 0.000000 0.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701000B5, 31021, 0x010003D7, 69.4484, -257.587, 18.0077, 0.979709, 0, 0, 0.200427,  True, '2005-02-09 10:00:00'); /* Puffball Thrungus */
/* @teleloc 0x010003D7 [69.448402 -257.587006 18.007700] 0.979709 0.000000 0.000000 0.200427 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701000B6, 31021, 0x010003D7, 71.6209, -259.333, 18.0077, 0.998536, 0, 0, 0.054084,  True, '2005-02-09 10:00:00'); /* Puffball Thrungus */
/* @teleloc 0x010003D7 [71.620903 -259.333008 18.007700] 0.998536 0.000000 0.000000 0.054084 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701000B7, 4179757, 0x010003DF, 77.375, -81.4871, 18.055, -0.740942, 0, 0, -0.671569,  True, '2005-02-09 10:00:00'); /* Infected Killer Wasp */
/* @teleloc 0x010003DF [77.375000 -81.487099 18.055000] -0.740942 0.000000 0.000000 -0.671569 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701000B8, 4179757, 0x010003DF, 78.2641, -79.1587, 18.0077, -0.669973, 0, 0, -0.742385,  True, '2005-02-09 10:00:00'); /* Infected Killer Wasp */
/* @teleloc 0x010003DF [78.264099 -79.158699 18.007700] -0.669973 0.000000 0.000000 -0.742385 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701000B9, 31021, 0x010003F0, 79.6224, -167.864, 18.0077, -0.999959, 0, 0, -0.009081,  True, '2005-02-09 10:00:00'); /* Puffball Thrungus */
/* @teleloc 0x010003F0 [79.622398 -167.863998 18.007700] -0.999959 0.000000 0.000000 -0.009081 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701000BA, 31021, 0x010003F0, 81.2625, -169.861, 18.0077, -0.998592, 0, 0, -0.053039,  True, '2005-02-09 10:00:00'); /* Puffball Thrungus */
/* @teleloc 0x010003F0 [81.262497 -169.860992 18.007700] -0.998592 0.000000 0.000000 -0.053039 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701000BB, 31021, 0x010003F0, 78.474, -169.848, 18.0077, -0.998419, 0, 0, -0.056212,  True, '2005-02-09 10:00:00'); /* Puffball Thrungus */
/* @teleloc 0x010003F0 [78.473999 -169.848007 18.007700] -0.998419 0.000000 0.000000 -0.056212 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701000BC, 4179757, 0x010003FC, 80.6716, -201.095, 18.0077, 0.962425, 0, 0, 0.271547,  True, '2005-02-09 10:00:00'); /* Infected Killer Wasp */
/* @teleloc 0x010003FC [80.671600 -201.095001 18.007700] 0.962425 0.000000 0.000000 0.271547 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701000BD, 4179757, 0x010003FC, 78.4137, -199.701, 18.0077, 0.999972, 0, 0, -0.007512,  True, '2005-02-09 10:00:00'); /* Infected Killer Wasp */
/* @teleloc 0x010003FC [78.413696 -199.701004 18.007700] 0.999972 0.000000 0.000000 -0.007512 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701000BE, 31021, 0x01000419, 81.0337, -286.73, 18.055, 0.987679, 0, 0, 0.156492,  True, '2005-02-09 10:00:00'); /* Puffball Thrungus */
/* @teleloc 0x01000419 [81.033699 -286.730011 18.055000] 0.987679 0.000000 0.000000 0.156492 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701000BF, 31021, 0x01000419, 78.7735, -286.706, 18.055, 0.99984, 0, 0, -0.017861,  True, '2005-02-09 10:00:00'); /* Puffball Thrungus */
/* @teleloc 0x01000419 [78.773499 -286.705994 18.055000] 0.999840 0.000000 0.000000 -0.017861 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701000C0, 2348257, 0x0100041E, 89.055, -290.021, 18.0093, -0.712037, 0, 0, -0.702142,  True, '2005-02-09 10:00:00'); /* Infected Olthoi Warrior */
/* @teleloc 0x0100041E [89.055000 -290.020996 18.009300] -0.712037 0.000000 0.000000 -0.702142 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701000C1, 2348257, 0x0100041E, 87.6912, -291.752, 18.0093, -0.756131, 0, 0, -0.654421,  True, '2005-02-09 10:00:00'); /* Infected Olthoi Warrior */
/* @teleloc 0x0100041E [87.691200 -291.752014 18.009300] -0.756131 0.000000 0.000000 -0.654421 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701000C2, 2348257, 0x0100041F, 89.8942, -300.724, 18.0071, 0.984727, 0, 0, 0.174108,  True, '2005-02-09 10:00:00'); /* Infected Olthoi Warrior */
/* @teleloc 0x0100041F [89.894203 -300.723999 18.007099] 0.984727 0.000000 0.000000 0.174108 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701000C3, 2348257, 0x0100041F, 87.5425, -300.2, 18.0071, 0.988738, 0, 0, 0.14966,  True, '2005-02-09 10:00:00'); /* Infected Olthoi Warrior */
/* @teleloc 0x0100041F [87.542503 -300.200012 18.007099] 0.988738 0.000000 0.000000 0.149660 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701000C4, 2348257, 0x0100041F, 92.1675, -298.341, 18.0071, 0.830325, 0, 0, 0.55728,  True, '2005-02-09 10:00:00'); /* Infected Olthoi Warrior */
/* @teleloc 0x0100041F [92.167503 -298.341003 18.007099] 0.830325 0.000000 0.000000 0.557280 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701000C5, 858357, 0x0100041F, 91.923, -301.943, 18.0077, -0.979566, 0, 0, -0.201122,  True, '2005-02-09 10:00:00'); /* Spore Thrungus */
/* @teleloc 0x0100041F [91.922997 -301.942993 18.007700] -0.979566 0.000000 0.000000 -0.201122 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701000C6, 858357, 0x0100041F, 91.223, -303.15, 18.0077, -0.961743, 0, 0, -0.273955,  True, '2005-02-09 10:00:00'); /* Spore Thrungus */
/* @teleloc 0x0100041F [91.223000 -303.149994 18.007700] -0.961743 0.000000 0.000000 -0.273955 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701000C7, 858357, 0x0100041F, 93.5057, -302.892, 18.0077, -0.973314, 0, 0, -0.229476,  True, '2005-02-09 10:00:00'); /* Spore Thrungus */
/* @teleloc 0x0100041F [93.505699 -302.891998 18.007700] -0.973314 0.000000 0.000000 -0.229476 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701000C8, 2348257, 0x01000420, 100.882, -141.09, 18.0093, -0.046228, 0, 0, -0.998931,  True, '2005-02-09 10:00:00'); /* Infected Olthoi Warrior */
/* @teleloc 0x01000420 [100.882004 -141.089996 18.009300] -0.046228 0.000000 0.000000 -0.998931 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701000C9, 31021, 0x01000421, 101.574, -146.298, 18.0077, 0.05373, 0, 0, -0.998555,  True, '2005-02-09 10:00:00'); /* Puffball Thrungus */
/* @teleloc 0x01000421 [101.573997 -146.298004 18.007700] 0.053730 0.000000 0.000000 -0.998555 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701000CA, 31021, 0x01000421, 100.34, -145.225, 18.055, 0.10357, 0, 0, -0.994622,  True, '2005-02-09 10:00:00'); /* Puffball Thrungus */
/* @teleloc 0x01000421 [100.339996 -145.225006 18.055000] 0.103570 0.000000 0.000000 -0.994622 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701000CB, 31021, 0x01000423, 101.324, -172.245, 18.0077, -0.721703, 0, 0, 0.692203,  True, '2005-02-09 10:00:00'); /* Puffball Thrungus */
/* @teleloc 0x01000423 [101.323997 -172.244995 18.007700] -0.721703 0.000000 0.000000 0.692203 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701000CC, 31021, 0x01000423, 102.181, -169.545, 18.0077, -0.759155, 0, 0, 0.650909,  True, '2005-02-09 10:00:00'); /* Puffball Thrungus */
/* @teleloc 0x01000423 [102.181000 -169.544998 18.007700] -0.759155 0.000000 0.000000 0.650909 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701000CD, 31021, 0x01000423, 100.602, -169.789, 18.0077, -0.759155, 0, 0, 0.650909,  True, '2005-02-09 10:00:00'); /* Puffball Thrungus */
/* @teleloc 0x01000423 [100.601997 -169.789001 18.007700] -0.759155 0.000000 0.000000 0.650909 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701000CE, 31021, 0x01000431, 140, -130, 18.0077, 0.04578, 0, 0, -0.998952,  True, '2005-02-09 10:00:00'); /* Puffball Thrungus */
/* @teleloc 0x01000431 [140.000000 -130.000000 18.007700] 0.045780 0.000000 0.000000 -0.998952 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701000CF, 31021, 0x01000431, 138.787, -131.026, 18.0077, 0.170599, 0, 0, -0.985341,  True, '2005-02-09 10:00:00'); /* Puffball Thrungus */
/* @teleloc 0x01000431 [138.787003 -131.026001 18.007700] 0.170599 0.000000 0.000000 -0.985341 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701000D0, 2348257, 0x01000432, 140, -140, 18.0093, -0.518058, 0, 0, -0.855345,  True, '2005-02-09 10:00:00'); /* Infected Olthoi Warrior */
/* @teleloc 0x01000432 [140.000000 -140.000000 18.009300] -0.518058 0.000000 0.000000 -0.855345 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701000D1, 2348257, 0x01000432, 137.904, -141.969, 18.0093, 0.998458, 0, 0, -0.055519,  True, '2005-02-09 10:00:00'); /* Infected Olthoi Warrior */
/* @teleloc 0x01000432 [137.904007 -141.968994 18.009300] 0.998458 0.000000 0.000000 -0.055519 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701000D2, 2348257, 0x01000432, 136.652, -139.518, 18.0093, 0.535083, 0, 0, -0.844799,  True, '2005-02-09 10:00:00'); /* Infected Olthoi Warrior */
/* @teleloc 0x01000432 [136.651993 -139.518005 18.009300] 0.535083 0.000000 0.000000 -0.844799 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701000D3, 31021, 0x01000433, 138.705, -152.122, 18.0077, 0.071781, 0, 0, -0.99742,  True, '2005-02-09 10:00:00'); /* Puffball Thrungus */
/* @teleloc 0x01000433 [138.705002 -152.121994 18.007700] 0.071781 0.000000 0.000000 -0.997420 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701000D4, 31021, 0x01000434, 140.105, -161.036, 18.0077, 0.107656, 0, 0, -0.994188,  True, '2005-02-09 10:00:00'); /* Puffball Thrungus */
/* @teleloc 0x01000434 [140.104996 -161.035995 18.007700] 0.107656 0.000000 0.000000 -0.994188 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701000D5, 31021, 0x01000434, 138.617, -160.015, 18.0077, 0.142468, 0, 0, -0.989799,  True, '2005-02-09 10:00:00'); /* Puffball Thrungus */
/* @teleloc 0x01000434 [138.617004 -160.014999 18.007700] 0.142468 0.000000 0.000000 -0.989799 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701000D6, 31021, 0x01000437, 144.311, -178.448, 18.0077, 0.610482, 0, 0, -0.79203,  True, '2005-02-09 10:00:00'); /* Puffball Thrungus */
/* @teleloc 0x01000437 [144.311005 -178.447998 18.007700] 0.610482 0.000000 0.000000 -0.792030 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701000D7, 31021, 0x01000437, 143.517, -180.831, 18.055, 0.582381, 0, 0, -0.812916,  True, '2005-02-09 10:00:00'); /* Puffball Thrungus */
/* @teleloc 0x01000437 [143.516998 -180.830994 18.055000] 0.582381 0.000000 0.000000 -0.812916 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701000D8, 31021, 0x0100043C, 141.37, -198.789, 18.0077, -0.433434, 0, 0, 0.901185,  True, '2005-02-09 10:00:00'); /* Puffball Thrungus */
/* @teleloc 0x0100043C [141.369995 -198.789001 18.007700] -0.433434 0.000000 0.000000 0.901185 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701000D9, 31021, 0x0100043C, 140.194, -199.913, 18.0077, -0.552289, 0, 0, 0.833653,  True, '2005-02-09 10:00:00'); /* Puffball Thrungus */
/* @teleloc 0x0100043C [140.194000 -199.912994 18.007700] -0.552289 0.000000 0.000000 0.833653 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701000DA, 31021, 0x01000441, 147.01, -141.055, 18.0077, 0.669896, 0, 0, -0.742455,  True, '2005-02-09 10:00:00'); /* Puffball Thrungus */
/* @teleloc 0x01000441 [147.009995 -141.054993 18.007700] 0.669896 0.000000 0.000000 -0.742455 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701000DB, 31021, 0x01000441, 148.743, -139.16, 18.0077, 0.660241, 0, 0, -0.751054,  True, '2005-02-09 10:00:00'); /* Puffball Thrungus */
/* @teleloc 0x01000441 [148.742996 -139.160004 18.007700] 0.660241 0.000000 0.000000 -0.751054 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701000DC, 31021, 0x01000443, 150.068, -161.072, 18.0077, -0.691299, 0, 0, -0.722569,  True, '2005-02-09 10:00:00'); /* Puffball Thrungus */
/* @teleloc 0x01000443 [150.067993 -161.072006 18.007700] -0.691299 0.000000 0.000000 -0.722569 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701000DD, 31021, 0x01000451, 163.653, -140.037, 18.0077, 0.728137, 0, 0, -0.685432,  True, '2005-02-09 10:00:00'); /* Puffball Thrungus */
/* @teleloc 0x01000451 [163.653000 -140.037003 18.007700] 0.728137 0.000000 0.000000 -0.685432 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701000DE, 31021, 0x01000451, 163.61, -138.63, 18.0077, 0.671016, 0, 0, -0.741443,  True, '2005-02-09 10:00:00'); /* Puffball Thrungus */
/* @teleloc 0x01000451 [163.610001 -138.630005 18.007700] 0.671016 0.000000 0.000000 -0.741443 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701000DF,  7253, 0x01000465, 10, -230, 24.005, 1, 0, 0, 0, False, '2005-02-09 10:00:00'); /* Surface Portal */
/* @teleloc 0x01000465 [10.000000 -230.000000 24.004999] 1.000000 0.000000 0.000000 0.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701000E0, 310235757, 0x01000467, 9.48002, -250.991, 24.055, -0.999242, 0, 0, 0.03894, False, '2025-07-22 01:03:54'); /* TwistedBlightGen */
/* @teleloc 0x01000467 [9.480020 -250.990997 24.055000] -0.999242 0.000000 0.000000 0.038940 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701000E1, 3483357, 0x0100012C, 61.205, -222.534, -0.02675, 0.96082, 0, 0, -0.277172, False, '2025-07-22 13:23:23'); /* Blue Glow Mushroom */
/* @teleloc 0x0100012C [61.205002 -222.533997 -0.026750] 0.960820 0.000000 0.000000 -0.277172 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701000E2, 3483357, 0x0100012B, 63.2776, -210.539, -0.02675, 0.999998, 0, 0, 0.001837, False, '2025-07-22 13:23:28'); /* Blue Glow Mushroom */
/* @teleloc 0x0100012B [63.277599 -210.539001 -0.026750] 0.999998 0.000000 0.000000 0.001837 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701000E3, 3483357, 0x0100012B, 63.2776, -210.539, -0.02675, 0.999998, 0, 0, 0.001837, False, '2025-07-22 13:23:29'); /* Blue Glow Mushroom */
/* @teleloc 0x0100012B [63.277599 -210.539001 -0.026750] 0.999998 0.000000 0.000000 0.001837 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701000E4, 3483357, 0x0100011B, 43.8231, -216.68, -0.02675, 0.960328, 0, 0, 0.278873, False, '2025-07-22 13:23:36'); /* Blue Glow Mushroom */
/* @teleloc 0x0100011B [43.823101 -216.679993 -0.026750] 0.960328 0.000000 0.000000 0.278873 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701000E5, 3483357, 0x0100010A, 34.654, -223.363, -0.02675, 0.546421, 0, 0, 0.83751, False, '2025-07-22 13:23:38'); /* Blue Glow Mushroom */
/* @teleloc 0x0100010A [34.653999 -223.363007 -0.026750] 0.546421 0.000000 0.000000 0.837510 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701000E6, 3483357, 0x01000102, 16.9031, -222.198, -0.02675, 0.402852, 0, 0, 0.915265, False, '2025-07-22 13:23:44'); /* Blue Glow Mushroom */
/* @teleloc 0x01000102 [16.903099 -222.197998 -0.026750] 0.402852 0.000000 0.000000 0.915265 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701000E7, 3483357, 0x01000100, 18.149, -197.038, -0.02675, 0.91921, 0, 0, 0.393767, False, '2025-07-22 13:23:49'); /* Blue Glow Mushroom */
/* @teleloc 0x01000100 [18.149000 -197.037994 -0.026750] 0.919210 0.000000 0.000000 0.393767 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701000E8, 3483357, 0x01000100, 18.149, -197.038, -0.02675, 0.91921, 0, 0, 0.393767, False, '2025-07-22 13:23:50'); /* Blue Glow Mushroom */
/* @teleloc 0x01000100 [18.149000 -197.037994 -0.026750] 0.919210 0.000000 0.000000 0.393767 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701000E9, 3483357, 0x01000109, 27.2098, -214.059, -0.02675, -0.44729, 0, 0, 0.894389, False, '2025-07-22 13:23:53'); /* Blue Glow Mushroom */
/* @teleloc 0x01000109 [27.209801 -214.059006 -0.026750] -0.447290 0.000000 0.000000 0.894389 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701000EA, 3483357, 0x01000107, 33.8866, -191.243, -0.02675, -0.994066, 0, 0, 0.108776, False, '2025-07-22 13:23:56'); /* Blue Glow Mushroom */
/* @teleloc 0x01000107 [33.886600 -191.242996 -0.026750] -0.994066 0.000000 0.000000 0.108776 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701000EB, 3483357, 0x01000113, 44.9509, -186.637, -0.02675, -0.975298, 0, 0, -0.220893, False, '2025-07-22 13:23:59'); /* Blue Glow Mushroom */
/* @teleloc 0x01000113 [44.950901 -186.636993 -0.026750] -0.975298 0.000000 0.000000 -0.220893 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701000EC, 3483357, 0x01000114, 42.2945, -203.363, -0.02675, 0.051422, 0, 0, -0.998677, False, '2025-07-22 13:24:02'); /* Blue Glow Mushroom */
/* @teleloc 0x01000114 [42.294498 -203.363007 -0.026750] 0.051422 0.000000 0.000000 -0.998677 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701000ED, 3483357, 0x0100012A, 62.7674, -197.95, -0.02675, 0.941615, 0, 0, -0.336693, False, '2025-07-22 13:24:05'); /* Blue Glow Mushroom */
/* @teleloc 0x0100012A [62.767399 -197.949997 -0.026750] 0.941615 0.000000 0.000000 -0.336693 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701000EE, 3483357, 0x01000124, 46.6371, -207.253, -0.02675, 0.934031, 0, 0, 0.357191, False, '2025-07-22 13:24:09'); /* Blue Glow Mushroom */
/* @teleloc 0x01000124 [46.637100 -207.253006 -0.026750] 0.934031 0.000000 0.000000 0.357191 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701000EF, 3483357, 0x01000123, 45.3429, -203.348, -0.02675, 0.043024, 0, 0, 0.999074, False, '2025-07-22 13:24:13'); /* Blue Glow Mushroom */
/* @teleloc 0x01000123 [45.342899 -203.348007 -0.026750] 0.043024 0.000000 0.000000 0.999074 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701000F0, 3483357, 0x01000123, 53.3629, -195.48, -0.02675, -0.966338, 0, 0, -0.257276, False, '2025-07-22 13:24:19'); /* Blue Glow Mushroom */
/* @teleloc 0x01000123 [53.362900 -195.479996 -0.026750] -0.966338 0.000000 0.000000 -0.257276 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701000F1, 3483357, 0x01000188, 67.1134, -81.5917, 5.97325, -0.590782, 0, 0, -0.806831, False, '2025-07-22 13:24:43'); /* Blue Glow Mushroom */
/* @teleloc 0x01000188 [67.113403 -81.591698 5.973250] -0.590782 0.000000 0.000000 -0.806831 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701000F2, 3483357, 0x01000155, 57.8697, -58.1159, 5.97325, -0.862747, 0, 0, -0.505635, False, '2025-07-22 13:24:51'); /* Blue Glow Mushroom */
/* @teleloc 0x01000155 [57.869701 -58.115898 5.973250] -0.862747 0.000000 0.000000 -0.505635 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701000F3, 3483357, 0x010001B8, 82.5055, -107.837, 5.97325, 0.915956, 0, 0, -0.40128, False, '2025-07-22 13:25:38'); /* Blue Glow Mushroom */
/* @teleloc 0x010001B8 [82.505501 -107.836998 5.973250] 0.915956 0.000000 0.000000 -0.401280 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701000F4, 3483357, 0x01000163, 60.7636, -121.334, 5.97325, 0.517813, 0, 0, 0.855494, False, '2025-07-22 13:25:43'); /* Blue Glow Mushroom */
/* @teleloc 0x01000163 [60.763599 -121.334000 5.973250] 0.517813 0.000000 0.000000 0.855494 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701000F5, 3483357, 0x01000162, 56.664, -107.478, 5.97325, 0.992009, 0, 0, 0.126167, False, '2025-07-22 13:25:45'); /* Blue Glow Mushroom */
/* @teleloc 0x01000162 [56.664001 -107.477997 5.973250] 0.992009 0.000000 0.000000 0.126167 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701000F6, 3483357, 0x010001B9, 82.2753, -122.67, 5.97325, 0.562407, 0, 0, -0.826861, False, '2025-07-22 13:25:49'); /* Blue Glow Mushroom */
/* @teleloc 0x010001B9 [82.275299 -122.669998 5.973250] 0.562407 0.000000 0.000000 -0.826861 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701000F7, 3483357, 0x010001B9, 82.2753, -122.67, 5.97325, 0.562407, 0, 0, -0.826861, False, '2025-07-22 13:25:51'); /* Blue Glow Mushroom */
/* @teleloc 0x010001B9 [82.275299 -122.669998 5.973250] 0.562407 0.000000 0.000000 -0.826861 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701000F8, 3483357, 0x010001B9, 82.6139, -122.902, 5.97325, 0.99201, 0, 0, 0.12616, False, '2025-07-22 13:25:52'); /* Blue Glow Mushroom */
/* @teleloc 0x010001B9 [82.613899 -122.902000 5.973250] 0.992010 0.000000 0.000000 0.126160 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701000F9, 3483357, 0x010001B9, 81.4863, -116.97, 5.97325, 0.999386, 0, 0, -0.035031, False, '2025-07-22 13:25:54'); /* Blue Glow Mushroom */
/* @teleloc 0x010001B9 [81.486298 -116.970001 5.973250] 0.999386 0.000000 0.000000 -0.035031 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701000FA, 3483357, 0x010001B8, 81.0209, -113.321, 5.97325, 0.717404, 0, 0, 0.696658, False, '2025-07-22 13:25:55'); /* Blue Glow Mushroom */
/* @teleloc 0x010001B8 [81.020897 -113.320999 5.973250] 0.717404 0.000000 0.000000 0.696658 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701000FB, 3483357, 0x01000398, 69.9899, -64.5631, 17.9732, -0.564575, 0, 0, 0.825382, False, '2025-07-22 13:26:18'); /* Blue Glow Mushroom */
/* @teleloc 0x01000398 [69.989899 -64.563103 17.973200] -0.564575 0.000000 0.000000 0.825382 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701000FC, 3483357, 0x010003A7, 70.8677, -96.6922, 17.9732, -0.251043, 0, 0, 0.967976, False, '2025-07-22 13:26:22'); /* Blue Glow Mushroom */
/* @teleloc 0x010003A7 [70.867699 -96.692200 17.973200] -0.251043 0.000000 0.000000 0.967976 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701000FD, 3483357, 0x010003AC, 71.6886, -112.84, 17.9732, -0.28899, 0, 0, 0.957332, False, '2025-07-22 13:26:25'); /* Blue Glow Mushroom */
/* @teleloc 0x010003AC [71.688599 -112.839996 17.973200] -0.288990 0.000000 0.000000 0.957332 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701000FE, 3483357, 0x01000328, 52.0265, -153.363, 17.9732, 0.523992, 0, 0, 0.851723, False, '2025-07-22 13:26:30'); /* Blue Glow Mushroom */
/* @teleloc 0x01000328 [52.026501 -153.363007 17.973200] 0.523992 0.000000 0.000000 0.851723 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701000FF, 3483357, 0x010002D6, 43.1427, -146.637, 17.9732, 0.881681, 0, 0, 0.471846, False, '2025-07-22 13:26:33'); /* Blue Glow Mushroom */
/* @teleloc 0x010002D6 [43.142700 -146.636993 17.973200] 0.881681 0.000000 0.000000 0.471846 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70100100, 3483357, 0x010002A5, 28.5739, -147.06, 17.9732, 0.594491, 0, 0, 0.804103, False, '2025-07-22 13:26:35'); /* Blue Glow Mushroom */
/* @teleloc 0x010002A5 [28.573900 -147.059998 17.973200] 0.594491 0.000000 0.000000 0.804103 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70100101, 3483357, 0x010002A5, 26.7713, -148.095, 17.9732, -0.100697, 0, 0, 0.994917, False, '2025-07-22 13:26:36'); /* Blue Glow Mushroom */
/* @teleloc 0x010002A5 [26.771299 -148.095001 17.973200] -0.100697 0.000000 0.000000 0.994917 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70100102, 3483357, 0x010002AB, 32.1377, -180.437, 17.9732, -0.337835, 0, 0, 0.941205, False, '2025-07-22 13:26:40'); /* Blue Glow Mushroom */
/* @teleloc 0x010002AB [32.137699 -180.436996 17.973200] -0.337835 0.000000 0.000000 0.941205 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70100103, 3483357, 0x010002B5, 32.2635, -200.589, 17.9732, -0.058517, 0, 0, 0.998286, False, '2025-07-22 13:26:51'); /* Blue Glow Mushroom */
/* @teleloc 0x010002B5 [32.263500 -200.589005 17.973200] -0.058517 0.000000 0.000000 0.998286 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70100104, 3483357, 0x01000331, 47.0694, -251.239, 17.9732, -0.100673, 0, 0, 0.99492, False, '2025-07-22 13:26:59'); /* Blue Glow Mushroom */
/* @teleloc 0x01000331 [47.069401 -251.238998 17.973200] -0.100673 0.000000 0.000000 0.994920 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70100105, 3483357, 0x010002A4, 23.855, -332.62, 17.9732, 0.317153, 0, 0, -0.948375, False, '2025-07-22 13:27:24'); /* Blue Glow Mushroom */
/* @teleloc 0x010002A4 [23.855000 -332.619995 17.973200] 0.317153 0.000000 0.000000 -0.948375 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70100106, 3483357, 0x010002A4, 15.6607, -333.191, 17.9732, -0.551371, 0, 0, -0.83426, False, '2025-07-22 13:27:28'); /* Blue Glow Mushroom */
/* @teleloc 0x010002A4 [15.660700 -333.191010 17.973200] -0.551371 0.000000 0.000000 -0.834260 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70100107, 3483357, 0x0100028A, 7.62871, -324.325, 17.9732, -0.945712, 0, 0, -0.325007, False, '2025-07-22 13:27:32'); /* Blue Glow Mushroom */
/* @teleloc 0x0100028A [7.628710 -324.325012 17.973200] -0.945712 0.000000 0.000000 -0.325007 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70100108, 3483357, 0x010002C4, 32.4131, -315.039, 17.9732, -0.77367, 0, 0, -0.633589, False, '2025-07-22 13:27:41'); /* Blue Glow Mushroom */
/* @teleloc 0x010002C4 [32.413101 -315.039001 17.973200] -0.773670 0.000000 0.000000 -0.633589 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70100109, 3483357, 0x010002A3, 17.9484, -319.503, 17.9732, 0.000948, 0, 0, -1, False, '2025-07-22 13:27:44'); /* Blue Glow Mushroom */
/* @teleloc 0x010002A3 [17.948400 -319.502991 17.973200] 0.000948 0.000000 0.000000 -1.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7010010A, 3483357, 0x01000463, -3.3629, -252.51, 23.9732, 0.981685, 0, 0, 0.190509, False, '2025-07-22 13:27:53'); /* Blue Glow Mushroom */
/* @teleloc 0x01000463 [-3.362900 -252.509995 23.973200] 0.981685 0.000000 0.000000 0.190509 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7010010B, 3483357, 0x01000463, -3.3629, -252.51, 23.9732, 0.981685, 0, 0, 0.190509, False, '2025-07-22 13:27:55'); /* Blue Glow Mushroom */
/* @teleloc 0x01000463 [-3.362900 -252.509995 23.973200] 0.981685 0.000000 0.000000 0.190509 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7010010C, 3483357, 0x01000462, -0.502564, -242.818, 23.9732, 0.867412, 0, 0, -0.497591, False, '2025-07-22 13:27:57'); /* Blue Glow Mushroom */
/* @teleloc 0x01000462 [-0.502564 -242.817993 23.973200] 0.867412 0.000000 0.000000 -0.497591 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7010010D, 3483357, 0x01000462, -0.502564, -242.818, 23.9732, 0.867412, 0, 0, -0.497591, False, '2025-07-22 13:27:59'); /* Blue Glow Mushroom */
/* @teleloc 0x01000462 [-0.502564 -242.817993 23.973200] 0.867412 0.000000 0.000000 -0.497591 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7010010E, 3483357, 0x01000462, 3.11813, -239.197, 23.9732, 0.912755, 0, 0, -0.408509, False, '2025-07-22 13:28:00'); /* Blue Glow Mushroom */
/* @teleloc 0x01000462 [3.118130 -239.197006 23.973200] 0.912755 0.000000 0.000000 -0.408509 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7010010F, 3483357, 0x01000466, 14.8331, -237.148, 23.9732, 0.262725, 0, 0, -0.964871, False, '2025-07-22 13:28:04'); /* Blue Glow Mushroom */
/* @teleloc 0x01000466 [14.833100 -237.147995 23.973200] 0.262725 0.000000 0.000000 -0.964871 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70100110, 3483357, 0x01000466, 14.8331, -237.148, 23.9732, 0.262725, 0, 0, -0.964871, False, '2025-07-22 13:28:06'); /* Blue Glow Mushroom */
/* @teleloc 0x01000466 [14.833100 -237.147995 23.973200] 0.262725 0.000000 0.000000 -0.964871 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70100111, 3483357, 0x0100046F, 22.3481, -245.525, 23.9732, 0.214173, 0, 0, -0.976796, False, '2025-07-22 13:28:08'); /* Blue Glow Mushroom */
/* @teleloc 0x0100046F [22.348101 -245.524994 23.973200] 0.214173 0.000000 0.000000 -0.976796 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70100112, 3483357, 0x0100046F, 23.2289, -252.407, 23.9732, -0.185002, 0, 0, -0.982738, False, '2025-07-22 13:28:10'); /* Blue Glow Mushroom */
/* @teleloc 0x0100046F [23.228901 -252.406998 23.973200] -0.185002 0.000000 0.000000 -0.982738 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70100113, 3483357, 0x0100046F, 23.2289, -252.407, 23.9732, -0.185002, 0, 0, -0.982738, False, '2025-07-22 13:28:12'); /* Blue Glow Mushroom */
/* @teleloc 0x0100046F [23.228901 -252.406998 23.973200] -0.185002 0.000000 0.000000 -0.982738 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70100114, 3483357, 0x01000470, 15.995, -261.672, 23.9732, -0.40619, 0, 0, -0.913789, False, '2025-07-22 13:28:14'); /* Blue Glow Mushroom */
/* @teleloc 0x01000470 [15.995000 -261.671997 23.973200] -0.406190 0.000000 0.000000 -0.913789 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70100115, 3483357, 0x01000468, 6.28382, -263.028, 23.9732, -0.676707, 0, 0, -0.736252, False, '2025-07-22 13:28:18'); /* Blue Glow Mushroom */
/* @teleloc 0x01000468 [6.283820 -263.028015 23.973200] -0.676707 0.000000 0.000000 -0.736252 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70100116, 3483357, 0x01000464, -0.369233, -257.316, 23.9732, -0.999826, 0, 0, 0.018635, False, '2025-07-22 13:28:21'); /* Blue Glow Mushroom */
/* @teleloc 0x01000464 [-0.369233 -257.316010 23.973200] -0.999826 0.000000 0.000000 0.018635 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70100117, 3483357, 0x01000463, -0.522651, -248.06, 23.9732, -0.940158, 0, 0, -0.34074, False, '2025-07-22 13:28:25'); /* Blue Glow Mushroom */
/* @teleloc 0x01000463 [-0.522651 -248.059998 23.973200] -0.940158 0.000000 0.000000 -0.340740 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70100118, 3483357, 0x01000466, 5.36573, -242.498, 23.9732, -0.953502, 0, 0, 0.301386, False, '2025-07-22 13:28:28'); /* Blue Glow Mushroom */
/* @teleloc 0x01000466 [5.365730 -242.498001 23.973200] -0.953502 0.000000 0.000000 0.301386 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70100119, 3483357, 0x01000465, 6.6371, -228.007, 23.9732, -0.999945, 0, 0, 0.010471, False, '2025-07-22 13:28:32'); /* Blue Glow Mushroom */
/* @teleloc 0x01000465 [6.637100 -228.007004 23.973200] -0.999945 0.000000 0.000000 0.010471 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7010011A, 3483357, 0x01000465, 13.3629, -227.415, 23.9732, -0.095286, 0, 0, 0.99545, False, '2025-07-22 13:28:39'); /* Blue Glow Mushroom */
/* @teleloc 0x01000465 [13.362900 -227.414993 23.973200] -0.095286 0.000000 0.000000 0.995450 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7010011B, 3483357, 0x0100046E, 18.3345, -243.888, 23.9732, -0.98343, 0, 0, -0.181289, False, '2025-07-22 13:28:57'); /* Blue Glow Mushroom */
/* @teleloc 0x0100046E [18.334499 -243.888000 23.973200] -0.983430 0.000000 0.000000 -0.181289 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7010011C, 3483357, 0x01000121, 37.7234, -258.191, -0.02675, 0.980067, 0, 0, 0.198669, False, '2025-07-22 13:41:18'); /* Blue Glow Mushroom */
/* @teleloc 0x01000121 [37.723400 -258.191010 -0.026750] 0.980067 0.000000 0.000000 0.198669 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7010011D, 3483357, 0x01000121, 43.3629, -258.187, -0.02675, 0.960576, 0, 0, -0.278019, False, '2025-07-22 13:41:24'); /* Blue Glow Mushroom */
/* @teleloc 0x01000121 [43.362900 -258.187012 -0.026750] 0.960576 0.000000 0.000000 -0.278019 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7010011E, 3483357, 0x010001BE, 86.6522, -172.991, 5.97325, -0.274673, 0, 0, 0.961538, False, '2025-07-22 13:42:03'); /* Blue Glow Mushroom */
/* @teleloc 0x010001BE [86.652199 -172.990997 5.973250] -0.274673 0.000000 0.000000 0.961538 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7010011F, 3483357, 0x010001BD, 93.3629, -163.174, 5.97325, -0.999376, 0, 0, -0.03533, False, '2025-07-22 13:42:07'); /* Blue Glow Mushroom */
/* @teleloc 0x010001BD [93.362900 -163.173996 5.973250] -0.999376 0.000000 0.000000 -0.035330 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70100120, 3483357, 0x010001BB, 93.3629, -136.743, 5.97325, -0.994386, 0, 0, -0.105811, False, '2025-07-22 13:42:10'); /* Blue Glow Mushroom */
/* @teleloc 0x010001BB [93.362900 -136.742996 5.973250] -0.994386 0.000000 0.000000 -0.105811 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70100121, 3483357, 0x010001BB, 93.3119, -137.135, 5.97325, -0.994386, 0, 0, -0.105811, False, '2025-07-22 13:42:12'); /* Blue Glow Mushroom */
/* @teleloc 0x010001BB [93.311897 -137.134995 5.973250] -0.994386 0.000000 0.000000 -0.105811 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70100122, 3483357, 0x010001BB, 86.7152, -138.923, 5.97325, -0.721946, 0, 0, -0.691949, False, '2025-07-22 13:42:15'); /* Blue Glow Mushroom */
/* @teleloc 0x010001BB [86.715202 -138.923004 5.973250] -0.721946 0.000000 0.000000 -0.691949 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70100123, 8729957, 0x0100027F, 247.411, -128.673, 12.03, 0.875513, 0, 0, 0.483195, False, '2025-07-22 13:42:55'); /* Red Burning Mushroom */
/* @teleloc 0x0100027F [247.410995 -128.673004 12.030000] 0.875513 0.000000 0.000000 0.483195 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70100124, 8729957, 0x01000270, 233.903, -128.409, 11.9858, 0.782225, 0, 0, 0.622996, False, '2025-07-22 13:42:59'); /* Red Burning Mushroom */
/* @teleloc 0x01000270 [233.903000 -128.408997 11.985800] 0.782225 0.000000 0.000000 0.622996 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70100125, 8729957, 0x01000277, 236.428, -102.288, 11.9858, 0.718772, 0, 0, -0.695246, False, '2025-07-22 13:43:05'); /* Red Burning Mushroom */
/* @teleloc 0x01000277 [236.427994 -102.288002 11.985800] 0.718772 0.000000 0.000000 -0.695246 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70100126, 8729957, 0x0100027E, 253.403, -93.052, 11.9858, 0.820413, 0, 0, -0.571771, False, '2025-07-22 13:43:09'); /* Red Burning Mushroom */
/* @teleloc 0x0100027E [253.403000 -93.052002 11.985800] 0.820413 0.000000 0.000000 -0.571771 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70100127, 8729957, 0x0100027E, 248.241, -86.5235, 11.9858, 0.794054, 0, 0, 0.607847, False, '2025-07-22 13:43:11'); /* Red Burning Mushroom */
/* @teleloc 0x0100027E [248.240997 -86.523499 11.985800] 0.794054 0.000000 0.000000 0.607847 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70100128, 8729957, 0x01000275, 240.472, -81.7057, 11.9858, 0.98913, 0, 0, 0.147043, False, '2025-07-22 13:43:13'); /* Red Burning Mushroom */
/* @teleloc 0x01000275 [240.472000 -81.705704 11.985800] 0.989130 0.000000 0.000000 0.147043 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70100129, 8729957, 0x0100026A, 232.726, -66.3642, 11.9858, 0.915341, 0, 0, -0.402679, False, '2025-07-22 13:43:16'); /* Red Burning Mushroom */
/* @teleloc 0x0100026A [232.725998 -66.364197 11.985800] 0.915341 0.000000 0.000000 -0.402679 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7010012A, 8729957, 0x0100026A, 232.726, -66.3642, 11.9858, 0.915341, 0, 0, -0.402679, False, '2025-07-22 13:43:18'); /* Red Burning Mushroom */
/* @teleloc 0x0100026A [232.725998 -66.364197 11.985800] 0.915341 0.000000 0.000000 -0.402679 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7010012B, 8729957, 0x01000266, 220.157, -81.0767, 11.9858, 0.670053, 0, 0, 0.742313, False, '2025-07-22 13:43:22'); /* Red Burning Mushroom */
/* @teleloc 0x01000266 [220.156998 -81.076698 11.985800] 0.670053 0.000000 0.000000 0.742313 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7010012C, 8729957, 0x01000264, 207.344, -85.8721, 11.9858, 0.814058, 0, 0, 0.580784, False, '2025-07-22 13:43:24'); /* Red Burning Mushroom */
/* @teleloc 0x01000264 [207.343994 -85.872101 11.985800] 0.814058 0.000000 0.000000 0.580784 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7010012D, 8729957, 0x01000264, 206.278, -94.1059, 11.9858, 0.047728, 0, 0, 0.99886, False, '2025-07-22 13:43:27'); /* Red Burning Mushroom */
/* @teleloc 0x01000264 [206.278000 -94.105904 11.985800] 0.047728 0.000000 0.000000 0.998860 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7010012E, 8729957, 0x01000268, 224.261, -103.028, 11.9858, -0.164016, 0, 0, 0.986458, False, '2025-07-22 13:43:32'); /* Red Burning Mushroom */
/* @teleloc 0x01000268 [224.261002 -103.028000 11.985800] -0.164016 0.000000 0.000000 0.986458 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7010012F, 3483357, 0x0100027E, 252.854, -87.2728, 11.9733, -0.99812, 0, 0, 0.061294, False, '2025-07-22 13:43:49'); /* Blue Glow Mushroom */
/* @teleloc 0x0100027E [252.854004 -87.272797 11.973300] -0.998120 0.000000 0.000000 0.061294 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70100130, 3483357, 0x0100026B, 233.363, -75.6207, 11.9733, -0.970385, 0, 0, -0.241562, False, '2025-07-22 13:43:55'); /* Blue Glow Mushroom */
/* @teleloc 0x0100026B [233.363007 -75.620697 11.973300] -0.970385 0.000000 0.000000 -0.241562 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70100131, 3483357, 0x0100026A, 226.637, -67.0456, 11.9733, -0.986476, 0, 0, -0.163909, False, '2025-07-22 13:43:58'); /* Blue Glow Mushroom */
/* @teleloc 0x0100026A [226.636993 -67.045601 11.973300] -0.986476 0.000000 0.000000 -0.163909 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70100132, 3483357, 0x01000264, 207.503, -90.8816, 11.9733, 0.572254, 0, 0, -0.820077, False, '2025-07-22 13:44:04'); /* Blue Glow Mushroom */
/* @teleloc 0x01000264 [207.503006 -90.881599 11.973300] 0.572254 0.000000 0.000000 -0.820077 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70100133, 3483357, 0x0100026C, 230.027, -89.2597, 11.9733, 0.689422, 0, 0, -0.72436, False, '2025-07-22 13:44:08'); /* Blue Glow Mushroom */
/* @teleloc 0x0100026C [230.026993 -89.259697 11.973300] 0.689422 0.000000 0.000000 -0.724360 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70100134, 3483357, 0x01000276, 237.902, -89.4754, 11.9733, 0.793451, 0, 0, -0.608634, False, '2025-07-22 13:44:10'); /* Blue Glow Mushroom */
/* @teleloc 0x01000276 [237.901993 -89.475403 11.973300] 0.793451 0.000000 0.000000 -0.608634 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70100135, 8729957, 0x0100025E, 200.3, -129.959, 11.9858, 0.517069, 0, 0, 0.855944, False, '2025-07-22 13:44:29'); /* Red Burning Mushroom */
/* @teleloc 0x0100025E [200.300003 -129.959000 11.985800] 0.517069 0.000000 0.000000 0.855944 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70100136, 8729957, 0x01000455, 186.116, -141.602, 17.537, 0.675748, 0, 0, 0.737133, False, '2025-07-22 13:44:32'); /* Red Burning Mushroom */
/* @teleloc 0x01000455 [186.115997 -141.602005 17.537001] 0.675748 0.000000 0.000000 0.737133 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70100137, 8729957, 0x0100042F, 130.628, -157.534, 17.9858, -0.135486, 0, 0, 0.990779, False, '2025-07-22 13:44:42'); /* Red Burning Mushroom */
/* @teleloc 0x0100042F [130.628006 -157.533997 17.985800] -0.135486 0.000000 0.000000 0.990779 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70100138, 8729957, 0x0100042F, 130.628, -157.534, 17.9858, -0.135486, 0, 0, 0.990779, False, '2025-07-22 13:44:44'); /* Red Burning Mushroom */
/* @teleloc 0x0100042F [130.628006 -157.533997 17.985800] -0.135486 0.000000 0.000000 0.990779 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70100139, 8729957, 0x0100042F, 127.705, -161.766, 17.9858, -0.537642, 0, 0, 0.843173, False, '2025-07-22 13:44:46'); /* Red Burning Mushroom */
/* @teleloc 0x0100042F [127.705002 -161.766006 17.985800] -0.537642 0.000000 0.000000 0.843173 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7010013A, 8729957, 0x01000443, 152.393, -163.171, 17.9858, -0.717248, 0, 0, 0.696818, False, '2025-07-22 13:44:49'); /* Red Burning Mushroom */
/* @teleloc 0x01000443 [152.393005 -163.171005 17.985800] -0.717248 0.000000 0.000000 0.696818 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7010013B, 8729957, 0x01000452, 162.151, -154.054, 17.9858, -0.608513, 0, 0, 0.793544, False, '2025-07-22 13:44:53'); /* Red Burning Mushroom */
/* @teleloc 0x01000452 [162.151001 -154.054001 17.985800] -0.608513 0.000000 0.000000 0.793544 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7010013C, 8729957, 0x01000452, 162.151, -154.054, 17.9858, -0.608513, 0, 0, 0.793544, False, '2025-07-22 13:44:54'); /* Red Burning Mushroom */
/* @teleloc 0x01000452 [162.151001 -154.054001 17.985800] -0.608513 0.000000 0.000000 0.793544 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7010013D, 8729957, 0x01000450, 163.647, -127.275, 17.9858, -0.989096, 0, 0, -0.147272, False, '2025-07-22 13:44:57'); /* Red Burning Mushroom */
/* @teleloc 0x01000450 [163.647003 -127.275002 17.985800] -0.989096 0.000000 0.000000 -0.147272 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7010013E, 8729957, 0x01000450, 163.647, -127.275, 17.9858, -0.989096, 0, 0, -0.147272, False, '2025-07-22 13:44:59'); /* Red Burning Mushroom */
/* @teleloc 0x01000450 [163.647003 -127.275002 17.985800] -0.989096 0.000000 0.000000 -0.147272 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7010013F, 8729957, 0x01000450, 156.407, -126.34, 17.9858, -0.637511, 0, 0, -0.770442, False, '2025-07-22 13:45:01'); /* Red Burning Mushroom */
/* @teleloc 0x01000450 [156.406998 -126.339996 17.985800] -0.637511 0.000000 0.000000 -0.770442 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70100140, 8729957, 0x01000450, 156.407, -126.34, 17.9858, -0.637511, 0, 0, -0.770442, False, '2025-07-22 13:45:03'); /* Red Burning Mushroom */
/* @teleloc 0x01000450 [156.406998 -126.339996 17.985800] -0.637511 0.000000 0.000000 -0.770442 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70100141, 8729957, 0x01000450, 156.407, -126.34, 17.9858, -0.637511, 0, 0, -0.770442, False, '2025-07-22 13:45:04'); /* Red Burning Mushroom */
/* @teleloc 0x01000450 [156.406998 -126.339996 17.985800] -0.637511 0.000000 0.000000 -0.770442 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70100142, 8729957, 0x01000440, 151.219, -127.278, 17.9858, -0.38846, 0, 0, -0.921466, False, '2025-07-22 13:45:06'); /* Red Burning Mushroom */
/* @teleloc 0x01000440 [151.218994 -127.278000 17.985800] -0.388460 0.000000 0.000000 -0.921466 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70100143, 8729957, 0x01000431, 137.867, -128.171, 17.9858, 0.455366, 0, 0, 0.890304, False, '2025-07-22 13:45:18'); /* Red Burning Mushroom */
/* @teleloc 0x01000431 [137.867004 -128.171005 17.985800] 0.455366 0.000000 0.000000 0.890304 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70100144, 8729957, 0x01000431, 137.867, -128.171, 17.9858, 0.455366, 0, 0, 0.890304, False, '2025-07-22 13:45:21'); /* Red Burning Mushroom */
/* @teleloc 0x01000431 [137.867004 -128.171005 17.985800] 0.455366 0.000000 0.000000 0.890304 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70100145, 3483357, 0x0100042D, 128.382, -137.577, 17.9732, 0.807045, 0, 0, 0.59049, False, '2025-07-22 13:45:36'); /* Blue Glow Mushroom */
/* @teleloc 0x0100042D [128.382004 -137.576996 17.973200] 0.807045 0.000000 0.000000 0.590490 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70100146, 3483357, 0x0100042F, 131.297, -162.093, 17.9732, -0.591163, 0, 0, 0.806552, False, '2025-07-22 13:45:41'); /* Blue Glow Mushroom */
/* @teleloc 0x0100042F [131.296997 -162.093002 17.973200] -0.591163 0.000000 0.000000 0.806552 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70100147, 3483357, 0x01000442, 148.311, -149.18, 17.9732, -0.940739, 0, 0, 0.339132, False, '2025-07-22 13:45:45'); /* Blue Glow Mushroom */
/* @teleloc 0x01000442 [148.311005 -149.179993 17.973200] -0.940739 0.000000 0.000000 0.339132 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70100148, 3483357, 0x01000441, 152.279, -138.575, 17.9732, -0.905344, 0, 0, -0.42468, False, '2025-07-22 13:45:48'); /* Blue Glow Mushroom */
/* @teleloc 0x01000441 [152.279007 -138.574997 17.973200] -0.905344 0.000000 0.000000 -0.424680 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70100149, 8729957, 0x01000434, 144.14, -162.69, 17.9858, 0.544071, 0, 0, 0.83904, False, '2025-07-22 13:46:12'); /* Red Burning Mushroom */
/* @teleloc 0x01000434 [144.139999 -162.690002 17.985800] 0.544071 0.000000 0.000000 0.839040 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7010014A, 8729957, 0x01000436, 140.331, -180.395, 18.0555, -0.395342, 0, 0, 0.918534, False, '2025-07-22 13:46:17'); /* Red Burning Mushroom */
/* @teleloc 0x01000436 [140.330994 -180.395004 18.055500] -0.395342 0.000000 0.000000 0.918534 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7010014B, 8729957, 0x01000447, 147.096, -190.734, 17.9858, 0.401148, 0, 0, 0.916013, False, '2025-07-22 13:46:21'); /* Red Burning Mushroom */
/* @teleloc 0x01000447 [147.095993 -190.733994 17.985800] 0.401148 0.000000 0.000000 0.916013 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7010014C, 8729957, 0x01000430, 130.715, -201.587, 18.1001, 0.634445, 0, 0, 0.772968, False, '2025-07-22 13:46:37'); /* Red Burning Mushroom */
/* @teleloc 0x01000430 [130.714996 -201.587006 18.100100] 0.634445 0.000000 0.000000 0.772968 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7010014D, 8729957, 0x0100042A, 120.885, -200.271, 17.9858, 0.848047, 0, 0, 0.52992, False, '2025-07-22 13:46:40'); /* Red Burning Mushroom */
/* @teleloc 0x0100042A [120.885002 -200.270996 17.985800] 0.848047 0.000000 0.000000 0.529920 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7010014E, 8729957, 0x01000425, 117.582, -171.587, 17.9858, 0.90072, 0, 0, 0.4344, False, '2025-07-22 13:46:44'); /* Red Burning Mushroom */
/* @teleloc 0x01000425 [117.582001 -171.587006 17.985800] 0.900720 0.000000 0.000000 0.434400 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7010014F, 8729957, 0x0100041D, 87.2088, -174.128, 17.9858, 0.384788, 0, 0, 0.923005, False, '2025-07-22 13:46:50'); /* Red Burning Mushroom */
/* @teleloc 0x0100041D [87.208801 -174.128006 17.985800] 0.384788 0.000000 0.000000 0.923005 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70100150, 8729957, 0x01000420, 102.564, -137.334, 17.9858, 0.999975, 0, 0, 0.007075, False, '2025-07-22 13:46:56'); /* Red Burning Mushroom */
/* @teleloc 0x01000420 [102.564003 -137.334000 17.985800] 0.999975 0.000000 0.000000 0.007075 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70100151, 8729957, 0x01000420, 102.564, -137.334, 17.9858, 0.999975, 0, 0, 0.007075, False, '2025-07-22 13:46:58'); /* Red Burning Mushroom */
/* @teleloc 0x01000420 [102.564003 -137.334000 17.985800] 0.999975 0.000000 0.000000 0.007075 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70100152, 8729957, 0x01000421, 102.446, -149.849, 17.9858, -0.335405, 0, 0, 0.942074, False, '2025-07-22 13:47:01'); /* Red Burning Mushroom */
/* @teleloc 0x01000421 [102.445999 -149.848999 17.985800] -0.335405 0.000000 0.000000 0.942074 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70100153, 8729957, 0x0100041D, 90.7266, -173.456, 17.9858, 0.819124, 0, 0, 0.573616, False, '2025-07-22 13:47:06'); /* Red Burning Mushroom */
/* @teleloc 0x0100041D [90.726601 -173.455994 17.985800] 0.819124 0.000000 0.000000 0.573616 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70100154, 8729957, 0x0100041D, 86.5705, -168.568, 17.9858, 0.946526, 0, 0, -0.322629, False, '2025-07-22 13:47:08'); /* Red Burning Mushroom */
/* @teleloc 0x0100041D [86.570503 -168.567993 17.985800] 0.946526 0.000000 0.000000 -0.322629 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70100155, 8729957, 0x01000374, 59.0907, -173.185, 17.9858, 0.259778, 0, 0, 0.965668, False, '2025-07-22 13:47:20'); /* Red Burning Mushroom */
/* @teleloc 0x01000374 [59.090698 -173.184998 17.985800] 0.259778 0.000000 0.000000 0.965668 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70100156, 8729957, 0x010003BA, 67.5143, -192.748, 17.9858, -0.295235, 0, 0, 0.955425, False, '2025-07-22 13:47:25'); /* Red Burning Mushroom */
/* @teleloc 0x010003BA [67.514297 -192.748001 17.985800] -0.295235 0.000000 0.000000 0.955425 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70100157, 8729957, 0x010003FC, 78.4128, -203.788, 17.9858, 0.107304, 0, 0, 0.994226, False, '2025-07-22 13:47:29'); /* Red Burning Mushroom */
/* @teleloc 0x010003FC [78.412804 -203.787994 17.985800] 0.107304 0.000000 0.000000 0.994226 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70100158, 8729957, 0x01000408, 76.1218, -239.357, 17.9858, -0.04823, 0, 0, 0.998836, False, '2025-07-22 13:47:38'); /* Red Burning Mushroom */
/* @teleloc 0x01000408 [76.121803 -239.356995 17.985800] -0.048230 0.000000 0.000000 0.998836 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70100159, 8729957, 0x01000410, 80.8972, -255.53, 17.9858, 0.065155, 0, 0, 0.997875, False, '2025-07-22 13:47:42'); /* Red Burning Mushroom */
/* @teleloc 0x01000410 [80.897202 -255.529999 17.985800] 0.065155 0.000000 0.000000 0.997875 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7010015A, 8729957, 0x0100041E, 93.0341, -286.261, 17.9858, 0.626666, 0, 0, 0.779288, False, '2025-07-22 13:47:56'); /* Red Burning Mushroom */
/* @teleloc 0x0100041E [93.034103 -286.260986 17.985800] 0.626666 0.000000 0.000000 0.779288 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7010015B, 8729957, 0x01000348, 48.4224, -301.299, 18.0466, 0.087731, 0, 0, 0.996144, False, '2025-07-22 13:48:05'); /* Red Burning Mushroom */
/* @teleloc 0x01000348 [48.422401 -301.299011 18.046600] 0.087731 0.000000 0.000000 0.996144 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7010015C, 8729957, 0x01000289, 8.98509, -313.4, 17.9858, 0.235697, 0, 0, 0.971827, False, '2025-07-22 13:50:50'); /* Red Burning Mushroom */
/* @teleloc 0x01000289 [8.985090 -313.399994 17.985800] 0.235697 0.000000 0.000000 0.971827 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7010015D, 8729957, 0x01000289, 12.6118, -308.622, 17.9858, -0.885713, 0, 0, 0.464233, False, '2025-07-22 13:50:53'); /* Red Burning Mushroom */
/* @teleloc 0x01000289 [12.611800 -308.622009 17.985800] -0.885713 0.000000 0.000000 0.464233 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7010015E, 8729957, 0x010002A2, 23.6439, -307.308, 17.9858, -0.534564, 0, 0, 0.845128, False, '2025-07-22 13:50:56'); /* Red Burning Mushroom */
/* @teleloc 0x010002A2 [23.643900 -307.308014 17.985800] -0.534564 0.000000 0.000000 0.845128 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7010015F, 8729957, 0x010002A2, 23.6439, -307.308, 17.9858, -0.534564, 0, 0, 0.845128, False, '2025-07-22 13:50:58'); /* Red Burning Mushroom */
/* @teleloc 0x010002A2 [23.643900 -307.308014 17.985800] -0.534564 0.000000 0.000000 0.845128 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70100160, 8729957, 0x01000463, 1.79532, -249.808, 23.9858, 0.912886, 0, 0, -0.408215, False, '2025-07-22 13:51:09'); /* Red Burning Mushroom */
/* @teleloc 0x01000463 [1.795320 -249.807999 23.985800] 0.912886 0.000000 0.000000 -0.408215 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70100161, 8729957, 0x01000463, 1.79532, -249.808, 23.9858, 0.912886, 0, 0, -0.408215, False, '2025-07-22 13:51:11'); /* Red Burning Mushroom */
/* @teleloc 0x01000463 [1.795320 -249.807999 23.985800] 0.912886 0.000000 0.000000 -0.408215 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70100162, 8729957, 0x01000463, 0.931051, -254.426, 23.9858, -0.103227, 0, 0, 0.994658, False, '2025-07-22 13:51:14'); /* Red Burning Mushroom */
/* @teleloc 0x01000463 [0.931051 -254.425995 23.985800] -0.103227 0.000000 0.000000 0.994658 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70100163, 8729957, 0x01000468, 5.20187, -259.221, 23.9858, -0.537804, 0, 0, 0.84307, False, '2025-07-22 13:51:16'); /* Red Burning Mushroom */
/* @teleloc 0x01000468 [5.201870 -259.221008 23.985800] -0.537804 0.000000 0.000000 0.843070 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70100164, 8729957, 0x0100046F, 19.7367, -251.267, 23.9858, -0.938685, 0, 0, 0.344776, False, '2025-07-22 13:51:21'); /* Red Burning Mushroom */
/* @teleloc 0x0100046F [19.736700 -251.266998 23.985800] -0.938685 0.000000 0.000000 0.344776 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70100165, 8729957, 0x0100046F, 19.7367, -251.267, 23.9858, -0.938685, 0, 0, 0.344776, False, '2025-07-22 13:51:23'); /* Red Burning Mushroom */
/* @teleloc 0x0100046F [19.736700 -251.266998 23.985800] -0.938685 0.000000 0.000000 0.344776 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70100166, 8729957, 0x0100046E, 15.2448, -242.893, 23.9858, -0.942008, 0, 0, -0.33559, False, '2025-07-22 13:51:26'); /* Red Burning Mushroom */
/* @teleloc 0x0100046E [15.244800 -242.893005 23.985800] -0.942008 0.000000 0.000000 -0.335590 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70100167, 8729957, 0x01000470, 17.6861, -257.32, 23.9858, 0.769561, 0, 0, -0.638573, False, '2025-07-22 13:51:31'); /* Red Burning Mushroom */
/* @teleloc 0x01000470 [17.686100 -257.320007 23.985800] 0.769561 0.000000 0.000000 -0.638573 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70100168, 8729957, 0x0100034A, 50.5684, -319.184, 17.9858, 0.564247, 0, 0, 0.825606, False, '2025-07-22 13:52:02'); /* Red Burning Mushroom */
/* @teleloc 0x0100034A [50.568401 -319.183990 17.985800] 0.564247 0.000000 0.000000 0.825606 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70100169, 8729957, 0x01000393, 60.6983, -278.613, 17.9858, 0.913059, 0, 0, -0.407828, False, '2025-07-22 13:52:10'); /* Red Burning Mushroom */
/* @teleloc 0x01000393 [60.698299 -278.613007 17.985800] 0.913059 0.000000 0.000000 -0.407828 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7010016A, 3102157, 0x0100033F, 49.6323, -276.664, 18, 0.880506, 0, 0, 0.474036, False, '2025-07-22 13:52:25'); /* Puffball Thrungus */
/* @teleloc 0x0100033F [49.632301 -276.664001 18.000000] 0.880506 0.000000 0.000000 0.474036 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7010016B, 3102157, 0x01000348, 51.8577, -298.072, 18, -0.209012, 0, 0, 0.977913, False, '2025-07-22 13:52:31'); /* Puffball Thrungus */
/* @teleloc 0x01000348 [51.857700 -298.071991 18.000000] -0.209012 0.000000 0.000000 0.977913 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7010016C, 3102157, 0x010002F7, 41.7328, -274.368, 18, -0.944492, 0, 0, 0.328535, False, '2025-07-22 13:52:38'); /* Puffball Thrungus */
/* @teleloc 0x010002F7 [41.732800 -274.368011 18.000000] -0.944492 0.000000 0.000000 0.328535 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7010016D, 3102157, 0x010002E5, 38.0388, -232.747, 18, -0.820224, 0, 0, -0.572042, False, '2025-07-22 13:52:44'); /* Puffball Thrungus */
/* @teleloc 0x010002E5 [38.038799 -232.746994 18.000000] -0.820224 0.000000 0.000000 -0.572042 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7010016E, 3102157, 0x01000291, 18.4287, -184.806, 18, -0.990449, 0, 0, -0.137879, False, '2025-07-22 13:52:52'); /* Puffball Thrungus */
/* @teleloc 0x01000291 [18.428699 -184.806000 18.000000] -0.990449 0.000000 0.000000 -0.137879 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7010016F, 3102157, 0x010002DA, 40.7664, -188.89, 18, -0.920812, 0, 0, 0.390007, False, '2025-07-22 13:52:58'); /* Puffball Thrungus */
/* @teleloc 0x010002DA [40.766399 -188.889999 18.000000] -0.920812 0.000000 0.000000 0.390007 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70100170, 3102157, 0x010002A6, 31.8703, -155.04, 18, -0.987033, 0, 0, 0.160518, False, '2025-07-22 13:53:03'); /* Puffball Thrungus */
/* @teleloc 0x010002A6 [31.870300 -155.039993 18.000000] -0.987033 0.000000 0.000000 0.160518 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70100171, 3102157, 0x01000372, 63.9724, -148.156, 18, -0.989455, 0, 0, 0.144839, False, '2025-07-22 13:53:09'); /* Puffball Thrungus */
/* @teleloc 0x01000372 [63.972401 -148.156006 18.000000] -0.989455 0.000000 0.000000 0.144839 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70100172, 3102157, 0x010003B1, 71.8405, -123.983, 18, -0.983156, 0, 0, 0.18277, False, '2025-07-22 13:53:14'); /* Puffball Thrungus */
/* @teleloc 0x010003B1 [71.840500 -123.983002 18.000000] -0.983156 0.000000 0.000000 0.182770 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70100173, 3102157, 0x01000361, 63.0174, -97.1645, 18, -0.92261, 0, 0, -0.385734, False, '2025-07-22 13:53:20'); /* Puffball Thrungus */
/* @teleloc 0x01000361 [63.017399 -97.164497 18.000000] -0.922610 0.000000 0.000000 -0.385734 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70100174, 3102157, 0x0100035C, 56.478, -87.9629, 18, -0.951614, 0, 0, -0.307296, False, '2025-07-22 13:53:23'); /* Puffball Thrungus */
/* @teleloc 0x0100035C [56.478001 -87.962898 18.000000] -0.951614 0.000000 0.000000 -0.307296 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70100175, 3102157, 0x0100035C, 63.5367, -88.0606, 18, -0.924339, 0, 0, 0.381574, False, '2025-07-22 13:53:26'); /* Puffball Thrungus */
/* @teleloc 0x0100035C [63.536701 -88.060600 18.000000] -0.924339 0.000000 0.000000 0.381574 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70100176, 3102157, 0x0100035C, 63.5367, -88.0606, 18, -0.924339, 0, 0, 0.381574, False, '2025-07-22 13:53:28'); /* Puffball Thrungus */
/* @teleloc 0x0100035C [63.536701 -88.060600 18.000000] -0.924339 0.000000 0.000000 0.381574 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70100177, 3102157, 0x0100034D, 58.5278, -38.9632, 18, -0.962728, 0, 0, -0.270473, False, '2025-07-22 13:53:34'); /* Puffball Thrungus */
/* @teleloc 0x0100034D [58.527802 -38.963200 18.000000] -0.962728 0.000000 0.000000 -0.270473 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70100178, 3102157, 0x01000250, 56.0886, 1.90612, 11.4216, -0.82958, 0, 0, 0.558388, False, '2025-07-22 13:53:41'); /* Puffball Thrungus */
/* @teleloc 0x01000250 [56.088600 1.906120 11.421600] -0.829580 0.000000 0.000000 0.558388 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70100179, 3102157, 0x0100016B, 68.1223, -7.74193, 6, 0.32022, 0, 0, 0.947343, False, '2025-07-22 13:53:45'); /* Puffball Thrungus */
/* @teleloc 0x0100016B [68.122299 -7.741930 6.000000] 0.320220 0.000000 0.000000 0.947343 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7010017A, 3102157, 0x01000171, 66.8358, -26.8859, 6, 0.869334, 0, 0, 0.494224, False, '2025-07-22 13:53:54'); /* Puffball Thrungus */
/* @teleloc 0x01000171 [66.835800 -26.885900 6.000000] 0.869334 0.000000 0.000000 0.494224 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7010017B, 3102157, 0x0100017D, 66.9191, -52.9934, 6, 0.299656, 0, 0, 0.954047, False, '2025-07-22 13:54:00'); /* Puffball Thrungus */
/* @teleloc 0x0100017D [66.919098 -52.993401 6.000000] 0.299656 0.000000 0.000000 0.954047 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7010017C, 3102157, 0x010001B5, 80.6123, -79.4654, 6, 0.320667, 0, 0, 0.947192, False, '2025-07-22 13:54:06'); /* Puffball Thrungus */
/* @teleloc 0x010001B5 [80.612297 -79.465401 6.000000] 0.320667 0.000000 0.000000 0.947192 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7010017D, 3102157, 0x01000162, 55.637, -112.659, 6, 0.158458, 0, 0, 0.987366, False, '2025-07-22 13:54:13'); /* Puffball Thrungus */
/* @teleloc 0x01000162 [55.637001 -112.658997 6.000000] 0.158458 0.000000 0.000000 0.987366 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7010017E, 3102157, 0x01000162, 55.637, -112.659, 6, 0.158458, 0, 0, 0.987366, False, '2025-07-22 13:54:16'); /* Puffball Thrungus */
/* @teleloc 0x01000162 [55.637001 -112.658997 6.000000] 0.158458 0.000000 0.000000 0.987366 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7010017F, 3102157, 0x01000163, 56.8951, -117.292, 6, -0.032214, 0, 0, 0.999481, False, '2025-07-22 13:54:18'); /* Puffball Thrungus */
/* @teleloc 0x01000163 [56.895100 -117.292000 6.000000] -0.032214 0.000000 0.000000 0.999481 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70100180, 3102157, 0x01000162, 56.9567, -114.843, 6, -0.987574, 0, 0, 0.157154, False, '2025-07-22 13:54:20'); /* Puffball Thrungus */
/* @teleloc 0x01000162 [56.956699 -114.843002 6.000000] -0.987574 0.000000 0.000000 0.157154 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70100181, 3102157, 0x01000199, 65.0217, -151.512, 6, 0.313358, 0, 0, 0.949635, False, '2025-07-22 13:54:29'); /* Puffball Thrungus */
/* @teleloc 0x01000199 [65.021698 -151.511993 6.000000] 0.313358 0.000000 0.000000 0.949635 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70100182, 3102157, 0x01000138, 40.6751, -141.878, 6, 0.720682, 0, 0, 0.693266, False, '2025-07-22 13:54:53'); /* Puffball Thrungus */
/* @teleloc 0x01000138 [40.675098 -141.878006 6.000000] 0.720682 0.000000 0.000000 0.693266 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70100183, 3102157, 0x01000103, 31.5814, -160.423, 0, -0.193008, 0, 0, 0.981197, False, '2025-07-22 13:55:22'); /* Puffball Thrungus */
/* @teleloc 0x01000103 [31.581400 -160.423004 0.000000] -0.193008 0.000000 0.000000 0.981197 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70100184, 3102157, 0x0100010F, 39.9799, -169.81, 0, -0.553068, 0, 0, 0.833136, False, '2025-07-22 13:55:59'); /* Puffball Thrungus */
/* @teleloc 0x0100010F [39.979900 -169.809998 0.000000] -0.553068 0.000000 0.000000 0.833136 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70100185, 3102157, 0x0100010F, 39.9799, -169.81, 0, -0.553068, 0, 0, 0.833136, False, '2025-07-22 13:56:01'); /* Puffball Thrungus */
/* @teleloc 0x0100010F [39.979900 -169.809998 0.000000] -0.553068 0.000000 0.000000 0.833136 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70100186, 3102157, 0x01000112, 41.7013, -176.107, 0, -0.265972, 0, 0, 0.963981, False, '2025-07-22 13:56:05'); /* Puffball Thrungus */
/* @teleloc 0x01000112 [41.701302 -176.106995 0.000000] -0.265972 0.000000 0.000000 0.963981 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70100187, 3102157, 0x01000112, 38.4003, -183.255, 0, 0.845456, 0, 0, 0.534046, False, '2025-07-22 13:56:19'); /* Puffball Thrungus */
/* @teleloc 0x01000112 [38.400299 -183.255005 0.000000] 0.845456 0.000000 0.000000 0.534046 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70100188, 3102157, 0x01000107, 25.5452, -185.492, 0, -0.437966, 0, 0, 0.898992, False, '2025-07-22 13:56:26'); /* Puffball Thrungus */
/* @teleloc 0x01000107 [25.545200 -185.492004 0.000000] -0.437966 0.000000 0.000000 0.898992 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70100189, 3102157, 0x01000107, 27.2675, -188.624, 0, -0.235712, 0, 0, 0.971823, False, '2025-07-22 13:56:29'); /* Puffball Thrungus */
/* @teleloc 0x01000107 [27.267500 -188.623993 0.000000] -0.235712 0.000000 0.000000 0.971823 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7010018A, 3102157, 0x01000107, 29.5095, -194.592, 0, -0.751578, 0, 0, 0.659645, False, '2025-07-22 13:56:32'); /* Puffball Thrungus */
/* @teleloc 0x01000107 [29.509501 -194.591995 0.000000] -0.751578 0.000000 0.000000 0.659645 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7010018B, 3102157, 0x01000107, 30.1504, -186.363, 0, -0.888264, 0, 0, -0.459334, False, '2025-07-22 13:56:35'); /* Puffball Thrungus */
/* @teleloc 0x01000107 [30.150400 -186.363007 0.000000] -0.888264 0.000000 0.000000 -0.459334 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7010018C, 3102157, 0x01000107, 30.1504, -186.363, 0, -0.888264, 0, 0, -0.459334, False, '2025-07-22 13:56:37'); /* Puffball Thrungus */
/* @teleloc 0x01000107 [30.150400 -186.363007 0.000000] -0.888264 0.000000 0.000000 -0.459334 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7010018D, 3102157, 0x01000107, 26.6721, -187.283, 0, -0.394984, 0, 0, -0.918688, False, '2025-07-22 13:56:39'); /* Puffball Thrungus */
/* @teleloc 0x01000107 [26.672100 -187.283005 0.000000] -0.394984 0.000000 0.000000 -0.918688 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7010018E, 3102157, 0x01000100, 19.3561, -201.351, 0, -0.552652, 0, 0, 0.833412, False, '2025-07-22 13:57:26'); /* Puffball Thrungus */
/* @teleloc 0x01000100 [19.356100 -201.350998 0.000000] -0.552652 0.000000 0.000000 0.833412 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7010018F, 3102157, 0x01000100, 17.1755, -202.544, 0, 0.933782, 0, 0, 0.357843, False, '2025-07-22 13:57:32'); /* Puffball Thrungus */
/* @teleloc 0x01000100 [17.175501 -202.544006 0.000000] 0.933782 0.000000 0.000000 0.357843 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70100190, 3102157, 0x01000100, 18.4267, -200.363, 0, -0.963806, 0, 0, 0.266604, False, '2025-07-22 13:57:35'); /* Puffball Thrungus */
/* @teleloc 0x01000100 [18.426701 -200.363007 0.000000] -0.963806 0.000000 0.000000 0.266604 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70100191, 3102157, 0x01000102, 19.1917, -220.765, 0, -0.056187, 0, 0, 0.99842, False, '2025-07-22 13:57:40'); /* Puffball Thrungus */
/* @teleloc 0x01000102 [19.191700 -220.764999 0.000000] -0.056187 0.000000 0.000000 0.998420 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70100192, 3102157, 0x01000102, 21.3166, -224.477, 0, -0.728297, 0, 0, 0.685262, False, '2025-07-22 13:57:43'); /* Puffball Thrungus */
/* @teleloc 0x01000102 [21.316601 -224.477005 0.000000] -0.728297 0.000000 0.000000 0.685262 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70100193, 3102157, 0x0100010A, 29.2752, -215.074, 0, -0.957904, 0, 0, -0.287089, False, '2025-07-22 13:57:47'); /* Puffball Thrungus */
/* @teleloc 0x0100010A [29.275200 -215.074005 0.000000] -0.957904 0.000000 0.000000 -0.287089 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70100194, 3102157, 0x01000109, 27.1943, -209.734, 0, -0.720232, 0, 0, -0.693733, False, '2025-07-22 13:57:51'); /* Puffball Thrungus */
/* @teleloc 0x01000109 [27.194300 -209.733994 0.000000] -0.720232 0.000000 0.000000 -0.693733 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70100195, 3102157, 0x01000101, 24.7306, -214.311, 0, 0.193667, 0, 0, -0.981067, False, '2025-07-22 13:57:54'); /* Puffball Thrungus */
/* @teleloc 0x01000101 [24.730600 -214.311005 0.000000] 0.193667 0.000000 0.000000 -0.981067 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70100196, 3102157, 0x0100011B, 37.0182, -220.972, 0, 0.642146, 0, 0, -0.766582, False, '2025-07-22 13:57:57'); /* Puffball Thrungus */
/* @teleloc 0x0100011B [37.018200 -220.972000 0.000000] 0.642146 0.000000 0.000000 -0.766582 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70100197, 3102157, 0x0100011B, 37.0182, -220.972, 0, 0.642146, 0, 0, -0.766582, False, '2025-07-22 13:57:59'); /* Puffball Thrungus */
/* @teleloc 0x0100011B [37.018200 -220.972000 0.000000] 0.642146 0.000000 0.000000 -0.766582 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70100198, 3102157, 0x01000125, 46.2112, -217.793, 0, 0.595241, 0, 0, 0.803547, False, '2025-07-22 13:58:03'); /* Puffball Thrungus */
/* @teleloc 0x01000125 [46.211201 -217.792999 0.000000] 0.595241 0.000000 0.000000 0.803547 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70100199, 3102157, 0x01000125, 54.9663, -216.069, 0, 0.561172, 0, 0, -0.827699, False, '2025-07-22 13:59:41'); /* Puffball Thrungus */
/* @teleloc 0x01000125 [54.966301 -216.069000 0.000000] 0.561172 0.000000 0.000000 -0.827699 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7010019A, 3102157, 0x01000126, 48.1068, -233.626, 0, -0.202313, 0, 0, -0.979321, False, '2025-07-22 13:59:46'); /* Puffball Thrungus */
/* @teleloc 0x01000126 [48.106800 -233.626007 0.000000] -0.202313 0.000000 0.000000 -0.979321 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7010019B, 3102157, 0x0100011C, 40.3745, -238.221, 0, -0.981052, 0, 0, -0.193743, False, '2025-07-22 13:59:49'); /* Puffball Thrungus */
/* @teleloc 0x0100011C [40.374500 -238.220993 0.000000] -0.981052 0.000000 0.000000 -0.193743 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7010019C, 3102157, 0x01000120, 38.1669, -250.191, 0, -0.2023, 0, 0, -0.979324, False, '2025-07-22 13:59:52'); /* Puffball Thrungus */
/* @teleloc 0x01000120 [38.166901 -250.190994 0.000000] -0.202300 0.000000 0.000000 -0.979324 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7010019D, 3102157, 0x01000120, 38.1669, -250.191, 0, -0.2023, 0, 0, -0.979324, False, '2025-07-22 13:59:54'); /* Puffball Thrungus */
/* @teleloc 0x01000120 [38.166901 -250.190994 0.000000] -0.202300 0.000000 0.000000 -0.979324 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7010019E, 3102157, 0x01000120, 38.2328, -248.258, 0, 0.999556, 0, 0, -0.029792, False, '2025-07-22 13:59:56'); /* Puffball Thrungus */
/* @teleloc 0x01000120 [38.232800 -248.257996 0.000000] 0.999556 0.000000 0.000000 -0.029792 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7010019F, 3102157, 0x01000120, 38.2328, -248.258, 0, 0.999556, 0, 0, -0.029792, False, '2025-07-22 13:59:59'); /* Puffball Thrungus */
/* @teleloc 0x01000120 [38.232800 -248.257996 0.000000] 0.999556 0.000000 0.000000 -0.029792 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701001A0, 851657, 0x01000102, 22.147, -215.547, 0.055, -0.996799, 0, 0, -0.079952, False, '2025-07-22 14:00:45'); /* The Black Breath */
/* @teleloc 0x01000102 [22.146999 -215.546997 0.055000] -0.996799 0.000000 0.000000 -0.079952 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701001A1, 851657, 0x01000108, 27.1302, -203.708, 0.055, 0.859708, 0, 0, -0.510786, False, '2025-07-22 14:01:30'); /* The Black Breath */
/* @teleloc 0x01000108 [27.130199 -203.707993 0.055000] 0.859708 0.000000 0.000000 -0.510786 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701001A2, 851657, 0x01000113, 43.8039, -194.809, 0.055, 0.772811, 0, 0, -0.634636, False, '2025-07-22 14:01:34'); /* The Black Breath */
/* @teleloc 0x01000113 [43.803902 -194.809006 0.055000] 0.772811 0.000000 0.000000 -0.634636 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701001A3, 851657, 0x01000113, 43.8039, -194.809, 0.055, 0.772811, 0, 0, -0.634636, False, '2025-07-22 14:01:37'); /* The Black Breath */
/* @teleloc 0x01000113 [43.803902 -194.809006 0.055000] 0.772811 0.000000 0.000000 -0.634636 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701001A4, 851657, 0x0100012C, 56.5455, -216.618, 0.055, -0.035477, 0, 0, -0.999371, False, '2025-07-22 14:01:41'); /* The Black Breath */
/* @teleloc 0x0100012C [56.545502 -216.617996 0.055000] -0.035477 0.000000 0.000000 -0.999371 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701001A5, 851657, 0x01000111, 39.889, -174.49, 0.055, 0.976307, 0, 0, 0.21639, False, '2025-07-22 14:01:51'); /* The Black Breath */
/* @teleloc 0x01000111 [39.889000 -174.490005 0.055000] 0.976307 0.000000 0.000000 0.216390 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701001A6, 851657, 0x01000111, 39.889, -174.49, 0.055, 0.976307, 0, 0, 0.21639, False, '2025-07-22 14:01:54'); /* The Black Breath */
/* @teleloc 0x01000111 [39.889000 -174.490005 0.055000] 0.976307 0.000000 0.000000 0.216390 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701001A7, 851657, 0x01000106, 30.8871, -166.192, 0.055, 0.971053, 0, 0, 0.238865, False, '2025-07-22 14:01:56'); /* The Black Breath */
/* @teleloc 0x01000106 [30.887100 -166.192001 0.055000] 0.971053 0.000000 0.000000 0.238865 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701001A8, 851657, 0x01000106, 30.8871, -166.192, 0.055, 0.971053, 0, 0, 0.238865, False, '2025-07-22 14:01:59'); /* The Black Breath */
/* @teleloc 0x01000106 [30.887100 -166.192001 0.055000] 0.971053 0.000000 0.000000 0.238865 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701001A9, 851657, 0x01000103, 30.4569, -163.845, 0.055, 0.997017, 0, 0, 0.077178, False, '2025-07-22 14:02:01'); /* The Black Breath */
/* @teleloc 0x01000103 [30.456900 -163.845001 0.055000] 0.997017 0.000000 0.000000 0.077178 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701001AA, 851657, 0x01000131, 31.5827, -143.832, 6.055, 0.999914, 0, 0, -0.01313, False, '2025-07-22 14:02:08'); /* The Black Breath */
/* @teleloc 0x01000131 [31.582701 -143.832001 6.055000] 0.999914 0.000000 0.000000 -0.013130 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701001AB, 851657, 0x0100013D, 47.1166, -139.764, 6.055, 0.646771, 0, 0, -0.762684, False, '2025-07-22 14:02:13'); /* The Black Breath */
/* @teleloc 0x0100013D [47.116600 -139.764008 6.055000] 0.646771 0.000000 0.000000 -0.762684 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701001AC, 851657, 0x01000140, 51.8759, -150.538, 6.055, 0.64015, 0, 0, -0.76825, False, '2025-07-22 14:02:18'); /* The Black Breath */
/* @teleloc 0x01000140 [51.875900 -150.537994 6.055000] 0.640150 0.000000 0.000000 -0.768250 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701001AD, 851657, 0x01000196, 69.4189, -150.35, 6.055, 0.646044, 0, 0, -0.7633, False, '2025-07-22 14:02:23'); /* The Black Breath */
/* @teleloc 0x01000196 [69.418900 -150.350006 6.055000] 0.646044 0.000000 0.000000 -0.763300 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701001AE, 851657, 0x01000192, 69.8244, -114.073, 6.055, -0.832903, 0, 0, 0.55342, False, '2025-07-22 14:02:33'); /* The Black Breath */
/* @teleloc 0x01000192 [69.824402 -114.072998 6.055000] -0.832903 0.000000 0.000000 0.553420 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701001AF, 851657, 0x01000192, 69.8244, -114.073, 6.055, -0.832903, 0, 0, 0.55342, False, '2025-07-22 14:02:36'); /* The Black Breath */
/* @teleloc 0x01000192 [69.824402 -114.072998 6.055000] -0.832903 0.000000 0.000000 0.553420 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701001B0, 851657, 0x01000194, 69.9012, -133.087, 6.055, 0.113042, 0, 0, 0.99359, False, '2025-07-22 14:02:46'); /* The Black Breath */
/* @teleloc 0x01000194 [69.901199 -133.087006 6.055000] 0.113042 0.000000 0.000000 0.993590 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701001B1, 851657, 0x010001BE, 89.8116, -170.975, 6.055, -0.089956, 0, 0, 0.995946, False, '2025-07-22 14:02:54'); /* The Black Breath */
/* @teleloc 0x010001BE [89.811600 -170.975006 6.055000] -0.089956 0.000000 0.000000 0.995946 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701001B2, 851657, 0x010001BC, 90.1169, -150.159, 6.055, -0.999317, 0, 0, 0.036961, False, '2025-07-22 14:02:58'); /* The Black Breath */
/* @teleloc 0x010001BC [90.116898 -150.158997 6.055000] -0.999317 0.000000 0.000000 0.036961 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701001B3, 851657, 0x010001C5, 111.584, -138.396, 6.055, -0.997003, 0, 0, -0.077366, False, '2025-07-22 14:03:03'); /* The Black Breath */
/* @teleloc 0x010001C5 [111.584000 -138.395996 6.055000] -0.997003 0.000000 0.000000 -0.077366 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701001B4, 851657, 0x010001C1, 110.179, -119.366, 6.055, -0.999597, 0, 0, -0.028404, False, '2025-07-22 14:03:07'); /* The Black Breath */
/* @teleloc 0x010001C1 [110.179001 -119.365997 6.055000] -0.999597 0.000000 0.000000 -0.028404 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701001B5, 851657, 0x010001C1, 110.179, -119.366, 6.055, -0.999597, 0, 0, -0.028404, False, '2025-07-22 14:03:09'); /* The Black Breath */
/* @teleloc 0x010001C1 [110.179001 -119.365997 6.055000] -0.999597 0.000000 0.000000 -0.028404 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701001B6, 851657, 0x010001D5, 135.24, -120.04, 6.055, -0.749481, 0, 0, 0.662027, False, '2025-07-22 14:03:13'); /* The Black Breath */
/* @teleloc 0x010001D5 [135.240005 -120.040001 6.055000] -0.749481 0.000000 0.000000 0.662027 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701001B7, 851657, 0x010001D5, 135.24, -120.04, 6.055, -0.749481, 0, 0, 0.662027, False, '2025-07-22 14:03:15'); /* The Black Breath */
/* @teleloc 0x010001D5 [135.240005 -120.040001 6.055000] -0.749481 0.000000 0.000000 0.662027 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701001B8, 851657, 0x010001FF, 149.706, -135.615, 6.055, 0.096311, 0, 0, 0.995351, False, '2025-07-22 14:03:21'); /* The Black Breath */
/* @teleloc 0x010001FF [149.705994 -135.615005 6.055000] 0.096311 0.000000 0.000000 0.995351 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701001B9, 851657, 0x01000200, 150.014, -147.039, 6.055, -0.422087, 0, 0, 0.906555, False, '2025-07-22 14:03:23'); /* The Black Breath */
/* @teleloc 0x01000200 [150.014008 -147.039001 6.055000] -0.422087 0.000000 0.000000 0.906555 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701001BA, 851657, 0x01000216, 161.048, -149.715, 6.055, -0.642134, 0, 0, 0.766592, False, '2025-07-22 14:03:27'); /* The Black Breath */
/* @teleloc 0x01000216 [161.048004 -149.714996 6.055000] -0.642134 0.000000 0.000000 0.766592 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701001BB, 851657, 0x0100021E, 179.552, -149.89, 6.055, -0.027082, 0, 0, 0.999633, False, '2025-07-22 14:03:31'); /* The Black Breath */
/* @teleloc 0x0100021E [179.552002 -149.889999 6.055000] -0.027082 0.000000 0.000000 0.999633 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701001BC, 851657, 0x01000231, 199.089, -151.016, 6.055, -0.812111, 0, 0, 0.583503, False, '2025-07-22 14:03:35'); /* The Black Breath */
/* @teleloc 0x01000231 [199.089005 -151.016006 6.055000] -0.812111 0.000000 0.000000 0.583503 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701001BD, 851657, 0x01000231, 199.089, -151.016, 6.055, -0.812111, 0, 0, 0.583503, False, '2025-07-22 14:03:37'); /* The Black Breath */
/* @teleloc 0x01000231 [199.089005 -151.016006 6.055000] -0.812111 0.000000 0.000000 0.583503 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701001BE, 851657, 0x01000237, 199.29, -160.417, 6.055, 0.135544, 0, 0, -0.990771, False, '2025-07-22 14:03:41'); /* The Black Breath */
/* @teleloc 0x01000237 [199.289993 -160.417007 6.055000] 0.135544 0.000000 0.000000 -0.990771 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701001BF, 851657, 0x01000237, 199.29, -160.417, 6.055, 0.135544, 0, 0, -0.990771, False, '2025-07-22 14:03:44'); /* The Black Breath */
/* @teleloc 0x01000237 [199.289993 -160.417007 6.055000] 0.135544 0.000000 0.000000 -0.990771 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701001C0, 851657, 0x01000244, 221.096, -151.074, 6.055, 0.995124, 0, 0, -0.098632, False, '2025-07-22 14:03:51'); /* The Black Breath */
/* @teleloc 0x01000244 [221.095993 -151.074005 6.055000] 0.995124 0.000000 0.000000 -0.098632 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701001C1, 851657, 0x01000282, 250.121, -136.533, 12.055, 0.999979, 0, 0, -0.006499, False, '2025-07-22 14:03:56'); /* The Black Breath */
/* @teleloc 0x01000282 [250.121002 -136.533005 12.055000] 0.999979 0.000000 0.000000 -0.006499 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701001C2, 851657, 0x01000278, 243.098, -131.669, 12.055, 0.793899, 0, 0, 0.60805, False, '2025-07-22 14:04:00'); /* The Black Breath */
/* @teleloc 0x01000278 [243.098007 -131.669006 12.055000] 0.793899 0.000000 0.000000 0.608050 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701001C3, 851657, 0x01000270, 228.594, -129.806, 12.055, 0.768703, 0, 0, 0.639606, False, '2025-07-22 14:04:04'); /* The Black Breath */
/* @teleloc 0x01000270 [228.593994 -129.806000 12.055000] 0.768703 0.000000 0.000000 0.639606 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701001C4, 851657, 0x0100026D, 229.31, -97.907, 12.055, 0.99996, 0, 0, -0.0089, False, '2025-07-22 14:04:08'); /* The Black Breath */
/* @teleloc 0x0100026D [229.309998 -97.906998 12.055000] 0.999960 0.000000 0.000000 -0.008900 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701001C5, 851657, 0x0100026D, 229.31, -97.907, 12.055, 0.99996, 0, 0, -0.0089, False, '2025-07-22 14:04:10'); /* The Black Breath */
/* @teleloc 0x0100026D [229.309998 -97.906998 12.055000] 0.999960 0.000000 0.000000 -0.008900 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701001C6, 851657, 0x0100027E, 246.645, -89.6538, 12.055, 0.82978, 0, 0, -0.558091, False, '2025-07-22 14:04:13'); /* The Black Breath */
/* @teleloc 0x0100027E [246.645004 -89.653801 12.055000] 0.829780 0.000000 0.000000 -0.558091 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701001C7, 851657, 0x01000275, 236.079, -82.5418, 12.055, 0.891379, 0, 0, 0.453258, False, '2025-07-22 14:04:16'); /* The Black Breath */
/* @teleloc 0x01000275 [236.078995 -82.541801 12.055000] 0.891379 0.000000 0.000000 0.453258 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701001C8, 851657, 0x01000267, 222.103, -85.2746, 12.055, 0.450401, 0, 0, 0.892827, False, '2025-07-22 14:04:19'); /* The Black Breath */
/* @teleloc 0x01000267 [222.102997 -85.274597 12.055000] 0.450401 0.000000 0.000000 0.892827 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701001C9, 851657, 0x0100026A, 228.253, -74.2781, 12.055, -0.988547, 0, 0, 0.150912, False, '2025-07-22 14:04:23'); /* The Black Breath */
/* @teleloc 0x0100026A [228.253006 -74.278099 12.055000] -0.988547 0.000000 0.000000 0.150912 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701001CA, 851657, 0x0100025E, 201.106, -130.544, 12.055, 0.316022, 0, 0, 0.948752, False, '2025-07-22 14:04:38'); /* The Black Breath */
/* @teleloc 0x0100025E [201.106003 -130.544006 12.055000] 0.316022 0.000000 0.000000 0.948752 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701001CB, 851657, 0x01000454, 178.672, -139.547, 18.055, 0.755951, 0, 0, 0.654628, False, '2025-07-22 14:04:43'); /* The Black Breath */
/* @teleloc 0x01000454 [178.671997 -139.546997 18.055000] 0.755951 0.000000 0.000000 0.654628 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701001CC, 851657, 0x01000451, 161.077, -140.47, 18.055, 0.785348, 0, 0, 0.619055, False, '2025-07-22 14:04:47'); /* The Black Breath */
/* @teleloc 0x01000451 [161.076996 -140.470001 18.055000] 0.785348 0.000000 0.000000 0.619055 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701001CD, 851657, 0x01000440, 148.498, -133.842, 18.055, 0.741612, 0, 0, 0.670829, False, '2025-07-22 14:04:51'); /* The Black Breath */
/* @teleloc 0x01000440 [148.498001 -133.841995 18.055000] 0.741612 0.000000 0.000000 0.670829 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701001CE, 851657, 0x01000440, 148.498, -133.842, 18.055, 0.741612, 0, 0, 0.670829, False, '2025-07-22 14:04:54'); /* The Black Breath */
/* @teleloc 0x01000440 [148.498001 -133.841995 18.055000] 0.741612 0.000000 0.000000 0.670829 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701001CF, 851657, 0x01000432, 135.187, -140.048, 18.055, 0.161217, 0, 0, 0.986919, False, '2025-07-22 14:04:57'); /* The Black Breath */
/* @teleloc 0x01000432 [135.186996 -140.048004 18.055000] 0.161217 0.000000 0.000000 0.986919 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701001D0, 851657, 0x01000432, 135.187, -140.048, 18.055, 0.161217, 0, 0, 0.986919, False, '2025-07-22 14:05:00'); /* The Black Breath */
/* @teleloc 0x01000432 [135.186996 -140.048004 18.055000] 0.161217 0.000000 0.000000 0.986919 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701001D1, 851657, 0x01000434, 136.876, -155.442, 18.055, -0.201109, 0, 0, 0.979569, False, '2025-07-22 14:05:03'); /* The Black Breath */
/* @teleloc 0x01000434 [136.876007 -155.442001 18.055000] -0.201109 0.000000 0.000000 0.979569 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701001D2, 851657, 0x01000443, 149.444, -159.726, 18.055, -0.861419, 0, 0, 0.507895, False, '2025-07-22 14:05:06'); /* The Black Breath */
/* @teleloc 0x01000443 [149.444000 -159.725998 18.055000] -0.861419 0.000000 0.000000 0.507895 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701001D3, 851657, 0x01000445, 145.134, -179.975, 18.055, 0.621732, 0, 0, -0.78323, False, '2025-07-22 14:05:14'); /* The Black Breath */
/* @teleloc 0x01000445 [145.134003 -179.975006 18.055000] 0.621732 0.000000 0.000000 -0.783230 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701001D4, 851657, 0x01000447, 147.896, -188.186, 18.055, -0.528575, 0, 0, -0.848887, False, '2025-07-22 14:05:18'); /* The Black Breath */
/* @teleloc 0x01000447 [147.895996 -188.186005 18.055000] -0.528575 0.000000 0.000000 -0.848887 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701001D5, 851657, 0x0100043A, 140.491, -194.184, 18.055, -0.149152, 0, 0, -0.988814, False, '2025-07-22 14:05:21'); /* The Black Breath */
/* @teleloc 0x0100043A [140.490997 -194.184006 18.055000] -0.149152 0.000000 0.000000 -0.988814 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701001D6, 851657, 0x0100043A, 140.491, -194.184, 18.055, -0.149152, 0, 0, -0.988814, False, '2025-07-22 14:05:24'); /* The Black Breath */
/* @teleloc 0x0100043A [140.490997 -194.184006 18.055000] -0.149152 0.000000 0.000000 -0.988814 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701001D7, 851657, 0x01000430, 132.779, -199.522, 18.055, -0.646936, 0, 0, -0.762545, False, '2025-07-22 14:05:26'); /* The Black Breath */
/* @teleloc 0x01000430 [132.779007 -199.522003 18.055000] -0.646936 0.000000 0.000000 -0.762545 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701001D8, 851657, 0x0100025C, 150.255, -239.473, 12.055, -0.999348, 0, 0, 0.036101, False, '2025-07-22 14:05:38'); /* The Black Breath */
/* @teleloc 0x0100025C [150.255005 -239.473007 12.055000] -0.999348 0.000000 0.000000 0.036101 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701001D9, 851657, 0x01000425, 117.539, -169.295, 18.055, -0.940214, 0, 0, -0.340584, False, '2025-07-22 14:05:49'); /* The Black Breath */
/* @teleloc 0x01000425 [117.539001 -169.294998 18.055000] -0.940214 0.000000 0.000000 -0.340584 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701001DA, 851657, 0x01000423, 97.3164, -168.731, 18.055, -0.965882, 0, 0, -0.258983, False, '2025-07-22 14:05:55'); /* The Black Breath */
/* @teleloc 0x01000423 [97.316399 -168.731003 18.055000] -0.965882 0.000000 0.000000 -0.258983 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701001DB, 851657, 0x0100041B, 94.4531, -153.073, 18.055, -0.984635, 0, 0, 0.174623, False, '2025-07-22 14:05:58'); /* The Black Breath */
/* @teleloc 0x0100041B [94.453102 -153.072998 18.055000] -0.984635 0.000000 0.000000 0.174623 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701001DC, 851657, 0x0100041B, 94.4531, -153.073, 18.055, -0.984635, 0, 0, 0.174623, False, '2025-07-22 14:06:01'); /* The Black Breath */
/* @teleloc 0x0100041B [94.453102 -153.072998 18.055000] -0.984635 0.000000 0.000000 0.174623 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701001DD, 851657, 0x010003F0, 79.6988, -170.94, 18.055, 0.040669, 0, 0, -0.999173, False, '2025-07-22 14:06:08'); /* The Black Breath */
/* @teleloc 0x010003F0 [79.698799 -170.940002 18.055000] 0.040669 0.000000 0.000000 -0.999173 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701001DE, 851657, 0x010003F4, 79.8463, -179.67, 18.055, -0.080385, 0, 0, -0.996764, False, '2025-07-22 14:06:12'); /* The Black Breath */
/* @teleloc 0x010003F4 [79.846298 -179.669998 18.055000] -0.080385 0.000000 0.000000 -0.996764 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701001DF, 851657, 0x010003FC, 80.1818, -199.725, 18.055, -0.020366, 0, 0, -0.999793, False, '2025-07-22 14:06:16'); /* The Black Breath */
/* @teleloc 0x010003FC [80.181801 -199.725006 18.055000] -0.020366 0.000000 0.000000 -0.999793 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701001E0, 851657, 0x010003C8, 69.929, -222.459, 18.055, -0.460056, 0, 0, -0.88789, False, '2025-07-22 14:06:21'); /* The Black Breath */
/* @teleloc 0x010003C8 [69.929001 -222.459000 18.055000] -0.460056 0.000000 0.000000 -0.887890 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701001E1, 851657, 0x010003CE, 69.6841, -239.016, 18.055, -0.04919, 0, 0, -0.998789, False, '2025-07-22 14:06:25'); /* The Black Breath */
/* @teleloc 0x010003CE [69.684097 -239.016006 18.055000] -0.049190 0.000000 0.000000 -0.998789 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701001E2, 851657, 0x0100032C, 48.973, -241.189, 18.055, -0.004979, 0, 0, -0.999988, False, '2025-07-22 14:06:30'); /* The Black Breath */
/* @teleloc 0x0100032C [48.973000 -241.188995 18.055000] -0.004979 0.000000 0.000000 -0.999988 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701001E3, 851657, 0x01000335, 50.2106, -260.929, 18.055, 0.069964, 0, 0, -0.99755, False, '2025-07-22 14:06:35'); /* The Black Breath */
/* @teleloc 0x01000335 [50.210602 -260.928986 18.055000] 0.069964 0.000000 0.000000 -0.997550 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701001E4, 851657, 0x0100033F, 51.477, -280.226, 18.055, 0.040682, 0, 0, -0.999172, False, '2025-07-22 14:06:40'); /* The Black Breath */
/* @teleloc 0x0100033F [51.477001 -280.226013 18.055000] 0.040682 0.000000 0.000000 -0.999172 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701001E5, 851657, 0x01000349, 49.8656, -311.694, 18.055, 0.052205, 0, 0, -0.998636, False, '2025-07-22 14:06:44'); /* The Black Breath */
/* @teleloc 0x01000349 [49.865601 -311.694000 18.055000] 0.052205 0.000000 0.000000 -0.998636 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701001E6, 851657, 0x01000300, 40.8682, -321.341, 18.055, -0.88611, 0, 0, -0.463476, False, '2025-07-22 14:06:52'); /* The Black Breath */
/* @teleloc 0x01000300 [40.868198 -321.341003 18.055000] -0.886110 0.000000 0.000000 -0.463476 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701001E7, 851657, 0x010002A3, 21.9088, -317.229, 18.055, -0.728611, 0, 0, -0.684928, False, '2025-07-22 14:06:57'); /* The Black Breath */
/* @teleloc 0x010002A3 [21.908800 -317.229004 18.055000] -0.728611 0.000000 0.000000 -0.684928 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701001E8, 851657, 0x0100028B, 14.3313, -328.613, 18.055, 0.337057, 0, 0, -0.941484, False, '2025-07-22 14:07:02'); /* The Black Breath */
/* @teleloc 0x0100028B [14.331300 -328.613007 18.055000] 0.337057 0.000000 0.000000 -0.941484 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701001E9, 851657, 0x01000286, 9.926, -287.763, 18.055, 0.891088, 0, 0, 0.45383, False, '2025-07-22 14:07:07'); /* The Black Breath */
/* @teleloc 0x01000286 [9.926000 -287.763000 18.055000] 0.891088 0.000000 0.000000 0.453830 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701001EA, 851657, 0x01000467, 9.15059, -245.15, 24.055, 0.310864, 0, 0, 0.950454, False, '2025-07-22 14:07:28'); /* The Black Breath */
/* @teleloc 0x01000467 [9.150590 -245.149994 24.055000] 0.310864 0.000000 0.000000 0.950454 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701001EB, 851657, 0x01000467, 9.15059, -245.15, 24.055, 0.310864, 0, 0, 0.950454, False, '2025-07-22 14:07:31'); /* The Black Breath */
/* @teleloc 0x01000467 [9.150590 -245.149994 24.055000] 0.310864 0.000000 0.000000 0.950454 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701001EC, 851657, 0x01000463, 3.47017, -251.464, 24.055, -0.06702, 0, 0, 0.997752, False, '2025-07-22 14:07:34'); /* The Black Breath */
/* @teleloc 0x01000463 [3.470170 -251.464005 24.055000] -0.067020 0.000000 0.000000 0.997752 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701001ED, 851657, 0x01000470, 16.4767, -257.011, 24.055, -0.828912, 0, 0, 0.559379, False, '2025-07-22 14:07:39'); /* The Black Breath */
/* @teleloc 0x01000470 [16.476700 -257.010986 24.055000] -0.828912 0.000000 0.000000 0.559379 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701001EE, 851657, 0x01000470, 16.4767, -257.011, 24.055, -0.828912, 0, 0, 0.559379, False, '2025-07-22 14:07:42'); /* The Black Breath */
/* @teleloc 0x01000470 [16.476700 -257.010986 24.055000] -0.828912 0.000000 0.000000 0.559379 */
