DELETE FROM `landblock_instance` WHERE `landblock` = 0xAFC6;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7AFC6001,  1314, 0xAFC60134, 89.6809, 58.9505, 120.005, 0.99989, 0, 0, -0.014846, False, '2005-02-09 10:00:00'); /* Book Shelf */
/* @teleloc 0xAFC60134 [89.680901 58.950500 120.004997] 0.999890 0.000000 0.000000 -0.014846 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7AFC6002,  1938, 0xAFC60134, 89.0876, 54.8306, 120.005, -0.711031, 0, 0, -0.70316, False, '2005-02-09 10:00:00'); /* Chest */
/* @teleloc 0xAFC60134 [89.087601 54.830601 120.004997] -0.711031 0.000000 0.000000 -0.703160 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7AFC6003,  5623, 0xAFC60000, 134.194, 65.5493, 120.082, 0, 0, 0, -1, False, '2005-02-09 10:00:00'); /* Door */
/* @teleloc 0xAFC60000 [134.194000 65.549301 120.082001] 0.000000 0.000000 0.000000 -1.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7AFC6004,  5623, 0xAFC60000, 40.7015, 86.2949, 120.082, -0.710102, 0, 0, -0.704099, False, '2005-02-09 10:00:00'); /* Door */
/* @teleloc 0xAFC60000 [40.701500 86.294899 120.082001] -0.710102 0.000000 0.000000 -0.704099 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7AFC6005,  1930, 0xAFC60122, 36.9134, 91.5502, 123.005, 0.999952, 0, 0, -0.009822, False, '2005-02-09 10:00:00'); /* Chest */
/* @teleloc 0xAFC60122 [36.913399 91.550201 123.004997] 0.999952 0.000000 0.000000 -0.009822 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7AFC6007,  5623, 0xAFC60000, 129.604, 60.6331, 120.082, 0.698265, 0, 0, -0.715839, False, '2005-02-09 10:00:00'); /* Door */
/* @teleloc 0xAFC60000 [129.604004 60.633099 120.082001] 0.698265 0.000000 0.000000 -0.715839 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7AFC6008,  1547, 0xAFC6015C, 102.548, 63.3117, 116.005, -0.999817, 0, 0, -0.019142, False, '2005-02-09 10:00:00'); /* Colier Mine */
/* @teleloc 0xAFC6015C [102.547997 63.311699 116.004997] -0.999817 0.000000 0.000000 -0.019142 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7AFC6009,  6441, 0xAFC60000, 53.7941, 49.1347, 120.005, -0.999143, 0, 0, -0.041393, False, '2005-02-09 10:00:00'); /* Well */
/* @teleloc 0xAFC60000 [53.794102 49.134701 120.004997] -0.999143 0.000000 0.000000 -0.041393 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7AFC600B,  1922, 0xAFC6010C, 137.479, 60.118, 123.005, 0.01948, 0, 0, 0.99981, False, '2005-02-09 10:00:00'); /* Chest */
/* @teleloc 0xAFC6010C [137.479004 60.118000 123.004997] 0.019480 0.000000 0.000000 0.999810 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7AFC6013,  1930, 0xAFC60150, 103.185, 9.88465, 126.005, 0.348438, 0, 0, -0.937332, False, '2005-02-09 10:00:00'); /* Chest */
/* @teleloc 0xAFC60150 [103.184998 9.884650 126.004997] 0.348438 0.000000 0.000000 -0.937332 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7AFC6021,  1915, 0xAFC6014B, 101.103, 12.2321, 120.005, -0.393996, 0, 0, -0.919112, False, '2005-02-09 10:00:00'); /* Chest */
/* @teleloc 0xAFC6014B [101.102997 12.232100 120.004997] -0.393996 0.000000 0.000000 -0.919112 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7AFC6023,  5623, 0xAFC60000, 34.1814, 94.147, 120.082, 0, 0, 0, -1, False, '2005-02-09 10:00:00'); /* Door */
/* @teleloc 0xAFC60000 [34.181400 94.147003 120.082001] 0.000000 0.000000 0.000000 -1.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7AFC6024,   509, 0xAFC60003, 4.4921, 52.5725, 120, 0.263672, 0, 0, 0.964612, False, '2025-07-29 01:43:17'); /* Life Stone */
/* @teleloc 0xAFC60003 [4.492100 52.572498 120.000000] 0.263672 0.000000 0.000000 0.964612 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7AFC6026, 86653868, 0xAFC6001D, 77.6966, 110.786, 120.007, 0.022452, 0, 0, -0.999748, False, '2025-07-29 01:54:35'); /* Bael'Zharon */
/* @teleloc 0xAFC6001D [77.696602 110.786003 120.007004] 0.022452 0.000000 0.000000 -0.999748 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7AFC6027, 86653870, 0xAFC6002C, 125.148, 86.1483, 119.988, -0.690837, 0, 0, -0.72301, False, '2025-07-29 01:55:02'); /* Asheron */
/* @teleloc 0xAFC6002C [125.148003 86.148300 119.987999] -0.690837 0.000000 0.000000 -0.723010 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7AFC6029, 129609, 0xAFC6001E, 76.0672, 134.845, 119.937, 0.001279, 0, 0, -0.999999, False, '2025-07-29 01:56:49'); /* Sanctum of Greatness */
/* @teleloc 0xAFC6001E [76.067200 134.845001 119.936996] 0.001279 0.000000 0.000000 -0.999999 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7AFC602A, 129611, 0xAFC6001E, 82.1069, 134.861, 119.937, 0.001279, 0, 0, -0.999999, False, '2025-07-29 01:56:59'); /* Sanctum of Honor */
/* @teleloc 0xAFC6001E [82.106903 134.860992 119.936996] 0.001279 0.000000 0.000000 -0.999999 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7AFC602B, 129612, 0xAFC6001E, 86.7233, 134.873, 119.937, 0.001279, 0, 0, -0.999999, False, '2025-07-29 01:57:08'); /* Sanctum of Valor */
/* @teleloc 0xAFC6001E [86.723297 134.873001 119.936996] 0.001279 0.000000 0.000000 -0.999999 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7AFC602C, 129613, 0xAFC6001E, 92.0958, 134.886, 119.937, 0.001279, 0, 0, -0.999999, False, '2025-07-29 01:57:16'); /* Sanctum of Glory */
/* @teleloc 0xAFC6001E [92.095802 134.886002 119.936996] 0.001279 0.000000 0.000000 -0.999999 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7AFC602F, 423481288, 0xAFC6002C, 123.87, 91.9911, 119.937, -0.680767, 0, 0, -0.7325, False, '2025-07-29 02:00:16'); /* Portal to Ravaged Island */
/* @teleloc 0xAFC6002C [123.870003 91.991096 119.936996] -0.680767 0.000000 0.000000 -0.732500 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7AFC6039, 251000, 0xAFC60011, 59.5368, 19.2443, 119.541, 0.263025, 0, 0, 0.964789, False, '2025-07-29 02:05:47'); /* Vault of Inverted Light */
/* @teleloc 0xAFC60011 [59.536800 19.244301 119.541000] 0.263025 0.000000 0.000000 0.964789 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7AFC603B, 43065, 0xAFC6000D, 37.1793, 102.259, 119.937, 0.773083, 0, 0, 0.634304, False, '2025-07-29 02:08:31'); /* Portal to Town Network */
/* @teleloc 0xAFC6000D [37.179298 102.259003 119.936996] 0.773083 0.000000 0.000000 0.634304 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7AFC603C, 42851, 0xAFC60002, 20.6347, 45.8485, 119.657, -0.645503, 0, 0, -0.763758, False, '2025-07-29 02:08:49'); /* Facility Hub Portal */
/* @teleloc 0xAFC60002 [20.634701 45.848499 119.656998] -0.645503 0.000000 0.000000 -0.763758 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7AFC603D, 51962, 0xAFC60023, 105.281, 69.3082, 120.005, 0.942474, 0, 0, 0.334278, False, '2025-07-29 02:14:23'); /* John */
/* @teleloc 0xAFC60023 [105.280998 69.308197 120.004997] 0.942474 0.000000 0.000000 0.334278 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7AFC603F, 5000876, 0xAFC60153, 111.608, 67.7325, 120.005, -0.023459, 0, 0, 0.999725, False, '2025-07-29 02:16:01'); /* lvl 50 Defense of Zaikhal Warden */
/* @teleloc 0xAFC60153 [111.608002 67.732498 120.004997] -0.023459 0.000000 0.000000 0.999725 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7AFC6040, 5000875, 0xAFC60153, 112.846, 66.1061, 120.005, 0.707107, 0, 0, 0.707107, False, '2025-07-29 02:16:10'); /* lvl 50 Healers Heart Warden */
/* @teleloc 0xAFC60153 [112.846001 66.106102 120.004997] 0.707107 0.000000 0.000000 0.707107 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7AFC6041, 5000874, 0xAFC60153, 112.881, 64.4416, 120.005, 0.707107, 0, 0, 0.707107, False, '2025-07-29 02:16:17'); /* lvl 50 Flag Warden */
/* @teleloc 0xAFC60153 [112.880997 64.441597 120.004997] 0.707107 0.000000 0.000000 0.707107 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7AFC6042, 5000873, 0xAFC60153, 112.888, 62.9434, 120.005, 0.707107, 0, 0, 0.707107, False, '2025-07-29 02:16:25'); /* lvl 50 ElariWood Bow Warden */
/* @teleloc 0xAFC60153 [112.888000 62.943401 120.004997] 0.707107 0.000000 0.000000 0.707107 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7AFC6043, 5000871, 0xAFC60153, 104.608, 57.7804, 120.005, 0.725118, 0, 0, -0.688625, False, '2025-07-29 02:17:18'); /* lvl 50 Arcane Pedestal Warden */
/* @teleloc 0xAFC60153 [104.608002 57.780399 120.004997] 0.725118 0.000000 0.000000 -0.688625 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7AFC6044, 5000880, 0xAFC60153, 104.557, 60.2391, 120.005, 0.725118, 0, 0, -0.688625, False, '2025-07-29 02:17:34'); /* lvl 60 Phantom Weapons Warden */
/* @teleloc 0xAFC60153 [104.556999 60.239101 120.004997] 0.725118 0.000000 0.000000 -0.688625 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7AFC6045, 5000872, 0xAFC60153, 105.403, 66.8951, 120.005, 0.005387, 0, 0, 0.999986, False, '2025-07-29 02:18:16'); /* lvl 50 Bandit Shield Warden */
/* @teleloc 0xAFC60153 [105.403000 66.895103 120.004997] 0.005387 0.000000 0.000000 0.999986 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7AFC6046, 5000879, 0xAFC60157, 108.744, 51.0546, 120.005, -0.999992, 0, 0, 0.004072, False, '2025-07-29 02:18:59'); /* lvl 60 Jade Spear Warden */
/* @teleloc 0xAFC60157 [108.744003 51.054600 120.004997] -0.999992 0.000000 0.000000 0.004072 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7AFC6047, 5000877, 0xAFC60153, 111.233, 57.2893, 120.005, 0.870328, 0, 0, 0.492473, False, '2025-07-29 02:19:12'); /* lvl 60 Aegis Warden */
/* @teleloc 0xAFC60153 [111.233002 57.289299 120.004997] 0.870328 0.000000 0.000000 0.492473 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7AFC6049, 5000878, 0xAFC60161, 110.67, 51.9476, 123.005, 0.999942, 0, 0, -0.010733, False, '2025-07-29 02:19:38'); /* lvl 60 Heart of Innocence Warden */
/* @teleloc 0xAFC60161 [110.669998 51.947601 123.004997] 0.999942 0.000000 0.000000 -0.010733 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7AFC604A, 5000883, 0xAFC60161, 103.806, 52.5015, 123.005, 0.917213, 0, 0, -0.398397, False, '2025-07-29 02:19:49'); /* lvl 80 Simulacra Warden */
/* @teleloc 0xAFC60161 [103.806000 52.501499 123.004997] 0.917213 0.000000 0.000000 -0.398397 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7AFC604B, 5000882, 0xAFC6015F, 111.802, 62.4409, 123.005, 0.705942, 0, 0, 0.70827, False, '2025-07-29 02:20:01'); /* lvl 80 Drudge Aviator Warden */
/* @teleloc 0xAFC6015F [111.802002 62.440899 123.004997] 0.705942 0.000000 0.000000 0.708270 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7AFC605A, 50090867, 0xAFC60100, 31.0851, 66.0565, 120.005, 0.462952, 0, 0, -0.886384, False, '2025-07-29 02:32:53'); /* Doctor Kavorkian the Healer */
/* @teleloc 0xAFC60100 [31.085100 66.056503 120.004997] 0.462952 0.000000 0.000000 -0.886384 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7AFC605B,   809, 0xAFC60120, 29.3406, 92.1688, 120.005, -0.498529, 0, 0, 0.866873, False, '2025-07-29 02:37:46'); /* Master Sonji Pan, Archmage */
/* @teleloc 0xAFC60120 [29.340599 92.168800 120.004997] -0.498529 0.000000 0.000000 0.866873 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7AFC605C, 38460, 0xAFC60126, 80.6045, 64.783, 120.005, -0.705881, 0, 0, -0.708331, False, '2025-07-29 02:38:24'); /* Arcanum Broker */
/* @teleloc 0xAFC60126 [80.604500 64.782997 120.004997] -0.705881 0.000000 0.000000 -0.708331 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7AFC605D,   712, 0xAFC60126, 87.8677, 63.4836, 120.005, -0.782056, 0, 0, 0.623208, False, '2025-07-29 02:50:38'); /* Sedor Wystan the Blacksmith */
/* @teleloc 0xAFC60126 [87.867699 63.483601 120.004997] -0.782056 0.000000 0.000000 0.623208 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7AFC605F, 86653855, 0xAFC6000D, 37.3546, 104.129, 120.055, 0.796157, 0, 0, 0.605091, False, '2025-07-29 02:53:50'); /* PILLAR3 */
/* @teleloc 0xAFC6000D [37.354599 104.128998 120.055000] 0.796157 0.000000 0.000000 0.605091 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7AFC6060, 86653855, 0xAFC6000D, 36.7878, 100.287, 120.055, 0.768409, 0, 0, 0.639959, False, '2025-07-29 02:53:56'); /* PILLAR3 */
/* @teleloc 0xAFC6000D [36.787800 100.287003 120.055000] 0.768409 0.000000 0.000000 0.639959 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7AFC6067, 29503, 0xAFC6001C, 87.2816, 73.3022, 119.937, 0.954291, 0, 0, 0.298878, False, '2025-07-29 03:01:20'); /* Nexus Gambling Den */
/* @teleloc 0xAFC6001C [87.281601 73.302200 119.936996] 0.954291 0.000000 0.000000 0.298878 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7AFC6068, 128192777, 0xAFC6001C, 89.1286, 75.5327, 120.055, -0.922126, 0, 0, -0.38689, False, '2025-07-29 03:02:04'); /* Treasure Pile */
/* @teleloc 0xAFC6001C [89.128601 75.532700 120.055000] -0.922126 0.000000 0.000000 -0.386890 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7AFC6069, 128192777, 0xAFC6001B, 84.7168, 71.8892, 120.055, 0.997235, 0, 0, 0.074309, False, '2025-07-29 03:02:15'); /* Treasure Pile */
/* @teleloc 0xAFC6001B [84.716797 71.889198 120.055000] 0.997235 0.000000 0.000000 0.074309 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7AFC606A, 42429, 0xAFC6014B, 103.307, 11.0105, 120.005, 0.914673, 0, 0, -0.404194, False, '2025-07-29 03:04:52'); /* Iqbal */
/* @teleloc 0xAFC6014B [103.306999 11.010500 120.004997] 0.914673 0.000000 0.000000 -0.404194 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7AFC606B,  1047, 0xAFC6014B, 104.47, 10.1714, 120.005, 0.946496, 0, 0, -0.322716, False, '2025-07-29 03:05:21'); /* Arlad ibn Mulud the Tailor */
/* @teleloc 0xAFC6014B [104.470001 10.171400 120.004997] 0.946496 0.000000 0.000000 -0.322716 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7AFC606C, 23032, 0xAFC6000D, 39.0881, 109.077, 119.937, 0.84827, 0, 0, 0.529564, False, '2025-07-29 03:25:42'); /* The Marketplace of Dereth */
/* @teleloc 0xAFC6000D [39.088100 109.077003 119.936996] 0.848270 0.000000 0.000000 0.529564 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7AFC606E, 14923, 0xAFC60014, 63.9932, 87.0837, 120.005, -0.875779, 0, 0, -0.482713, False, '2025-07-30 05:09:12'); /* Clerk of Nexus Deeds  */
/* @teleloc 0xAFC60014 [63.993198 87.083702 120.004997] -0.875779 0.000000 0.000000 -0.482713 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7AFC6072,   411, 0xAFC60118, 33.6963, 29.2765, 120.005, 0.97785, 0, 0, -0.209308, False, '2025-07-31 17:12:28'); /* Fisana the Jeweler */
/* @teleloc 0xAFC60118 [33.696301 29.276501 120.004997] 0.977850 0.000000 0.000000 -0.209308 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7AFC6073, 44076, 0xAFC60140, 90.2335, 109.479, 119.205, -0.999885, 0, 0, -0.015195, False, '2025-07-31 17:13:05'); /* Laurana */
/* @teleloc 0xAFC60140 [90.233498 109.478996 119.205002] -0.999885 0.000000 0.000000 -0.015195 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7AFC6074, 53385, 0xAFC60029, 126.391, 16.0051, 120.003, 0.707897, 0, 0, 0.706316, False, '2025-07-31 17:19:27'); /* Professor of Void Magic */
/* @teleloc 0xAFC60029 [126.390999 16.005100 120.002998] 0.707897 0.000000 0.000000 0.706316 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7AFC6075, 53381, 0xAFC60029, 126.48, 13.9174, 120.005, -0.733661, 0, 0, -0.679515, False, '2025-07-31 17:19:48'); /* Professor of War Magic */
/* @teleloc 0xAFC60029 [126.480003 13.917400 120.004997] -0.733661 0.000000 0.000000 -0.679515 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7AFC6077, 53383, 0xAFC60029, 126.437, 10.251, 120.005, -0.716446, 0, 0, -0.697643, False, '2025-07-31 17:20:16'); /* Professor of Item Magic */
/* @teleloc 0xAFC60029 [126.436996 10.251000 120.004997] -0.716446 0.000000 0.000000 -0.697643 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7AFC6078, 53382, 0xAFC60029, 126.4, 8.8666, 120.005, -0.716446, 0, 0, -0.697643, False, '2025-07-31 17:20:28'); /* Professor of Creature Magic */
/* @teleloc 0xAFC60029 [126.400002 8.866600 120.004997] -0.716446 0.000000 0.000000 -0.697643 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7AFC6079, 20213, 0xAFC60143, 135.094, 13.0994, 120.005, 0.731788, 0, 0, 0.681532, False, '2025-07-31 17:36:06'); /* Journeyman Scrivener of Item Magic */
/* @teleloc 0xAFC60143 [135.093994 13.099400 120.004997] 0.731788 0.000000 0.000000 0.681532 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7AFC607A, 20214, 0xAFC60143, 135.231, 15.0259, 120.005, 0.731788, 0, 0, 0.681532, False, '2025-07-31 17:36:11'); /* Scrivener of Item Magic */
/* @teleloc 0xAFC60143 [135.231003 15.025900 120.004997] 0.731788 0.000000 0.000000 0.681532 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7AFC607C, 46424, 0xAFC6000A, 41.5369, 39.0589, 120.005, -0.850627, 0, 0, 0.525769, False, '2025-07-31 21:40:02'); /* Monroe */
/* @teleloc 0xAFC6000A [41.536900 39.058899 120.004997] -0.850627 0.000000 0.000000 0.525769 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7AFC607D, 46425, 0xAFC6000A, 40.1306, 41.8721, 120.005, -0.850627, 0, 0, 0.525769, False, '2025-07-31 21:40:07'); /* Marid */
/* @teleloc 0xAFC6000A [40.130600 41.872101 120.004997] -0.850627 0.000000 0.000000 0.525769 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7AFC607E, 53384, 0xAFC60029, 126.489, 12.0784, 120.005, -0.736275, 0, 0, -0.676683, False, '2025-08-01 12:52:05'); /* Professor of Life Magic */
/* @teleloc 0xAFC60029 [126.488998 12.078400 120.004997] -0.736275 0.000000 0.000000 -0.676683 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7AFC6081, 33596, 0xAFC60014, 65.3412, 84.4227, 120.005, -0.608456, 0, 0, 0.793588, False, '2025-08-01 16:38:42'); /* Pathwarden Thorolf */
/* @teleloc 0xAFC60014 [65.341202 84.422699 120.004997] -0.608456 0.000000 0.000000 0.793588 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7AFC6082, 33611, 0xAFC60014, 66.472, 85.5357, 120, 0.896266, 0, 0, 0.443516, False, '2025-08-01 16:53:09'); /* Nexus Pathwarden Chest */
/* @teleloc 0xAFC60014 [66.472000 85.535698 120.000000] 0.896266 0.000000 0.000000 0.443516 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7AFC6084, 66611666, 0xAFC60026, 98.3651, 134.565, 120.437, 0.99722, 0, 0, -0.074517, False, '2025-08-03 19:43:09'); /* Sanctum of Chaos */
/* @teleloc 0xAFC60026 [98.365097 134.565002 120.436996] 0.997220 0.000000 0.000000 -0.074517 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7AFC6087, 999999, 0xAFC60014, 67.121, 86.8681, 120.005, -0.833652, 0, 0, 0.55229, False, '2025-08-04 23:56:38'); /* Maggie the Jack Cat */
/* @teleloc 0xAFC60014 [67.121002 86.868103 120.004997] -0.833652 0.000000 0.000000 0.552290 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7AFC6089, 91332772, 0xAFC60025, 112.4, 118.201, 119.937, 0.421931, 0, 0, 0.906628, False, '2025-08-06 11:57:19'); /* Calfadar Village Portal */
/* @teleloc 0xAFC60025 [112.400002 118.200996 119.936996] 0.421931 0.000000 0.000000 0.906628 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7AFC608A, 5000801, 0xAFC60137, 103.922, 131.117, 120.005, -0.444677, 0, 0, 0.895691, False, '2025-08-07 02:18:38'); /* Steel Salvage */
/* @teleloc 0xAFC60137 [103.921997 131.117004 120.004997] -0.444677 0.000000 0.000000 0.895691 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7AFC608B, 5000802, 0xAFC60137, 104.979, 132.565, 120.005, -0.444677, 0, 0, 0.895691, False, '2025-08-07 02:18:47'); /* Iron Salvage */
/* @teleloc 0xAFC60137 [104.978996 132.565002 120.004997] -0.444677 0.000000 0.000000 0.895691 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7AFC608C, 5000803, 0xAFC60137, 108.425, 127.898, 120.005, -0.893371, 0, 0, -0.449321, False, '2025-08-07 02:19:25'); /* Granite Salvage */
/* @teleloc 0xAFC60137 [108.425003 127.898003 120.004997] -0.893371 0.000000 0.000000 -0.449321 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7AFC608D, 5000804, 0xAFC60137, 109.512, 129.473, 120.005, -0.890107, 0, 0, -0.455752, False, '2025-08-07 02:19:44'); /* Green Garnet Salvage */
/* @teleloc 0xAFC60137 [109.512001 129.473007 120.004997] -0.890107 0.000000 0.000000 -0.455752 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7AFC608E, 5000805, 0xAFC60137, 109.052, 138.266, 120.005, -0.442982, 0, 0, 0.896531, False, '2025-08-07 02:19:58'); /* Brass Salvage */
/* @teleloc 0xAFC60137 [109.052002 138.266006 120.004997] -0.442982 0.000000 0.000000 0.896531 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7AFC608F, 5000806, 0xAFC60137, 107.852, 136.673, 120.005, -0.465254, 0, 0, 0.885177, False, '2025-08-07 02:20:16'); /* Velvet Salvage */
/* @teleloc 0xAFC60137 [107.851997 136.673004 120.004997] -0.465254 0.000000 0.000000 0.885177 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7AFC6090, 5000807, 0xAFC60137, 113.639, 135.234, 120.005, -0.887685, 0, 0, -0.460452, False, '2025-08-07 02:20:28'); /* Mahogany Salvage */
/* @teleloc 0xAFC60137 [113.639000 135.233994 120.004997] -0.887685 0.000000 0.000000 -0.460452 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7AFC6091, 5000809, 0xAFC60026, 103.275, 128.888, 120.005, -0.299179, 0, 0, -0.954197, False, '2025-08-07 02:20:47'); /* Salvage Token Vendor */
/* @teleloc 0xAFC60026 [103.275002 128.888000 120.004997] -0.299179 0.000000 0.000000 -0.954197 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7AFC6092, 90172314, 0xAFC60016, 54.7534, 139.731, 119.937, -0.233875, 0, 0, 0.972267, False, '2025-08-07 04:57:21'); /* Pancake Golem Dungeon */
/* @teleloc 0xAFC60016 [54.753399 139.731003 119.936996] -0.233875 0.000000 0.000000 0.972267 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7AFC6093,   702, 0xAFC60126, 80.6027, 66.4123, 120.005, -0.70824, 0, 0, -0.705972, False, '2025-08-07 04:59:26'); /* Shopkeep Mirinda */
/* @teleloc 0xAFC60126 [80.602699 66.412300 120.004997] -0.708240 0.000000 0.000000 -0.705972 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7AFC6094,   696, 0xAFC60126, 88.6322, 66.4638, 120.005, -0.686046, 0, 0, 0.727558, False, '2025-08-07 05:00:29'); /* Grocer Rodega Tyning */
/* @teleloc 0xAFC60126 [88.632202 66.463799 120.004997] -0.686046 0.000000 0.000000 0.727558 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7AFC6098, 29181312, 0xAFC6000C, 42.6702, 95.7208, 120.005, -0.600797, 0, 0, 0.799402, False, '2025-08-08 05:33:34'); /* Elysa Strathelar */
/* @teleloc 0xAFC6000C [42.670200 95.720802 120.004997] -0.600797 0.000000 0.000000 0.799402 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7AFC609A, 7235123, 0xAFC60011, 56.3876, 21.9223, 119.832, -0.982717, 0, 0, 0.185114, False, '2025-08-08 22:45:16'); /* Chester Thornberry */
/* @teleloc 0xAFC60011 [56.387600 21.922300 119.832001] -0.982717 0.000000 0.000000 0.185114 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7AFC609B, 82752124, 0xAFC60016, 51.0263, 136.684, 120.005, 0.117612, 0, 0, -0.99306, False, '2025-08-08 22:48:59'); /* Terry Thornberry */
/* @teleloc 0xAFC60016 [51.026299 136.684006 120.004997] 0.117612 0.000000 0.000000 -0.993060 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7AFC609C, 700012, 0xAFC6001D, 85.9371, 106.091, 120.007, 0.105847, 0, 0, 0.994382, False, '2025-08-08 22:51:47'); /* Nexus Buffer Mage */
/* @teleloc 0xAFC6001D [85.937103 106.091003 120.007004] 0.105847 0.000000 0.000000 0.994382 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7AFC609D, 42820, 0xAFC60003, 23.0588, 66.7108, 119.78, 0.002139, 0, 0, 0.999998, False, '2025-08-09 07:24:31'); /* Holtburg Portal */
/* @teleloc 0xAFC60003 [23.058800 66.710800 119.779999] 0.002139 0.000000 0.000000 0.999998 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7AFC609E, 42818, 0xAFC60004, 21.6283, 77.7116, 119.542, 0.996471, 0, 0, 0.083943, False, '2025-08-09 07:24:40'); /* Cragstone Portal */
/* @teleloc 0xAFC60004 [21.628300 77.711601 119.542000] 0.996471 0.000000 0.000000 0.083943 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7AFC609F, 42816, 0xAFC60003, 11.3897, 66.8849, 117.835, 0.042999, 0, 0, 0.999075, False, '2025-08-09 07:24:46'); /* Lytelthorpe Portal */
/* @teleloc 0xAFC60003 [11.389700 66.884903 117.834999] 0.042999 0.000000 0.000000 0.999075 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7AFC60A0, 42814, 0xAFC60003, 6.63196, 68.0716, 117.042, 0.992541, 0, 0, -0.121912, False, '2025-08-09 07:24:54'); /* Glenden Wood Portal */
/* @teleloc 0xAFC60003 [6.631960 68.071602 117.042000] 0.992541 0.000000 0.000000 -0.121912 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7AFC60A1, 42812, 0xAFC60004, 9.201, 77.5707, 117.47, 0.106752, 0, 0, 0.994286, False, '2025-08-09 07:25:00'); /* Plateau Portal */
/* @teleloc 0xAFC60004 [9.201000 77.570702 117.470001] 0.106752 0.000000 0.000000 0.994286 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7AFC60A2, 43001, 0xAFC60004, 14.5788, 76.7461, 118.367, 0.14966, 0, 0, 0.988738, False, '2025-08-09 07:25:11'); /* Fort Tethana Portal */
/* @teleloc 0xAFC60004 [14.578800 76.746101 118.366997] 0.149660 0.000000 0.000000 0.988738 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7AFC60A3,  5772, 0xAFC6001C, 91.8556, 91.2366, 120.005, -0.711965, 0, 0, -0.702215, False, '2025-08-09 10:17:38'); /* Town Crier */
/* @teleloc 0xAFC6001C [91.855598 91.236603 120.004997] -0.711965 0.000000 0.000000 -0.702215 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7AFC60A4, 9282901, 0xAFC6000C, 41.2179, 92.1366, 120.005, -0.696759, 0, 0, 0.717306, False, '2025-08-10 16:05:29'); /* Nexus Weeping Vendor */
/* @teleloc 0xAFC6000C [41.217899 92.136597 120.004997] -0.696759 0.000000 0.000000 0.717306 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7AFC60A5, 90191200, 0xAFC6002A, 140.805, 42.7611, 119.937, 0.643154, 0, 0, -0.765737, False, '2025-08-10 20:00:58'); /* Ulgrim's Invaded Island */
/* @teleloc 0xAFC6002A [140.804993 42.761101 119.936996] 0.643154 0.000000 0.000000 -0.765737 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7AFC60A6, 90191900, 0xAFC6002A, 140.867, 35.9141, 119.937, 0.576136, 0, 0, -0.817354, False, '2025-08-10 20:01:19'); /* Decimation Golems */
/* @teleloc 0xAFC6002A [140.867004 35.914101 119.936996] 0.576136 0.000000 0.000000 -0.817354 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7AFC60A7, 49517, 0xAFC60029, 128.104, 17.2259, 120.006, 0.997815, 0, 0, 0.066069, False, '2025-08-11 03:48:53'); /* Iaret */
/* @teleloc 0xAFC60029 [128.104004 17.225901 120.005997] 0.997815 0.000000 0.000000 0.066069 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7AFC60A8,  1520, 0xAFC6002E, 143.909, 134.753, 120.008, 0.977391, 0, 0, -0.211442, False, '2025-08-11 15:19:52'); /* Banderling Raider Guardian */
/* @teleloc 0xAFC6002E [143.908997 134.753006 120.008003] 0.977391 0.000000 0.000000 -0.211442 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7AFC60A9,  1520, 0xAFC6002E, 143.909, 134.753, 120.008, 0.999929, 0, 0, 0.01195, False, '2025-08-11 15:19:53'); /* Banderling Raider Guardian */
/* @teleloc 0xAFC6002E [143.908997 134.753006 120.008003] 0.999929 0.000000 0.000000 0.011950 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7AFC60AA,  1520, 0xAFC6002E, 143.176, 136.578, 120.008, 0.981579, 0, 0, 0.191056, False, '2025-08-11 15:19:54'); /* Banderling Raider Guardian */
/* @teleloc 0xAFC6002E [143.175995 136.578003 120.008003] 0.981579 0.000000 0.000000 0.191056 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7AFC60AB,  1520, 0xAFC6002E, 142.881, 137.309, 120.008, 0.81548, 0, 0, 0.578785, False, '2025-08-11 15:19:55'); /* Banderling Raider Guardian */
/* @teleloc 0xAFC6002E [142.880997 137.309006 120.008003] 0.815480 0.000000 0.000000 0.578785 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7AFC60AC,  1520, 0xAFC6002E, 139.154, 138.446, 120.008, 0.689132, 0, 0, 0.724636, False, '2025-08-11 15:19:56'); /* Banderling Raider Guardian */
/* @teleloc 0xAFC6002E [139.154007 138.445999 120.008003] 0.689132 0.000000 0.000000 0.724636 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7AFC60AD,  1521, 0xAFC6002E, 139.02, 141.69, 120.005, 0.110067, 0, 0, 0.993924, False, '2025-08-11 15:20:15'); /* Heavy Drudge Prowler */
/* @teleloc 0xAFC6002E [139.020004 141.690002 120.004997] 0.110067 0.000000 0.000000 0.993924 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7AFC60AE,  1521, 0xAFC6002E, 138.26, 143.399, 120.005, 0.110067, 0, 0, 0.993924, False, '2025-08-11 15:20:16'); /* Heavy Drudge Prowler */
/* @teleloc 0xAFC6002E [138.259995 143.399002 120.004997] 0.110067 0.000000 0.000000 0.993924 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7AFC60AF,  1520, 0xAFC6002E, 143.77, 130.904, 120.008, -0.993222, 0, 0, -0.116231, False, '2025-08-11 15:20:22'); /* Banderling Raider Guardian */
/* @teleloc 0xAFC6002E [143.770004 130.904007 120.008003] -0.993222 0.000000 0.000000 -0.116231 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7AFC60B1,   509, 0xAFC6000E, 36.1344, 132.497, 120, 0.780998, 0, 0, 0.624533, False, '2025-08-12 14:13:04'); /* Life Stone */
/* @teleloc 0xAFC6000E [36.134399 132.496994 120.000000] 0.780998 0.000000 0.000000 0.624533 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7AFC60B2,   509, 0xAFC60031, 144.219, 19.0958, 120.036, -0.27653, 0, 0, 0.961005, False, '2025-08-12 14:13:17'); /* Life Stone */
/* @teleloc 0xAFC60031 [144.218994 19.095800 120.036003] -0.276530 0.000000 0.000000 0.961005 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7AFC60B3,  3920, 0xAFC60014, 52.4781, 76.5468, 120.398, -0.686656, 0, 0, 0.726983, False, '2025-08-14 15:43:00'); /* Collector */
/* @teleloc 0xAFC60014 [52.478100 76.546799 120.398003] -0.686656 0.000000 0.000000 0.726983 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7AFC60B4, 716165, 0xAFC6001D, 80.2415, 111.143, 119.79, 0.999494, 0, 0, -0.031802, False, '2025-08-15 09:16:36'); /* Hopeslayer's Reach */
/* @teleloc 0xAFC6001D [80.241501 111.142998 119.790001] 0.999494 0.000000 0.000000 -0.031802 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7AFC60B5, 29812819, 0xAFC60014, 65.8625, 87.4897, 120.005, -0.985041, 0, 0, 0.172322, False, '2025-08-16 01:24:33'); /* Captain Fixer */
/* @teleloc 0xAFC60014 [65.862503 87.489700 120.004997] -0.985041 0.000000 0.000000 0.172322 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7AFC60B6,  7242, 0xAFC6002C, 131.253, 73.4038, 119.937, 0.67708, 0, 0, -0.73591, False, '2025-08-20 13:00:54'); /* Blackened Spawn Den */
/* @teleloc 0xAFC6002C [131.253006 73.403801 119.936996] 0.677080 0.000000 0.000000 -0.735910 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7AFC60B7, 42378177, 0xAFC6000F, 30.187, 156.475, 123.056, 0.967971, 0, 0, 0.251063, False, '2025-08-21 04:41:31'); /* Practice Island  */
/* @teleloc 0xAFC6000F [30.187000 156.475006 123.056000] 0.967971 0.000000 0.000000 0.251063 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7AFC60B9, 86653877, 0xAFC6001B, 80.2173, 70.2091, 120.005, 0.044719, 0, 0, -0.999, False, '2025-08-22 11:34:04'); /* PINK BALL OF LIGHT */
/* @teleloc 0xAFC6001B [80.217300 70.209099 120.004997] 0.044719 0.000000 0.000000 -0.999000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7AFC60BA, 86653877, 0xAFC6001B, 76.9713, 70.021, 120.005, 0.999913, 0, 0, -0.01319, False, '2025-08-22 11:34:10'); /* PINK BALL OF LIGHT */
/* @teleloc 0xAFC6001B [76.971298 70.021004 120.004997] 0.999913 0.000000 0.000000 -0.013190 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7AFC60BB, 743223317, 0xAFC60024, 110.764, 72.2904, 119.937, -0.999321, 0, 0, 0.036853, False, '2025-08-26 16:51:44'); /* White View */
/* @teleloc 0xAFC60024 [110.764000 72.290398 119.936996] -0.999321 0.000000 0.000000 0.036853 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7AFC60BC,   509, 0xAFC6001C, 78.1954, 92.3733, 120, 0.97451, 0, 0, -0.224344, False, '2025-08-27 14:15:23'); /* Life Stone */
/* @teleloc 0xAFC6001C [78.195396 92.373299 120.000000] 0.974510 0.000000 0.000000 -0.224344 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7AFC60BD,   509, 0xAFC6002D, 123.189, 112.545, 120, 0.940097, 0, 0, -0.340907, False, '2025-08-27 14:16:13'); /* Life Stone */
/* @teleloc 0xAFC6002D [123.189003 112.544998 120.000000] 0.940097 0.000000 0.000000 -0.340907 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7AFC60BE, 32145216, 0xAFC60014, 63.7096, 86.0429, 120.005, -0.459873, 0, 0, -0.887985, False, '2025-08-28 08:12:11'); /* Mule Helper */
/* @teleloc 0xAFC60014 [63.709599 86.042900 120.004997] -0.459873 0.000000 0.000000 -0.887985 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7AFC60BF, 23719265, 0xAFC60026, 100.503, 132.937, 120.005, -0.393426, 0, 0, -0.919357, False, '2025-08-29 01:39:28'); /* Aun Pallaton */
/* @teleloc 0xAFC60026 [100.502998 132.936996 120.004997] -0.393426 0.000000 0.000000 -0.919357 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7AFC60C0, 213892177, 0xAFC6001B, 78.90874, 70.13726, 120.005, 0.999976, 0, 0, 0.006924, False, '2025-09-04 18:00:20'); /* Ambassador Casual */
/* @teleloc 0xAFC6001B [78.908737 70.137260 120.004997] 0.999976 0.000000 0.000000 0.006924 */
