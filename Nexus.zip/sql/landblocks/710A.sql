DELETE FROM `landblock_instance` WHERE `landblock` = 0x710A;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7710A000, 24491, 0x710A0000, 24.0512, 6.89566, 30.5789, -0.06876, 0, 0, 0.997633, False, '2005-02-09 10:00:00'); /* Ulgrim Island Volcano Caldera Gen */
/* @teleloc 0x710A0000 [24.051201 6.895660 30.578899] -0.068760 0.000000 0.000000 0.997633 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7710A001, 24492, 0x710A0000, 44.6437, 20.1697, 22.1922, 0.433591, 0, 0, -0.90111, False, '2005-02-09 10:00:00'); /* Ulgrim Island Volcano-Mix Gen */
/* @teleloc 0x710A0000 [44.643700 20.169701 22.192200] 0.433591 0.000000 0.000000 -0.901110 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7710A003, 24489, 0x710A0000, 70.1099, 95.9987, 6.00479, -0.752656, 0, 0, 0.658414, False, '2005-02-09 10:00:00'); /* Ulgrim Island Rock-Mix Gen */
/* @teleloc 0x710A0000 [70.109901 95.998703 6.004790] -0.752656 0.000000 0.000000 0.658414 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7710A006, 24487, 0x710A0000, 164.19, 106.959, -0.445, 0.033957, 0, 0, -0.999423, False, '2005-02-09 10:00:00'); /* Ulgrim Island Beach Gen */
/* @teleloc 0x710A0000 [164.190002 106.959000 -0.445000] 0.033957 0.000000 0.000000 -0.999423 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7710A00B, 24487, 0x710A0000, 106.947, 164.919, -0.445, -0.835049, 0, 0, -0.550176, False, '2005-02-09 10:00:00'); /* Ulgrim Island Beach Gen */
/* @teleloc 0x710A0000 [106.946999 164.919006 -0.445000] -0.835049 0.000000 0.000000 -0.550176 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7710A00C, 24487, 0x710A0000, 71.8165, 179.679, -0.895, 0.453869, 0, 0, -0.891068, False, '2005-02-09 10:00:00'); /* Ulgrim Island Beach Gen */
/* @teleloc 0x710A0000 [71.816498 179.679001 -0.895000] 0.453869 0.000000 0.000000 -0.891068 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7710A00D, 24487, 0x710A0000, 113.084, 121.07, -0.095, -0.923618, 0, 0, -0.383315, False, '2005-02-09 10:00:00'); /* Ulgrim Island Beach Gen */
/* @teleloc 0x710A0000 [113.084000 121.070000 -0.095000] -0.923618 0.000000 0.000000 -0.383315 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7710A00E, 24487, 0x710A0000, 21.7355, 155.12, -0.095, 0.04013, 0, 0, 0.999195, False, '2005-02-09 10:00:00'); /* Ulgrim Island Beach Gen */
/* @teleloc 0x710A0000 [21.735500 155.119995 -0.095000] 0.040130 0.000000 0.000000 0.999195 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7710A011, 24487, 0x710A0000, 51.5219, 150.5, -0.095, -0.762551, 0, 0, 0.646928, False, '2005-02-09 10:00:00'); /* Ulgrim Island Beach Gen */
/* @teleloc 0x710A0000 [51.521900 150.500000 -0.095000] -0.762551 0.000000 0.000000 0.646928 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7710A012, 24490, 0x710A0000, 174.899, 39.6718, 2.81815, -0.934987, 0, 0, -0.354681, False, '2005-02-09 10:00:00'); /* Ulgrim Island Tree-Line Gen */
/* @teleloc 0x710A0000 [174.899002 39.671799 2.818150] -0.934987 0.000000 0.000000 -0.354681 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7710A013, 24490, 0x710A0000, 136.569, 59.954, 1.62311, -0.74395, 0, 0, 0.668235, False, '2005-02-09 10:00:00'); /* Ulgrim Island Tree-Line Gen */
/* @teleloc 0x710A0000 [136.569000 59.953999 1.623110] -0.743950 0.000000 0.000000 0.668235 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7710A015, 24488, 0x710A0000, 122.767, 20.0761, 0.79318, -0.649468, 0, 0, -0.760389, False, '2005-02-09 10:00:00'); /* Ulgrim Island Jungle-Mix Gen */
/* @teleloc 0x710A0000 [122.766998 20.076099 0.793180] -0.649468 0.000000 0.000000 -0.760389 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7710A016, 24488, 0x710A0000, 87.7406, 27.7416, 3.6932, -0.965068, 0, 0, -0.261998, False, '2005-02-09 10:00:00'); /* Ulgrim Island Jungle-Mix Gen */
/* @teleloc 0x710A0000 [87.740601 27.741600 3.693200] -0.965068 0.000000 0.000000 -0.261998 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7710A01A,  7786, 0x710A0000, 12.0207, 180.297, 0, 0.855026, 0, 0, -0.518585, False, '2005-02-09 10:00:00'); /* Volcanic Vent */
/* @teleloc 0x710A0000 [12.020700 180.296997 0.000000] 0.855026 0.000000 0.000000 -0.518585 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7710A01B, 23885, 0x710A0000, 164.592, 4.42212, 6.005, -0.963219, 0, 0, -0.268719, False, '2005-02-09 10:00:00'); /* Keg */
/* @teleloc 0x710A0000 [164.591995 4.422120 6.005000] -0.963219 0.000000 0.000000 -0.268719 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7710A01C, 23886, 0x710A0000, 31.4258, 98.6808, 6.005, -0.998609, 0, 0, -0.052726, False, '2005-02-09 10:00:00'); /* Keg */
/* @teleloc 0x710A0000 [31.425800 98.680801 6.005000] -0.998609 0.000000 0.000000 -0.052726 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7710A01D, 24492, 0x710A0000, 7.77518, 22.9838, 25.6631, 0.896455, 0, 0, -0.443136, False, '2005-02-09 10:00:00'); /* Ulgrim Island Volcano-Mix Gen */
/* @teleloc 0x710A0000 [7.775180 22.983801 25.663099] 0.896455 0.000000 0.000000 -0.443136 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7710A01E, 73217237, 0x710A000F, 32.529, 145.858, -0.045, 0.638445, 0, 0, -0.769667, False, '2025-08-12 12:40:28'); /* Islandgolemgen */
/* @teleloc 0x710A000F [32.528999 145.858002 -0.045000] 0.638445 0.000000 0.000000 -0.769667 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7710A01F, 73217237, 0x710A001E, 72.0638, 140.812, 0.586253, 0.698461, 0, 0, -0.715648, False, '2025-08-12 12:40:31'); /* Islandgolemgen */
/* @teleloc 0x710A001E [72.063797 140.811996 0.586253] 0.698461 0.000000 0.000000 -0.715648 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7710A020, 73217237, 0x710A002E, 120.37, 123.179, -0.045, 0.398417, 0, 0, -0.917205, False, '2025-08-12 12:40:34'); /* Islandgolemgen */
/* @teleloc 0x710A002E [120.370003 123.179001 -0.045000] 0.398417 0.000000 0.000000 -0.917205 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7710A021, 73217237, 0x710A0034, 158.247, 84.9692, -0.395, 0.361061, 0, 0, -0.932542, False, '2025-08-12 12:40:38'); /* Islandgolemgen */
/* @teleloc 0x710A0034 [158.246994 84.969200 -0.395000] 0.361061 0.000000 0.000000 -0.932542 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7710A022, 83217237, 0x710A000F, 24.1378, 147.009, -0.045, -0.68746, 0, 0, 0.726223, False, '2025-09-04 22:35:05'); /* Trophy Keeper of Honor */
/* @teleloc 0x710A000F [24.137800 147.009003 -0.045000] -0.687460 0.000000 0.000000 0.726223 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7710A023, 83217237, 0x710A001E, 83.975, 143.797, 0.088819, -0.536397, 0, 0, 0.843966, False, '2025-09-04 22:35:09'); /* Trophy Keeper of Honor */
/* @teleloc 0x710A001E [83.974998 143.796997 0.088819] -0.536397 0.000000 0.000000 0.843966 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7710A024, 83217237, 0x710A0034, 156.866, 94.7878, -0.395, -0.536397, 0, 0, 0.843966, False, '2025-09-04 22:35:15'); /* Trophy Keeper of Honor */
/* @teleloc 0x710A0034 [156.865997 94.787804 -0.395000] -0.536397 0.000000 0.000000 0.843966 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7710A025, 73217237, 0x710A0019, 88.4074, 15.2431, 4.78474, 0.876681, 0, 0, 0.481073, False, '2025-09-06 02:51:34'); /* Islandgolemgen */
/* @teleloc 0x710A0019 [88.407402 15.243100 4.784740] 0.876681 0.000000 0.000000 0.481073 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7710A026, 73217237, 0x710A0011, 69.6993, 19.0916, 5.80614, 0.663626, 0, 0, 0.748065, False, '2025-09-06 02:51:36'); /* Islandgolemgen */
/* @teleloc 0x710A0011 [69.699303 19.091600 5.806140] 0.663626 0.000000 0.000000 0.748065 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7710A027, 73217237, 0x710A0009, 26.8306, 7.37248, 30.9053, 0.999467, 0, 0, 0.03264, False, '2025-09-06 02:51:47'); /* Islandgolemgen */
/* @teleloc 0x710A0009 [26.830601 7.372480 30.905300] 0.999467 0.000000 0.000000 0.032640 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7710A028, 73217237, 0x710A0006, 11.5274, 141.908, 0.577893, -0.654339, 0, 0, 0.756202, False, '2025-09-06 18:58:05'); /* Islandgolemgen */
/* @teleloc 0x710A0006 [11.527400 141.908005 0.577893] -0.654339 0.000000 0.000000 0.756202 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7710A029, 73217237, 0x710A001E, 92.357, 127.626, 0.662171, -0.456349, 0, 0, 0.889801, False, '2025-09-06 18:58:11'); /* Islandgolemgen */
/* @teleloc 0x710A001E [92.357002 127.625999 0.662171] -0.456349 0.000000 0.000000 0.889801 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7710A02A, 73217237, 0x710A0025, 119.254, 106.783, 0.055, -0.345467, 0, 0, 0.938431, False, '2025-09-06 18:58:13'); /* Islandgolemgen */
/* @teleloc 0x710A0025 [119.253998 106.782997 0.055000] -0.345467 0.000000 0.000000 0.938431 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7710A02B, 73217237, 0x710A002C, 135.105, 90.1765, 0.540289, -0.420054, 0, 0, 0.907499, False, '2025-09-06 18:58:15'); /* Islandgolemgen */
/* @teleloc 0x710A002C [135.104996 90.176498 0.540289] -0.420054 0.000000 0.000000 0.907499 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7710A02C, 73217237, 0x710A0034, 160.954, 74.8637, -0.045, -0.648868, 0, 0, 0.760901, False, '2025-09-06 18:58:18'); /* Islandgolemgen */
/* @teleloc 0x710A0034 [160.953995 74.863701 -0.045000] -0.648868 0.000000 0.000000 0.760901 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7710A02D, 73217237, 0x710A003B, 190.4468, 68.95978, 0.18443, -0.641153, 0, 0, 0.767413, False, '2025-09-06 18:58:20'); /* Islandgolemgen */
/* @teleloc 0x710A003B [190.446793 68.959778 0.184430] -0.641153 0.000000 0.000000 0.767413 */
