DELETE FROM `landblock_instance` WHERE `landblock` = 0xF1D6;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F1D6006, 5000294, 0xF1D6002F, 129.581, 161.053, 0.055, 0.698487, 0, 0, -0.715623, False, '2020-01-13 01:40:43'); /* Plant */
/* @teleloc 0xF1D6002F [129.580994 161.052994 0.055000] 0.698487 0.000000 0.000000 -0.715623 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F1D6007, 5000294, 0xF1D6002F, 134.867, 160.925, 0.055, 0.698487, 0, 0, -0.715623, False, '2020-01-13 01:40:44'); /* Plant */
/* @teleloc 0xF1D6002F [134.867004 160.925003 0.055000] 0.698487 0.000000 0.000000 -0.715623 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F1D6008, 5000294, 0xF1D6002F, 133.664, 155.684, 0.055, -0.449435, 0, 0, -0.893313, False, '2020-01-13 01:40:46'); /* Plant */
/* @teleloc 0xF1D6002F [133.664001 155.684006 0.055000] -0.449435 0.000000 0.000000 -0.893313 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F1D6009, 5000294, 0xF1D6002F, 127.506, 151.742, 0.055, -0.619458, 0, 0, -0.78503, False, '2020-01-13 01:40:47'); /* Plant */
/* @teleloc 0xF1D6002F [127.505997 151.742004 0.055000] -0.619458 0.000000 0.000000 -0.785030 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F1D600A, 5000295, 0xF1D6002F, 128.908, 156.063, 0.055, -0.872397, 0, 0, 0.488798, False, '2020-01-13 01:40:51'); /* Plant */
/* @teleloc 0xF1D6002F [128.908005 156.063004 0.055000] -0.872397 0.000000 0.000000 0.488798 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F1D600B, 5000295, 0xF1D6003C, 183.751, 92.2568, -0.045, -0.492451, 0, 0, 0.87034, False, '2020-01-13 01:40:57'); /* Plant */
/* @teleloc 0xF1D6003C [183.751007 92.256798 -0.045000] -0.492451 0.000000 0.000000 0.870340 */
