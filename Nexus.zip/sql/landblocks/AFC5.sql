DELETE FROM `landblock_instance` WHERE `landblock` = 0xAFC5;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7AFC5001, 63163114, 0xAFC50020, 73.6881, 191.497, 118.078, -0.995313, 0, 0, -0.096704, False, '2025-08-08 00:10:10'); /* Ugly Lizard Dungeon */
/* @teleloc 0xAFC50020 [73.688103 191.496994 118.078003] -0.995313 0.000000 0.000000 -0.096704 */
