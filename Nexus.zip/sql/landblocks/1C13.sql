DELETE FROM `landblock_instance` WHERE `landblock` = 0x1C13;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x71C13000,  4179, 0x1C130000, 130.232, 129.203, 85.8742, -0.935998, 0, 0, 0.352006, False, '2005-02-09 10:00:00'); /* Bonfire */
/* @teleloc 0x1C130000 [130.231995 129.203003 85.874199] -0.935998 0.000000 0.000000 0.352006 */
