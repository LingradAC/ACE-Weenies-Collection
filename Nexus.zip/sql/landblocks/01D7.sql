DELETE FROM `landblock_instance` WHERE `landblock` = 0x01D7;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701D7000, 63163113, 0x01D70268, 113.123, -161.057, -5.945, 0.764446, 0, 0, 0.644688, False, '2025-08-07 17:00:58'); /* lizardlizardlizardgen */
/* @teleloc 0x01D70268 [113.123001 -161.057007 -5.945000] 0.764446 0.000000 0.000000 0.644688 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701D7001, 63163113, 0x01D70268, 108.331, -158.104, -5.945, 0.57215, 0, 0, 0.820149, False, '2025-08-07 17:00:59'); /* lizardlizardlizardgen */
/* @teleloc 0x01D70268 [108.331001 -158.104004 -5.945000] 0.572150 0.000000 0.000000 0.820149 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701D7002, 63163113, 0x01D70264, 85.3907, -167.232, -5.945, 0.658438, 0, 0, 0.752635, False, '2025-08-07 17:01:02'); /* lizardlizardlizardgen */
/* @teleloc 0x01D70264 [85.390701 -167.231995 -5.945000] 0.658438 0.000000 0.000000 0.752635 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701D7003, 63163113, 0x01D70255, 74.984, -158.828, -5.945, 0.913932, 0, 0, 0.405868, False, '2025-08-07 17:01:03'); /* lizardlizardlizardgen */
/* @teleloc 0x01D70255 [74.984001 -158.828003 -5.945000] 0.913932 0.000000 0.000000 0.405868 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701D7004, 63212983, 0x01D70272, 54.5971, -127.836, -0.063, -0.042369, 0, 0, -0.999102, False, '2025-08-07 17:01:52'); /* Simiran Portal */
/* @teleloc 0x01D70272 [54.597099 -127.835999 -0.063000] -0.042369 0.000000 0.000000 -0.999102 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701D7005, 63163113, 0x01D7026C, 31.7711, -148.825, 0.055, -0.681093, 0, 0, -0.732197, False, '2025-08-07 17:02:07'); /* lizardlizardlizardgen */
/* @teleloc 0x01D7026C [31.771099 -148.824997 0.055000] -0.681093 0.000000 0.000000 -0.732197 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701D7006, 63163113, 0x01D7024E, 57.0389, -171.249, -5.945, -0.384189, 0, 0, -0.923254, False, '2025-08-07 17:02:13'); /* lizardlizardlizardgen */
/* @teleloc 0x01D7024E [57.038898 -171.248993 -5.945000] -0.384189 0.000000 0.000000 -0.923254 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701D7007, 63163113, 0x01D70257, 72.4715, -180.441, -5.945, 0.881411, 0, 0, -0.47235, False, '2025-08-07 17:02:16'); /* lizardlizardlizardgen */
/* @teleloc 0x01D70257 [72.471497 -180.440994 -5.945000] 0.881411 0.000000 0.000000 -0.472350 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701D7008, 63163113, 0x01D7025A, 75.9196, -149.697, -5.945, 0.803805, 0, 0, -0.594893, False, '2025-08-07 17:02:21'); /* lizardlizardlizardgen */
/* @teleloc 0x01D7025A [75.919601 -149.697006 -5.945000] 0.803805 0.000000 0.000000 -0.594893 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701D7009, 63163113, 0x01D70260, 90.4719, -149.599, -5.945, 0.704859, 0, 0, -0.709347, False, '2025-08-07 17:02:22'); /* lizardlizardlizardgen */
/* @teleloc 0x01D70260 [90.471901 -149.598999 -5.945000] 0.704859 0.000000 0.000000 -0.709347 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701D700A, 63163113, 0x01D701C6, 40.0841, -152.875, -11.945, -0.999896, 0, 0, 0.014403, False, '2025-08-07 17:02:37'); /* lizardlizardlizardgen */
/* @teleloc 0x01D701C6 [40.084099 -152.875000 -11.945000] -0.999896 0.000000 0.000000 0.014403 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701D700B, 63163113, 0x01D701C9, 39.8685, -162.09, -11.945, -0.117064, 0, 0, 0.993124, False, '2025-08-07 17:02:40'); /* lizardlizardlizardgen */
/* @teleloc 0x01D701C9 [39.868500 -162.089996 -11.945000] -0.117064 0.000000 0.000000 0.993124 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701D700C, 63163113, 0x01D701E2, 60.6372, -147.008, -11.945, 0.14912, 0, 0, 0.988819, False, '2025-08-07 17:02:44'); /* lizardlizardlizardgen */
/* @teleloc 0x01D701E2 [60.637199 -147.007996 -11.945000] 0.149120 0.000000 0.000000 0.988819 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701D700D, 63163113, 0x01D701EB, 60.2208, -176.818, -11.945, 0.002572, 0, 0, 0.999997, False, '2025-08-07 17:02:49'); /* lizardlizardlizardgen */
/* @teleloc 0x01D701EB [60.220798 -176.817993 -11.945000] 0.002572 0.000000 0.000000 0.999997 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701D700E, 63163113, 0x01D701F9, 68.1211, -149.124, -11.945, 0.98994, 0, 0, 0.141491, False, '2025-08-07 17:02:54'); /* lizardlizardlizardgen */
/* @teleloc 0x01D701F9 [68.121101 -149.123993 -11.945000] 0.989940 0.000000 0.000000 0.141491 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701D700F, 63163113, 0x01D701F9, 70.7168, -152.149, -11.945, 0.997865, 0, 0, 0.065304, False, '2025-08-07 17:02:55'); /* lizardlizardlizardgen */
/* @teleloc 0x01D701F9 [70.716797 -152.149002 -11.945000] 0.997865 0.000000 0.000000 0.065304 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701D7010, 63163113, 0x01D70217, 76.04, -202.059, -11.945, 0.88613, 0, 0, 0.463437, False, '2025-08-07 17:03:08'); /* lizardlizardlizardgen */
/* @teleloc 0x01D70217 [76.040001 -202.059006 -11.945000] 0.886130 0.000000 0.000000 0.463437 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701D7011, 63163113, 0x01D70201, 70.1498, -195.345, -11.945, 0.95981, 0, 0, -0.280652, False, '2025-08-07 17:03:09'); /* lizardlizardlizardgen */
/* @teleloc 0x01D70201 [70.149803 -195.345001 -11.945000] 0.959810 0.000000 0.000000 -0.280652 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701D7012, 63163113, 0x01D70216, 83.0716, -192.813, -11.945, 0.69716, 0, 0, -0.716915, False, '2025-08-07 17:03:11'); /* lizardlizardlizardgen */
/* @teleloc 0x01D70216 [83.071602 -192.813004 -11.945000] 0.697160 0.000000 0.000000 -0.716915 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701D7013, 63163113, 0x01D70221, 86.3093, -160.27, -11.3552, 0.742212, 0, 0, -0.670165, False, '2025-08-07 17:03:21'); /* lizardlizardlizardgen */
/* @teleloc 0x01D70221 [86.309303 -160.270004 -11.355200] 0.742212 0.000000 0.000000 -0.670165 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701D7014, 63163113, 0x01D701E1, 55.744, -123.269, -11.945, 0.927955, 0, 0, 0.372692, False, '2025-08-07 17:03:29'); /* lizardlizardlizardgen */
/* @teleloc 0x01D701E1 [55.743999 -123.268997 -11.945000] 0.927955 0.000000 0.000000 0.372692 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701D7015, 63163113, 0x01D701E1, 60.2074, -118.96, -11.945, 0.956972, 0, 0, -0.290182, False, '2025-08-07 17:03:30'); /* lizardlizardlizardgen */
/* @teleloc 0x01D701E1 [60.207401 -118.959999 -11.945000] 0.956972 0.000000 0.000000 -0.290182 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701D7016, 63163113, 0x01D701D8, 63.0188, -89.8425, -11.945, 0.999617, 0, 0, 0.027681, False, '2025-08-07 17:03:34'); /* lizardlizardlizardgen */
/* @teleloc 0x01D701D8 [63.018799 -89.842499 -11.945000] 0.999617 0.000000 0.000000 0.027681 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701D7017, 63163113, 0x01D701D8, 58.1069, -88.5204, -11.945, 0.947589, 0, 0, -0.319493, False, '2025-08-07 17:03:36'); /* lizardlizardlizardgen */
/* @teleloc 0x01D701D8 [58.106899 -88.520401 -11.945000] 0.947589 0.000000 0.000000 -0.319493 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701D7018, 63163113, 0x01D70187, 78.3333, -92.1459, -17.945, 0.977555, 0, 0, 0.210681, False, '2025-08-07 17:03:45'); /* lizardlizardlizardgen */
/* @teleloc 0x01D70187 [78.333298 -92.145897 -17.945000] 0.977555 0.000000 0.000000 0.210681 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701D7019, 63163113, 0x01D70187, 77.6722, -87.5372, -17.945, 0.999919, 0, 0, -0.012729, False, '2025-08-07 17:03:48'); /* lizardlizardlizardgen */
/* @teleloc 0x01D70187 [77.672203 -87.537201 -17.945000] 0.999919 0.000000 0.000000 -0.012729 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701D701A, 63163113, 0x01D70186, 76.6908, -82.0971, -17.945, 0.999919, 0, 0, -0.012729, False, '2025-08-07 17:03:51'); /* lizardlizardlizardgen */
/* @teleloc 0x01D70186 [76.690804 -82.097099 -17.945000] 0.999919 0.000000 0.000000 -0.012729 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701D701B, 63163113, 0x01D70185, 82.4691, -73.1529, -17.945, 0.979443, 0, 0, -0.201719, False, '2025-08-07 17:03:53'); /* lizardlizardlizardgen */
/* @teleloc 0x01D70185 [82.469101 -73.152901 -17.945000] 0.979443 0.000000 0.000000 -0.201719 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701D701C, 63163113, 0x01D7018F, 91.8341, -70.6648, -17.945, 0.594341, 0, 0, -0.804213, False, '2025-08-07 17:03:54'); /* lizardlizardlizardgen */
/* @teleloc 0x01D7018F [91.834099 -70.664803 -17.945000] 0.594341 0.000000 0.000000 -0.804213 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701D701D, 63163113, 0x01D70199, 101.337, -70.8186, -17.945, 0.179697, 0, 0, -0.983722, False, '2025-08-07 17:03:55'); /* lizardlizardlizardgen */
/* @teleloc 0x01D70199 [101.336998 -70.818604 -17.945000] 0.179697 0.000000 0.000000 -0.983722 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701D701E, 63163113, 0x01D7021B, 86.9117, -61.0311, -11.945, 0.706314, 0, 0, 0.707899, False, '2025-08-07 17:04:01'); /* lizardlizardlizardgen */
/* @teleloc 0x01D7021B [86.911697 -61.031101 -11.945000] 0.706314 0.000000 0.000000 0.707899 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701D701F, 63163113, 0x01D7021B, 92.2219, -59.2757, -11.945, 0.958267, 0, 0, -0.285876, False, '2025-08-07 17:04:03'); /* lizardlizardlizardgen */
/* @teleloc 0x01D7021B [92.221901 -59.275700 -11.945000] 0.958267 0.000000 0.000000 -0.285876 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701D7020, 63163113, 0x01D701AC, 125.994, -34.7142, -17.945, 0.921802, 0, 0, -0.387661, False, '2025-08-07 17:04:08'); /* lizardlizardlizardgen */
/* @teleloc 0x01D701AC [125.994003 -34.714199 -17.945000] 0.921802 0.000000 0.000000 -0.387661 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701D7021, 63163113, 0x01D701AB, 131.34, -24.9224, -17.945, 0.990631, 0, 0, 0.136566, False, '2025-08-07 17:04:10'); /* lizardlizardlizardgen */
/* @teleloc 0x01D701AB [131.339996 -24.922400 -17.945000] 0.990631 0.000000 0.000000 0.136566 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701D7022, 63163113, 0x01D701A8, 120.872, -20.027, -17.945, 0.79494, 0, 0, 0.606688, False, '2025-08-07 17:04:11'); /* lizardlizardlizardgen */
/* @teleloc 0x01D701A8 [120.872002 -20.027000 -17.945000] 0.794940 0.000000 0.000000 0.606688 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701D7023, 63212983, 0x01D701AF, 149.454, -30.0639, -18.063, 0.69454, 0, 0, 0.719455, False, '2025-08-07 17:04:33'); /* Simiran Portal */
/* @teleloc 0x01D701AF [149.453995 -30.063900 -18.063000] 0.694540 0.000000 0.000000 0.719455 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701D7024, 63163113, 0x01D701AE, 136.107, -30.5324, -17.945, 0.746496, 0, 0, 0.66539, False, '2025-08-07 17:04:40'); /* lizardlizardlizardgen */
/* @teleloc 0x01D701AE [136.106995 -30.532400 -17.945000] 0.746496 0.000000 0.000000 0.665390 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701D7025, 63163113, 0x01D70193, 100.169, -18.8911, -17.945, -0.001283, 0, 0, 0.999999, False, '2025-08-07 17:04:47'); /* lizardlizardlizardgen */
/* @teleloc 0x01D70193 [100.168999 -18.891100 -17.945000] -0.001283 0.000000 0.000000 0.999999 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701D7026, 63163113, 0x01D7013C, 28.0084, -93.3311, -17.945, -0.720639, 0, 0, 0.69331, False, '2025-08-07 17:05:07'); /* lizardlizardlizardgen */
/* @teleloc 0x01D7013C [28.008400 -93.331100 -17.945000] -0.720639 0.000000 0.000000 0.693310 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701D7027, 63163113, 0x01D7013C, 33.0162, -87.8532, -17.945, -0.993815, 0, 0, 0.111045, False, '2025-08-07 17:05:08'); /* lizardlizardlizardgen */
/* @teleloc 0x01D7013C [33.016201 -87.853203 -17.945000] -0.993815 0.000000 0.000000 0.111045 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701D7028, 63163113, 0x01D7013B, 29.5905, -79.3687, -17.945, -0.987017, 0, 0, -0.160618, False, '2025-08-07 17:05:09'); /* lizardlizardlizardgen */
/* @teleloc 0x01D7013B [29.590500 -79.368698 -17.945000] -0.987017 0.000000 0.000000 -0.160618 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701D7029, 63163113, 0x01D7012F, 21.4974, -71.6068, -17.945, -0.73381, 0, 0, -0.679355, False, '2025-08-07 17:05:11'); /* lizardlizardlizardgen */
/* @teleloc 0x01D7012F [21.497400 -71.606796 -17.945000] -0.733810 0.000000 0.000000 -0.679355 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701D702A, 63163113, 0x01D7012D, 14.4122, -80.5962, -17.945, -0.196673, 0, 0, -0.980469, False, '2025-08-07 17:05:12'); /* lizardlizardlizardgen */
/* @teleloc 0x01D7012D [14.412200 -80.596199 -17.945000] -0.196673 0.000000 0.000000 -0.980469 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701D702B, 63163113, 0x01D7012E, 10.2444, -92.1806, -17.945, -0.965682, 0, 0, -0.259729, False, '2025-08-07 17:05:14'); /* lizardlizardlizardgen */
/* @teleloc 0x01D7012E [10.244400 -92.180603 -17.945000] -0.965682 0.000000 0.000000 -0.259729 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701D702C, 63163113, 0x01D70129, 11.3551, -60.4328, -17.945, -0.607024, 0, 0, 0.794684, False, '2025-08-07 17:05:18'); /* lizardlizardlizardgen */
/* @teleloc 0x01D70129 [11.355100 -60.432800 -17.945000] -0.607024 0.000000 0.000000 0.794684 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701D702D, 63163113, 0x01D701BB, 31.6572, -137.752, -11.945, -0.866368, 0, 0, 0.499407, False, '2025-08-07 17:05:48'); /* lizardlizardlizardgen */
/* @teleloc 0x01D701BB [31.657200 -137.751999 -11.945000] -0.866368 0.000000 0.000000 0.499407 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701D702E, 63163113, 0x01D701C4, 41.0421, -132.829, -11.945, -0.948922, 0, 0, 0.315511, False, '2025-08-07 17:05:49'); /* lizardlizardlizardgen */
/* @teleloc 0x01D701C4 [41.042099 -132.828995 -11.945000] -0.948922 0.000000 0.000000 0.315511 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701D702F, 63163113, 0x01D701D0, 47.3597, -124.517, -11.945, -0.996061, 0, 0, 0.088671, False, '2025-08-07 17:05:50'); /* lizardlizardlizardgen */
/* @teleloc 0x01D701D0 [47.359699 -124.516998 -11.945000] -0.996061 0.000000 0.000000 0.088671 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701D7030, 63163113, 0x01D70162, 49.7695, -97.8852, -17.945, -0.998829, 0, 0, 0.048385, False, '2025-08-07 17:05:52'); /* lizardlizardlizardgen */
/* @teleloc 0x01D70162 [49.769501 -97.885201 -17.945000] -0.998829 0.000000 0.000000 0.048385 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701D7031, 63163113, 0x01D70170, 60.9107, -66.0359, -17.945, -0.999089, 0, 0, 0.042684, False, '2025-08-07 17:05:57'); /* lizardlizardlizardgen */
/* @teleloc 0x01D70170 [60.910702 -66.035896 -17.945000] -0.999089 0.000000 0.000000 0.042684 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701D7032, 63163113, 0x01D7015D, 54.699, -60.7138, -17.945, -0.840194, 0, 0, -0.542287, False, '2025-08-07 17:05:58'); /* lizardlizardlizardgen */
/* @teleloc 0x01D7015D [54.699001 -60.713799 -17.945000] -0.840194 0.000000 0.000000 -0.542287 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701D7033, 63163113, 0x01D7014D, 40.3706, -52.1462, -17.945, -0.999958, 0, 0, -0.009217, False, '2025-08-07 17:06:00'); /* lizardlizardlizardgen */
/* @teleloc 0x01D7014D [40.370602 -52.146198 -17.945000] -0.999958 0.000000 0.000000 -0.009217 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701D7034, 63163113, 0x01D70150, 40.6531, -60.348, -17.945, -0.376647, 0, 0, -0.926357, False, '2025-08-07 17:06:02'); /* lizardlizardlizardgen */
/* @teleloc 0x01D70150 [40.653099 -60.348000 -17.945000] -0.376647 0.000000 0.000000 -0.926357 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701D7035, 63163113, 0x01D7014B, 44.9969, -40.4072, -17.945, -0.567947, 0, 0, 0.823065, False, '2025-08-07 17:06:07'); /* lizardlizardlizardgen */
/* @teleloc 0x01D7014B [44.996899 -40.407200 -17.945000] -0.567947 0.000000 0.000000 0.823065 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701D7036, 63163113, 0x01D7016B, 62.6596, -42.6508, -17.945, -0.942475, 0, 0, 0.334277, False, '2025-08-07 17:06:09'); /* lizardlizardlizardgen */
/* @teleloc 0x01D7016B [62.659599 -42.650799 -17.945000] -0.942475 0.000000 0.000000 0.334277 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701D7037, 63163113, 0x01D70181, 77.009, -28.2789, -17.945, -0.942475, 0, 0, 0.334277, False, '2025-08-07 17:06:11'); /* lizardlizardlizardgen */
/* @teleloc 0x01D70181 [77.009003 -28.278900 -17.945000] -0.942475 0.000000 0.000000 0.334277 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701D7038, 63163113, 0x01D7017D, 77.4218, -10.4759, -17.945, -0.926608, 0, 0, -0.376029, False, '2025-08-07 17:06:15'); /* lizardlizardlizardgen */
/* @teleloc 0x01D7017D [77.421799 -10.475900 -17.945000] -0.926608 0.000000 0.000000 -0.376029 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701D7039, 63163113, 0x01D70151, 52.51, -1.72382, -17.945, -0.797295, 0, 0, -0.60359, False, '2025-08-07 17:06:19'); /* lizardlizardlizardgen */
/* @teleloc 0x01D70151 [52.509998 -1.723820 -17.945000] -0.797295 0.000000 0.000000 -0.603590 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701D703A, 63163113, 0x01D70142, 39.4046, -1.32751, -17.945, -0.997899, 0, 0, -0.064794, False, '2025-08-07 17:06:22'); /* lizardlizardlizardgen */
/* @teleloc 0x01D70142 [39.404598 -1.327510 -17.945000] -0.997899 0.000000 0.000000 -0.064794 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701D703B, 63163113, 0x01D70147, 36.3302, -19.0384, -17.945, -0.32005, 0, 0, -0.947401, False, '2025-08-07 17:06:25'); /* lizardlizardlizardgen */
/* @teleloc 0x01D70147 [36.330200 -19.038401 -17.945000] -0.320050 0.000000 0.000000 -0.947401 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701D703C, 63163113, 0x01D70219, 89.8788, -48.8176, -14.945, -0.926167, 0, 0, -0.377113, False, '2025-08-07 17:06:41'); /* lizardlizardlizardgen */
/* @teleloc 0x01D70219 [89.878799 -48.817600 -14.945000] -0.926167 0.000000 0.000000 -0.377113 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701D703D, 63163113, 0x01D70206, 80.3763, -60.409, -11.945, -0.5967, 0, 0, -0.802464, False, '2025-08-07 17:06:44'); /* lizardlizardlizardgen */
/* @teleloc 0x01D70206 [80.376297 -60.409000 -11.945000] -0.596700 0.000000 0.000000 -0.802464 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701D703E, 63163113, 0x01D70100, 16.9319, -20.2226, -35.945, 0.991408, 0, 0, -0.130808, False, '2025-08-07 17:07:07'); /* lizardlizardlizardgen */
/* @teleloc 0x01D70100 [16.931900 -20.222601 -35.945000] 0.991408 0.000000 0.000000 -0.130808 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701D703F, 63163113, 0x01D70100, 21.561, -20.9138, -35.945, 0.86857, 0, 0, -0.495566, False, '2025-08-07 17:07:09'); /* lizardlizardlizardgen */
/* @teleloc 0x01D70100 [21.561001 -20.913799 -35.945000] 0.868570 0.000000 0.000000 -0.495566 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701D7040, 5187492, 0x01D70273, 45.5835, -135.435, 0.0075, 0.425865, 0, 0, -0.904787, False, '2025-08-07 17:35:29'); /* Lizard Hunter */
/* @teleloc 0x01D70273 [45.583500 -135.434998 0.007500] 0.425865 0.000000 0.000000 -0.904787 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701D7041, 63163113, 0x01D70103, 45.5916, -15.5, -35.945, 0.113622, 0, 0, -0.993524, False, '2025-08-07 17:40:14'); /* lizardlizardlizardgen */
/* @teleloc 0x01D70103 [45.591599 -15.500000 -35.945000] 0.113622 0.000000 0.000000 -0.993524 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701D7042, 63163113, 0x01D70104, 50.8837, -25.6473, -35.945, 0.075336, 0, 0, -0.997158, False, '2025-08-07 17:40:16'); /* lizardlizardlizardgen */
/* @teleloc 0x01D70104 [50.883701 -25.647301 -35.945000] 0.075336 0.000000 0.000000 -0.997158 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701D7043, 63163113, 0x01D70107, 61.1667, -22.0121, -35.945, 0.907351, 0, 0, -0.420373, False, '2025-08-07 17:40:18'); /* lizardlizardlizardgen */
/* @teleloc 0x01D70107 [61.166698 -22.012100 -35.945000] 0.907351 0.000000 0.000000 -0.420373 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701D7044, 63163113, 0x01D7016D, 64.09575, -39.95573, -17.945, -0.420502, 0, 0, -0.907292, False, '2025-08-07 17:40:37'); /* lizardlizardlizardgen */
/* @teleloc 0x01D7016D [64.095749 -39.955730 -17.945000] -0.420502 0.000000 0.000000 -0.907292 */
