DELETE FROM `landblock_instance` WHERE `landblock` = 0x07FA;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA000, 86653816, 0x07FA0016, 50.0687, 136.673, 50.055, -0.709175, 0, 0, -0.705032, False, '2025-08-26 04:24:00'); /* wallwithwalkwayattop */
/* @teleloc 0x07FA0016 [50.068699 136.673004 50.055000] -0.709175 0.000000 0.000000 -0.705032 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA001, 86653816, 0x07FA0016, 55.7368, 143.303, 50.055, -0.999995, 0, 0, -0.003165, False, '2025-08-26 04:24:11'); /* wallwithwalkwayattop */
/* @teleloc 0x07FA0016 [55.736801 143.302994 50.055000] -0.999995 0.000000 0.000000 -0.003165 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA002, 86653816, 0x07FA0016, 68.8928, 143.386, 50.055, -0.999995, 0, 0, -0.003165, False, '2025-08-26 04:24:16'); /* wallwithwalkwayattop */
/* @teleloc 0x07FA0016 [68.892799 143.386002 50.055000] -0.999995 0.000000 0.000000 -0.003165 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA004, 86653816, 0x07FA001E, 90.9225, 143.525, 50.055, -0.999995, 0, 0, -0.003165, False, '2025-08-26 04:24:23'); /* wallwithwalkwayattop */
/* @teleloc 0x07FA001E [90.922501 143.524994 50.055000] -0.999995 0.000000 0.000000 -0.003165 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA005, 86653816, 0x07FA0026, 102.318, 143.547, 50.055, -0.999762, 0, 0, 0.021833, False, '2025-08-26 04:24:29'); /* wallwithwalkwayattop */
/* @teleloc 0x07FA0026 [102.318001 143.546997 50.055000] -0.999762 0.000000 0.000000 0.021833 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA006, 86653816, 0x07FA0026, 114.101, 143.532, 50.055, -0.999995, 0, 0, -0.003165, False, '2025-08-26 04:24:35'); /* wallwithwalkwayattop */
/* @teleloc 0x07FA0026 [114.100998 143.531998 50.055000] -0.999995 0.000000 0.000000 -0.003165 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA008, 86653816, 0x07FA002E, 139.87, 143.433, 50.055, -0.999995, 0, 0, -0.003165, False, '2025-08-26 04:24:47'); /* wallwithwalkwayattop */
/* @teleloc 0x07FA002E [139.869995 143.432999 50.055000] -0.999995 0.000000 0.000000 -0.003165 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA009, 86653816, 0x07FA002E, 123.785, 142.382, 50.055, -0.997485, 0, 0, 0.070874, False, '2025-08-26 04:25:04'); /* wallwithwalkwayattop */
/* @teleloc 0x07FA002E [123.785004 142.382004 50.055000] -0.997485 0.000000 0.000000 0.070874 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA00A, 86653816, 0x07FA002E, 133.556, 142.101, 50.055, -0.999863, 0, 0, -0.016566, False, '2025-08-26 04:25:09'); /* wallwithwalkwayattop */
/* @teleloc 0x07FA002E [133.556000 142.100998 50.055000] -0.999863 0.000000 0.000000 -0.016566 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA00B, 86653816, 0x07FA002E, 143.992, 135.229, 50.055, -0.735495, 0, 0, 0.677531, False, '2025-08-26 04:25:19'); /* wallwithwalkwayattop */
/* @teleloc 0x07FA002E [143.992004 135.229004 50.055000] -0.735495 0.000000 0.000000 0.677531 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA00C, 86653816, 0x07FA002E, 143.839, 121.571, 50.055, -0.700713, 0, 0, 0.713443, False, '2025-08-26 04:25:24'); /* wallwithwalkwayattop */
/* @teleloc 0x07FA002E [143.839005 121.570999 50.055000] -0.700713 0.000000 0.000000 0.713443 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA00E, 86653816, 0x07FA002D, 142.542, 97.6393, 50.055, -0.68266, 0, 0, 0.730736, False, '2025-08-26 04:25:33'); /* wallwithwalkwayattop */
/* @teleloc 0x07FA002D [142.542007 97.639297 50.055000] -0.682660 0.000000 0.000000 0.730736 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA00F, 86653816, 0x07FA002C, 142.997, 83.624, 50.055, -0.722664, 0, 0, 0.6912, False, '2025-08-26 04:25:39'); /* wallwithwalkwayattop */
/* @teleloc 0x07FA002C [142.996994 83.624001 50.055000] -0.722664 0.000000 0.000000 0.691200 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA010, 86653816, 0x07FA002C, 143.999, 73.4092, 50.055, -0.722664, 0, 0, 0.6912, False, '2025-08-26 04:25:43'); /* wallwithwalkwayattop */
/* @teleloc 0x07FA002C [143.998993 73.409203 50.055000] -0.722664 0.000000 0.000000 0.691200 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA011, 86653816, 0x07FA002B, 143.999, 61.7163, 50.055, -0.722664, 0, 0, 0.6912, False, '2025-08-26 04:25:47'); /* wallwithwalkwayattop */
/* @teleloc 0x07FA002B [143.998993 61.716301 50.055000] -0.722664 0.000000 0.000000 0.691200 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA012, 86653816, 0x07FA002B, 143.999, 50.6233, 50.055, -0.722664, 0, 0, 0.6912, False, '2025-08-26 04:25:51'); /* wallwithwalkwayattop */
/* @teleloc 0x07FA002B [143.998993 50.623299 50.055000] -0.722664 0.000000 0.000000 0.691200 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA013, 86653816, 0x07FA002B, 136.692, 48.0143, 50.055, -0.026739, 0, 0, 0.999642, False, '2025-08-26 04:26:00'); /* wallwithwalkwayattop */
/* @teleloc 0x07FA002B [136.692001 48.014301 50.055000] -0.026739 0.000000 0.000000 0.999642 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA014, 86653816, 0x07FA002B, 125.704, 48.0004, 50.055, -0.026739, 0, 0, 0.999642, False, '2025-08-26 04:26:03'); /* wallwithwalkwayattop */
/* @teleloc 0x07FA002B [125.704002 48.000401 50.055000] -0.026739 0.000000 0.000000 0.999642 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA015, 86653816, 0x07FA0023, 115.7, 48.0004, 50.055, -0.026739, 0, 0, 0.999642, False, '2025-08-26 04:26:07'); /* wallwithwalkwayattop */
/* @teleloc 0x07FA0023 [115.699997 48.000401 50.055000] -0.026739 0.000000 0.000000 0.999642 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA016, 86653816, 0x07FA0023, 105.228, 48.0004, 50.055, -0.026739, 0, 0, 0.999642, False, '2025-08-26 04:26:11'); /* wallwithwalkwayattop */
/* @teleloc 0x07FA0023 [105.227997 48.000401 50.055000] -0.026739 0.000000 0.000000 0.999642 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA017, 86653816, 0x07FA001B, 94.7682, 48.0004, 50.055, -0.026739, 0, 0, 0.999642, False, '2025-08-26 04:26:15'); /* wallwithwalkwayattop */
/* @teleloc 0x07FA001B [94.768204 48.000401 50.055000] -0.026739 0.000000 0.000000 0.999642 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA018, 86653816, 0x07FA001B, 84.1938, 48.0004, 50.055, -0.026739, 0, 0, 0.999642, False, '2025-08-26 04:26:18'); /* wallwithwalkwayattop */
/* @teleloc 0x07FA001B [84.193802 48.000401 50.055000] -0.026739 0.000000 0.000000 0.999642 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA019, 86653816, 0x07FA001B, 73.7801, 48.0004, 50.055, -0.026739, 0, 0, 0.999642, False, '2025-08-26 04:26:23'); /* wallwithwalkwayattop */
/* @teleloc 0x07FA001B [73.780098 48.000401 50.055000] -0.026739 0.000000 0.000000 0.999642 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA01A, 86653816, 0x07FA0013, 63.2057, 48.0004, 50.055, -0.026739, 0, 0, 0.999642, False, '2025-08-26 04:26:26'); /* wallwithwalkwayattop */
/* @teleloc 0x07FA0013 [63.205700 48.000401 50.055000] -0.026739 0.000000 0.000000 0.999642 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA01B, 86653816, 0x07FA0013, 52.9787, 48.0004, 50.055, -0.026739, 0, 0, 0.999642, False, '2025-08-26 04:26:30'); /* wallwithwalkwayattop */
/* @teleloc 0x07FA0013 [52.978699 48.000401 50.055000] -0.026739 0.000000 0.000000 0.999642 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA01C, 86653816, 0x07FA0013, 48.068, 55.5452, 50.055, -0.715426, 0, 0, -0.698688, False, '2025-08-26 04:26:41'); /* wallwithwalkwayattop */
/* @teleloc 0x07FA0013 [48.068001 55.545200 50.055000] -0.715426 0.000000 0.000000 -0.698688 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA01D, 86653816, 0x07FA0013, 48.3225, 66.293, 50.055, -0.715426, 0, 0, -0.698688, False, '2025-08-26 04:26:45'); /* wallwithwalkwayattop */
/* @teleloc 0x07FA0013 [48.322498 66.292999 50.055000] -0.715426 0.000000 0.000000 -0.698688 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA01E, 86653816, 0x07FA0014, 48.5467, 75.7604, 50.055, -0.715426, 0, 0, -0.698688, False, '2025-08-26 04:26:48'); /* wallwithwalkwayattop */
/* @teleloc 0x07FA0014 [48.546700 75.760399 50.055000] -0.715426 0.000000 0.000000 -0.698688 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA01F, 86653816, 0x07FA0014, 48.8091, 86.844, 50.055, -0.715426, 0, 0, -0.698688, False, '2025-08-26 04:26:52'); /* wallwithwalkwayattop */
/* @teleloc 0x07FA0014 [48.809101 86.844002 50.055000] -0.715426 0.000000 0.000000 -0.698688 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA020, 86653816, 0x07FA0015, 49.0694, 97.8362, 50.055, -0.715426, 0, 0, -0.698688, False, '2025-08-26 04:26:56'); /* wallwithwalkwayattop */
/* @teleloc 0x07FA0015 [49.069401 97.836197 50.055000] -0.715426 0.000000 0.000000 -0.698688 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA021, 86653816, 0x07FA0015, 49.3095, 107.978, 50.055, -0.715426, 0, 0, -0.698688, False, '2025-08-26 04:26:59'); /* wallwithwalkwayattop */
/* @teleloc 0x07FA0015 [49.309502 107.977997 50.055000] -0.715426 0.000000 0.000000 -0.698688 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA022, 86653816, 0x07FA0015, 49.5698, 118.971, 50.055, -0.715426, 0, 0, -0.698688, False, '2025-08-26 04:27:03'); /* wallwithwalkwayattop */
/* @teleloc 0x07FA0015 [49.569801 118.971001 50.055000] -0.715426 0.000000 0.000000 -0.698688 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA023, 86653816, 0x07FA0016, 49.7332, 128.095, 50.055, -0.71032, 0, 0, -0.703879, False, '2025-08-26 04:27:30'); /* wallwithwalkwayattop */
/* @teleloc 0x07FA0016 [49.733200 128.095001 50.055000] -0.710320 0.000000 0.000000 -0.703879 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA024, 86653816, 0x07FA002D, 143.384, 109.381, 50.055, 0.693461, 0, 0, -0.720495, False, '2025-08-26 04:27:54'); /* wallwithwalkwayattop */
/* @teleloc 0x07FA002D [143.384003 109.380997 50.055000] 0.693461 0.000000 0.000000 -0.720495 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA025, 86653816, 0x07FA002D, 142.697, 115.095, 50.055, 0.68877, 0, 0, -0.72498, False, '2025-08-26 04:28:22'); /* wallwithwalkwayattop */
/* @teleloc 0x07FA002D [142.697006 115.095001 50.055000] 0.688770 0.000000 0.000000 -0.724980 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA026, 86653816, 0x07FA002E, 143.882, 129.362, 50.055, 0.697868, 0, 0, -0.716227, False, '2025-08-26 04:28:30'); /* wallwithwalkwayattop */
/* @teleloc 0x07FA002E [143.882004 129.362000 50.055000] 0.697868 0.000000 0.000000 -0.716227 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA027, 86653816, 0x07FA0016, 62.462, 143.797, 50.055, 0.999858, 0, 0, 0.016848, False, '2025-08-26 04:28:47'); /* wallwithwalkwayattop */
/* @teleloc 0x07FA0016 [62.462002 143.796997 50.055000] 0.999858 0.000000 0.000000 0.016848 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA028, 86653816, 0x07FA001E, 79.2047, 143.249, 50.055, -0.999884, 0, 0, 0.015231, False, '2025-08-26 04:38:24'); /* wallwithwalkwayattop */
/* @teleloc 0x07FA001E [79.204697 143.248993 50.055000] -0.999884 0.000000 0.000000 0.015231 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA02D, 490143, 0x07FA002D, 129.886, 105.13, 50.055, 0.697912, 0, 0, -0.716184, False, '2025-08-26 04:45:40'); /* Outpost Tent6 */
/* @teleloc 0x07FA002D [129.886002 105.129997 50.055000] 0.697912 0.000000 0.000000 -0.716184 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA02E, 490143, 0x07FA002C, 130.846, 92.8895, 50.055, 0.701511, 0, 0, -0.712659, False, '2025-08-26 04:45:48'); /* Outpost Tent6 */
/* @teleloc 0x07FA002C [130.845993 92.889503 50.055000] 0.701511 0.000000 0.000000 -0.712659 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA02F, 490143, 0x07FA002C, 130.453, 79.0082, 50.055, 0.744509, 0, 0, -0.667613, False, '2025-08-26 04:45:54'); /* Outpost Tent6 */
/* @teleloc 0x07FA002C [130.453003 79.008202 50.055000] 0.744509 0.000000 0.000000 -0.667613 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA030, 86653816, 0x07FA002C, 142.545, 90.1057, 50.055, 0.70949, 0, 0, -0.704715, False, '2025-08-26 04:46:21'); /* wallwithwalkwayattop */
/* @teleloc 0x07FA002C [142.544998 90.105698 50.055000] 0.709490 0.000000 0.000000 -0.704715 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA031, 490143, 0x07FA0026, 98.0004, 133.035, 50.055, 0.999795, 0, 0, -0.020257, False, '2025-08-26 04:46:44'); /* Outpost Tent6 */
/* @teleloc 0x07FA0026 [98.000397 133.035004 50.055000] 0.999795 0.000000 0.000000 -0.020257 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA036, 5000352, 0x07FA002B, 129.508, 53.2248, 50.055, 0.001548, 0, 0, 0.999999, False, '2025-08-26 04:48:38'); /* Great Frost Tree */
/* @teleloc 0x07FA002B [129.507996 53.224800 50.055000] 0.001548 0.000000 0.000000 0.999999 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA037, 5000352, 0x07FA002B, 124.404, 53.2407, 50.055, 0.001548, 0, 0, 0.999999, False, '2025-08-26 04:48:40'); /* Great Frost Tree */
/* @teleloc 0x07FA002B [124.403999 53.240700 50.055000] 0.001548 0.000000 0.000000 0.999999 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA038, 5000352, 0x07FA0023, 118.993, 53.2574, 50.055, 0.001548, 0, 0, 0.999999, False, '2025-08-26 04:48:42'); /* Great Frost Tree */
/* @teleloc 0x07FA0023 [118.992996 53.257401 50.055000] 0.001548 0.000000 0.000000 0.999999 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA039, 5000352, 0x07FA0023, 114.752, 53.2705, 50.055, 0.001548, 0, 0, 0.999999, False, '2025-08-26 04:48:43'); /* Great Frost Tree */
/* @teleloc 0x07FA0023 [114.751999 53.270500 50.055000] 0.001548 0.000000 0.000000 0.999999 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA03A, 5000352, 0x07FA0023, 109.943, 53.2854, 50.055, 0.001548, 0, 0, 0.999999, False, '2025-08-26 04:48:45'); /* Great Frost Tree */
/* @teleloc 0x07FA0023 [109.943001 53.285400 50.055000] 0.001548 0.000000 0.000000 0.999999 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA03B, 5000352, 0x07FA0023, 105.839, 53.2981, 50.055, 0.001548, 0, 0, 0.999999, False, '2025-08-26 04:48:47'); /* Great Frost Tree */
/* @teleloc 0x07FA0023 [105.838997 53.298100 50.055000] 0.001548 0.000000 0.000000 0.999999 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA03C, 5000352, 0x07FA0023, 101.839, 53.3105, 50.055, 0.001548, 0, 0, 0.999999, False, '2025-08-26 04:48:48'); /* Great Frost Tree */
/* @teleloc 0x07FA0023 [101.838997 53.310501 50.055000] 0.001548 0.000000 0.000000 0.999999 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA03D, 5000352, 0x07FA0023, 97.6938, 53.3234, 50.055, 0.001548, 0, 0, 0.999999, False, '2025-08-26 04:48:50'); /* Great Frost Tree */
/* @teleloc 0x07FA0023 [97.693802 53.323399 50.055000] 0.001548 0.000000 0.000000 0.999999 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA03E, 5000352, 0x07FA001B, 93.6891, 53.3358, 50.055, 0.001548, 0, 0, 0.999999, False, '2025-08-26 04:48:51'); /* Great Frost Tree */
/* @teleloc 0x07FA001B [93.689102 53.335800 50.055000] 0.001548 0.000000 0.000000 0.999999 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA03F, 5000352, 0x07FA001B, 89.2787, 53.3494, 50.055, 0.001548, 0, 0, 0.999999, False, '2025-08-26 04:48:53'); /* Great Frost Tree */
/* @teleloc 0x07FA001B [89.278702 53.349400 50.055000] 0.001548 0.000000 0.000000 0.999999 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA040, 5000352, 0x07FA001B, 85.1335, 53.3623, 50.055, 0.001548, 0, 0, 0.999999, False, '2025-08-26 04:48:54'); /* Great Frost Tree */
/* @teleloc 0x07FA001B [85.133499 53.362301 50.055000] 0.001548 0.000000 0.000000 0.999999 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA041, 5000352, 0x07FA001B, 81.0295, 53.375, 50.055, 0.001548, 0, 0, 0.999999, False, '2025-08-26 04:48:56'); /* Great Frost Tree */
/* @teleloc 0x07FA001B [81.029503 53.375000 50.055000] 0.001548 0.000000 0.000000 0.999999 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA042, 5000352, 0x07FA001B, 77.0373, 53.4161, 50.055, 0.001548, 0, 0, 0.999999, False, '2025-08-26 04:48:59'); /* Great Frost Tree */
/* @teleloc 0x07FA001B [77.037300 53.416100 50.055000] 0.001548 0.000000 0.000000 0.999999 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA043, 5000352, 0x07FA001B, 72.7418, 53.4294, 50.055, 0.001548, 0, 0, 0.999999, False, '2025-08-26 04:49:01'); /* Great Frost Tree */
/* @teleloc 0x07FA001B [72.741798 53.429401 50.055000] 0.001548 0.000000 0.000000 0.999999 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA044, 5000352, 0x07FA0013, 67.76, 53.4448, 50.055, 0.001548, 0, 0, 0.999999, False, '2025-08-26 04:49:03'); /* Great Frost Tree */
/* @teleloc 0x07FA0013 [67.760002 53.444801 50.055000] 0.001548 0.000000 0.000000 0.999999 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA045, 5000352, 0x07FA0013, 63.112, 53.4592, 50.055, 0.001548, 0, 0, 0.999999, False, '2025-08-26 04:49:05'); /* Great Frost Tree */
/* @teleloc 0x07FA0013 [63.112000 53.459202 50.055000] 0.001548 0.000000 0.000000 0.999999 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA046, 5000352, 0x07FA0013, 59.3035, 53.471, 50.055, 0.001548, 0, 0, 0.999999, False, '2025-08-26 04:49:07'); /* Great Frost Tree */
/* @teleloc 0x07FA0013 [59.303501 53.471001 50.055000] 0.001548 0.000000 0.000000 0.999999 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA047, 5000352, 0x07FA0013, 52.6431, 60.69, 50.055, 0.720178, 0, 0, 0.693789, False, '2025-08-26 04:49:11'); /* Great Frost Tree */
/* @teleloc 0x07FA0013 [52.643101 60.689999 50.055000] 0.720178 0.000000 0.000000 0.693789 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA048, 5000352, 0x07FA0013, 52.8299, 65.6911, 50.055, 0.720178, 0, 0, 0.693789, False, '2025-08-26 04:49:13'); /* Great Frost Tree */
/* @teleloc 0x07FA0013 [52.829899 65.691101 50.055000] 0.720178 0.000000 0.000000 0.693789 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA049, 5000352, 0x07FA0013, 52.9817, 69.7569, 50.055, 0.720178, 0, 0, 0.693789, False, '2025-08-26 04:49:15'); /* Great Frost Tree */
/* @teleloc 0x07FA0013 [52.981701 69.756897 50.055000] 0.720178 0.000000 0.000000 0.693789 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA04A, 5000352, 0x07FA0014, 53.1335, 73.8226, 50.055, 0.720178, 0, 0, 0.693789, False, '2025-08-26 04:49:16'); /* Great Frost Tree */
/* @teleloc 0x07FA0014 [53.133499 73.822601 50.055000] 0.720178 0.000000 0.000000 0.693789 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA04B, 5000352, 0x07FA0014, 53.311, 78.5776, 50.055, 0.720178, 0, 0, 0.693789, False, '2025-08-26 04:49:18'); /* Great Frost Tree */
/* @teleloc 0x07FA0014 [53.311001 78.577599 50.055000] 0.720178 0.000000 0.000000 0.693789 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA04C, 5000352, 0x07FA0014, 53.4778, 83.0445, 50.055, 0.720178, 0, 0, 0.693789, False, '2025-08-26 04:49:20'); /* Great Frost Tree */
/* @teleloc 0x07FA0014 [53.477798 83.044502 50.055000] 0.720178 0.000000 0.000000 0.693789 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA04D, 5000352, 0x07FA0014, 53.6325, 87.1867, 50.055, 0.720178, 0, 0, 0.693789, False, '2025-08-26 04:49:21'); /* Great Frost Tree */
/* @teleloc 0x07FA0014 [53.632500 87.186699 50.055000] 0.720178 0.000000 0.000000 0.693789 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA04E, 5000352, 0x07FA0014, 53.8107, 91.9599, 50.055, 0.720178, 0, 0, 0.693789, False, '2025-08-26 04:49:23'); /* Great Frost Tree */
/* @teleloc 0x07FA0014 [53.810699 91.959900 50.055000] 0.720178 0.000000 0.000000 0.693789 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA04F, 5000352, 0x07FA0015, 53.9971, 96.9517, 50.055, 0.720178, 0, 0, 0.693789, False, '2025-08-26 04:49:25'); /* Great Frost Tree */
/* @teleloc 0x07FA0015 [53.997101 96.951698 50.055000] 0.720178 0.000000 0.000000 0.693789 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA050, 5000352, 0x07FA0015, 54.1782, 101.803, 50.055, 0.720178, 0, 0, 0.693789, False, '2025-08-26 04:49:27'); /* Great Frost Tree */
/* @teleloc 0x07FA0015 [54.178200 101.803001 50.055000] 0.720178 0.000000 0.000000 0.693789 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA051, 5000352, 0x07FA0015, 54.3406, 106.152, 50.055, 0.720178, 0, 0, 0.693789, False, '2025-08-26 04:49:28'); /* Great Frost Tree */
/* @teleloc 0x07FA0015 [54.340599 106.152000 50.055000] 0.720178 0.000000 0.000000 0.693789 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA052, 5000352, 0x07FA0015, 54.503, 110.501, 50.055, 0.720178, 0, 0, 0.693789, False, '2025-08-26 04:49:30'); /* Great Frost Tree */
/* @teleloc 0x07FA0015 [54.502998 110.500999 50.055000] 0.720178 0.000000 0.000000 0.693789 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA053, 5000352, 0x07FA0015, 53.924, 114.312, 50.055, 0.706176, 0, 0, 0.708036, False, '2025-08-26 04:49:39'); /* Great Frost Tree */
/* @teleloc 0x07FA0015 [53.924000 114.311996 50.055000] 0.706176 0.000000 0.000000 0.708036 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA054, 5000352, 0x07FA0015, 54.6787, 119.6, 50.055, 0.765349, 0, 0, 0.643616, False, '2025-08-26 04:49:41'); /* Great Frost Tree */
/* @teleloc 0x07FA0015 [54.678699 119.599998 50.055000] 0.765349 0.000000 0.000000 0.643616 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA055, 5000352, 0x07FA0016, 55.5363, 124.526, 50.055, 0.765349, 0, 0, 0.643616, False, '2025-08-26 04:49:42'); /* Great Frost Tree */
/* @teleloc 0x07FA0016 [55.536301 124.526001 50.055000] 0.765349 0.000000 0.000000 0.643616 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA056, 5000352, 0x07FA0016, 55.9125, 129.459, 50.055, 0.714971, 0, 0, 0.699154, False, '2025-08-26 04:49:44'); /* Great Frost Tree */
/* @teleloc 0x07FA0016 [55.912498 129.459000 50.055000] 0.714971 0.000000 0.000000 0.699154 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA057, 5000352, 0x07FA0016, 55.9966, 133.217, 50.055, 0.714971, 0, 0, 0.699154, False, '2025-08-26 04:49:46'); /* Great Frost Tree */
/* @teleloc 0x07FA0016 [55.996601 133.216995 50.055000] 0.714971 0.000000 0.000000 0.699154 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA058, 5000352, 0x07FA0016, 61.4575, 138.882, 50.055, 0.999978, 0, 0, 0.006705, False, '2025-08-26 04:49:50'); /* Great Frost Tree */
/* @teleloc 0x07FA0016 [61.457500 138.882004 50.055000] 0.999978 0.000000 0.000000 0.006705 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA059, 5000352, 0x07FA0016, 65.7315, 138.511, 50.055, 0.999023, 0, 0, 0.044191, False, '2025-08-26 04:49:53'); /* Great Frost Tree */
/* @teleloc 0x07FA0016 [65.731499 138.511002 50.055000] 0.999023 0.000000 0.000000 0.044191 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA05A, 5000352, 0x07FA0016, 70.6084, 138.943, 50.055, 0.999023, 0, 0, 0.044191, False, '2025-08-26 04:49:55'); /* Great Frost Tree */
/* @teleloc 0x07FA0016 [70.608398 138.942993 50.055000] 0.999023 0.000000 0.000000 0.044191 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA05B, 5000352, 0x07FA001E, 75.0582, 138.919, 50.055, 0.999023, 0, 0, 0.044191, False, '2025-08-26 04:49:57'); /* Great Frost Tree */
/* @teleloc 0x07FA001E [75.058197 138.919006 50.055000] 0.999023 0.000000 0.000000 0.044191 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA05C, 5000352, 0x07FA001E, 79.0675, 138.797, 50.055, 0.999023, 0, 0, 0.044191, False, '2025-08-26 04:49:58'); /* Great Frost Tree */
/* @teleloc 0x07FA001E [79.067497 138.796997 50.055000] 0.999023 0.000000 0.000000 0.044191 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA05D, 5000352, 0x07FA001E, 83.1055, 138.674, 50.055, 0.999023, 0, 0, 0.044191, False, '2025-08-26 04:50:00'); /* Great Frost Tree */
/* @teleloc 0x07FA001E [83.105499 138.673996 50.055000] 0.999023 0.000000 0.000000 0.044191 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA05E, 5000352, 0x07FA001E, 88.0775, 138.837, 50.055, 0.999023, 0, 0, 0.044191, False, '2025-08-26 04:50:02'); /* Great Frost Tree */
/* @teleloc 0x07FA001E [88.077499 138.837006 50.055000] 0.999023 0.000000 0.000000 0.044191 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA05F, 5000352, 0x07FA001E, 92.8183, 139.083, 50.055, 0.999023, 0, 0, 0.044191, False, '2025-08-26 04:50:04'); /* Great Frost Tree */
/* @teleloc 0x07FA001E [92.818298 139.082993 50.055000] 0.999023 0.000000 0.000000 0.044191 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA060, 5000352, 0x07FA0026, 97.9915, 139.189, 50.055, 0.999023, 0, 0, 0.044191, False, '2025-08-26 04:50:05'); /* Great Frost Tree */
/* @teleloc 0x07FA0026 [97.991501 139.188995 50.055000] 0.999023 0.000000 0.000000 0.044191 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA061, 5000352, 0x07FA0026, 102.803, 139.068, 50.055, 0.999023, 0, 0, 0.044191, False, '2025-08-26 04:50:07'); /* Great Frost Tree */
/* @teleloc 0x07FA0026 [102.803001 139.067993 50.055000] 0.999023 0.000000 0.000000 0.044191 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA062, 5000352, 0x07FA0026, 108.048, 138.839, 50.055, 0.999023, 0, 0, 0.044191, False, '2025-08-26 04:50:09'); /* Great Frost Tree */
/* @teleloc 0x07FA0026 [108.047997 138.839005 50.055000] 0.999023 0.000000 0.000000 0.044191 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA063, 5000352, 0x07FA0026, 112.986, 139.066, 50.055, 0.999023, 0, 0, 0.044191, False, '2025-08-26 04:50:11'); /* Great Frost Tree */
/* @teleloc 0x07FA0026 [112.986000 139.065994 50.055000] 0.999023 0.000000 0.000000 0.044191 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA064, 5000352, 0x07FA0026, 117.382, 139.1, 50.055, 0.999023, 0, 0, 0.044191, False, '2025-08-26 04:50:13'); /* Great Frost Tree */
/* @teleloc 0x07FA0026 [117.382004 139.100006 50.055000] 0.999023 0.000000 0.000000 0.044191 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA065, 5000352, 0x07FA002E, 121.509, 138.058, 50.055, 0.999978, 0, 0, 0.006705, False, '2025-08-26 04:50:16'); /* Great Frost Tree */
/* @teleloc 0x07FA002E [121.509003 138.057999 50.055000] 0.999978 0.000000 0.000000 0.006705 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA066, 5000352, 0x07FA002E, 125.875, 137.584, 50.055, 0.999063, 0, 0, -0.043281, False, '2025-08-26 04:50:18'); /* Great Frost Tree */
/* @teleloc 0x07FA002E [125.875000 137.584000 50.055000] 0.999063 0.000000 0.000000 -0.043281 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA067, 5000352, 0x07FA002E, 129.804, 137.088, 50.055, 0.999978, 0, 0, 0.006705, False, '2025-08-26 04:50:20'); /* Great Frost Tree */
/* @teleloc 0x07FA002E [129.804001 137.087997 50.055000] 0.999978 0.000000 0.000000 0.006705 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA068, 5000352, 0x07FA002E, 133.785, 137.142, 50.055, 0.999978, 0, 0, 0.006705, False, '2025-08-26 04:50:21'); /* Great Frost Tree */
/* @teleloc 0x07FA002E [133.785004 137.141998 50.055000] 0.999978 0.000000 0.000000 0.006705 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA069, 5000352, 0x07FA002E, 139.717, 132.157, 50.055, 0.676769, 0, 0, -0.736195, False, '2025-08-26 04:50:26'); /* Great Frost Tree */
/* @teleloc 0x07FA002E [139.716995 132.156998 50.055000] 0.676769 0.000000 0.000000 -0.736195 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA06A, 5000352, 0x07FA002E, 139.531, 128.159, 50.055, 0.703894, 0, 0, -0.710305, False, '2025-08-26 04:50:27'); /* Great Frost Tree */
/* @teleloc 0x07FA002E [139.531006 128.158997 50.055000] 0.703894 0.000000 0.000000 -0.710305 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA06B, 5000352, 0x07FA002E, 139.236, 124.681, 50.055, 0.703894, 0, 0, -0.710305, False, '2025-08-26 04:50:30'); /* Great Frost Tree */
/* @teleloc 0x07FA002E [139.235992 124.681000 50.055000] 0.703894 0.000000 0.000000 -0.710305 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA06C, 5000352, 0x07FA002E, 139.118, 121.186, 50.055, 0.648692, 0, 0, -0.761051, False, '2025-08-26 04:50:33'); /* Great Frost Tree */
/* @teleloc 0x07FA002E [139.117996 121.185997 50.055000] 0.648692 0.000000 0.000000 -0.761051 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA06D, 5000352, 0x07FA002D, 138.35, 117.246, 50.055, 0.72143, 0, 0, -0.692487, False, '2025-08-26 04:50:36'); /* Great Frost Tree */
/* @teleloc 0x07FA002D [138.350006 117.246002 50.055000] 0.721430 0.000000 0.000000 -0.692487 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA06E, 5000352, 0x07FA002D, 138.133, 113.028, 50.055, 0.72143, 0, 0, -0.692487, False, '2025-08-26 04:50:38'); /* Great Frost Tree */
/* @teleloc 0x07FA002D [138.132996 113.028000 50.055000] 0.721430 0.000000 0.000000 -0.692487 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA06F, 5000352, 0x07FA002D, 137.938, 108.755, 50.055, 0.72143, 0, 0, -0.692487, False, '2025-08-26 04:50:39'); /* Great Frost Tree */
/* @teleloc 0x07FA002D [137.938004 108.754997 50.055000] 0.721430 0.000000 0.000000 -0.692487 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA070, 5000352, 0x07FA002D, 138.126, 104.17, 50.055, 0.72143, 0, 0, -0.692487, False, '2025-08-26 04:50:41'); /* Great Frost Tree */
/* @teleloc 0x07FA002D [138.126007 104.169998 50.055000] 0.721430 0.000000 0.000000 -0.692487 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA071, 5000352, 0x07FA002D, 137.85, 99.7832, 50.055, 0.658155, 0, 0, -0.752883, False, '2025-08-26 04:50:43'); /* Great Frost Tree */
/* @teleloc 0x07FA002D [137.850006 99.783203 50.055000] 0.658155 0.000000 0.000000 -0.752883 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA072, 5000352, 0x07FA002C, 137.608, 95.4997, 50.055, 0.694961, 0, 0, -0.719048, False, '2025-08-26 04:50:45'); /* Great Frost Tree */
/* @teleloc 0x07FA002C [137.608002 95.499702 50.055000] 0.694961 0.000000 0.000000 -0.719048 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA073, 5000352, 0x07FA002C, 137.449, 90.8411, 50.055, 0.694961, 0, 0, -0.719048, False, '2025-08-26 04:50:48'); /* Great Frost Tree */
/* @teleloc 0x07FA002C [137.449005 90.841103 50.055000] 0.694961 0.000000 0.000000 -0.719048 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA074, 5000352, 0x07FA002C, 137.291, 86.1959, 50.055, 0.694961, 0, 0, -0.719048, False, '2025-08-26 04:50:49'); /* Great Frost Tree */
/* @teleloc 0x07FA002C [137.291000 86.195900 50.055000] 0.694961 0.000000 0.000000 -0.719048 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA075, 5000352, 0x07FA002C, 137.121, 81.217, 50.055, 0.694961, 0, 0, -0.719048, False, '2025-08-26 04:50:51'); /* Great Frost Tree */
/* @teleloc 0x07FA002C [137.121002 81.217003 50.055000] 0.694961 0.000000 0.000000 -0.719048 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA076, 5000352, 0x07FA002C, 136.954, 76.3238, 50.055, 0.694961, 0, 0, -0.719048, False, '2025-08-26 04:50:54'); /* Great Frost Tree */
/* @teleloc 0x07FA002C [136.953995 76.323799 50.055000] 0.694961 0.000000 0.000000 -0.719048 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA077, 5000352, 0x07FA002C, 136.974, 72.1355, 50.055, 0.72143, 0, 0, -0.692487, False, '2025-08-26 04:50:56'); /* Great Frost Tree */
/* @teleloc 0x07FA002C [136.973999 72.135498 50.055000] 0.721430 0.000000 0.000000 -0.692487 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA078, 5000352, 0x07FA002B, 137.179, 67.135, 50.055, 0.72143, 0, 0, -0.692487, False, '2025-08-26 04:50:57'); /* Great Frost Tree */
/* @teleloc 0x07FA002B [137.179001 67.135002 50.055000] 0.721430 0.000000 0.000000 -0.692487 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA079, 5000352, 0x07FA002B, 137.362, 62.6688, 50.055, 0.72143, 0, 0, -0.692487, False, '2025-08-26 04:51:00'); /* Great Frost Tree */
/* @teleloc 0x07FA002B [137.362000 62.668800 50.055000] 0.721430 0.000000 0.000000 -0.692487 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA07B, 5000352, 0x07FA002B, 133.604, 54.2629, 50.055, 0.057249, 0, 0, -0.99836, False, '2025-08-26 04:51:37'); /* Great Frost Tree */
/* @teleloc 0x07FA002B [133.604004 54.262901 50.055000] 0.057249 0.000000 0.000000 -0.998360 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA07D, 86653823, 0x07FA001D, 86.0286, 99.3051, 50.3, -0.019328, 0, 0, -0.999813, False, '2025-08-26 04:58:18'); /* building4 */
/* @teleloc 0x07FA001D [86.028603 99.305099 50.299999] -0.019328 0.000000 0.000000 -0.999813 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA07F, 86653830, 0x07FA001C, 78.5697, 85.4632, 53.9856, -0.040332, 0, 0, -0.999186, False, '2025-08-26 05:08:01'); /* painting11 */
/* @teleloc 0x07FA001C [78.569702 85.463203 53.985600] -0.040332 0.000000 0.000000 -0.999186 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA080, 86653831, 0x07FA0014, 69.5694, 85.6279, 53.5979, -0.05581, 0, 0, -0.998441, False, '2025-08-26 05:08:30'); /* painting22 */
/* @teleloc 0x07FA0014 [69.569397 85.627899 53.597900] -0.055810 0.000000 0.000000 -0.998441 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA081, 86653832, 0x07FA0014, 61.4007, 91.699, 53.4152, -0.713036, 0, 0, -0.701128, False, '2025-08-26 05:09:07'); /* painting33 */
/* @teleloc 0x07FA0014 [61.400700 91.698997 53.415199] -0.713036 0.000000 0.000000 -0.701128 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA082, 86653876, 0x07FA0014, 65.6114, 85.8425, 54.6089, 0.999982, 0, 0, -0.005973, False, '2025-08-26 05:10:23'); /* HANGING MOSWART */
/* @teleloc 0x07FA0014 [65.611397 85.842499 54.608898] 0.999982 0.000000 0.000000 -0.005973 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA088, 86659137, 0x07FA001B, 95.589, 68.1364, 50.055, -0.152162, 0, 0, -0.988356, False, '2025-08-26 05:14:42'); /* Cool lanter for road */
/* @teleloc 0x07FA001B [95.588997 68.136398 50.055000] -0.152162 0.000000 0.000000 -0.988356 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA089, 86659137, 0x07FA001B, 86.5093, 71.0124, 50.055, -0.159291, 0, 0, -0.987232, False, '2025-08-26 05:14:48'); /* Cool lanter for road */
/* @teleloc 0x07FA001B [86.509300 71.012398 50.055000] -0.159291 0.000000 0.000000 -0.987232 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA08B, 5000352, 0x07FA002E, 136.909, 135.258, 50.055, -0.921622, 0, 0, 0.38809, False, '2025-08-26 05:28:27'); /* Great Frost Tree */
/* @teleloc 0x07FA002E [136.908997 135.257996 50.055000] -0.921622 0.000000 0.000000 0.388090 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA08C, 5000352, 0x07FA0016, 56.545, 137.112, 50.055, -0.849593, 0, 0, -0.527439, False, '2025-08-26 05:28:38'); /* Great Frost Tree */
/* @teleloc 0x07FA0016 [56.544998 137.112000 50.055000] -0.849593 0.000000 0.000000 -0.527439 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA08D, 5000352, 0x07FA0013, 55.2899, 55.5594, 50.055, -0.310529, 0, 0, -0.950564, False, '2025-08-26 05:28:47'); /* Great Frost Tree */
/* @teleloc 0x07FA0013 [55.289902 55.559399 50.055000] -0.310529 0.000000 0.000000 -0.950564 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA08E, 5000352, 0x07FA002B, 136.084, 57.7698, 50.055, 0.451801, 0, 0, -0.892119, False, '2025-08-26 05:28:56'); /* Great Frost Tree */
/* @teleloc 0x07FA002B [136.084000 57.769798 50.055000] 0.451801 0.000000 0.000000 -0.892119 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA08F, 86653820, 0x07FA002B, 129.007, 61.9966, 50.055, -0.323619, 0, 0, 0.946188, False, '2025-08-26 05:29:10'); /* firepit1 */
/* @teleloc 0x07FA002B [129.007004 61.996601 50.055000] -0.323619 0.000000 0.000000 0.946188 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA090, 86653820, 0x07FA002E, 133.064, 128.487, 50.055, -0.958515, 0, 0, 0.285043, False, '2025-08-26 05:29:17'); /* firepit1 */
/* @teleloc 0x07FA002E [133.063995 128.487000 50.055000] -0.958515 0.000000 0.000000 0.285043 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA091, 86653820, 0x07FA0016, 62.1246, 133.206, 50.055, -0.907932, 0, 0, -0.419117, False, '2025-08-26 05:29:24'); /* firepit1 */
/* @teleloc 0x07FA0016 [62.124599 133.205994 50.055000] -0.907932 0.000000 0.000000 -0.419117 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA092, 86653820, 0x07FA0013, 58.8423, 61.5529, 50.055, -0.388581, 0, 0, -0.921415, False, '2025-08-26 05:29:31'); /* firepit1 */
/* @teleloc 0x07FA0013 [58.842300 61.552898 50.055000] -0.388581 0.000000 0.000000 -0.921415 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA097, 44288, 0x07FA002C, 129.968, 84.8067, 50.0055, 0.749912, 0, 0, 0.661538, False, '2025-08-26 05:43:05'); /* Bemeth the Gatherer */
/* @teleloc 0x07FA002C [129.968002 84.806702 50.005501] 0.749912 0.000000 0.000000 0.661538 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA098, 44300, 0x07FA002C, 130.251, 87.2201, 50.005, 0.655012, 0, 0, 0.755618, False, '2025-08-26 05:43:54'); /* Hammah al Rundik */
/* @teleloc 0x07FA002C [130.251007 87.220100 50.005001] 0.655012 0.000000 0.000000 0.755618 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA099, 44261, 0x07FA002C, 130.39, 93.0866, 50.005, -0.679085, 0, 0, -0.73406, False, '2025-08-26 05:44:27'); /* Sir Ibreh bin Kassim */
/* @teleloc 0x07FA002C [130.389999 93.086601 50.005001] -0.679085 0.000000 0.000000 -0.734060 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA09A, 44301, 0x07FA002D, 131.649, 98.9005, 50.005, 0.677144, 0, 0, 0.73585, False, '2025-08-26 05:45:01'); /* Taylarn bint Tulani */
/* @teleloc 0x07FA002D [131.649002 98.900497 50.005001] 0.677144 0.000000 0.000000 0.735850 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA09B, 44299, 0x07FA002D, 131.234, 104.053, 50.005, 0.605956, 0, 0, 0.795498, False, '2025-08-26 05:45:29'); /* T'ing Setsuko */
/* @teleloc 0x07FA002D [131.233994 104.053001 50.005001] 0.605956 0.000000 0.000000 0.795498 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA09C, 44263, 0x07FA002C, 131.096, 90.0018, 50.005, 0.694447, 0, 0, 0.719544, False, '2025-08-26 05:46:02'); /* Sir Hassim bin Tamarek */
/* @teleloc 0x07FA002C [131.095993 90.001801 50.005001] 0.694447 0.000000 0.000000 0.719544 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA09D, 44262, 0x07FA002D, 131.588, 101.354, 50.005, -0.649551, 0, 0, -0.760318, False, '2025-08-26 05:46:30'); /* Sir Adarl */
/* @teleloc 0x07FA002D [131.587997 101.353996 50.005001] -0.649551 0.000000 0.000000 -0.760318 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA09E, 44260, 0x07FA002D, 129.672, 106.577, 50.005, -0.706626, 0, 0, -0.707588, False, '2025-08-26 05:47:06'); /* Dame Tularin */
/* @teleloc 0x07FA002D [129.671997 106.577003 50.005001] -0.706626 0.000000 0.000000 -0.707588 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA09F, 43804, 0x07FA0026, 97.1293, 132.74, 50.005, 0.012323, 0, 0, -0.999924, False, '2025-08-26 05:48:37'); /* Sir Donovan */
/* @teleloc 0x07FA0026 [97.129303 132.740005 50.005001] 0.012323 0.000000 0.000000 -0.999924 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA0A0, 43847, 0x07FA0026, 99.4499, 132.538, 50.006, -0.008231, 0, 0, 0.999966, False, '2025-08-26 05:48:58'); /* Sir Learth */
/* @teleloc 0x07FA0026 [99.449898 132.537994 50.006001] -0.008231 0.000000 0.000000 0.999966 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA0A1, 43988, 0x07FA001E, 92.3382, 133.001, 50.0057, 0.015691, 0, 0, -0.999877, False, '2025-08-26 05:49:19'); /* Lady Daenerah */
/* @teleloc 0x07FA001E [92.338203 133.001007 50.005699] 0.015691 0.000000 0.000000 -0.999877 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA0A2, 43495, 0x07FA001E, 90.0974, 132.55, 50.005, 0.025898, 0, 0, 0.999665, False, '2025-08-26 05:49:42'); /* Gregoria, Gurog Destroyer */
/* @teleloc 0x07FA001E [90.097397 132.550003 50.005001] 0.025898 0.000000 0.000000 0.999665 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA0A3, 43740, 0x07FA001E, 88.3499, 132.63, 50.005, 0.026251, 0, 0, -0.999655, False, '2025-08-26 05:50:20'); /* Hunter */
/* @teleloc 0x07FA001E [88.349899 132.630005 50.005001] 0.026251 0.000000 0.000000 -0.999655 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA0A4, 43741, 0x07FA001E, 85.5824, 133.011, 50.005, -0.087912, 0, 0, 0.996128, False, '2025-08-26 05:50:49'); /* Archmage Ichihiri */
/* @teleloc 0x07FA001E [85.582397 133.011002 50.005001] -0.087912 0.000000 0.000000 0.996128 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA0A5, 44989, 0x07FA001E, 82.8175, 133.898, 50.005, 0.028157, 0, 0, -0.999604, False, '2025-08-26 05:51:20'); /* Halvor */
/* @teleloc 0x07FA001E [82.817497 133.897995 50.005001] 0.028157 0.000000 0.000000 -0.999604 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA0A6, 51961, 0x07FA001E, 80.41, 134.068, 50.005, 0.002135, 0, 0, -0.999998, False, '2025-08-26 05:51:39'); /* Leilah */
/* @teleloc 0x07FA001E [80.410004 134.067993 50.005001] 0.002135 0.000000 0.000000 -0.999998 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA0A7, 51959, 0x07FA0026, 102.354, 133.109, 50.005, -0.057622, 0, 0, 0.998339, False, '2025-08-26 05:52:02'); /* George */
/* @teleloc 0x07FA0026 [102.353996 133.108994 50.005001] -0.057622 0.000000 0.000000 0.998339 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA0A8, 51960, 0x07FA0026, 104.508, 133.319, 50.005, 0.020229, 0, 0, 0.999795, False, '2025-08-26 05:52:19'); /* Kumiko */
/* @teleloc 0x07FA0026 [104.508003 133.319000 50.005001] 0.020229 0.000000 0.000000 0.999795 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA0A9, 52286, 0x07FA0026, 106.461, 133.24, 50.005, 0.020229, 0, 0, 0.999795, False, '2025-08-26 05:52:31'); /* Boone */
/* @teleloc 0x07FA0026 [106.460999 133.240005 50.005001] 0.020229 0.000000 0.000000 0.999795 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA0AB, 86659125, 0x07FA001C, 91.4902, 94.1686, 50.055, 0.683814, 0, 0, 0.729656, False, '2025-08-26 05:56:10'); /* FIRE PEDISTAL 1 */
/* @teleloc 0x07FA001C [91.490196 94.168602 50.055000] 0.683814 0.000000 0.000000 0.729656 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA0AC, 86659125, 0x07FA001D, 91.7859, 103.275, 50.055, 0.723508, 0, 0, 0.690316, False, '2025-08-26 05:56:13'); /* FIRE PEDISTAL 1 */
/* @teleloc 0x07FA001D [91.785896 103.275002 50.055000] 0.723508 0.000000 0.000000 0.690316 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA0AD, 86659125, 0x07FA0015, 70.4799, 105.422, 50.055, -0.013236, 0, 0, 0.999912, False, '2025-08-26 05:56:17'); /* FIRE PEDISTAL 1 */
/* @teleloc 0x07FA0015 [70.479897 105.421997 50.055000] -0.013236 0.000000 0.000000 0.999912 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA0AE, 86659125, 0x07FA0015, 61.9531, 106.066, 50.055, -0.006983, 0, 0, 0.999976, False, '2025-08-26 05:56:20'); /* FIRE PEDISTAL 1 */
/* @teleloc 0x07FA0015 [61.953098 106.066002 50.055000] -0.006983 0.000000 0.000000 0.999976 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA0AF, 86659125, 0x07FA0015, 71.7316, 103.634, 50.055, -0.911975, 0, 0, -0.410245, False, '2025-08-26 05:56:36'); /* FIRE PEDISTAL 1 */
/* @teleloc 0x07FA0015 [71.731598 103.634003 50.055000] -0.911975 0.000000 0.000000 -0.410245 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA0B0, 86659125, 0x07FA001C, 89.3453, 85.3055, 50.055, -0.389398, 0, 0, 0.92107, False, '2025-08-26 05:56:40'); /* FIRE PEDISTAL 1 */
/* @teleloc 0x07FA001C [89.345299 85.305496 50.055000] -0.389398 0.000000 0.000000 0.921070 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA0B1, 86659125, 0x07FA0014, 61.6018, 86.4522, 50.055, 0.392011, 0, 0, 0.91996, False, '2025-08-26 05:56:45'); /* FIRE PEDISTAL 1 */
/* @teleloc 0x07FA0014 [61.601799 86.452202 50.055000] 0.392011 0.000000 0.000000 0.919960 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA0B2, 86659125, 0x07FA0015, 62.1238, 99.7511, 50.055, 0.969747, 0, 0, 0.244111, False, '2025-08-26 05:56:48'); /* FIRE PEDISTAL 1 */
/* @teleloc 0x07FA0015 [62.123798 99.751099 50.055000] 0.969747 0.000000 0.000000 0.244111 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA0B3, 86659125, 0x07FA0015, 69.8369, 99.6781, 50.055, 0.999929, 0, 0, -0.011932, False, '2025-08-26 05:56:52'); /* FIRE PEDISTAL 1 */
/* @teleloc 0x07FA0015 [69.836899 99.678101 50.055000] 0.999929 0.000000 0.000000 -0.011932 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA0B4, 86659125, 0x07FA001D, 86.1093, 103.21, 50.055, 0.709661, 0, 0, -0.704543, False, '2025-08-26 05:56:57'); /* FIRE PEDISTAL 1 */
/* @teleloc 0x07FA001D [86.109299 103.209999 50.055000] 0.709661 0.000000 0.000000 -0.704543 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA0B5, 86659125, 0x07FA001C, 84.8684, 95.401, 50.055, 0.682043, 0, 0, -0.731312, False, '2025-08-26 05:57:02'); /* FIRE PEDISTAL 1 */
/* @teleloc 0x07FA001C [84.868401 95.401001 50.055000] 0.682043 0.000000 0.000000 -0.731312 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA0B8, 36236, 0x07FA001C, 84.3469, 85.448, 50.005, 0.999817, 0, 0, -0.019138, False, '2025-08-26 05:58:32'); /* Lo Shoen */
/* @teleloc 0x07FA001C [84.346901 85.447998 50.005001] 0.999817 0.000000 0.000000 -0.019138 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA0B9, 37477, 0x07FA0014, 61.8172, 92.2029, 50.006, -0.718535, 0, 0, 0.695491, False, '2025-08-26 05:59:04'); /* Hurnmel the Smith */
/* @teleloc 0x07FA0014 [61.817200 92.202904 50.006001] -0.718535 0.000000 0.000000 0.695491 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA0BA, 86659130, 0x07FA0014, 63.4132, 88.4551, 50.055, -0.338271, 0, 0, -0.941049, False, '2025-08-26 05:59:21'); /* COOL FORGE PROP */
/* @teleloc 0x07FA0014 [63.413200 88.455101 50.055000] -0.338271 0.000000 0.000000 -0.941049 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA0BD, 35106, 0x07FA001C, 78.1189, 85.6913, 50.006, 0.995892, 0, 0, -0.090546, False, '2025-08-26 06:00:32'); /* Shade of Parieth */
/* @teleloc 0x07FA001C [78.118896 85.691299 50.006001] 0.995892 0.000000 0.000000 -0.090546 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA0BE, 40922, 0x07FA001C, 74.7604, 85.8305, 50.005, -0.999852, 0, 0, 0.017206, False, '2025-08-26 06:01:02'); /* Sharia Blackmist */
/* @teleloc 0x07FA001C [74.760399 85.830498 50.005001] -0.999852 0.000000 0.000000 0.017206 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA0BF, 51955, 0x07FA001D, 73.8866, 103.692, 50.005, 0.015661, 0, 0, 0.999877, False, '2025-08-26 06:04:46'); /* Renata */
/* @teleloc 0x07FA001D [73.886597 103.692001 50.005001] 0.015661 0.000000 0.000000 0.999877 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA0C0, 51957, 0x07FA001D, 76.0701, 103.613, 50.005, 0.015661, 0, 0, 0.999877, False, '2025-08-26 06:04:50'); /* Yoite */
/* @teleloc 0x07FA001D [76.070099 103.612999 50.005001] 0.015661 0.000000 0.000000 0.999877 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA0C1, 51958, 0x07FA001D, 78.4202, 103.522, 50.005, -0.009339, 0, 0, 0.999956, False, '2025-08-26 06:05:07'); /* Gadi */
/* @teleloc 0x07FA001D [78.420197 103.522003 50.005001] -0.009339 0.000000 0.000000 0.999956 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA0C2, 51956, 0x07FA001D, 80.4335, 103.444, 50.005, -0.009339, 0, 0, 0.999956, False, '2025-08-26 06:05:11'); /* Aethelswith */
/* @teleloc 0x07FA001D [80.433502 103.444000 50.005001] -0.009339 0.000000 0.000000 0.999956 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA0C4, 86659156, 0x07FA0023, 119.892, 57.8935, 50, -0.99938, 0, 0, 0.035216, False, '2025-08-26 06:07:13'); /* BLACK PILLAR WITH RED LIGHTNING */
/* @teleloc 0x07FA0023 [119.891998 57.893501 50.000000] -0.999380 0.000000 0.000000 0.035216 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA0C5, 86659156, 0x07FA0013, 65.4645, 57.9835, 50, -0.713162, 0, 0, -0.700999, False, '2025-08-26 06:07:21'); /* BLACK PILLAR WITH RED LIGHTNING */
/* @teleloc 0x07FA0013 [65.464500 57.983501 50.000000] -0.713162 0.000000 0.000000 -0.700999 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA0C6, 51654, 0x07FA0023, 115.91, 56.6413, 50.0075, -0.999772, 0, 0, -0.021343, False, '2025-08-26 06:07:39'); /* Ilte Krongal */
/* @teleloc 0x07FA0023 [115.910004 56.641300 50.007500] -0.999772 0.000000 0.000000 -0.021343 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA0C7, 51789, 0x07FA0023, 113.468, 56.537, 50.005, -0.999772, 0, 0, -0.021343, False, '2025-08-26 06:07:49'); /* Rinne Gorber */
/* @teleloc 0x07FA0023 [113.468002 56.536999 50.005001] -0.999772 0.000000 0.000000 -0.021343 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA0C8, 51681, 0x07FA0023, 111.711, 56.462, 50.005, -0.999772, 0, 0, -0.021343, False, '2025-08-26 06:08:00'); /* Geilla */
/* @teleloc 0x07FA0023 [111.710999 56.462002 50.005001] -0.999772 0.000000 0.000000 -0.021343 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA0C9, 51861, 0x07FA0023, 108.601, 56.3586, 50.005, -0.997456, 0, 0, -0.071284, False, '2025-08-26 06:08:33'); /* Hernd */
/* @teleloc 0x07FA0023 [108.600998 56.358601 50.005001] -0.997456 0.000000 0.000000 -0.071284 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA0CA, 51860, 0x07FA0023, 106.4, 56.5902, 50.006, -0.997456, 0, 0, -0.071284, False, '2025-08-26 06:08:44'); /* Tillahan */
/* @teleloc 0x07FA0023 [106.400002 56.590199 50.006001] -0.997456 0.000000 0.000000 -0.071284 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA0CB, 51888, 0x07FA0023, 103.325, 56.3111, 50.029, -0.997456, 0, 0, -0.071284, False, '2025-08-26 06:08:55'); /* The Bringer of Light */
/* @teleloc 0x07FA0023 [103.324997 56.311100 50.028999] -0.997456 0.000000 0.000000 -0.071284 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA0CC, 52281, 0x07FA0023, 100.996, 56.5582, 50.029, -0.997456, 0, 0, -0.071284, False, '2025-08-26 06:09:06'); /* Lohrn */
/* @teleloc 0x07FA0023 [100.996002 56.558201 50.028999] -0.997456 0.000000 0.000000 -0.071284 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA0CD, 51862, 0x07FA0023, 98.9812, 56.3826, 50.029, -0.997456, 0, 0, -0.071284, False, '2025-08-26 06:09:19'); /* Marcus */
/* @teleloc 0x07FA0023 [98.981201 56.382599 50.028999] -0.997456 0.000000 0.000000 -0.071284 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA0CE, 51923, 0x07FA0023, 96.8351, 56.5332, 50.01, -0.999772, 0, 0, -0.021343, False, '2025-08-26 06:09:31'); /* Raksaa */
/* @teleloc 0x07FA0023 [96.835098 56.533199 50.009998] -0.999772 0.000000 0.000000 -0.021343 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA0CF, 51864, 0x07FA001B, 94.6462, 56.5304, 50.029, -0.999772, 0, 0, -0.021343, False, '2025-08-26 06:09:43'); /* Ranulf */
/* @teleloc 0x07FA001B [94.646202 56.530399 50.028999] -0.999772 0.000000 0.000000 -0.021343 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA0D0, 51863, 0x07FA001B, 91.7725, 56.5665, 50.029, -0.999772, 0, 0, -0.021343, False, '2025-08-26 06:09:59'); /* Sylvanus */
/* @teleloc 0x07FA001B [91.772499 56.566502 50.028999] -0.999772 0.000000 0.000000 -0.021343 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA0D1, 51866, 0x07FA001B, 88.1884, 56.6136, 50.029, -0.999772, 0, 0, -0.021343, False, '2025-08-26 06:10:11'); /* Rhys */
/* @teleloc 0x07FA001B [88.188400 56.613602 50.028999] -0.999772 0.000000 0.000000 -0.021343 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA0D2, 51865, 0x07FA001B, 84.3453, 56.6419, 50.029, -0.999772, 0, 0, -0.021343, False, '2025-08-26 06:10:22'); /* Wido */
/* @teleloc 0x07FA001B [84.345299 56.641899 50.028999] -0.999772 0.000000 0.000000 -0.021343 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA0D3, 51614, 0x07FA001B, 80.7091, 56.6794, 50.029, -0.999772, 0, 0, -0.021343, False, '2025-08-26 06:10:40'); /* Vision of Horror */
/* @teleloc 0x07FA001B [80.709099 56.679401 50.028999] -0.999772 0.000000 0.000000 -0.021343 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA0D4, 51592, 0x07FA001B, 76.7464, 56.713, 50.029, -0.999772, 0, 0, -0.021343, False, '2025-08-26 06:10:54'); /* Virindi Delegate */
/* @teleloc 0x07FA001B [76.746399 56.713001 50.028999] -0.999772 0.000000 0.000000 -0.021343 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA0D5, 51987, 0x07FA001B, 74.4013, 56.7391, 50.006, 0.999957, 0, 0, -0.009266, False, '2025-08-26 06:11:41'); /* Morgethais */
/* @teleloc 0x07FA001B [74.401299 56.739101 50.006001] 0.999957 0.000000 0.000000 -0.009266 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA0D6, 52015, 0x07FA0013, 71.9317, 56.7849, 50.0055, 0.999957, 0, 0, -0.009266, False, '2025-08-26 06:11:54'); /* Aun Ol'tra */
/* @teleloc 0x07FA0013 [71.931702 56.784901 50.005501] 0.999957 0.000000 0.000000 -0.009266 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA0D7, 35109, 0x07FA001C, 75.6371, 95.7392, 50.0065, 0.556497, 0, 0, 0.83085, False, '2025-08-26 06:12:21'); /* Apep-tek the Tolerant */
/* @teleloc 0x07FA001C [75.637100 95.739197 50.006500] 0.556497 0.000000 0.000000 0.830850 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA0D8, 46015, 0x07FA001D, 88.6575, 104.697, 50.006, 0.988267, 0, 0, 0.152738, False, '2025-08-26 06:22:18'); /* Royal Guard */
/* @teleloc 0x07FA001D [88.657501 104.696999 50.006001] 0.988267 0.000000 0.000000 0.152738 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA0D9, 46016, 0x07FA001D, 84.9336, 104.834, 50.005, 0.988267, 0, 0, 0.152738, False, '2025-08-26 06:22:24'); /* Umbral Guard */
/* @teleloc 0x07FA001D [84.933601 104.834000 50.005001] 0.988267 0.000000 0.000000 0.152738 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA0DA, 52272, 0x07FA001D, 81.6709, 104.96, 50.005, 0.988267, 0, 0, 0.152738, False, '2025-08-26 06:22:32'); /* Royal Guard */
/* @teleloc 0x07FA001D [81.670898 104.959999 50.005001] 0.988267 0.000000 0.000000 0.152738 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA0DB, 46018, 0x07FA001D, 78.5772, 105.079, 50.005, 0.988267, 0, 0, 0.152738, False, '2025-08-26 06:22:42'); /* Royal Guard */
/* @teleloc 0x07FA001D [78.577202 105.079002 50.005001] 0.988267 0.000000 0.000000 0.152738 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA0DC, 46017, 0x07FA001D, 74.8255, 105.225, 50.005, 0.994665, 0, 0, 0.103154, False, '2025-08-26 06:22:51'); /* Royal Guard */
/* @teleloc 0x07FA001D [74.825500 105.224998 50.005001] 0.994665 0.000000 0.000000 0.103154 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA0DD, 41548, 0x07FA001C, 88.0828, 83.7236, 50.005, 0.038606, 0, 0, 0.999255, False, '2025-08-26 06:29:38'); /* T'ing Douzen */
/* @teleloc 0x07FA001C [88.082802 83.723602 50.005001] 0.038606 0.000000 0.000000 0.999255 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA0DE, 41546, 0x07FA001C, 85.9413, 83.8165, 50.005, 0.038606, 0, 0, 0.999255, False, '2025-08-26 06:29:45'); /* Dame Trielle */
/* @teleloc 0x07FA001C [85.941299 83.816498 50.005001] 0.038606 0.000000 0.000000 0.999255 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA0DF, 41545, 0x07FA001C, 83.5134, 83.9104, 50.005, 0.038606, 0, 0, 0.999255, False, '2025-08-26 06:29:49'); /* Sir Yanov */
/* @teleloc 0x07FA001C [83.513397 83.910400 50.005001] 0.038606 0.000000 0.000000 0.999255 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA0E0, 42360, 0x07FA001C, 80.7005, 83.9846, 50.005, 0.038606, 0, 0, 0.999255, False, '2025-08-26 06:30:03'); /* Sir Durnstad */
/* @teleloc 0x07FA001C [80.700500 83.984596 50.005001] 0.038606 0.000000 0.000000 0.999255 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA0E1, 43213, 0x07FA001C, 78.0152, 83.9157, 50.005, -0.011385, 0, 0, 0.999935, False, '2025-08-26 06:30:28'); /* Emissary of Asheron */
/* @teleloc 0x07FA001C [78.015198 83.915703 50.005001] -0.011385 0.000000 0.000000 0.999935 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA0E2, 43144, 0x07FA001C, 75.2644, 83.853, 50.0065, -0.036377, 0, 0, 0.999338, False, '2025-08-26 06:30:37'); /* Lintareal */
/* @teleloc 0x07FA001C [75.264397 83.852997 50.006500] -0.036377 0.000000 0.000000 0.999338 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA0E3, 41545, 0x07FA001C, 72.8009, 84.3734, 50.005, -0.036377, 0, 0, 0.999338, False, '2025-08-26 06:30:42'); /* Sir Yanov */
/* @teleloc 0x07FA001C [72.800903 84.373398 50.005001] -0.036377 0.000000 0.000000 0.999338 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA0E4, 64322152, 0x07FA001C, 91.9367, 89.8759, 50.006, -0.713526, 0, 0, 0.700629, False, '2025-08-26 08:29:46'); /* Naddamus The Hoarder */
/* @teleloc 0x07FA001C [91.936699 89.875900 50.006001] -0.713526 0.000000 0.000000 0.700629 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA0E8, 743223315, 0x07FA001E, 76.1796, 136.749, 49.937, 0.046057, 0, 0, -0.998939, False, '2025-08-26 15:40:34'); /* Snowy Valley Portal */
/* @teleloc 0x07FA001E [76.179604 136.748993 49.937000] 0.046057 0.000000 0.000000 -0.998939 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA0E9, 743223311, 0x07FA002C, 133.432, 74.178, 49.937, 0.725288, 0, 0, -0.688446, False, '2025-08-26 15:41:17'); /* Neftet Portal */
/* @teleloc 0x07FA002C [133.432007 74.178001 49.937000] 0.725288 0.000000 0.000000 -0.688446 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA0EA, 743223313, 0x07FA0013, 61.2861, 57.9528, 49.937, 0.382684, 0, 0, 0.92388, False, '2025-08-26 15:41:34'); /* Rynthid Portal */
/* @teleloc 0x07FA0013 [61.286098 57.952801 49.937000] 0.382684 0.000000 0.000000 0.923880 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA0EB, 743223314, 0x07FA0014, 67.2698, 86.8866, 49.937, -0.031167, 0, 0, -0.999514, False, '2025-08-26 15:42:53'); /* Graveyard Portal */
/* @teleloc 0x07FA0014 [67.269798 86.886597 49.937000] -0.031167 0.000000 0.000000 -0.999514 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA0EC, 743223312, 0x07FA0015, 57.0431, 111.141, 49.937, 0.648661, 0, 0, 0.761078, False, '2025-08-26 15:43:23'); /* TouTou Portal */
/* @teleloc 0x07FA0015 [57.043098 111.140999 49.937000] 0.648661 0.000000 0.000000 0.761078 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA0ED, 42852, 0x07FA002B, 125.335, 64.7662, 49.937, -0.375674, 0, 0, 0.926752, False, '2025-08-26 15:44:23'); /* Portal to Town Network */
/* @teleloc 0x07FA002B [125.334999 64.766197 49.937000] -0.375674 0.000000 0.000000 0.926752 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA0EE, 423481288, 0x07FA002E, 130.967, 127.315, 49.937, -0.885258, 0, 0, 0.4651, False, '2025-08-26 15:44:54'); /* Portal to Ravaged Island */
/* @teleloc 0x07FA002E [130.966995 127.315002 49.937000] -0.885258 0.000000 0.000000 0.465100 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA0EF, 91332772, 0x07FA0016, 64.4939, 130.274, 49.937, -0.923879, 0, 0, -0.382686, False, '2025-08-26 15:45:17'); /* Calfadar Village Portal */
/* @teleloc 0x07FA0016 [64.493896 130.274002 49.937000] -0.923879 0.000000 0.000000 -0.382686 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA0F0, 716165, 0x07FA0013, 56.5603, 68.2226, 49.7902, -0.731313, 0, 0, 0.682042, False, '2025-08-26 15:46:18'); /* Hopeslayer's Reach */
/* @teleloc 0x07FA0013 [56.560299 68.222603 49.790199] -0.731313 0.000000 0.000000 0.682042 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA0F1, 700012, 0x07FA001D, 92.2681, 103.198, 50.0065, 0.716866, 0, 0, -0.697211, False, '2025-08-26 15:47:16'); /* Nexus Buffer Mage */
/* @teleloc 0x07FA001D [92.268097 103.197998 50.006500] 0.716866 0.000000 0.000000 -0.697211 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA0F2, 49605, 0x07FA0024, 108.755, 82.0017, 50.005, 0.918556, 0, 0, 0.39529, False, '2025-08-26 15:47:47'); /* Town Crier */
/* @teleloc 0x07FA0024 [108.754997 82.001701 50.005001] 0.918556 0.000000 0.000000 0.395290 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA0F3, 86653868, 0x07FA002B, 120.9, 60.0524, 50.0075, -0.966526, 0, 0, -0.256568, False, '2025-08-26 15:48:21'); /* Bael'Zharon */
/* @teleloc 0x07FA002B [120.900002 60.052399 50.007500] -0.966526 0.000000 0.000000 -0.256568 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA0F4, 86653870, 0x07FA002E, 128.745, 133.868, 49.9875, 0.319342, 0, 0, 0.94764, False, '2025-08-26 15:48:45'); /* Asheron */
/* @teleloc 0x07FA002E [128.744995 133.867996 49.987499] 0.319342 0.000000 0.000000 0.947640 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA0F5, 743223316, 0x07FA0014, 68.0036, 84.0833, 49.937, 0.008453, 0, 0, 0.999964, False, '2025-08-26 16:05:15'); /* Gearknight Invasion Camp Portal */
/* @teleloc 0x07FA0014 [68.003601 84.083298 49.937000] 0.008453 0.000000 0.000000 0.999964 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA0F6, 960230, 0x07FA002E, 132.197, 120.276, 50.01, 0.682483, 0, 0, 0.730902, False, '2025-08-26 16:38:23'); /* Tammy The Tailor Vendor */
/* @teleloc 0x07FA002E [132.197006 120.276001 50.009998] 0.682483 0.000000 0.000000 0.730902 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA0F7, 450450, 0x07FA002D, 132.484, 116.09, 49.98, 0.682483, 0, 0, 0.730902, False, '2025-08-26 16:38:31'); /* Fasheron */
/* @teleloc 0x07FA002D [132.483994 116.089996 49.980000] 0.682483 0.000000 0.000000 0.730902 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA0F8, 42145216, 0x07FA001C, 91.4391, 86.6288, 50.005, 0.890765, 0, 0, -0.454464, False, '2025-08-26 17:25:59'); /* Tingdale the Barterer */
/* @teleloc 0x07FA001C [91.439102 86.628799 50.005001] 0.890765 0.000000 0.000000 -0.454464 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA0F9, 44101, 0x07FA002C, 129.191, 79.7328, 50.005, 0.749668, 0, 0, 0.661814, False, '2025-08-29 16:23:06'); /* Nephthys */
/* @teleloc 0x07FA002C [129.190994 79.732803 50.005001] 0.749668 0.000000 0.000000 0.661814 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA0FA, 47052, 0x07FA002C, 131.25, 94.717, 50.005, -0.717915, 0, 0, -0.696131, False, '2025-08-29 16:42:54'); /* Fahneph */
/* @teleloc 0x07FA002C [131.250000 94.717003 50.005001] -0.717915 0.000000 0.000000 -0.696131 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA0FB, 716002, 0x07FA0026, 117.959, 133.887, 50.0075, 0.009231, 0, 0, 0.999957, False, '2025-09-04 14:50:42'); /* Twisted Heat */
/* @teleloc 0x07FA0026 [117.959000 133.886993 50.007500] 0.009231 0.000000 0.000000 0.999957 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x707FA0FC,   509, 0x07FA0015, 64.05981, 119.9352, 50, 0.762665, 0, 0, 0.646794, False, '2025-09-06 17:33:36'); /* Life Stone */
/* @teleloc 0x07FA0015 [64.059807 119.935204 50.000000] 0.762665 0.000000 0.000000 0.646794 */
