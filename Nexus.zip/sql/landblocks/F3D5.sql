DELETE FROM `landblock_instance` WHERE `landblock` = 0xF3D5;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3D5001, 5000662, 0xF3D50010, 31.5782, 191.909, 0.055, -0.106654, 0, 0, -0.994296, False, '2020-01-13 01:42:56'); /* Plant */
/* @teleloc 0xF3D50010 [31.578199 191.908997 0.055000] -0.106654 0.000000 0.000000 -0.994296 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3D5002, 5000662, 0xF3D50010, 37.3226, 169.644, 0.055, 0.843464, 0, 0, -0.537186, False, '2020-01-13 01:42:58'); /* Plant */
/* @teleloc 0xF3D50010 [37.322601 169.643997 0.055000] 0.843464 0.000000 0.000000 -0.537186 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3D5003, 5000662, 0xF3D50018, 48.148, 189.109, 0.055, 0.682589, 0, 0, -0.730802, False, '2020-01-13 01:43:00'); /* Plant */
/* @teleloc 0xF3D50018 [48.147999 189.108994 0.055000] 0.682589 0.000000 0.000000 -0.730802 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3D5004, 5000294, 0xF3D50038, 144.145, 181.034, 0.055, -0.60531, 0, 0, 0.79599, False, '2020-01-13 01:43:10'); /* Plant */
/* @teleloc 0xF3D50038 [144.145004 181.033997 0.055000] -0.605310 0.000000 0.000000 0.795990 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3D5005, 5000295, 0xF3D50038, 155.053, 178.01, 0.055, -0.60531, 0, 0, 0.79599, False, '2020-01-13 01:43:10'); /* Plant */
/* @teleloc 0xF3D50038 [155.052994 178.009995 0.055000] -0.605310 0.000000 0.000000 0.795990 */
