DELETE FROM `landblock_instance` WHERE `landblock` = 0xE6CF;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E6CF000, 4200152, 0xE6CF0010, 34.0625, 178.882, -0.045, -0.823546, 0, 0, 0.56725, False, '2025-07-19 10:35:52'); /* Gate */
/* @teleloc 0xE6CF0010 [34.062500 178.882004 -0.045000] -0.823546 0.000000 0.000000 0.567250 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E6CF001, 4200152, 0xE6CF000F, 39.5682, 159.877, 0.055, -0.778172, 0, 0, 0.628052, False, '2025-07-19 10:35:56'); /* Gate */
/* @teleloc 0xE6CF000F [39.568199 159.876999 0.055000] -0.778172 0.000000 0.000000 0.628052 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E6CF002, 4200152, 0xE6CF000E, 45.6602, 141.518, 0.67545, -0.807644, 0, 0, 0.589671, False, '2025-07-19 10:36:01'); /* Gate */
/* @teleloc 0xE6CF000E [45.660198 141.518005 0.675450] -0.807644 0.000000 0.000000 0.589671 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E6CF003, 4200152, 0xE6CF000E, 46.6548, 123.151, 5.26722, -0.718996, 0, 0, 0.695015, False, '2025-07-19 10:36:09'); /* Gate */
/* @teleloc 0xE6CF000E [46.654800 123.151001 5.267220] -0.718996 0.000000 0.000000 0.695015 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E6CF004, 4200152, 0xE6CF0016, 49.5422, 127.627, 4.14828, -0.765667, 0, 0, 0.643238, False, '2025-07-19 10:36:14'); /* Gate */
/* @teleloc 0xE6CF0016 [49.542198 127.626999 4.148280] -0.765667 0.000000 0.000000 0.643238 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E6CF005, 4200152, 0xE6CF000D, 46.2879, 102.589, 6.055, -0.75808, 0, 0, 0.652161, False, '2025-07-19 10:36:20'); /* Gate */
/* @teleloc 0xE6CF000D [46.287899 102.588997 6.055000] -0.758080 0.000000 0.000000 0.652161 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E6CF006, 4200152, 0xE6CF0014, 48.0172, 83.9389, 6.055, -0.556604, 0, 0, 0.830778, False, '2025-07-19 10:36:35'); /* Gate */
/* @teleloc 0xE6CF0014 [48.017200 83.938904 6.055000] -0.556604 0.000000 0.000000 0.830778 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E6CF007, 4200152, 0xE6CF000B, 39.8021, 65.2559, 6.61701, -0.491706, 0, 0, 0.870761, False, '2025-07-19 10:36:39'); /* Gate */
/* @teleloc 0xE6CF000B [39.802101 65.255898 6.617010] -0.491706 0.000000 0.000000 0.870761 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E6CF008, 4200152, 0xE6CF000B, 27.6464, 49.7255, 7.91121, -0.386697, 0, 0, 0.922207, False, '2025-07-19 10:36:44'); /* Gate */
/* @teleloc 0xE6CF000B [27.646400 49.725498 7.911210] -0.386697 0.000000 0.000000 0.922207 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E6CF009, 4200152, 0xE6CF0002, 13.7389, 36.1889, 7.32907, -0.445085, 0, 0, 0.895488, False, '2025-07-19 10:36:49'); /* Gate */
/* @teleloc 0xE6CF0002 [13.738900 36.188900 7.329070] -0.445085 0.000000 0.000000 0.895488 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E6CF00A, 4200152, 0xE6CF0001, 1.18289, 18.733, 6.25215, -0.498787, 0, 0, 0.866724, False, '2025-07-19 10:36:53'); /* Gate */
/* @teleloc 0xE6CF0001 [1.182890 18.733000 6.252150] -0.498787 0.000000 0.000000 0.866724 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E6CF00B, 700255, 0xE6CF000F, 34.35148, 145.2258, 0.055, -0.960213, 0, 0, 0.279268, False, '2025-08-04 17:41:07'); /* OathliegeGen */
/* @teleloc 0xE6CF000F [34.351479 145.225800 0.055000] -0.960213 0.000000 0.000000 0.279268 */
