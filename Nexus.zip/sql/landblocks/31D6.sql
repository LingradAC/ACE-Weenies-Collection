DELETE FROM `landblock_instance` WHERE `landblock` = 0x31D6;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x731D6000,   412, 0x31D6014B, 28.7737, 132.974, 90.082, 0, 0, 0, -1, False, '2024-05-26 19:09:10'); /* Door */
/* @teleloc 0x31D6014B [28.773701 132.973999 90.082001] 0.000000 0.000000 0.000000 -1.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x731D6001,   412, 0x31D60142, 28.7862, 112.01, 90.082, 1, 0, 0, 0, False, '2024-05-26 19:09:10'); /* Door */
/* @teleloc 0x31D60142 [28.786200 112.010002 90.082001] 1.000000 0.000000 0.000000 0.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x731D6002,   412, 0x31D60139, 34.521, 116.067, 90.082, -0.707107, 0, 0, -0.707107, False, '2024-05-26 19:09:10'); /* Door */
/* @teleloc 0x31D60139 [34.521000 116.067001 90.082001] -0.707107 0.000000 0.000000 -0.707107 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x731D6003,   165, 0x31D6013F, 44, 116, 90.05, -0.707107, 0, 0, -0.707107, False, '2024-05-26 19:09:10'); /* Pool */
/* @teleloc 0x31D6013F [44.000000 116.000000 90.050003] -0.707107 0.000000 0.000000 -0.707107 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x731D6004,   412, 0x31D6013A, 38.9939, 116.075, 90.082, 0.679342, 0, 0, -0.733822, False, '2024-05-26 19:09:10'); /* Door */
/* @teleloc 0x31D6013A [38.993900 116.074997 90.082001] 0.679342 0.000000 0.000000 -0.733822 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x731D6005,   412, 0x31D6014A, 36.809, 132.465, 90.082, 1, 0, 0, 0, False, '2024-05-26 19:09:10'); /* Door */
/* @teleloc 0x31D6014A [36.808998 132.464996 90.082001] 1.000000 0.000000 0.000000 0.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x731D6006,  1286, 0x31D60119, 104.919, 116.06, 90.082, -0.707107, 0, 0, -0.707107, False, '2024-05-26 19:09:10'); /* Door */
/* @teleloc 0x31D60119 [104.918999 116.059998 90.082001] -0.707107 0.000000 0.000000 -0.707107 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x731D6007,  1286, 0x31D60106, 115.193, 132.974, 90.082, 0, 0, 0, -1, False, '2024-05-26 19:09:10'); /* Door */
/* @teleloc 0x31D60106 [115.193001 132.973999 90.082001] 0.000000 0.000000 0.000000 -1.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x731D600D, 30026, 0x31D60108, 98.357, 141.558, 90, 0.347889, 0, 0, -0.937536, False, '2024-05-26 19:09:10'); /* Scrivener of Creature Magic */
/* @teleloc 0x31D60108 [98.357002 141.557999 90.000000] 0.347889 0.000000 0.000000 -0.937536 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x731D600E, 30020, 0x31D60108, 116.686, 141.442, 90, -0.405274, 0, 0, -0.914195, False, '2024-05-26 19:09:10'); /* Scrivener of War Magic */
/* @teleloc 0x31D60108 [116.685997 141.442001 90.000000] -0.405274 0.000000 0.000000 -0.914195 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x731D600F, 30030, 0x31D60108, 116.611, 135.61, 90.005, -0.711955, 0, 0, -0.702225, False, '2024-05-26 19:09:10'); /* Scrivener of Item Magic */
/* @teleloc 0x31D60108 [116.611000 135.610001 90.004997] -0.711955 0.000000 0.000000 -0.702225 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x731D6010, 30016, 0x31D60108, 108.15, 141.595, 90.005, -0.032407, 0, 0, -0.999475, False, '2024-05-26 19:09:10'); /* Scrivener of Life Magic */
/* @teleloc 0x31D60108 [108.150002 141.595001 90.004997] -0.032407 0.000000 0.000000 -0.999475 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x731D6015, 32996, 0x31D60154, 13.5, 81.5, 80.037, 1, 0, 0, 0, False, '2024-05-26 19:09:10'); /* Dardante's Workshop */
/* @teleloc 0x31D60154 [13.500000 81.500000 80.037003] 1.000000 0.000000 0.000000 0.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x731D6025,  1154, 0x31D60102, 113.411, 137.521, 80.105, 0.433486, 0, 0, 0.90116, False, '2024-05-26 19:09:10'); /* Linkable Monster Generator */
/* @teleloc 0x31D60102 [113.411003 137.520996 80.105003] 0.433486 0.000000 0.000000 0.901160 */

INSERT INTO `landblock_instance_link` (`parent_GUID`, `child_GUID`, `last_Modified`)
VALUES (0x731D6025, 0x731D6027, '2024-05-26 19:09:10') /* Lieutenant Dialossa (32843) */;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x731D6027, 32843, 0x31D60109, 116.347, 123.457, 90.005, 0.999545, 0, 0, 0.030181,  True, '2024-05-26 19:09:10'); /* Lieutenant Dialossa */
/* @teleloc 0x31D60109 [116.347000 123.457001 90.004997] 0.999545 0.000000 0.000000 0.030181 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x731D602C, 40529, 0x31D60109, 111.964, 123.356, 90.003, 0.989022, 0, 0, -0.147769, False, '2024-05-26 19:09:10'); /* Skeleton */
/* @teleloc 0x31D60109 [111.963997 123.356003 90.002998] 0.989022 0.000000 0.000000 -0.147769 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x731D602D, 81090, 0x31D60109, 110.5, 126.4, 90.005, 0.707107, 0, 0, -0.707107, False, '2024-05-26 19:09:10'); /* Lieutenant Dialossa */
/* @teleloc 0x31D60109 [110.500000 126.400002 90.004997] 0.707107 0.000000 0.000000 -0.707107 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x731D602E, 28700, 0x31D60101, 118.539, 129.487, 80.105, -0.737805, 0, 0, -0.675014, False, '2025-07-24 06:17:43'); /* Grand Knight */
/* @teleloc 0x31D60101 [118.539001 129.487000 80.105003] -0.737805 0.000000 0.000000 -0.675014 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x731D602F, 31431, 0x31D60101, 118.471, 128.518, 80.105, 0.656118, 0, 0, 0.754659, False, '2025-07-24 06:18:08'); /* Gallatria du Ressetta */
/* @teleloc 0x31D60101 [118.471001 128.518005 80.105003] 0.656118 0.000000 0.000000 0.754659 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x731D6030, 32693, 0x31D60101, 118.521, 127.345, 80.105, -0.677104, 0, 0, -0.735887, False, '2025-07-24 06:18:31'); /* Garmasi */
/* @teleloc 0x31D60101 [118.521004 127.345001 80.105003] -0.677104 0.000000 0.000000 -0.735887 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x731D6031, 33013, 0x31D60101, 118.489, 126.047, 80.105, -0.697907, 0, 0, -0.716188, False, '2025-07-24 06:19:38'); /* Melaverre */
/* @teleloc 0x31D60101 [118.488998 126.046997 80.105003] -0.697907 0.000000 0.000000 -0.716188 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x731D6032, 28679, 0x31D60101, 118.534, 124.633, 80.105, 0.716758, 0, 0, 0.697322, False, '2025-07-24 06:19:54'); /* Piersanti Linante */
/* @teleloc 0x31D60101 [118.533997 124.633003 80.105003] 0.716758 0.000000 0.000000 0.697322 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x731D6034,  9496, 0x31D60122, 73.5534, 143.776, 80.105, 0.999923, 0, 0, 0.012448, False, '2025-07-24 06:34:28'); /* Gharu'ndim High-Stakes Gamesmaster */
/* @teleloc 0x31D60122 [73.553398 143.776001 80.105003] 0.999923 0.000000 0.000000 0.012448 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x731D6035,  9496, 0x31D6012D, 71.554, 143.726, 80.105, 0.999923, 0, 0, 0.012448, False, '2025-07-24 06:34:33'); /* Gharu'ndim High-Stakes Gamesmaster */
/* @teleloc 0x31D6012D [71.554001 143.725998 80.105003] 0.999923 0.000000 0.000000 0.012448 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x731D6036,  9496, 0x31D6012D, 69.5546, 143.676, 80.105, 0.999923, 0, 0, 0.012448, False, '2025-07-24 06:34:35'); /* Gharu'ndim High-Stakes Gamesmaster */
/* @teleloc 0x31D6012D [69.554604 143.675995 80.105003] 0.999923 0.000000 0.000000 0.012448 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x731D6038,  9502, 0x31D6015F, 76.2663, 165.888, 80.1049, 0.000148, 0, 0, 1, False, '2025-07-24 06:35:25'); /* Gharu'ndim Mid-Stakes Gamesmaster */
/* @teleloc 0x31D6015F [76.266296 165.888000 80.104897] 0.000148 0.000000 0.000000 1.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x731D6039,  9502, 0x31D6015F, 74.3936, 165.889, 80.1049, 0.000148, 0, 0, 1, False, '2025-07-24 06:35:29'); /* Gharu'ndim Mid-Stakes Gamesmaster */
/* @teleloc 0x31D6015F [74.393600 165.889008 80.104897] 0.000148 0.000000 0.000000 1.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x731D603A,  9499, 0x31D60134, 67.4381, 166.018, 80.1049, -0.036413, 0, 0, 0.999337, False, '2025-07-24 06:35:43'); /* Gharu'ndim Low-Stakes Gamesmaster */
/* @teleloc 0x31D60134 [67.438103 166.018005 80.104897] -0.036413 0.000000 0.000000 0.999337 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x731D603B,  9499, 0x31D60134, 69.3673, 166.018, 80.1049, -0.036413, 0, 0, 0.999337, False, '2025-07-24 06:35:46'); /* Gharu'ndim Low-Stakes Gamesmaster */
/* @teleloc 0x31D60134 [69.367302 166.018005 80.104897] -0.036413 0.000000 0.000000 0.999337 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x731D603C, 911913, 0x31D60134, 66.6639, 146.522, 80.105, -0.703586, 0, 0, 0.71061, False, '2025-07-24 06:36:24'); /* 20 Uber-Gem Gambler */
/* @teleloc 0x31D60134 [66.663902 146.522003 80.105003] -0.703586 0.000000 0.000000 0.710610 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x731D603D, 911912, 0x31D60134, 66.6841, 151.061, 80.1049, -0.703586, 0, 0, 0.71061, False, '2025-07-24 06:36:29'); /* 10 Uber-Gem Gambler */
/* @teleloc 0x31D60134 [66.684097 151.061005 80.104897] -0.703586 0.000000 0.000000 0.710610 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x731D603E, 911911, 0x31D60134, 66.7036, 155.022, 80.1049, -0.703586, 0, 0, 0.71061, False, '2025-07-24 06:36:37'); /* 5 Uber-Gem Gambler */
/* @teleloc 0x31D60134 [66.703598 155.022003 80.104897] -0.703586 0.000000 0.000000 0.710610 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x731D603F, 911917, 0x31D6015F, 77.51, 146.438, 80.105, 0.705769, 0, 0, 0.708442, False, '2025-07-24 06:37:00'); /* 100MMD Gambler */
/* @teleloc 0x31D6015F [77.510002 146.438004 80.105003] 0.705769 0.000000 0.000000 0.708442 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x731D6040, 911916, 0x31D6015F, 77.5017, 151.145, 80.1049, 0.705769, 0, 0, 0.708442, False, '2025-07-24 06:37:05'); /* 60MMD Gambler */
/* @teleloc 0x31D6015F [77.501701 151.145004 80.104897] 0.705769 0.000000 0.000000 0.708442 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x731D6045, 490211, 0x31D60122, 94.0196, 121.98, 80.105, -0.941189, 0, 0, -0.337881, False, '2025-07-24 06:39:22'); /* Foolproof Exchanger */
/* @teleloc 0x31D60122 [94.019600 121.980003 80.105003] -0.941189 0.000000 0.000000 -0.337881 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x731D6047,  9502, 0x31D6015F, 92.3533, 166.019, 80.1049, 0.002336, 0, 0, -0.999997, False, '2025-07-24 06:39:47'); /* Gharu'ndim Mid-Stakes Gamesmaster */
/* @teleloc 0x31D6015F [92.353302 166.018997 80.104897] 0.002336 0.000000 0.000000 -0.999997 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x731D6048,  9499, 0x31D60134, 54.2847, 166.019, 80.1049, -0.003465, 0, 0, -0.999994, False, '2025-07-24 06:40:05'); /* Gharu'ndim Low-Stakes Gamesmaster */
/* @teleloc 0x31D60134 [54.284698 166.018997 80.104897] -0.003465 0.000000 0.000000 -0.999994 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x731D604A,  9461, 0x31D60122, 85.5129, 130.977, 80.1, -0.008637, 0, 0, 0.999963, False, '2025-07-24 06:47:06'); /* Arshid's Golden Chest */
/* @teleloc 0x31D60122 [85.512901 130.977005 80.099998] -0.008637 0.000000 0.000000 0.999963 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x731D604B, 38942, 0x31D6012D, 58.9148, 131.132, 80.1, 0.000985, 0, 0, 1, False, '2025-07-24 06:47:43'); /* Grand Casino Chest */
/* @teleloc 0x31D6012D [58.914799 131.132004 80.099998] 0.000985 0.000000 0.000000 1.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x731D604C, 52032, 0x31D6012D, 71.9928, 131.212, 80.1, 0.01268, 0, 0, 0.99992, False, '2025-07-24 06:48:11'); /* Exquisite Casino Chest */
/* @teleloc 0x31D6012D [71.992798 131.212006 80.099998] 0.012680 0.000000 0.000000 0.999920 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x731D604D, 666666666, 0x31D6012D, 71.4631, 121.729, 80.037, 0.004114, 0, 0, -0.999992, False, '2025-07-24 06:49:37'); /* Vault of the Nexus */
/* @teleloc 0x31D6012D [71.463097 121.728996 80.037003] 0.004114 0.000000 0.000000 -0.999992 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x731D604E, 86659156, 0x31D60122, 75.726, 121.506, 80.1, 0.001891, 0, 0, -0.999998, False, '2025-07-24 06:50:06'); /* BLACK PILLAR WITH RED LIGHTNING */
/* @teleloc 0x31D60122 [75.725998 121.505997 80.099998] 0.001891 0.000000 0.000000 -0.999998 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x731D604F, 86659156, 0x31D6012D, 68.0497, 121.677, 80.1, -0.000518, 0, 0, -1, False, '2025-07-24 06:50:14'); /* BLACK PILLAR WITH RED LIGHTNING */
/* @teleloc 0x31D6012D [68.049698 121.677002 80.099998] -0.000518 0.000000 0.000000 -1.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x731D6050, 128192777, 0x31D60122, 73.3509, 122.169, 80.155, -0.020202, 0, 0, -0.999796, False, '2025-07-24 06:50:39'); /* Treasure Pile */
/* @teleloc 0x31D60122 [73.350899 122.168999 80.154999] -0.020202 0.000000 0.000000 -0.999796 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x731D6051, 128192777, 0x31D60122, 72.4816, 123.079, 80.155, 0.3474, 0, 0, -0.937717, False, '2025-07-24 06:50:46'); /* Treasure Pile */
/* @teleloc 0x31D60122 [72.481598 123.079002 80.154999] 0.347400 0.000000 0.000000 -0.937717 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x731D6052, 128192777, 0x31D6012D, 71.7229, 122.428, 80.155, 0.3474, 0, 0, -0.937717, False, '2025-07-24 06:50:47'); /* Treasure Pile */
/* @teleloc 0x31D6012D [71.722900 122.428001 80.154999] 0.347400 0.000000 0.000000 -0.937717 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x731D6053, 128192777, 0x31D6012D, 70.9945, 121.802, 80.155, 0.3474, 0, 0, -0.937717, False, '2025-07-24 06:50:48'); /* Treasure Pile */
/* @teleloc 0x31D6012D [70.994499 121.802002 80.154999] 0.347400 0.000000 0.000000 -0.937717 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x731D6054, 128192777, 0x31D6012D, 69.6195, 121.532, 80.155, 0.3474, 0, 0, -0.937717, False, '2025-07-24 06:50:49'); /* Treasure Pile */
/* @teleloc 0x31D6012D [69.619499 121.531998 80.154999] 0.347400 0.000000 0.000000 -0.937717 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x731D6055, 128192777, 0x31D6012D, 69.4585, 122.517, 80.155, 0.3474, 0, 0, -0.937717, False, '2025-07-24 06:50:50'); /* Treasure Pile */
/* @teleloc 0x31D6012D [69.458504 122.516998 80.154999] 0.347400 0.000000 0.000000 -0.937717 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x731D6056, 128192777, 0x31D6012D, 71.3012, 122.614, 80.155, 0.3474, 0, 0, -0.937717, False, '2025-07-24 06:50:53'); /* Treasure Pile */
/* @teleloc 0x31D6012D [71.301201 122.613998 80.154999] 0.347400 0.000000 0.000000 -0.937717 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x731D6057, 128192777, 0x31D6012D, 71.7676, 123.605, 80.155, 0.17883, 0, 0, -0.98388, False, '2025-07-24 06:50:54'); /* Treasure Pile */
/* @teleloc 0x31D6012D [71.767601 123.605003 80.154999] 0.178830 0.000000 0.000000 -0.983880 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x731D6058, 128192777, 0x31D6012D, 70.5178, 123.135, 80.155, 0.17883, 0, 0, -0.98388, False, '2025-07-24 06:50:55'); /* Treasure Pile */
/* @teleloc 0x31D6012D [70.517799 123.135002 80.154999] 0.178830 0.000000 0.000000 -0.983880 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x731D6059, 128192777, 0x31D60123, 72.464, 120.949, 80.155, -0.973901, 0, 0, -0.226972, False, '2025-07-24 06:50:59'); /* Treasure Pile */
/* @teleloc 0x31D60123 [72.463997 120.948997 80.154999] -0.973901 0.000000 0.000000 -0.226972 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x731D605A, 128192777, 0x31D6012E, 71.3252, 120.673, 80.155, -0.998941, 0, 0, 0.046017, False, '2025-07-24 06:51:00'); /* Treasure Pile */
/* @teleloc 0x31D6012E [71.325203 120.672997 80.154999] -0.998941 0.000000 0.000000 0.046017 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x731D605B, 128192777, 0x31D6012E, 70.6237, 120.738, 80.155, -0.998941, 0, 0, 0.046017, False, '2025-07-24 06:51:01'); /* Treasure Pile */
/* @teleloc 0x31D6012E [70.623703 120.737999 80.154999] -0.998941 0.000000 0.000000 0.046017 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x731D605C, 128192777, 0x31D6012E, 69.7725, 120.816, 80.155, -0.998941, 0, 0, 0.046017, False, '2025-07-24 06:51:02'); /* Treasure Pile */
/* @teleloc 0x31D6012E [69.772499 120.816002 80.154999] -0.998941 0.000000 0.000000 0.046017 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x731D605D, 128192777, 0x31D6012D, 70.1846, 124.395, 80.155, -0.040895, 0, 0, 0.999163, False, '2025-07-24 06:51:11'); /* Treasure Pile */
/* @teleloc 0x31D6012D [70.184601 124.394997 80.154999] -0.040895 0.000000 0.000000 0.999163 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x731D605E, 128192777, 0x31D6012D, 70.1026, 125.396, 80.155, -0.040895, 0, 0, 0.999163, False, '2025-07-24 06:51:11'); /* Treasure Pile */
/* @teleloc 0x31D6012D [70.102600 125.396004 80.154999] -0.040895 0.000000 0.000000 0.999163 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x731D6064, 128192777, 0x31D60122, 72.5678, 126.904, 80.155, -0.040895, 0, 0, 0.999163, False, '2025-07-24 06:51:19'); /* Treasure Pile */
/* @teleloc 0x31D60122 [72.567802 126.903999 80.154999] -0.040895 0.000000 0.000000 0.999163 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x731D6065, 128192777, 0x31D60122, 72.5788, 126.769, 80.155, -0.040895, 0, 0, 0.999163, False, '2025-07-24 06:51:20'); /* Treasure Pile */
/* @teleloc 0x31D60122 [72.578796 126.768997 80.154999] -0.040895 0.000000 0.000000 0.999163 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x731D6066, 128192777, 0x31D60122, 72.9425, 123.981, 80.155, -0.040895, 0, 0, 0.999163, False, '2025-07-24 06:51:21'); /* Treasure Pile */
/* @teleloc 0x31D60122 [72.942497 123.981003 80.154999] -0.040895 0.000000 0.000000 0.999163 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x731D6067, 128192777, 0x31D60122, 73.1198, 125.167, 80.155, 0.071532, 0, 0, 0.997438, False, '2025-07-24 06:51:22'); /* Treasure Pile */
/* @teleloc 0x31D60122 [73.119797 125.167000 80.154999] 0.071532 0.000000 0.000000 0.997438 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x731D6068, 10706, 0x31D6012D, 68.4713, 124.575, 80.1015, 0.000097, 0, 0, 1, False, '2025-07-24 06:52:08'); /* Wheel of Fortune */
/* @teleloc 0x31D6012D [68.471298 124.574997 80.101501] 0.000097 0.000000 0.000000 1.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x731D6069, 10706, 0x31D60122, 74.5556, 123.434, 80.1015, 0.02317, 0, 0, 0.999732, False, '2025-07-24 06:52:12'); /* Wheel of Fortune */
/* @teleloc 0x31D60122 [74.555603 123.433998 80.101501] 0.023170 0.000000 0.000000 0.999732 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x731D606A, 10706, 0x31D60018, 67.7999, 169.823, 80.0015, 0.010812, 0, 0, 0.999942, False, '2025-07-24 06:52:25'); /* Wheel of Fortune */
/* @teleloc 0x31D60018 [67.799896 169.822998 80.001503] 0.010812 0.000000 0.000000 0.999942 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x731D606B, 10706, 0x31D60020, 76.4782, 170.426, 80.0015, 0.01167, 0, 0, 0.999932, False, '2025-07-24 06:52:30'); /* Wheel of Fortune */
/* @teleloc 0x31D60020 [76.478203 170.425995 80.001503] 0.011670 0.000000 0.000000 0.999932 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x731D606C, 86659171, 0x31D6015F, 73.1617, 150.584, 80.1, 0.708552, 0, 0, -0.705658, False, '2025-07-24 06:54:02'); /* DISCO LIGHT11 */
/* @teleloc 0x31D6015F [73.161697 150.584000 80.099998] 0.708552 0.000000 0.000000 -0.705658 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x731D606D, 86659171, 0x31D60122, 74.0988, 134.407, 80.1, 0.740604, 0, 0, -0.671942, False, '2025-07-24 06:54:35'); /* DISCO LIGHT11 */
/* @teleloc 0x31D60122 [74.098801 134.406998 80.099998] 0.740604 0.000000 0.000000 -0.671942 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x731D606E, 86659171, 0x31D6012D, 55.929, 135.312, 80.1, 0.718579, 0, 0, -0.695445, False, '2025-07-24 06:54:44'); /* DISCO LIGHT11 */
/* @teleloc 0x31D6012D [55.929001 135.311996 80.099998] 0.718579 0.000000 0.000000 -0.695445 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x731D606F, 86659171, 0x31D60134, 54.7149, 150.696, 80.1, 0.722556, 0, 0, -0.691313, False, '2025-07-24 06:54:51'); /* DISCO LIGHT11 */
/* @teleloc 0x31D60134 [54.714901 150.695999 80.099998] 0.722556 0.000000 0.000000 -0.691313 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x731D6070, 86659171, 0x31D60128, 69.0052, 110.346, 80.1, 0.023256, 0, 0, -0.99973, False, '2025-07-24 06:55:08'); /* DISCO LIGHT11 */
/* @teleloc 0x31D60128 [69.005203 110.346001 80.099998] 0.023256 0.000000 0.000000 -0.999730 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x731D6071, 86653868, 0x31D60122, 78.669, 121.918, 80.1075, 0.999903, 0, 0, -0.013921, False, '2025-07-24 06:55:46'); /* Bael'Zharon */
/* @teleloc 0x31D60122 [78.668999 121.917999 80.107498] 0.999903 0.000000 0.000000 -0.013921 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x731D6073, 86653870, 0x31D6012D, 65.1222, 121.972, 80.0875, -0.999026, 0, 0, -0.044126, False, '2025-07-24 11:33:49'); /* Asheron */
/* @teleloc 0x31D6012D [65.122200 121.972000 80.087502] -0.999026 0.000000 0.000000 -0.044126 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x731D6074, 8087001, 0x31D60122, 72.3363, 142.949, 80.155, -0.016145, 0, 0, 0.99987, False, '2025-07-26 03:12:39');
/* @teleloc 0x31D60122 [72.336304 142.949005 80.154999] -0.016145 0.000000 0.000000 0.999870 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x731D6075, 86653847, 0x31D6000F, 24.6558, 146.894, 78.425, 0.034646, 0, 0, 0.9994, False, '2025-07-26 18:39:05'); /* CRAZYLIGHT22 */
/* @teleloc 0x31D6000F [24.655800 146.893997 78.425003] 0.034646 0.000000 0.000000 0.999400 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x731D6076, 86653847, 0x31D60007, 17.1387, 147.473, 78.425, -0.010848, 0, 0, 0.999941, False, '2025-07-26 18:39:09'); /* CRAZYLIGHT22 */
/* @teleloc 0x31D60007 [17.138700 147.473007 78.425003] -0.010848 0.000000 0.000000 0.999941 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x731D6077, 86653847, 0x31D60006, 17.6841, 133.584, 78.425, 0.047352, 0, 0, 0.998878, False, '2025-07-26 18:39:15'); /* CRAZYLIGHT22 */
/* @teleloc 0x31D60006 [17.684099 133.584000 78.425003] 0.047352 0.000000 0.000000 0.998878 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x731D6078, 86653847, 0x31D60006, 21.5007, 129.228, 78.425, -0.000278, 0, 0, 1, False, '2025-07-26 18:39:17'); /* CRAZYLIGHT22 */
/* @teleloc 0x31D60006 [21.500700 129.227997 78.425003] -0.000278 0.000000 0.000000 1.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x731D6079, 86653847, 0x31D60005, 17.2999, 115.567, 78.425, -0.000277, 0, 0, 1, False, '2025-07-26 18:39:19'); /* CRAZYLIGHT22 */
/* @teleloc 0x31D60005 [17.299900 115.567001 78.425003] -0.000277 0.000000 0.000000 1.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x731D607A, 86653847, 0x31D60005, 21.5007, 111.269, 78.425, -0.040818, 0, 0, 0.999167, False, '2025-07-26 18:39:21'); /* CRAZYLIGHT22 */
/* @teleloc 0x31D60005 [21.500700 111.268997 78.425003] -0.040818 0.000000 0.000000 0.999167 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x731D607B, 28689, 0x31D6000C, 24.6759, 86.8919, 80.005, -0.99999, 0, 0, 0.004432, False, '2025-07-26 18:40:01'); /* Husoon */
/* @teleloc 0x31D6000C [24.675900 86.891899 80.004997] -0.999990 0.000000 0.000000 0.004432 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x731D607C, 28685, 0x31D6000C, 25.7767, 86.9636, 80.005, 0.999918, 0, 0, -0.012839, False, '2025-07-26 18:40:22'); /* Dumida bint Ruminre */
/* @teleloc 0x31D6000C [25.776699 86.963600 80.004997] 0.999918 0.000000 0.000000 -0.012839 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x731D607D, 41523, 0x31D6000C, 29.0856, 86.882, 80.005, 0.999918, 0, 0, -0.012839, False, '2025-07-26 18:40:35'); /* Raphel Detante */
/* @teleloc 0x31D6000C [29.085600 86.882004 80.004997] 0.999918 0.000000 0.000000 -0.012839 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x731D607E, 41520, 0x31D6000C, 27.3321, 87.009, 80.005, 0.996991, 0, 0, -0.077521, False, '2025-07-26 18:40:50'); /* Akemi Fei */
/* @teleloc 0x31D6000C [27.332100 87.009003 80.004997] 0.996991 0.000000 0.000000 -0.077521 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x731D607F, 41521, 0x31D6000C, 30.3669, 86.8837, 80.005, 0.999652, 0, 0, -0.026391, False, '2025-07-26 18:41:03'); /* Gan Fo */
/* @teleloc 0x31D6000C [30.366899 86.883698 80.004997] 0.999652 0.000000 0.000000 -0.026391 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x731D6080, 41519, 0x31D6000C, 33.9068, 86.885, 80.005, 0.999999, 0, 0, -0.001696, False, '2025-07-26 18:41:16'); /* Gustuv Lansdown */
/* @teleloc 0x31D6000C [33.906799 86.885002 80.004997] 0.999999 0.000000 0.000000 -0.001696 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x731D6081, 43410, 0x31D6000C, 32.2687, 87.0007, 80.005, -0.995041, 0, 0, -0.099469, False, '2025-07-26 18:41:37'); /* Morathe */
/* @teleloc 0x31D6000C [32.268700 87.000702 80.004997] -0.995041 0.000000 0.000000 -0.099469 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x731D6084, 28680, 0x31D6000C, 40.6495, 86.8811, 80.005, -0.999206, 0, 0, 0.039848, False, '2025-07-26 18:42:36'); /* Rickard Dumalia */
/* @teleloc 0x31D6000C [40.649502 86.881104 80.004997] -0.999206 0.000000 0.000000 0.039848 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x731D6085, 28688, 0x31D6000C, 44.4725, 86.8802, 80.005, -0.999206, 0, 0, 0.039848, False, '2025-07-26 18:42:57'); /* Alison Dulane */
/* @teleloc 0x31D6000C [44.472500 86.880203 80.004997] -0.999206 0.000000 0.000000 0.039848 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x731D6086, 28692, 0x31D6000C, 47.0203, 86.9, 80.0105, -0.999206, 0, 0, 0.039848, False, '2025-07-26 18:43:09'); /* Fiun Luunere */
/* @teleloc 0x31D6000C [47.020302 86.900002 80.010498] -0.999206 0.000000 0.000000 0.039848 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x731D6087, 28693, 0x31D60014, 48.9356, 86.9, 80.0105, -0.999206, 0, 0, 0.039848, False, '2025-07-26 18:43:18'); /* Fiun Ruun */
/* @teleloc 0x31D60014 [48.935600 86.900002 80.010498] -0.999206 0.000000 0.000000 0.039848 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x731D6088, 28694, 0x31D60014, 50.9831, 86.9, 80.0105, -0.999206, 0, 0, 0.039848, False, '2025-07-26 18:43:26'); /* Fiun Bayaas */
/* @teleloc 0x31D60014 [50.983101 86.900002 80.010498] -0.999206 0.000000 0.000000 0.039848 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x731D6089, 28695, 0x31D60014, 53.0221, 86.9, 80.0105, -0.999206, 0, 0, 0.039848, False, '2025-07-26 18:43:34'); /* Fiun Riish */
/* @teleloc 0x31D60014 [53.022099 86.900002 80.010498] -0.999206 0.000000 0.000000 0.039848 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x731D608A, 28696, 0x31D60014, 55.4089, 86.9, 80.0105, -0.999206, 0, 0, 0.039848, False, '2025-07-26 18:43:42'); /* Fiun Vasherr */
/* @teleloc 0x31D60014 [55.408901 86.900002 80.010498] -0.999206 0.000000 0.000000 0.039848 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x731D608B, 28697, 0x31D60014, 57.7192, 86.9, 80.0105, -0.999206, 0, 0, 0.039848, False, '2025-07-26 18:43:50'); /* Fiun Noress */
/* @teleloc 0x31D60014 [57.719200 86.900002 80.010498] -0.999206 0.000000 0.000000 0.039848 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x731D608C, 28683, 0x31D60014, 59.9347, 86.8945, 80.005, -0.999231, 0, 0, 0.039219, False, '2025-07-26 18:44:21'); /* Nawamara Dia */
/* @teleloc 0x31D60014 [59.934700 86.894501 80.004997] -0.999231 0.000000 0.000000 0.039219 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x731D608D, 30270, 0x31D60014, 61.3654, 86.8847, 80.005, -0.999231, 0, 0, 0.039219, False, '2025-07-26 18:44:31'); /* Ilin Wis */
/* @teleloc 0x31D60014 [61.365398 86.884697 80.004997] -0.999231 0.000000 0.000000 0.039219 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x731D608E, 30271, 0x31D60014, 63.706, 86.8813, 80.005, -0.999231, 0, 0, 0.039219, False, '2025-07-26 18:44:43'); /* Kyujo Rujen */
/* @teleloc 0x31D60014 [63.706001 86.881302 80.004997] -0.999231 0.000000 0.000000 0.039219 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x731D608F, 30272, 0x31D60014, 66.4124, 86.8813, 80.005, -0.999231, 0, 0, 0.039219, False, '2025-07-26 18:44:50'); /* Enli Yuo */
/* @teleloc 0x31D60014 [66.412399 86.881302 80.004997] -0.999231 0.000000 0.000000 0.039219 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x731D6090, 30273, 0x31D60014, 68.7575, 86.8813, 80.005, -0.999231, 0, 0, 0.039219, False, '2025-07-26 18:45:01'); /* Rikshen Ri */
/* @teleloc 0x31D60014 [68.757500 86.881302 80.004997] -0.999231 0.000000 0.000000 0.039219 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x731D6091, 30274, 0x31D60014, 71.1445, 86.8813, 80.005, -0.999231, 0, 0, 0.039219, False, '2025-07-26 18:45:09'); /* Lu Bao */
/* @teleloc 0x31D60014 [71.144501 86.881302 80.004997] -0.999231 0.000000 0.000000 0.039219 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x731D6092, 30275, 0x31D6001C, 73.6192, 86.8813, 80.005, -0.999231, 0, 0, 0.039219, False, '2025-07-26 18:45:12'); /* Shujio Milao */
/* @teleloc 0x31D6001C [73.619202 86.881302 80.004997] -0.999231 0.000000 0.000000 0.039219 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x731D6093, 28679, 0x31D6001C, 76.7366, 86.8813, 80.005, -0.999231, 0, 0, 0.039219, False, '2025-07-26 18:45:29'); /* Piersanti Linante */
/* @teleloc 0x31D6001C [76.736603 86.881302 80.004997] -0.999231 0.000000 0.000000 0.039219 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x731D6094, 41516, 0x31D6001C, 78.3354, 86.8813, 80.005, -0.999231, 0, 0, 0.039219, False, '2025-07-26 18:45:41'); /* Neela Nashua */
/* @teleloc 0x31D6001C [78.335403 86.881302 80.004997] -0.999231 0.000000 0.000000 0.039219 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x731D6095, 41518, 0x31D6001C, 80.3228, 86.8813, 80.005, -0.999231, 0, 0, 0.039219, False, '2025-07-26 18:45:49'); /* Emily Yarow */
/* @teleloc 0x31D6001C [80.322800 86.881302 80.004997] -0.999231 0.000000 0.000000 0.039219 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x731D6096, 41515, 0x31D6001C, 82.4263, 86.8813, 80.005, -0.999231, 0, 0, 0.039219, False, '2025-07-26 18:45:57'); /* Anfram Mellow */
/* @teleloc 0x31D6001C [82.426300 86.881302 80.004997] -0.999231 0.000000 0.000000 0.039219 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x731D6097, 41526, 0x31D6001C, 84.8133, 86.8813, 80.005, -0.999231, 0, 0, 0.039219, False, '2025-07-26 18:46:05'); /* Alishia bint Aldan */
/* @teleloc 0x31D6001C [84.813301 86.881302 80.004997] -0.999231 0.000000 0.000000 0.039219 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x731D6098, 28687, 0x31D6001C, 87.2003, 86.8813, 80.005, -0.999231, 0, 0, 0.039219, False, '2025-07-26 18:46:19'); /* Kris Cennis */
/* @teleloc 0x31D6001C [87.200302 86.881302 80.004997] -0.999231 0.000000 0.000000 0.039219 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x731D6099, 28681, 0x31D6001C, 88.9913, 86.8813, 80.005, -0.999231, 0, 0, 0.039219, False, '2025-07-26 18:52:17'); /* Lug */
/* @teleloc 0x31D6001C [88.991302 86.881302 80.004997] -0.999231 0.000000 0.000000 0.039219 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x731D609A, 30276, 0x31D6001C, 91.1751, 86.8813, 80.005, -0.999231, 0, 0, 0.039219, False, '2025-07-26 18:53:52'); /* Joshun Felden */
/* @teleloc 0x31D6001C [91.175102 86.881302 80.004997] -0.999231 0.000000 0.000000 0.039219 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x731D609B, 28684, 0x31D6001C, 93.4266, 86.8813, 80.005, -0.999231, 0, 0, 0.039219, False, '2025-07-26 18:54:05'); /* Brienne Carlus */
/* @teleloc 0x31D6001C [93.426598 86.881302 80.004997] -0.999231 0.000000 0.000000 0.039219 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x731D609C, 30277, 0x31D6001C, 95.9436, 86.8813, 80.005, -0.999231, 0, 0, 0.039219, False, '2025-07-26 18:54:15'); /* Burrell Sammrun */
/* @teleloc 0x31D6001C [95.943604 86.881302 80.004997] -0.999231 0.000000 0.000000 0.039219 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x731D609D, 30278, 0x31D60024, 98.2886, 86.8813, 80.005, -0.999231, 0, 0, 0.039219, False, '2025-07-26 19:08:08'); /* Lenor Turk */
/* @teleloc 0x31D60024 [98.288597 86.881302 80.004997] -0.999231 0.000000 0.000000 0.039219 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x731D609E, 30269, 0x31D60024, 100.963, 86.8813, 80.005, -0.999231, 0, 0, 0.039219, False, '2025-07-26 19:08:22'); /* Robert Crow */
/* @teleloc 0x31D60024 [100.962997 86.881302 80.004997] -0.999231 0.000000 0.000000 0.039219 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x731D609F, 41522, 0x31D60024, 103.709, 86.8813, 80.005, -0.999231, 0, 0, 0.039219, False, '2025-07-26 19:08:36'); /* Carlito Gallo */
/* @teleloc 0x31D60024 [103.709000 86.881302 80.004997] -0.999231 0.000000 0.000000 0.039219 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x731D60A0, 41525, 0x31D60024, 105.813, 86.8813, 80.005, -0.999231, 0, 0, 0.039219, False, '2025-07-26 19:08:43'); /* Rahina bint Zalanis */
/* @teleloc 0x31D60024 [105.813004 86.881302 80.004997] -0.999231 0.000000 0.000000 0.039219 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x731D60A1, 41524, 0x31D60024, 108.287, 86.8813, 80.005, -0.999231, 0, 0, 0.039219, False, '2025-07-26 19:08:51'); /* Kilaf */
/* @teleloc 0x31D60024 [108.287003 86.881302 80.004997] -0.999231 0.000000 0.000000 0.039219 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x731D60A2, 44886, 0x31D60024, 110.686, 86.8813, 80.005, -0.999231, 0, 0, 0.039219, False, '2025-07-26 19:09:02'); /* Arianna the Adept */
/* @teleloc 0x31D60024 [110.685997 86.881302 80.004997] -0.999231 0.000000 0.000000 0.039219 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x731D60A3, 28682, 0x31D60024, 113.552, 86.8813, 80.005, -0.999231, 0, 0, 0.039219, False, '2025-07-26 19:10:27'); /* Nawamara Ujio */
/* @teleloc 0x31D60024 [113.552002 86.881302 80.004997] -0.999231 0.000000 0.000000 0.039219 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x731D60A4, 99616121, 0x31D60025, 98.1771, 100.241, 80.005, -0.032951, 0, 0, -0.999457, False, '2025-07-26 19:55:12'); /* Vendor of Seer Augmentations */
/* @teleloc 0x31D60025 [98.177101 100.240997 80.004997] -0.032951 0.000000 0.000000 -0.999457 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x731D60A5, 43406, 0x31D60025, 103.297, 100.211, 80.006, -0.017523, 0, 0, -0.999847, False, '2025-07-26 19:57:40'); /* Lord Tyragar */
/* @teleloc 0x31D60025 [103.296997 100.210999 80.005997] -0.017523 0.000000 0.000000 -0.999847 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x731D60A6, 43404, 0x31D60025, 107.249, 100.072, 80.0105, -0.017523, 0, 0, -0.999847, False, '2025-07-26 19:57:48'); /* Ka'hiri */
/* @teleloc 0x31D60025 [107.249001 100.071999 80.010498] -0.017523 0.000000 0.000000 -0.999847 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x731D60A7, 43403, 0x31D60025, 111.137, 99.9356, 80.0065, -0.017523, 0, 0, -0.999847, False, '2025-07-26 19:58:00'); /* Liam of Gelid */
/* @teleloc 0x31D60025 [111.137001 99.935600 80.006500] -0.017523 0.000000 0.000000 -0.999847 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x731D60A8, 43405, 0x31D60025, 114.817, 99.8066, 80.0065, -0.017523, 0, 0, -0.999847, False, '2025-07-26 19:58:11'); /* Shade of Lady Adja */
/* @teleloc 0x31D60025 [114.817001 99.806602 80.006500] -0.017523 0.000000 0.000000 -0.999847 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x731D60A9,  9492, 0x31D60134, 71.1007, 165.098, 80.105, -0.012495, 0, 0, -0.999922, False, '2025-07-27 12:46:46'); /* Monty the Munificent */
/* @teleloc 0x31D60134 [71.100700 165.098007 80.105003] -0.012495 0.000000 0.000000 -0.999922 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x731D60AA, 38460, 0x31D6015F, 72.4657, 164.963, 80.105, 0, 0, 0, 1, False, '2025-07-27 12:48:10'); /* Arcanum Broker */
/* @teleloc 0x31D6015F [72.465698 164.962997 80.105003] 0.000000 0.000000 0.000000 1.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x731D60AB, 911914, 0x31D6015F, 77.6476, 154.789, 80.1049, 0.69761, 0, 0, 0.716478, False, '2025-07-27 12:51:01'); /* 20MMD Gambler */
/* @teleloc 0x31D6015F [77.647598 154.789001 80.104897] 0.697610 0.000000 0.000000 0.716478 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x731D60AC, 996000, 0x31D6002C, 126.022, 86.8828, 80.005, -0.882972, 0, 0, -0.469425, False, '2025-07-27 22:41:36'); /* Halzar */
/* @teleloc 0x31D6002C [126.022003 86.882797 80.004997] -0.882972 0.000000 0.000000 -0.469425 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x731D60AD, 43298217, 0x31D6015F, 91.5763, 149.41, 80.103, 0.701802, 0, 0, -0.712372, False, '2025-07-30 07:29:20'); /* Daily Wheel of Fortune */
/* @teleloc 0x31D6015F [91.576302 149.410004 80.102997] 0.701802 0.000000 0.000000 -0.712372 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x731D60AE, 128192777, 0x31D6015F, 92.0763, 150.813, 80.155, 0.685338, 0, 0, -0.728226, False, '2025-07-30 07:29:50'); /* Treasure Pile */
/* @teleloc 0x31D6015F [92.076302 150.813004 80.154999] 0.685338 0.000000 0.000000 -0.728226 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x731D60AF, 128192777, 0x31D6015F, 91.9186, 150.39, 80.155, 0.685338, 0, 0, -0.728226, False, '2025-07-30 07:29:51'); /* Treasure Pile */
/* @teleloc 0x31D6015F [91.918602 150.389999 80.154999] 0.685338 0.000000 0.000000 -0.728226 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x731D60B0, 128192777, 0x31D6015F, 91.1147, 150.028, 80.155, 0.685338, 0, 0, -0.728226, False, '2025-07-30 07:29:53'); /* Treasure Pile */
/* @teleloc 0x31D6015F [91.114700 150.028000 80.154999] 0.685338 0.000000 0.000000 -0.728226 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x731D60B1, 128192777, 0x31D6015F, 90.4492, 149.772, 80.155, 0.685338, 0, 0, -0.728226, False, '2025-07-30 07:29:54'); /* Treasure Pile */
/* @teleloc 0x31D6015F [90.449203 149.772003 80.154999] 0.685338 0.000000 0.000000 -0.728226 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x731D60B2, 128192777, 0x31D6015F, 90.4032, 149.015, 80.155, 0.685338, 0, 0, -0.728226, False, '2025-07-30 07:29:55'); /* Treasure Pile */
/* @teleloc 0x31D6015F [90.403198 149.014999 80.154999] 0.685338 0.000000 0.000000 -0.728226 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x731D60B3, 128192777, 0x31D6015F, 92.1061, 147.973, 80.155, 0.955858, 0, 0, -0.293828, False, '2025-07-30 07:29:57'); /* Treasure Pile */
/* @teleloc 0x31D6015F [92.106102 147.973007 80.154999] 0.955858 0.000000 0.000000 -0.293828 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x731D60B4, 128192777, 0x31D6015F, 91.3535, 148.523, 80.155, 0.955858, 0, 0, -0.293828, False, '2025-07-30 07:29:58'); /* Treasure Pile */
/* @teleloc 0x31D6015F [91.353500 148.522995 80.154999] 0.955858 0.000000 0.000000 -0.293828 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x731D60B5, 128192777, 0x31D6015F, 90.9846, 148.557, 80.155, 0.955858, 0, 0, -0.293828, False, '2025-07-30 07:29:59'); /* Treasure Pile */
/* @teleloc 0x31D6015F [90.984596 148.557007 80.154999] 0.955858 0.000000 0.000000 -0.293828 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x731D60B6, 73482737, 0x31D6015F, 90.1654, 145.224, 80.155, 0.705452, 0, 0, -0.708757, False, '2025-07-30 07:31:17'); /* ONE SPIN PER DAY */
/* @teleloc 0x31D6015F [90.165398 145.223999 80.154999] 0.705452 0.000000 0.000000 -0.708757 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x731D60B9, 32849238, 0x31D6012D, 68.3847, 126.316, 80.1065, 0.999382, 0, 0, -0.035167, False, '2025-08-03 01:56:18'); /* Jester */
/* @teleloc 0x31D6012D [68.384697 126.316002 80.106499] 0.999382 0.000000 0.000000 -0.035167 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x731D60BA, 5000223, 0x31D6012D, 50.0084, 142.517, 80.1, -0.720998, 0, 0, -0.692937, False, '2025-08-04 07:06:16'); /* Chair */
/* @teleloc 0x31D6012D [50.008400 142.516998 80.099998] -0.720998 0.000000 0.000000 -0.692937 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x731D60BC, 86653882, 0x31D60134, 49.9948, 150.376, 80.6175, 0.701936, 0, 0, 0.712241, False, '2025-08-04 07:14:30'); /* GREEN BALL OF LIGHT */
/* @teleloc 0x31D60134 [49.994801 150.376007 80.617500] 0.701936 0.000000 0.000000 0.712241 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x731D60BD, 86653877, 0x31D60134, 49.9859, 151.603, 80.6175, 0.726165, 0, 0, 0.68752, False, '2025-08-04 07:14:42'); /* PINK BALL OF LIGHT */
/* @teleloc 0x31D60134 [49.985901 151.602997 80.617500] 0.726165 0.000000 0.000000 0.687520 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x731D60BF, 8080025, 0x31D60134, 50.9811, 159.936, 80.5495, 0.882408, 0, 0, 0.470485, False, '2025-08-15 09:13:44'); /* The Dog Races Portal */
/* @teleloc 0x31D60134 [50.981098 159.936005 80.549500] 0.882408 0.000000 0.000000 0.470485 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x731D60C0, 40463999, 0x31D6012D, 49.986, 138.311, 80.105, -0.704928, 0, 0, 0.709279, False, '2025-08-19 10:32:54'); /* Nexus Rare Exchanger */
/* @teleloc 0x31D6012D [49.986000 138.311005 80.105003] -0.704928 0.000000 0.000000 0.709279 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x731D60C1, 490198, 0x31D60122, 94.0131, 137.132, 80.105, 0.692618, 0, 0, 0.721305, False, '2025-08-19 11:12:22'); /* Shiyama the Currency Exchanger */
/* @teleloc 0x31D60122 [94.013100 137.132004 80.105003] 0.692618 0.000000 0.000000 0.721305 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x731D60C2, 28690, 0x31D6000C, 36.9052, 86.88, 80.005, 0.998333, 0, 0, -0.057717, False, '2025-08-20 16:11:31'); /* Erik Festus */
/* @teleloc 0x31D6000C [36.905201 86.879997 80.004997] 0.998333 0.000000 0.000000 -0.057717 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x731D60C3, 36969911, 0x31D60134, 51.8069, 147.204, 80.037, -0.475972, 0, 0, -0.87946, False, '2025-08-28 04:03:57'); /* The Forge of Souls */
/* @teleloc 0x31D60134 [51.806900 147.203995 80.037003] -0.475972 0.000000 0.000000 -0.879460 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x731D60C4, 666666666, 0x31D6012E, 71.4535, 120.461, 80.037, -0.00957, 0, 0, -0.999954, False, '2025-08-28 04:06:34'); /* Vault of the Nexus */
/* @teleloc 0x31D6012E [71.453499 120.460999 80.037003] -0.009570 0.000000 0.000000 -0.999954 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x731D60C5, 732492218, 0x31D60134, 51.56014, 151.1083, 80.103, 0.696317, 0, 0, -0.717734, False, '2025-09-05 01:06:37'); /* Danky the Terrible */
/* @teleloc 0x31D60134 [51.560139 151.108307 80.102997] 0.696317 0.000000 0.000000 -0.717734 */
