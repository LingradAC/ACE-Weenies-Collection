DELETE FROM `landblock_instance` WHERE `landblock` = 0x45F2;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x745F2000, 28823, 0x45F20026, 108.1208, 122.1253, 65.937, 0.999624, 0, 0, -0.027405, False, '2025-08-12 03:55:31'); /* Abayar's Study */
/* @teleloc 0x45F20026 [108.120796 122.125298 65.936996] 0.999624 0.000000 0.000000 -0.027405 */
