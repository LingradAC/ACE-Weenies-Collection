DELETE FROM `landblock_instance` WHERE `landblock` = 0xAEC6;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7AEC6000,   412, 0xAEC60000, 176.253, 15.7705, 118, 0.381978, 0, 0, -0.924171, False, '2005-02-09 10:00:00'); /* Door */
/* @teleloc 0xAEC60000 [176.253006 15.770500 118.000000] 0.381978 0.000000 0.000000 -0.924171 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7AEC6001,   412, 0xAEC60000, 176.138, 9.83096, 118, 0.923587, 0, 0, -0.383389, False, '2005-02-09 10:00:00'); /* Door */
/* @teleloc 0xAEC60000 [176.138000 9.830960 118.000000] 0.923587 0.000000 0.000000 -0.383389 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7AEC6002,  2343, 0xAEC60000, 97.6714, 161.659, 110.39, -0.336106, 0, 0, 0.941824, False, '2005-02-09 10:00:00'); /* Monolith */
/* @teleloc 0xAEC60000 [97.671402 161.658997 110.389999] -0.336106 0.000000 0.000000 0.941824 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7AEC6003, 12304, 0xAEC60039, 183.555, 15.8651, 118.055, 0.942593, 0, 0, -0.333945, False, '2025-07-31 17:14:44'); /* Agent of the Arcanum  */
/* @teleloc 0xAEC60039 [183.554993 15.865100 118.055000] 0.942593 0.000000 0.000000 -0.333945 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7AEC6004, 21340, 0xAEC60100, 181.091, 6.45359, 118.005, -0.995566, 0, 0, -0.094069, False, '2025-07-31 17:15:58'); /* Wedding Planner */
/* @teleloc 0xAEC60100 [181.091003 6.453590 118.004997] -0.995566 0.000000 0.000000 -0.094069 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7AEC6005, 12050, 0xAEC60100, 183.4625, 8.829254, 118.005, -0.915863, 0, 0, -0.401492, False, '2025-07-31 17:16:04'); /* Agent of the Arcanum */
/* @teleloc 0xAEC60100 [183.462494 8.829254 118.004997] -0.915863 0.000000 0.000000 -0.401492 */
