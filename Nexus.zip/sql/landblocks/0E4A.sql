DELETE FROM `landblock_instance` WHERE `landblock` = 0x0E4A;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70E4A000, 92834236, 0x0E4A0013, 70.4837, 60.9537, -0.395, 0.97043, 0, 0, 0.241382, False, '2025-07-23 05:52:12'); /* Hopeslayer Warden + Ravener Generator */
/* @teleloc 0x0E4A0013 [70.483704 60.953701 -0.395000] 0.970430 0.000000 0.000000 0.241382 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70E4A001, 56843983, 0x0E4A0001, 1.0357, 18.2862, 8.055, 0.645193, 0, 0, -0.764019, False, '2025-07-23 07:10:23'); /* Oathblade Gen */
/* @teleloc 0x0E4A0001 [1.035700 18.286200 8.055000] 0.645193 0.000000 0.000000 -0.764019 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70E4A002, 56843983, 0x0E4A0001, 14.04994, 10.95759, 8.054999, 0.640657, 0, 0, -0.767827, False, '2025-07-30 03:55:55'); /* Oathblade Gen */
/* @teleloc 0x0E4A0001 [14.049940 10.957590 8.054999] 0.640657 0.000000 0.000000 -0.767827 */
