DELETE FROM `landblock_instance` WHERE `landblock` = 0xE5CF;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E5CF000, 4200152, 0xE5CF0039, 183.131, 1.96562, 6.055, -0.508867, 0, 0, 0.860845, False, '2025-07-19 10:37:01'); /* Gate */
/* @teleloc 0xE5CF0039 [183.130997 1.965620 6.055000] -0.508867 0.000000 0.000000 0.860845 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E5CF002, 700261, 0xE5CF001E, 95.427, 138.194, 6.055, 0.282584, 0, 0, 0.959243, False, '2025-07-19 18:20:50'); /* FenrisTheAlphaGen */
/* @teleloc 0xE5CF001E [95.427002 138.194000 6.055000] 0.282584 0.000000 0.000000 0.959243 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E5CF003, 12382138, 0xE5CF0019, 80.0637, 5.89175, 18.055, -0.533894, 0, 0, -0.845552, False, '2025-07-20 14:15:06'); /* Picker Golem Generator */
/* @teleloc 0xE5CF0019 [80.063698 5.891750 18.055000] -0.533894 0.000000 0.000000 -0.845552 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E5CF005, 700253, 0xE5CF001C, 79.4896, 84.1981, 9.43086, -0.489075, 0, 0, -0.872242, False, '2025-07-22 01:50:17'); /* HoodedOneGen */
/* @teleloc 0xE5CF001C [79.489601 84.198097 9.430860] -0.489075 0.000000 0.000000 -0.872242 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E5CF006, 700253, 0xE5CF001B, 76.9729, 61.7901, 10.5134, -0.265503, 0, 0, -0.96411, False, '2025-07-22 01:50:19'); /* HoodedOneGen */
/* @teleloc 0xE5CF001B [76.972900 61.790100 10.513400] -0.265503 0.000000 0.000000 -0.964110 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E5CF007, 700253, 0xE5CF001B, 85.9133, 51.5425, 9.98626, 0.580809, 0, 0, -0.81404, False, '2025-07-22 01:50:22'); /* HoodedOneGen */
/* @teleloc 0xE5CF001B [85.913300 51.542500 9.986260] 0.580809 0.000000 0.000000 -0.814040 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E5CF009, 91737171, 0xE5CF0010, 24.1294, 179.316, -0.395, 0.851844, 0, 0, -0.523796, False, '2025-07-27 14:44:47'); /* cultistsoldiergen */
/* @teleloc 0xE5CF0010 [24.129400 179.315994 -0.395000] 0.851844 0.000000 0.000000 -0.523796 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E5CF00A, 700255, 0xE5CF0018, 71.2021, 174.463, -0.045, -0.411257, 0, 0, 0.91152, False, '2025-08-04 17:40:53'); /* OathliegeGen */
/* @teleloc 0xE5CF0018 [71.202103 174.462997 -0.045000] -0.411257 0.000000 0.000000 0.911520 */
