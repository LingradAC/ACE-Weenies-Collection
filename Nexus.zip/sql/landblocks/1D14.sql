DELETE FROM `landblock_instance` WHERE `landblock` = 0x1D14;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x71D14000,  4179, 0x1D140102, 178.53, 58.6934, 2.405, -0.353088, 0, 0, -0.93559, False, '2005-02-09 10:00:00'); /* Bonfire */
/* @teleloc 0x1D140102 [178.529999 58.693401 2.405000] -0.353088 0.000000 0.000000 -0.935590 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x71D14001,  4179, 0x1D140100, 155.45, 81.678, 5.33363, 0.350983, 0, 0, 0.936382, False, '2005-02-09 10:00:00'); /* Bonfire */
/* @teleloc 0x1D140100 [155.449997 81.678001 5.333630] 0.350983 0.000000 0.000000 0.936382 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x71D14015, 30680, 0x1D140000, 185.199, 13.7724, 0.571972, -0.959839, 0, 0, 0.280551, False, '2005-02-09 10:00:00'); /* Withered Drudge Seraph */
/* @teleloc 0x1D140000 [185.199005 13.772400 0.571972] -0.959839 0.000000 0.000000 0.280551 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x71D14018, 30685, 0x1D140000, 180.325, 18.412, 0.981167, -0.959839, 0, 0, 0.280551, False, '2005-02-09 10:00:00'); /* Withered Banderling Paragon */
/* @teleloc 0x1D140000 [180.324997 18.412001 0.981167] -0.959839 0.000000 0.000000 0.280551 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x71D14019, 30687, 0x1D140000, 177.687, 14.8321, 1.19922, -0.927036, 0, 0, 0.374973, False, '2005-02-09 10:00:00'); /* Withered Revered Tumerok Shaman */
/* @teleloc 0x1D140000 [177.686996 14.832100 1.199220] -0.927036 0.000000 0.000000 0.374973 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x71D1401A, 30683, 0x1D140000, 124.142, 65.8581, 8.805, -0.985306, 0, 0, 0.1708, False, '2005-02-09 10:00:00'); /* Withered Banderling Hierophant */
/* @teleloc 0x1D140000 [124.141998 65.858101 8.805000] -0.985306 0.000000 0.000000 0.170800 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x71D1401C, 30687, 0x1D140000, 128.248, 61.4721, 7.75454, -0.989764, 0, 0, 0.142711, False, '2005-02-09 10:00:00'); /* Withered Revered Tumerok Shaman */
/* @teleloc 0x1D140000 [128.248001 61.472099 7.754540] -0.989764 0.000000 0.000000 0.142711 */
