DELETE FROM `landblock_instance` WHERE `landblock` = 0xB6E8;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7B6E8000, 32934128, 0xB6E80100, 107.9554, 107.9444, 2.95374, -0.380247, 0, 0, -0.924885, False, '2025-07-25 13:07:33'); /* Martine, Nexus-Wrought Archmage */
/* @teleloc 0xB6E80100 [107.955399 107.944397 2.953740] -0.380247 0.000000 0.000000 -0.924885 */
