DELETE FROM `landblock_instance` WHERE `landblock` = 0xE5D2;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E5D2000, 12382138, 0xE5D20022, 113.967, 33.1901, 0.055, -0.220626, 0, 0, 0.975358, False, '2025-07-19 10:03:05'); /* Picker Golem Generator */
/* @teleloc 0xE5D20022 [113.967003 33.190102 0.055000] -0.220626 0.000000 0.000000 0.975358 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E5D2001, 12382137, 0xE5D2003D, 181.103, 102.861, -0.045, -0.992401, 0, 0, 0.123047, False, '2025-07-19 10:03:25'); /* Mutated Tusker Generator */
/* @teleloc 0xE5D2003D [181.102997 102.861000 -0.045000] -0.992401 0.000000 0.000000 0.123047 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E5D2002, 4200152, 0xE5D20008, 17.3304, 178.875, -0.845, -0.773728, 0, 0, 0.633519, False, '2025-07-19 10:30:47'); /* Gate */
/* @teleloc 0xE5D20008 [17.330400 178.875000 -0.845000] -0.773728 0.000000 0.000000 0.633519 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E5D2003, 4200152, 0xE5D20007, 20.6341, 162.805, -0.845, -0.780299, 0, 0, 0.625406, False, '2025-07-19 10:30:51'); /* Gate */
/* @teleloc 0xE5D20007 [20.634100 162.804993 -0.845000] -0.780299 0.000000 0.000000 0.625406 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E5D2004, 4200152, 0xE5D20007, 23.9582, 144.38, -0.845, -0.802276, 0, 0, 0.596954, False, '2025-07-19 10:30:56'); /* Gate */
/* @teleloc 0xE5D20007 [23.958200 144.380005 -0.845000] -0.802276 0.000000 0.000000 0.596954 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E5D2005, 4200152, 0xE5D2000E, 29.1469, 128.316, -0.845, -0.790938, 0, 0, 0.611897, False, '2025-07-19 10:31:05'); /* Gate */
/* @teleloc 0xE5D2000E [29.146900 128.315994 -0.845000] -0.790938 0.000000 0.000000 0.611897 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E5D2006, 4200152, 0xE5D2000D, 31.7481, 112.367, -0.845, -0.631102, 0, 0, 0.7757, False, '2025-07-19 10:31:12'); /* Gate */
/* @teleloc 0xE5D2000D [31.748100 112.366997 -0.845000] -0.631102 0.000000 0.000000 0.775700 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E5D2007, 4200152, 0xE5D2000C, 26.9818, 95.3055, -0.395, -0.591188, 0, 0, 0.806534, False, '2025-07-19 10:31:16'); /* Gate */
/* @teleloc 0xE5D2000C [26.981800 95.305496 -0.395000] -0.591188 0.000000 0.000000 0.806534 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E5D2008, 4200152, 0xE5D20004, 21.163, 78.2468, -0.845, -0.6295, 0, 0, 0.777, False, '2025-07-19 10:31:20'); /* Gate */
/* @teleloc 0xE5D20004 [21.163000 78.246803 -0.845000] -0.629500 0.000000 0.000000 0.777000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E5D2009, 4200152, 0xE5D20003, 14.6709, 61.0848, -0.395, -0.476811, 0, 0, 0.879006, False, '2025-07-19 10:31:27'); /* Gate */
/* @teleloc 0xE5D20003 [14.670900 61.084801 -0.395000] -0.476811 0.000000 0.000000 0.879006 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E5D200A, 4200152, 0xE5D20002, 5.47885, 44.9584, -0.395, -0.715474, 0, 0, 0.698639, False, '2025-07-19 10:31:31'); /* Gate */
/* @teleloc 0xE5D20002 [5.478850 44.958401 -0.395000] -0.715474 0.000000 0.000000 0.698639 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E5D200B, 4200152, 0xE5D20002, 4.010562, 28.57038, -0.045, -0.486748, 0, 0, 0.873542, False, '2025-07-19 10:31:34'); /* Gate */
/* @teleloc 0xE5D20002 [4.010562 28.570379 -0.045000] -0.486748 0.000000 0.000000 0.873542 */
