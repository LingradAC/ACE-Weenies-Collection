DELETE FROM `landblock_instance` WHERE `landblock` = 0x1134;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x71134000,  1148, 0x11340000, 77.75, 67.51, 42, 0, 0, 0, -1, False, '2021-11-01 00:00:00'); /* Door */
/* @teleloc 0x11340000 [77.750000 67.510002 42.000000] 0.000000 0.000000 0.000000 -1.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x71134001,  1148, 0x11340000, 85.5, 57.51, 42, 0, 0, 0, -1, False, '2021-11-01 00:00:00'); /* Door */
/* @teleloc 0x11340000 [85.500000 57.509998 42.000000] 0.000000 0.000000 0.000000 -1.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x71134002,  1148, 0x11340000, 85.5, 49.985, 42, -1, 0, 0, 0, False, '2021-11-01 00:00:00'); /* Door */
/* @teleloc 0x11340000 [85.500000 49.985001 42.000000] -1.000000 0.000000 0.000000 0.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x71134003,  1148, 0x11340111, 135.5, 76.01, 42, 0, 0, 0, -1, False, '2021-11-01 00:00:00'); /* Door */
/* @teleloc 0x11340111 [135.500000 76.010002 42.000000] 0.000000 0.000000 0.000000 -1.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x71134004,  1148, 0x11340000, 127.5, 82.01, 42, 0, 0, 0, -1, False, '2021-11-01 00:00:00'); /* Door */
/* @teleloc 0x11340000 [127.500000 82.010002 42.000000] 0.000000 0.000000 0.000000 -1.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x71134005,  1148, 0x11340000, 130.49, 87.5, 42, -0.707107, 0, 0, 0.707107, False, '2021-11-01 00:00:00'); /* Door */
/* @teleloc 0x11340000 [130.490005 87.500000 42.000000] -0.707107 0.000000 0.000000 0.707107 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x71134006,  8377, 0x11340138, 84.1664, 157.337, 42.9279, 0.906702, 0, 0, -0.421771, False, '2021-11-01 00:00:00'); /* Beer Keg */
/* @teleloc 0x11340138 [84.166397 157.337006 42.927898] 0.906702 0.000000 0.000000 -0.421771 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x71134007,  6862, 0x11340101, 75.9405, 61.9682, 41.205, -0.744559, 0, 0, 0.667556,  True, '2021-11-01 00:00:00'); /* Sang Nen-Kai the Weaponsmith */
/* @teleloc 0x11340101 [75.940498 61.968201 41.205002] -0.744559 0.000000 0.000000 0.667556 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x71134008,  6860, 0x11340000, 66.773, 129.873, 42.005, 0.680955, 0, 0, -0.732325,  True, '2021-11-01 00:00:00'); /* Jeweler Daryam ibn Zubed */
/* @teleloc 0x11340000 [66.773003 129.873001 42.005001] 0.680955 0.000000 0.000000 -0.732325 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x71134009,  3926, 0x11340000, 66.2035, 80.434, 42.005, 0.667238, 0, 0, -0.744845,  True, '2021-11-01 00:00:00'); /* Ivory Crafter */
/* @teleloc 0x11340000 [66.203499 80.433998 42.005001] 0.667238 0.000000 0.000000 -0.744845 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7113400B,  6855, 0x11340100, 81.6822, 57.8933, 42.005, -0.92505, 0, 0, 0.379845,  True, '2021-11-01 00:00:00'); /* Sung Wenxio the Armorer */
/* @teleloc 0x11340100 [81.682198 57.893299 42.005001] -0.925050 0.000000 0.000000 0.379845 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7113400C,  6858, 0x11340130, 77.5, 155.842, 42.005, 0.720152, 0, 0, -0.693817,  True, '2021-11-01 00:00:00'); /* Grocer Nihara bint Umar */
/* @teleloc 0x11340130 [77.500000 155.841995 42.005001] 0.720152 0.000000 0.000000 -0.693817 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7113400D,  6869, 0x11340000, 67, 134, 43.305, 1, 0, 0, 0, False, '2021-11-01 00:00:00'); /* Jewel of the Desert */
/* @teleloc 0x11340000 [67.000000 134.000000 43.305000] 1.000000 0.000000 0.000000 0.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7113400E,  6856, 0x1134013A, 84.397, 162.5, 42.005, -0.033452, 0, 0, -0.99944,  True, '2021-11-01 00:00:00'); /* Berkholt the Burly Barkeep */
/* @teleloc 0x1134013A [84.397003 162.500000 42.005001] -0.033452 0.000000 0.000000 -0.999440 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7113400F,  3955, 0x1134010D, 89.6851, 56.0353, 42.005, 0.040071, 0, 0, -0.999197, False, '2021-11-01 00:00:00'); /* Linkable Monster Gen (15 min.) */
/* @teleloc 0x1134010D [89.685097 56.035301 42.005001] 0.040071 0.000000 0.000000 -0.999197 */

INSERT INTO `landblock_instance_link` (`parent_GUID`, `child_GUID`, `last_Modified`)
VALUES (0x7113400F, 0x71134007, '2021-11-01 00:00:00') /* Sang Nen-Kai the Weaponsmith (6862) */
     , (0x7113400F, 0x71134008, '2021-11-01 00:00:00') /* Jeweler Daryam ibn Zubed (6860) */
     , (0x7113400F, 0x71134009, '2021-11-01 00:00:00') /* Ivory Crafter (3926) */
     , (0x7113400F, 0x7113400B, '2021-11-01 00:00:00') /* Sung Wenxio the Armorer (6855) */
     , (0x7113400F, 0x7113400C, '2021-11-01 00:00:00') /* Grocer Nihara bint Umar (6858) */
     , (0x7113400F, 0x7113400E, '2021-11-01 00:00:00') /* Berkholt the Burly Barkeep (6856) */
     , (0x7113400F, 0x71134010, '2021-11-01 00:00:00') /* Scribe Muhiza bint Murqidh  (6861) */
     , (0x7113400F, 0x71134011, '2021-11-01 00:00:00') /* Leather Crafter (4214) */
     , (0x7113400F, 0x71134016, '2021-11-01 00:00:00') /* Thiuda the Sharp-Eyed Bowyer (6857) */
     , (0x7113400F, 0x71134017, '2021-11-01 00:00:00') /* Oak Target Drudge (6077) */
     , (0x7113400F, 0x71134018, '2021-11-01 00:00:00') /* Ellimar Jorning the Healer (6859) */
     , (0x7113400F, 0x7113401C, '2021-11-01 00:00:00') /* Yuan Hanzu (7241) */
     , (0x7113400F, 0x7113401E, '2021-11-01 00:00:00') /* Town Crier (5774) */
     , (0x7113400F, 0x71134022, '2021-11-01 00:00:00') /* Agent of the Arcanum (12050) */
     , (0x7113400F, 0x71134043, '2021-11-01 00:00:00') /* Aaminah (24153) */
     , (0x7113400F, 0x7113404B, '2021-11-01 00:00:00') /* Tanami Kei (30509) */
     , (0x7113400F, 0x71134076, '2021-11-01 00:00:00') /* Vierana du Canamorra (37600) */
     , (0x7113400F, 0x71134078, '2021-11-01 00:00:00') /* Gaston Shadowbound (38462) */
     , (0x7113400F, 0x71134082, '2021-11-01 00:00:00') /* Joku Shunja (37599) */
     , (0x7113400F, 0x7113408A, '2021-11-01 00:00:00') /* Qurakh al-Taal (37598) */;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x71134010,  6861, 0x11340111, 138.604, 79.0318, 42.005, -0.860808, 0, 0, -0.508929,  True, '2021-11-01 00:00:00'); /* Scribe Muhiza bint Murqidh  */
/* @teleloc 0x11340111 [138.604004 79.031799 42.005001] -0.860808 0.000000 0.000000 -0.508929 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x71134011,  4214, 0x11340102, 87.3571, 52.1344, 42.005, -0.999846, 0, 0, 0.017543,  True, '2021-11-01 00:00:00'); /* Leather Crafter */
/* @teleloc 0x11340102 [87.357101 52.134399 42.005001] -0.999846 0.000000 0.000000 0.017543 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x71134012,  6867, 0x11340000, 114, 67, 43.305, -0.707107, 0, 0, -0.707107, False, '2021-11-01 00:00:00'); /* The Old Campaigner's Bows */
/* @teleloc 0x11340000 [114.000000 67.000000 43.305000] -0.707107 0.000000 0.000000 -0.707107 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x71134013,  6870, 0x11340000, 81.5, 145, 45.7, 0.707107, 0, 0, -0.707107, False, '2021-11-01 00:00:00'); /* The Smoking Axe Tavern */
/* @teleloc 0x11340000 [81.500000 145.000000 45.700001] 0.707107 0.000000 0.000000 -0.707107 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x71134014,  6868, 0x11340000, 129.423, 90.6667, 45.2, 0, 0, 0, -1, False, '2021-11-01 00:00:00'); /* The Secluded Sanctuary */
/* @teleloc 0x11340000 [129.423004 90.666702 45.200001] 0.000000 0.000000 0.000000 -1.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x71134015,  6871, 0x11340000, 93.5, 58.6667, 45.2, -0.707107, 0, 0, -0.707107, False, '2021-11-01 00:00:00'); /* The Whispering Sword */
/* @teleloc 0x11340000 [93.500000 58.666698 45.200001] -0.707107 0.000000 0.000000 -0.707107 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x71134016,  6857, 0x11340000, 110.09, 65.3801, 42.005, -0.998897, 0, 0, 0.046947,  True, '2021-11-01 00:00:00'); /* Thiuda the Sharp-Eyed Bowyer */
/* @teleloc 0x11340000 [110.089996 65.380096 42.005001] -0.998897 0.000000 0.000000 0.046947 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x71134017,  6077, 0x1134011D, 100.623, 56.398, 41.705, -0.959759, 0, 0, 0.280824,  True, '2021-11-01 00:00:00'); /* Oak Target Drudge */
/* @teleloc 0x1134011D [100.623001 56.397999 41.705002] -0.959759 0.000000 0.000000 0.280824 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x71134018,  6859, 0x11340000, 135.385, 86.9925, 45.605, -0.797174, 0, 0, 0.60375,  True, '2021-11-01 00:00:00'); /* Ellimar Jorning the Healer */
/* @teleloc 0x11340000 [135.384995 86.992500 45.605000] -0.797174 0.000000 0.000000 0.603750 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x71134019,  6441, 0x11340000, 99.0351, 70.9894, 42.005, -0.989304, 0, 0, -0.145868, False, '2021-11-01 00:00:00'); /* Well */
/* @teleloc 0x11340000 [99.035103 70.989403 42.005001] -0.989304 0.000000 0.000000 -0.145868 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7113401A,  6441, 0x11340000, 78.678, 136.631, 42.005, -0.981168, 0, 0, 0.193158, False, '2021-11-01 00:00:00'); /* Well */
/* @teleloc 0x11340000 [78.678001 136.630997 42.005001] -0.981168 0.000000 0.000000 0.193158 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7113401B,   153, 0x11340000, 108, 108, 42.005, 1, 0, 0, 0, False, '2021-11-01 00:00:00'); /* Fountain */
/* @teleloc 0x11340000 [108.000000 108.000000 42.005001] 1.000000 0.000000 0.000000 0.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7113401C,  7241, 0x11340000, 103.419, 66.3338, 42.005, -0.999809, 0, 0, 0.019539,  True, '2021-11-01 00:00:00'); /* Yuan Hanzu */
/* @teleloc 0x11340000 [103.418999 66.333801 42.005001] -0.999809 0.000000 0.000000 0.019539 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7113401E,  5774, 0x11340000, 121.871, 112.476, 42.005, 0.653408, 0, 0, -0.757006,  True, '2021-11-01 00:00:00'); /* Town Crier */
/* @teleloc 0x11340000 [121.871002 112.475998 42.005001] 0.653408 0.000000 0.000000 -0.757006 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x71134021,   412, 0x11340143, 127.685, 129.036, 42, 0.695835, 0, 0, -0.718202, False, '2021-11-01 00:00:00'); /* Door */
/* @teleloc 0x11340143 [127.684998 129.035995 42.000000] 0.695835 0.000000 0.000000 -0.718202 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x71134022, 12050, 0x11340145, 135.177, 137.059, 42.005, 0.122871, 0, 0, -0.992423,  True, '2021-11-01 00:00:00'); /* Agent of the Arcanum */
/* @teleloc 0x11340145 [135.177002 137.059006 42.005001] 0.122871 0.000000 0.000000 -0.992423 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x71134024, 12304, 0x11340000, 126.222, 123.242, 42.005, 0.702381, 0, 0, -0.711801, False, '2021-11-01 00:00:00'); /* Agent of the Arcanum  */
/* @teleloc 0x11340000 [126.222000 123.241997 42.005001] 0.702381 0.000000 0.000000 -0.711801 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7113402A, 16919, 0x11340000, 85.4188, 87.3644, 42, -0.729118, 0, 0, -0.684388, False, '2021-11-01 00:00:00'); /* Pedestal Weak Spot */
/* @teleloc 0x11340000 [85.418800 87.364403 42.000000] -0.729118 0.000000 0.000000 -0.684388 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7113402D, 19457, 0x11340000, 89.631, 87.409, 49, -0.061763, 0, 0, -0.998091, False, '2021-11-01 00:00:00'); /* Fireworks Generator */
/* @teleloc 0x11340000 [89.630997 87.408997 49.000000] -0.061763 0.000000 0.000000 -0.998091 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x71134030,  1148, 0x1134014F, 28.01, 104.5, 42, 0.707107, 0, 0, 0.707107, False, '2021-11-01 00:00:00'); /* Door */
/* @teleloc 0x1134014F [28.010000 104.500000 42.000000] 0.707107 0.000000 0.000000 0.707107 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x71134031,  1148, 0x11340000, 34.01, 112.5, 42, 0.707107, 0, 0, 0.707107, False, '2021-11-01 00:00:00'); /* Door */
/* @teleloc 0x11340000 [34.009998 112.500000 42.000000] 0.707107 0.000000 0.000000 0.707107 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x71134032,  1148, 0x11340000, 39.5, 109.51, 42, 0, 0, 0, -1, False, '2021-11-01 00:00:00'); /* Door */
/* @teleloc 0x11340000 [39.500000 109.510002 42.000000] 0.000000 0.000000 0.000000 -1.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x71134033, 19207, 0x11340000, 89.5038, 87.375, 48.916, 0.997208, 0, 0, -0.074668, False, '2021-11-01 00:00:00'); /* Nullified Statue of a Virindi */
/* @teleloc 0x11340000 [89.503799 87.375000 48.916000] 0.997208 0.000000 0.000000 -0.074668 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x71134034, 19715, 0x11340149, 103.085, 86.0657, 36.805, 0.655995, 0, 0, -0.754765, False, '2021-11-01 00:00:00'); /* Colossus Foundry Portal */
/* @teleloc 0x11340149 [103.084999 86.065697 36.805000] 0.655995 0.000000 0.000000 -0.754765 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x71134035, 20224, 0x1134014C, 39.1283, 101.175, 42.005, -0.996548, 0, 0, 0.083014, False, '2021-11-01 00:00:00'); /* Grand Master Scrivener of War Magic */
/* @teleloc 0x1134014C [39.128300 101.175003 42.005001] -0.996548 0.000000 0.000000 0.083014 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x71134036, 20208, 0x11340000, 41.4561, 104.499, 45.605, 0.628545, 0, 0, -0.777773, False, '2021-11-01 00:00:00'); /* Grand Master Scrivener of Creature Magic */
/* @teleloc 0x11340000 [41.456100 104.499001 45.605000] 0.628545 0.000000 0.000000 -0.777773 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x71134037, 20212, 0x11340000, 33.3447, 102.261, 50.805, 0.971237, 0, 0, 0.238115, False, '2021-11-01 00:00:00'); /* Grand Master Scrivener of Item Magic */
/* @teleloc 0x11340000 [33.344700 102.261002 50.805000] 0.971237 0.000000 0.000000 0.238115 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x71134038, 20220, 0x11340151, 29.0512, 114.19, 42.005, 0.403605, 0, 0, -0.914933, False, '2021-11-01 00:00:00'); /* Grand Master Scrivener of Life Magic */
/* @teleloc 0x11340151 [29.051201 114.190002 42.005001] 0.403605 0.000000 0.000000 -0.914933 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x71134040, 10722, 0x11340000, 77.8661, 146.642, 42.005, -0.0349, 0, 0, -0.999391, False, '2021-11-01 00:00:00'); /* Ulgrim's Green Sword Gen */
/* @teleloc 0x11340000 [77.866096 146.641998 42.005001] -0.034900 0.000000 0.000000 -0.999391 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x71134042, 23631, 0x11340000, 86.9135, 108.323, 158.939, -0.999711, 0, 0, -0.024051, False, '2021-11-01 00:00:00'); /* April 2003 Raining Mad Cows Gen */
/* @teleloc 0x11340000 [86.913498 108.322998 158.938995] -0.999711 0.000000 0.000000 -0.024051 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x71134043, 24153, 0x11340000, 128.708, 84.8105, 42.005, -0.694209, 0, 0, -0.719773,  True, '2021-11-01 00:00:00'); /* Aaminah */
/* @teleloc 0x11340000 [128.707993 84.810501 42.005001] -0.694209 0.000000 0.000000 -0.719773 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x71134044, 24142, 0x11340000, 134.896, 80.638, 51.75, -0.760128, 0, 0, -0.649773,  True, '2021-11-01 00:00:00'); /* Half Empty Cider */
/* @teleloc 0x11340000 [134.895996 80.638000 51.750000] -0.760128 0.000000 0.000000 -0.649773 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x71134045, 24143, 0x11340000, 135.17, 80.2072, 51.75, -0.760128, 0, 0, -0.649773,  True, '2021-11-01 00:00:00'); /* Empty Mug */
/* @teleloc 0x11340000 [135.169998 80.207199 51.750000] -0.760128 0.000000 0.000000 -0.649773 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x71134046, 24144, 0x11340000, 133.497, 79.7667, 50.805, 0.260399, 0, 0, 0.965501,  True, '2021-11-01 00:00:00'); /* Strands of Silk */
/* @teleloc 0x11340000 [133.496994 79.766701 50.805000] 0.260399 0.000000 0.000000 0.965501 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x71134047, 24141, 0x11340000, 136.348, 79.509, 51, 0.901436, 0, 0, -0.432912,  True, '2021-11-01 00:00:00'); /* Sweet Smelling Bark */
/* @teleloc 0x11340000 [136.348007 79.509003 51.000000] 0.901436 0.000000 0.000000 -0.432912 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x71134048, 15759, 0x11340000, 134.957, 78.0182, 50.805, 0.606421, 0, 0, 0.795143, False, '2021-11-01 00:00:00'); /* Linkable Item Generator */
/* @teleloc 0x11340000 [134.957001 78.018204 50.805000] 0.606421 0.000000 0.000000 0.795143 */

INSERT INTO `landblock_instance_link` (`parent_GUID`, `child_GUID`, `last_Modified`)
VALUES (0x71134048, 0x71134044, '2021-11-01 00:00:00') /* Half Empty Cider (24142) */
     , (0x71134048, 0x71134045, '2021-11-01 00:00:00') /* Empty Mug (24143) */
     , (0x71134048, 0x71134046, '2021-11-01 00:00:00') /* Strands of Silk (24144) */
     , (0x71134048, 0x71134047, '2021-11-01 00:00:00') /* Sweet Smelling Bark (24141) */;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x71134049,  7924, 0x11340000, 77.866, 146.642, 42.005, -0.0349, 0, 0, -0.999391, False, '2021-11-01 00:00:00'); /* Linkable Monster Generator ( 5 Min.) */
/* @teleloc 0x11340000 [77.865997 146.641998 42.005001] -0.034900 0.000000 0.000000 -0.999391 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7113404A, 29678, 0x11340000, 60.6388, 61.8331, 42.005, 0.736409, 0, 0, -0.676536, False, '2021-11-01 00:00:00'); /* Qin Xikit Watcher Generator */
/* @teleloc 0x11340000 [60.638802 61.833099 42.005001] 0.736409 0.000000 0.000000 -0.676536 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7113404B, 30509, 0x11340131, 76.1548, 155.905, 45.205, 0.59337, 0, 0, -0.80493,  True, '2021-11-01 00:00:00'); /* Tanami Kei */
/* @teleloc 0x11340131 [76.154800 155.904999 45.205002] 0.593370 0.000000 0.000000 -0.804930 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7113404C, 41515, 0x1134010E, 135.584, 90.4377, 42.005, 0.20526, 0, 0, 0.978707, False, '2021-11-01 00:00:00'); /* Anfram Mellow */
/* @teleloc 0x1134010E [135.584000 90.437698 42.005001] 0.205260 0.000000 0.000000 0.978707 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7113404D, 41526, 0x1134010E, 139.698, 88.2701, 42.005, -0.606282, 0, 0, -0.79525, False, '2021-11-01 00:00:00'); /* Alishia bint Aldan */
/* @teleloc 0x1134010E [139.697998 88.270103 42.005001] -0.606282 0.000000 0.000000 -0.795250 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7113404E, 31690, 0x1134001F, 90.655, 161.575, 42.005, 0.980588, 0, 0, -0.196078, False, '2021-11-01 00:00:00'); /* Dionaea */
/* @teleloc 0x1134001F [90.654999 161.574997 42.005001] 0.980588 0.000000 0.000000 -0.196078 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x71134051,  6873, 0x1134001F, 79.2045, 145.96, 42.005, -0.213365, 0, 0, -0.976973, False, '2021-11-01 00:00:00'); /* Ulgrim the Unpleasant */
/* @teleloc 0x1134001F [79.204498 145.960007 42.005001] -0.213365 0.000000 0.000000 -0.976973 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x71134052, 43353, 0x1134000D, 31.9046, 107.454, 50.805, -0.045071, 0, 0, -0.998984, False, '2021-11-01 00:00:00'); /* Grand Master Scrivener of Void Magic */
/* @teleloc 0x1134000D [31.904600 107.454002 50.805000] -0.045071 0.000000 0.000000 -0.998984 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x71134054, 32991, 0x11340138, 87.5, 157.5, 42.005, 1, 0, 0, 0, False, '2021-11-01 00:00:00'); /* Harkwull the Discreet */
/* @teleloc 0x11340138 [87.500000 157.500000 42.005001] 1.000000 0.000000 0.000000 0.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x71134055, 32684, 0x1134015A, 37.9793, 154.072, 41.705, 1, 0, 0, 0, False, '2021-11-01 00:00:00'); /* Mekhmet */
/* @teleloc 0x1134015A [37.979301 154.072006 41.705002] 1.000000 0.000000 0.000000 0.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x71134056, 33876, 0x1134015C, 83, 179, 41.705, 1, 0, 0, 0, False, '2021-11-01 00:00:00'); /* Soju Bo-Ki */
/* @teleloc 0x1134015C [83.000000 179.000000 41.705002] 1.000000 0.000000 0.000000 0.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x71134057, 33875, 0x1134015C, 79, 179, 41.705, 1, 0, 0, 0, False, '2021-11-01 00:00:00'); /* Lamorda Loschi */
/* @teleloc 0x1134015C [79.000000 179.000000 41.705002] 1.000000 0.000000 0.000000 0.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x71134058, 33877, 0x1134015D, 87.5, 179, 41.705, 1, 0, 0, 0, False, '2021-11-01 00:00:00'); /* Hoshar ibn Jalaq */
/* @teleloc 0x1134015D [87.500000 179.000000 41.705002] 1.000000 0.000000 0.000000 0.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7113405A, 35962, 0x11340023, 99, 67, 42.005, 1, 0, 0, 0, False, '2021-11-01 00:00:00'); /* Havala bint Mylos */
/* @teleloc 0x11340023 [99.000000 67.000000 42.005001] 1.000000 0.000000 0.000000 0.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7113405B, 43074, 0x1134001C, 89.8829, 91.5945, 42.005, -0.983076, 0, 0, -0.183198, False, '2021-11-01 00:00:00'); /* Emissary of Asheron */
/* @teleloc 0x1134001C [89.882896 91.594498 42.005001] -0.983076 0.000000 0.000000 -0.183198 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7113405C, 36534, 0x1134001C, 90.1444, 82.7602, 42.005, 0.003307, 0, 0, 0.999995, False, '2021-11-01 00:00:00'); /* Guard Q'alia */
/* @teleloc 0x1134001C [90.144402 82.760201 42.005001] 0.003307 0.000000 0.000000 0.999995 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7113405D, 38211, 0x1134001D, 89.6356, 103.934, 42.005, 0.105314, 0, 0, -0.994439, False, '2021-11-01 00:00:00'); /* Laedron the Geomancer */
/* @teleloc 0x1134001D [89.635597 103.933998 42.005001] 0.105314 0.000000 0.000000 -0.994439 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7113405F, 37445, 0x1134000E, 27.2326, 134.412, 42.005, 0.581059, 0, 0, 0.813862, False, '2021-11-01 00:00:00'); /* Guard Bey */
/* @teleloc 0x1134000E [27.232599 134.412003 42.005001] 0.581059 0.000000 0.000000 0.813862 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x71134060, 31970, 0x11340033, 159.279, 67.7768, 38.7596, 0.407239, 0, 0, -0.913321, False, '2021-11-01 00:00:00'); /* Shuthoth */
/* @teleloc 0x11340033 [159.279007 67.776802 38.759602] 0.407239 0.000000 0.000000 -0.913321 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x71134061, 32813, 0x1134001F, 93, 145, 42.005, 0.047194, 0, 0, -0.998886, False, '2021-11-01 00:00:00'); /* Lydda */
/* @teleloc 0x1134001F [93.000000 145.000000 42.005001] 0.047194 0.000000 0.000000 -0.998886 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x71134062, 35344, 0x1134002F, 141.028, 166.162, 42.005, 0.16671, 0, 0, -0.986006, False, '2021-11-01 00:00:00'); /* Guard Winterborn */
/* @teleloc 0x1134002F [141.028000 166.162003 42.005001] 0.166710 0.000000 0.000000 -0.986006 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x71134063, 37400, 0x1134000F, 31.3122, 163.329, 42.0055, 0.879951, 0, 0, -0.475064, False, '2021-11-01 00:00:00'); /* Merwart Mundagurg */
/* @teleloc 0x1134000F [31.312201 163.328995 42.005501] 0.879951 0.000000 0.000000 -0.475064 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x71134064, 35562, 0x11340038, 157.791, 189.607, 34.4582, -0.991826, 0, 0, -0.127596, False, '2021-11-01 00:00:00'); /* Ennio di Cinghalle */
/* @teleloc 0x11340038 [157.791000 189.606995 34.458199] -0.991826 0.000000 0.000000 -0.127596 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7113406D, 42852, 0x11340026, 105.754, 133.537, 42.198, 0.311994, 0, 0, 0.950084, False, '2021-11-01 00:00:00'); /* Portal to Town Network */
/* @teleloc 0x11340026 [105.753998 133.537003 42.198002] 0.311994 0.000000 0.000000 0.950084 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x71134076, 37600, 0x11340111, 137.373, 82.534, 42.005, 0.168682, 0, 0, 0.985671,  True, '2021-11-01 00:00:00'); /* Vierana du Canamorra */
/* @teleloc 0x11340111 [137.373001 82.533997 42.005001] 0.168682 0.000000 0.000000 0.985671 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x71134078, 38462, 0x11340133, 91.674, 156.404, 45.205, 0.530105, 0, 0, 0.847932,  True, '2021-11-01 00:00:00'); /* Gaston Shadowbound */
/* @teleloc 0x11340133 [91.674004 156.404007 45.205002] 0.530105 0.000000 0.000000 0.847932 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x71134082, 37599, 0x1134001B, 91, 55.4, 45.605, -0.745709, 0, 0, -0.666272,  True, '2021-11-01 00:00:00'); /* Joku Shunja */
/* @teleloc 0x1134001B [91.000000 55.400002 45.605000] -0.745709 0.000000 0.000000 -0.666272 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7113408A, 37598, 0x11340025, 118, 105, 42.005, -0.707107, 0, 0, -0.707107,  True, '2021-11-01 00:00:00'); /* Qurakh al-Taal */
/* @teleloc 0x11340025 [118.000000 105.000000 42.005001] -0.707107 0.000000 0.000000 -0.707107 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7113408B, 5000902, 0x1134001C, 75.8263, 82.1288, 42.055, 0.980541, 0, 0, -0.196313, False, '2025-07-30 03:52:38'); /* AyanAttack */
/* @teleloc 0x1134001C [75.826302 82.128799 42.055000] 0.980541 0.000000 0.000000 -0.196313 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7113408C, 5000902, 0x1134001D, 73.047, 107.845, 42.055, 0.020804, 0, 0, 0.999784, False, '2025-07-30 03:52:44'); /* AyanAttack */
/* @teleloc 0x1134001D [73.046997 107.845001 42.055000] 0.020804 0.000000 0.000000 0.999784 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7113408D, 5000904, 0x11340015, 71.5104, 110.74, 42.055, -0.449936, 0, 0, 0.893061, False, '2025-07-30 03:53:01'); /* AyanAttack */
/* @teleloc 0x11340015 [71.510399 110.739998 42.055000] -0.449936 0.000000 0.000000 0.893061 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7113408E, 5000972, 0x1134001D, 80.3141, 112.546, 42.055, -0.697901, 0, 0, 0.716195, False, '2025-07-30 03:53:09'); /* AyanAttack2 */
/* @teleloc 0x1134001D [80.314102 112.545998 42.055000] -0.697901 0.000000 0.000000 0.716195 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7113408F, 5000972, 0x1134001E, 94.2284, 134.543, 42.055, -0.983047, 0, 0, 0.183352, False, '2025-07-30 03:53:12'); /* AyanAttack2 */
/* @teleloc 0x1134001E [94.228401 134.542999 42.055000] -0.983047 0.000000 0.000000 0.183352 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x71134090, 5000976, 0x11340026, 99.7644, 142.236, 42.055, -0.928283, 0, 0, 0.371874, False, '2025-07-30 03:53:20'); /* AyanAttack2 */
/* @teleloc 0x11340026 [99.764397 142.235992 42.055000] -0.928283 0.000000 0.000000 0.371874 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x71134091, 5000972, 0x11340025, 99.7792, 113.965, 42.055, -0.00856, 0, 0, -0.999963, False, '2025-07-30 03:53:29'); /* AyanAttack2 */
/* @teleloc 0x11340025 [99.779198 113.964996 42.055000] -0.008560 0.000000 0.000000 -0.999963 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x71134092, 5000972, 0x11340017, 66.9526, 144.053, 42.055, -0.897822, 0, 0, -0.440359, False, '2025-07-30 03:53:40'); /* AyanAttack2 */
/* @teleloc 0x11340017 [66.952599 144.052994 42.055000] -0.897822 0.000000 0.000000 -0.440359 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x71134093, 5000972, 0x1134000F, 42.7382, 147.601, 42.055, -0.564563, 0, 0, -0.82539, False, '2025-07-30 03:53:42'); /* AyanAttack2 */
/* @teleloc 0x1134000F [42.738201 147.600998 42.055000] -0.564563 0.000000 0.000000 -0.825390 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x71134094, 28690, 0x11340147, 133.7729, 131.5529, 38.006, -0.681862, 0, 0, 0.731481, False, '2025-08-20 16:09:54'); /* Erik Festus */
/* @teleloc 0x11340147 [133.772903 131.552902 38.006001] -0.681862 0.000000 0.000000 0.731481 */
