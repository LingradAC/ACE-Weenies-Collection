DELETE FROM `landblock_instance` WHERE `landblock` = 0xD116;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7D116000, 12383322, 0xD1160036, 153.63, 128.447, 0.055, -0.997436, 0, 0, -0.07156, False, '2025-08-21 04:38:24');
/* @teleloc 0xD1160036 [153.630005 128.447006 0.055000] -0.997436 0.000000 0.000000 -0.071560 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7D116001, 12383322, 0xD1160024, 114.281, 95.7103, 0.055, 0.162901, 0, 0, 0.986642, False, '2025-08-21 04:38:30');
/* @teleloc 0xD1160024 [114.280998 95.710297 0.055000] 0.162901 0.000000 0.000000 0.986642 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7D116002, 12383322, 0xD116001C, 80.1981, 81.202, 0.055, 0.619754, 0, 0, 0.784797, False, '2025-08-21 04:38:33');
/* @teleloc 0xD116001C [80.198097 81.202003 0.055000] 0.619754 0.000000 0.000000 0.784797 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7D116003, 12383322, 0xD116001A, 78.3096, 45.9859, -0.045, 0.01411, 0, 0, 0.999901, False, '2025-08-21 04:38:36');
/* @teleloc 0xD116001A [78.309601 45.985901 -0.045000] 0.014110 0.000000 0.000000 0.999901 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7D116004, 12383322, 0xD1160033, 144.174, 52.8914, 0.055, -0.712863, 0, 0, 0.701304, False, '2025-08-21 04:38:42');
/* @teleloc 0xD1160033 [144.173996 52.891399 0.055000] -0.712863 0.000000 0.000000 0.701304 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7D116005, 12383322, 0xD1160033, 164.1812, 61.75932, 0.055, 0.01937, 0, 0, -0.999812, False, '2025-08-21 04:39:23');
/* @teleloc 0xD1160033 [164.181198 61.759319 0.055000] 0.019370 0.000000 0.000000 -0.999812 */
