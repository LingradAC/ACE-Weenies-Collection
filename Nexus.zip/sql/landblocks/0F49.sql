DELETE FROM `landblock_instance` WHERE `landblock` = 0x0F49;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70F49000, 92834236, 0x0F49000D, 40.608, 117.659, 1.03024, 0.642352, 0, 0, -0.766409, False, '2025-07-23 05:52:28'); /* Hopeslayer Warden + Ravener Generator */
/* @teleloc 0x0F49000D [40.608002 117.658997 1.030240] 0.642352 0.000000 0.000000 -0.766409 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70F49001, 56843983, 0x0F49003E, 170.049, 134.482, 0.677375, 0.429175, 0, 0, -0.903221, False, '2025-07-23 07:10:50'); /* Oathblade Gen */
/* @teleloc 0x0F49003E [170.048996 134.481995 0.677375] 0.429175 0.000000 0.000000 -0.903221 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70F49004, 1623822, 0x0F490033, 161.28, 60.994, 5.49499, 0.897732, 0, 0, -0.440541, False, '2025-07-29 18:17:08'); /* BloodyOthloigener */
/* @teleloc 0x0F490033 [161.279999 60.993999 5.494990] 0.897732 0.000000 0.000000 -0.440541 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70F49005, 5000765, 0x0F49002D, 125.36, 104.02, 15.6166, -0.00916, 0, 0, -0.999958, False, '2025-07-30 04:21:52'); /* Mage Skellie gen */
/* @teleloc 0x0F49002D [125.360001 104.019997 15.616600] -0.009160 0.000000 0.000000 -0.999958 */
