DELETE FROM `landblock_instance` WHERE `landblock` = 0x7AC3;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x77AC3000,  1132, 0x7AC30000, 93.4587, 70.6899, 209.59, -0.740246, 0, 0, 0.672336, False, '2005-02-09 10:00:00'); /* Item Powder Generator */
/* @teleloc 0x7AC30000 [93.458702 70.689903 209.589996] -0.740246 0.000000 0.000000 0.672336 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x77AC3001,   196, 0x7AC30000, 90.8329, 69.2981, 211.383, -0.464576, 0, 0, -0.885533,  True, '2005-02-09 10:00:00'); /* Ice Golem */
/* @teleloc 0x7AC30000 [90.832901 69.298103 211.382996] -0.464576 0.000000 0.000000 -0.885533 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x77AC3002,   196, 0x7AC30000, 64.6946, 62.2439, 225.05, -0.970543, 0, 0, -0.240928,  True, '2005-02-09 10:00:00'); /* Ice Golem */
/* @teleloc 0x7AC30000 [64.694603 62.243900 225.050003] -0.970543 0.000000 0.000000 -0.240928 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x77AC3003,   196, 0x7AC30000, 51.7058, 101.395, 233.076, -0.52954, 0, 0, 0.848285,  True, '2005-02-09 10:00:00'); /* Ice Golem */
/* @teleloc 0x7AC30000 [51.705799 101.394997 233.076004] -0.529540 0.000000 0.000000 0.848285 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x77AC3004,  1903, 0x7AC30000, 36.2469, 68.8212, 232.943, 0.520013, 0, 0, 0.854158, False, '2005-02-09 10:00:00'); /* Desert Ridge Border */
/* @teleloc 0x7AC30000 [36.246899 68.821198 232.942993] 0.520013 0.000000 0.000000 0.854158 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x77AC3007,  1154, 0x7AC30000, 44.7165, 70.4087, 230.826, -0.114247, 0, 0, 0.993452, False, '2005-02-09 10:00:00'); /* Linkable Monster Generator */
/* @teleloc 0x7AC30000 [44.716499 70.408699 230.826004] -0.114247 0.000000 0.000000 0.993452 */

INSERT INTO `landblock_instance_link` (`parent_GUID`, `child_GUID`, `last_Modified`)
VALUES (0x77AC3007, 0x77AC3001, '2005-02-09 10:00:00') /* Ice Golem (196) */
     , (0x77AC3007, 0x77AC3002, '2005-02-09 10:00:00') /* Ice Golem (196) */
     , (0x77AC3007, 0x77AC3003, '2005-02-09 10:00:00') /* Ice Golem (196) */;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x77AC3008, 42842, 0x7AC30014, 53.7374, 82.6726, 229.392, 0.972268, 0, 0, 0.233869, False, '2025-07-22 10:52:21'); /* Mayoi Portal */
/* @teleloc 0x7AC30014 [53.737400 82.672600 229.391998] 0.972268 0.000000 0.000000 0.233869 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x77AC3009, 10763, 0x7AC30012, 60.79947, 42.28527, 225.6896, -0.124551, 0, 0, 0.992213, False, '2025-07-22 10:52:39'); /* Holtburg Portal */
/* @teleloc 0x7AC30012 [60.799469 42.285271 225.689606] -0.124551 0.000000 0.000000 0.992213 */
