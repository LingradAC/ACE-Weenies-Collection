DELETE FROM `landblock_instance` WHERE `landblock` = 0xE6D0;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E6D0000, 4200152, 0xE6D00002, 8.349, 35.5283, -0.845, -0.904559, 0, 0, 0.426348, False, '2025-07-19 10:35:38'); /* Gate */
/* @teleloc 0xE6D00002 [8.349000 35.528301 -0.845000] -0.904559 0.000000 0.000000 0.426348 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E6D0001, 4200152, 0xE6D00001, 19.3764, 20.5336, -0.395, -0.88973, 0, 0, 0.456488, False, '2025-07-19 10:35:43'); /* Gate */
/* @teleloc 0xE6D00001 [19.376400 20.533600 -0.395000] -0.889730 0.000000 0.000000 0.456488 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E6D0002, 4200152, 0xE6D00009, 28.9946, 6.2299, -0.845, -0.790648, 0, 0, 0.612271, False, '2025-07-19 10:35:48'); /* Gate */
/* @teleloc 0xE6D00009 [28.994600 6.229900 -0.845000] -0.790648 0.000000 0.000000 0.612271 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E6D0003, 700255, 0xE6D00001, 19.6506, 1.8225, -0.395, -0.529188, 0, 0, 0.848505, False, '2025-08-04 17:40:32'); /* OathliegeGen */
/* @teleloc 0xE6D00001 [19.650600 1.822500 -0.395000] -0.529188 0.000000 0.000000 0.848505 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E6D0004, 700255, 0xE6D00001, 6.440097, 13.48297, -0.395, 0.779593, 0, 0, 0.626287, False, '2025-08-04 17:40:35'); /* OathliegeGen */
/* @teleloc 0xE6D00001 [6.440097 13.482970 -0.395000] 0.779593 0.000000 0.000000 0.626287 */
