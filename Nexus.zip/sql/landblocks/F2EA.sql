DELETE FROM `landblock_instance` WHERE `landblock` = 0xF2EA;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F2EA000, 4200154, 0xF2EA001C, 90.4576, 74.4106, 0, 0.043489, 0, 0, 0.999054, False, '2025-07-08 13:33:08'); /* Irwin's Blight */
/* @teleloc 0xF2EA001C [90.457603 74.410599 0.000000] 0.043489 0.000000 0.000000 0.999054 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F2EA001, 4200155, 0xF2EA001C, 88.08907, 74.26449, 0.06, 0.023088, 0, 0, -0.999733, False, '2025-07-08 13:33:31'); /* Irwin's Blight Generator 5 min */
/* @teleloc 0xF2EA001C [88.089073 74.264488 0.060000] 0.023088 0.000000 0.000000 -0.999733 */
