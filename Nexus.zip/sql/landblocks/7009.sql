DELETE FROM `landblock_instance` WHERE `landblock` = 0x7009;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x77009003, 24489, 0x70090000, 167.359, 123.379, 2.51479, 0.980694, 0, 0, -0.19555, False, '2005-02-09 10:00:00'); /* Ulgrim Island Rock-Mix Gen */
/* @teleloc 0x70090000 [167.358994 123.378998 2.514790] 0.980694 0.000000 0.000000 -0.195550 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x77009004, 24487, 0x70090000, 90.8286, 183.884, -0.095, 0.175412, 0, 0, 0.984495, False, '2005-02-09 10:00:00'); /* Ulgrim Island Beach Gen */
/* @teleloc 0x70090000 [90.828598 183.884003 -0.095000] 0.175412 0.000000 0.000000 0.984495 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x77009006, 24487, 0x70090000, 97.0087, 120.452, -0.445, 0.226705, 0, 0, 0.973963, False, '2005-02-09 10:00:00'); /* Ulgrim Island Beach Gen */
/* @teleloc 0x70090000 [97.008698 120.452003 -0.445000] 0.226705 0.000000 0.000000 0.973963 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7700900C, 24487, 0x70090000, 48.1896, 149.555, -0.445, -0.811762, 0, 0, 0.583988, False, '2005-02-09 10:00:00'); /* Ulgrim Island Beach Gen */
/* @teleloc 0x70090000 [48.189602 149.554993 -0.445000] -0.811762 0.000000 0.000000 0.583988 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7700900E, 24487, 0x70090000, 131.254, 108.8, 0.005, -0.655973, 0, 0, 0.754784, False, '2005-02-09 10:00:00'); /* Ulgrim Island Beach Gen */
/* @teleloc 0x70090000 [131.253998 108.800003 0.005000] -0.655973 0.000000 0.000000 0.754784 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x77009010, 24487, 0x70090000, 190.738, 61.3014, -0.095, -0.226729, 0, 0, 0.973958, False, '2005-02-09 10:00:00'); /* Ulgrim Island Beach Gen */
/* @teleloc 0x70090000 [190.738007 61.301399 -0.095000] -0.226729 0.000000 0.000000 0.973958 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x77009014, 24487, 0x70090000, 127.66, 62.6725, -0.895, -0.999631, 0, 0, 0.027157, False, '2005-02-09 10:00:00'); /* Ulgrim Island Beach Gen */
/* @teleloc 0x70090000 [127.660004 62.672501 -0.895000] -0.999631 0.000000 0.000000 0.027157 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x77009015, 73217237, 0x70090040, 171.25, 176.65, 12.9966, 0.986897, 0, 0, 0.161353, False, '2025-08-12 08:50:26'); /* Islandgolemgen */
/* @teleloc 0x70090040 [171.250000 176.649994 12.996600] 0.986897 0.000000 0.000000 0.161353 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x77009016, 73217237, 0x7009003B, 189.136, 48.5003, -0.045, 0.993837, 0, 0, 0.110857, False, '2025-08-12 12:39:59'); /* Islandgolemgen */
/* @teleloc 0x7009003B [189.136002 48.500301 -0.045000] 0.993837 0.000000 0.000000 0.110857 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x77009017, 73217237, 0x7009003C, 174.708, 84.1586, -0.045, 0.894071, 0, 0, 0.447926, False, '2025-08-12 12:40:02'); /* Islandgolemgen */
/* @teleloc 0x7009003C [174.707993 84.158600 -0.045000] 0.894071 0.000000 0.000000 0.447926 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x77009018, 73217237, 0x7009002D, 143.608, 100.593, 0.055, 0.798395, 0, 0, 0.602134, False, '2025-08-12 12:40:04'); /* Islandgolemgen */
/* @teleloc 0x7009002D [143.608002 100.593002 0.055000] 0.798395 0.000000 0.000000 0.602134 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x77009019, 73217237, 0x70090025, 119.322, 111.867, -0.045, 0.951413, 0, 0, 0.307918, False, '2025-08-12 12:40:06'); /* Islandgolemgen */
/* @teleloc 0x70090025 [119.321999 111.866997 -0.045000] 0.951413 0.000000 0.000000 0.307918 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7700901A, 73217237, 0x7009001F, 92.9532, 144.225, 0.055, 0.911426, 0, 0, 0.411464, False, '2025-08-12 12:40:08'); /* Islandgolemgen */
/* @teleloc 0x7009001F [92.953201 144.225006 0.055000] 0.911426 0.000000 0.000000 0.411464 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7700901B, 73217237, 0x70090020, 83.6145, 168.521, -0.045, 0.999186, 0, 0, -0.040344, False, '2025-08-12 12:40:11'); /* Islandgolemgen */
/* @teleloc 0x70090020 [83.614502 168.520996 -0.045000] 0.999186 0.000000 0.000000 -0.040344 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7700901C, 83217237, 0x7009003B, 177.22, 48.5308, -0.395, -0.994242, 0, 0, -0.10716, False, '2025-09-04 22:34:37'); /* Trophy Keeper of Honor */
/* @teleloc 0x7009003B [177.220001 48.530800 -0.395000] -0.994242 0.000000 0.000000 -0.107160 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7700901D, 83217237, 0x70090034, 167.936, 81.1357, -0.395, -0.966696, 0, 0, -0.255926, False, '2025-09-04 22:34:39'); /* Trophy Keeper of Honor */
/* @teleloc 0x70090034 [167.936005 81.135696 -0.395000] -0.966696 0.000000 0.000000 -0.255926 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7700901E, 83217237, 0x7009002D, 143.737, 97.6153, 0.055, -0.895731, 0, 0, -0.444598, False, '2025-09-04 22:34:41'); /* Trophy Keeper of Honor */
/* @teleloc 0x7009002D [143.737000 97.615303 0.055000] -0.895731 0.000000 0.000000 -0.444598 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7700901F, 73217237, 0x70090035, 165.743, 114.193, 1.383, -0.8832, 0, 0, -0.468996, False, '2025-09-06 18:57:44'); /* Islandgolemgen */
/* @teleloc 0x70090035 [165.742996 114.193001 1.383000] -0.883200 0.000000 0.000000 -0.468996 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x77009020, 73217237, 0x7009002E, 139.415, 130.727, -0.045, -0.976856, 0, 0, -0.213897, False, '2025-09-06 18:57:46'); /* Islandgolemgen */
/* @teleloc 0x7009002E [139.414993 130.727005 -0.045000] -0.976856 0.000000 0.000000 -0.213897 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x77009021, 73217237, 0x7009002F, 128.0565, 158.8942, -0.045, -0.99344, 0, 0, -0.114352, False, '2025-09-06 18:57:48'); /* Islandgolemgen */
/* @teleloc 0x7009002F [128.056503 158.894196 -0.045000] -0.993440 0.000000 0.000000 -0.114352 */
