DELETE FROM `landblock_instance` WHERE `landblock` = 0x0186;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70186004,  4059, 0x01860107, 66.5635, -56.3375, -8.75262, 1, 0, 0, 0, False, '2005-02-09 10:00:00'); /* Lightning Trap */
/* @teleloc 0x01860107 [66.563499 -56.337502 -8.752620] 1.000000 0.000000 0.000000 0.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7018600C,  4059, 0x0186011E, 93.2742, -56.2895, -8.766, 0.707107, 0, 0, -0.707107, False, '2005-02-09 10:00:00'); /* Lightning Trap */
/* @teleloc 0x0186011E [93.274200 -56.289501 -8.766000] 0.707107 0.000000 0.000000 -0.707107 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70186012,   171, 0x01860129, 102.662, -39.1723, -12, 0.707107, 0, 0, -0.707107, False, '2005-02-09 10:00:00'); /* Vat */
/* @teleloc 0x01860129 [102.662003 -39.172298 -12.000000] 0.707107 0.000000 0.000000 -0.707107 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70186013,  3962, 0x0186012C, 0.827773, -114.175, -6, 0, 0, 0, -1, False, '2005-02-09 10:00:00'); /* Chest */
/* @teleloc 0x0186012C [0.827773 -114.175003 -6.000000] 0.000000 0.000000 0.000000 -1.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70186029,  4060, 0x018601C2, 58.3116, -28.7264, 3.08688, 1, 0, 0, 0, False, '2005-02-09 10:00:00'); /* Flame Trap */
/* @teleloc 0x018601C2 [58.311600 -28.726400 3.086880] 1.000000 0.000000 0.000000 0.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70186032,  4060, 0x018601D4, 71.5678, -31.5095, 3.31425, 0, 0, 0, -1, False, '2005-02-09 10:00:00'); /* Flame Trap */
/* @teleloc 0x018601D4 [71.567802 -31.509501 3.314250] 0.000000 0.000000 0.000000 -1.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70186033,  4066, 0x018601D6, 69.6551, -46.6057, 3.30088, 1, 0, 0, 0, False, '2005-02-09 10:00:00'); /* Flame Trap */
/* @teleloc 0x018601D6 [69.655098 -46.605701 3.300880] 1.000000 0.000000 0.000000 0.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7018603A,  4060, 0x018601E3, 78.0514, -28.4693, 3.04675, 1, 0, 0, 0, False, '2005-02-09 10:00:00'); /* Flame Trap */
/* @teleloc 0x018601E3 [78.051399 -28.469299 3.046750] 1.000000 0.000000 0.000000 0.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70186070,  4057, 0x01860253, 89.3851, -60.7934, 9.127, -0.707107, 0, 0, -0.707107, False, '2005-02-09 10:00:00'); /* Acid Trap */
/* @teleloc 0x01860253 [89.385101 -60.793400 9.127000] -0.707107 0.000000 0.000000 -0.707107 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70186075,  4057, 0x0186025C, 110.763, -60.888, 9.12699, 0, 0, 0, -1, False, '2005-02-09 10:00:00'); /* Acid Trap */
/* @teleloc 0x0186025C [110.763000 -60.888000 9.126990] 0.000000 0.000000 0.000000 -1.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70186076, 83217237, 0x018601C6, 63.4303, -72.8773, 0.055, -0.315042, 0, 0, 0.949078, False, '2025-08-10 19:26:02'); /* Trophy Keeper of Honor */
/* @teleloc 0x018601C6 [63.430302 -72.877296 0.055000] -0.315042 0.000000 0.000000 0.949078 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70186077, 83217237, 0x018601E3, 81.2252, -31.5911, 0.055, -0.982249, 0, 0, 0.187584, False, '2025-08-10 19:26:09'); /* Trophy Keeper of Honor */
/* @teleloc 0x018601E3 [81.225197 -31.591101 0.055000] -0.982249 0.000000 0.000000 0.187584 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70186078, 83217237, 0x018601F0, 101.227, -46.82, 0.055, 0.134787, 0, 0, 0.990875, False, '2025-08-10 19:26:13'); /* Trophy Keeper of Honor */
/* @teleloc 0x018601F0 [101.226997 -46.820000 0.055000] 0.134787 0.000000 0.000000 0.990875 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70186079, 83217237, 0x01860191, 81.3513, -70.3108, -5.945, 0.739482, 0, 0, 0.673177, False, '2025-08-10 19:26:17'); /* Trophy Keeper of Honor */
/* @teleloc 0x01860191 [81.351303 -70.310799 -5.945000] 0.739482 0.000000 0.000000 0.673177 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7018607A, 83217237, 0x01860112, 78.8652, -62.1692, -11.945, 0.722804, 0, 0, -0.691053, False, '2025-08-10 19:26:20'); /* Trophy Keeper of Honor */
/* @teleloc 0x01860112 [78.865196 -62.169201 -11.945000] 0.722804 0.000000 0.000000 -0.691053 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7018607B, 83217237, 0x01860119, 76.5619, -80.4506, -11.945, -0.607719, 0, 0, -0.794152, False, '2025-08-10 19:26:23'); /* Trophy Keeper of Honor */
/* @teleloc 0x01860119 [76.561897 -80.450600 -11.945000] -0.607719 0.000000 0.000000 -0.794152 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7018607C, 83217237, 0x01860129, 97.0641, -39.2432, -11.945, -0.882081, 0, 0, 0.471099, False, '2025-08-10 19:26:27'); /* Trophy Keeper of Honor */
/* @teleloc 0x01860129 [97.064102 -39.243198 -11.945000] -0.882081 0.000000 0.000000 0.471099 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7018607D, 83217237, 0x01860101, 60.5583, -40.0144, -11.945, -0.180558, 0, 0, -0.983564, False, '2025-08-10 19:26:34'); /* Trophy Keeper of Honor */
/* @teleloc 0x01860101 [60.558300 -40.014400 -11.945000] -0.180558 0.000000 0.000000 -0.983564 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7018607E, 83217237, 0x01860178, 52.1268, -70.0779, -5.945, 0.448484, 0, 0, -0.893791, False, '2025-08-10 19:26:38'); /* Trophy Keeper of Honor */
/* @teleloc 0x01860178 [52.126801 -70.077904 -5.945000] 0.448484 0.000000 0.000000 -0.893791 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7018607F, 83217237, 0x0186015D, 31.6163, -100.205, -5.945, -0.704689, 0, 0, -0.709516, False, '2025-08-10 19:26:45'); /* Trophy Keeper of Honor */
/* @teleloc 0x0186015D [31.616301 -100.205002 -5.945000] -0.704689 0.000000 0.000000 -0.709516 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70186080, 83217237, 0x0186014D, 19.5442, -97.3328, -5.945, -0.652829, 0, 0, -0.757505, False, '2025-08-10 19:26:46'); /* Trophy Keeper of Honor */
/* @teleloc 0x0186014D [19.544201 -97.332802 -5.945000] -0.652829 0.000000 0.000000 -0.757505 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70186081, 83217237, 0x0186012C, 2.6261, -109.507, -5.945, -0.692304, 0, 0, -0.721606, False, '2025-08-10 19:26:49'); /* Trophy Keeper of Honor */
/* @teleloc 0x0186012C [2.626100 -109.507004 -5.945000] -0.692304 0.000000 0.000000 -0.721606 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70186082, 83217237, 0x0186012B, 4.98393, -85.5611, -5.945, -0.990155, 0, 0, -0.139976, False, '2025-08-10 19:26:56'); /* Trophy Keeper of Honor */
/* @teleloc 0x0186012B [4.983930 -85.561096 -5.945000] -0.990155 0.000000 0.000000 -0.139976 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70186083, 83217237, 0x01860157, 32.4008, -80.3423, -5.945, -0.646568, 0, 0, 0.762857, False, '2025-08-10 19:26:58'); /* Trophy Keeper of Honor */
/* @teleloc 0x01860157 [32.400799 -80.342300 -5.945000] -0.646568 0.000000 0.000000 0.762857 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70186084, 83217237, 0x018601FB, 108.997, -90.122, 0.055, 0.213315, 0, 0, 0.976983, False, '2025-08-10 19:28:23'); /* Trophy Keeper of Honor */
/* @teleloc 0x018601FB [108.997002 -90.122002 0.055000] 0.213315 0.000000 0.000000 0.976983 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70186085, 83217237, 0x018601F5, 100.854, -90.1664, 0.055, 0.999387, 0, 0, -0.035022, False, '2025-08-10 19:28:26'); /* Trophy Keeper of Honor */
/* @teleloc 0x018601F5 [100.853996 -90.166397 0.055000] 0.999387 0.000000 0.000000 -0.035022 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70186086, 83217237, 0x01860211, 139.723, -90.1787, 0.055, 0.719831, 0, 0, -0.694149, False, '2025-08-10 19:28:29'); /* Trophy Keeper of Honor */
/* @teleloc 0x01860211 [139.723007 -90.178703 0.055000] 0.719831 0.000000 0.000000 -0.694149 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70186087, 83217237, 0x0186020E, 131.514, -100.907, 0.055, -0.872367, 0, 0, 0.488852, False, '2025-08-10 19:28:36'); /* Trophy Keeper of Honor */
/* @teleloc 0x0186020E [131.514008 -100.906998 0.055000] -0.872367 0.000000 0.000000 0.488852 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70186088, 83217237, 0x01860207, 130.722, -80.5871, 0.055, -0.67524, 0, 0, 0.737598, False, '2025-08-10 19:28:42'); /* Trophy Keeper of Honor */
/* @teleloc 0x01860207 [130.722000 -80.587097 0.055000] -0.675240 0.000000 0.000000 0.737598 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70186089, 83217237, 0x0186023D, 59.8092, -59.7588, 6.055, -0.683924, 0, 0, -0.729553, False, '2025-08-10 19:28:59'); /* Trophy Keeper of Honor */
/* @teleloc 0x0186023D [59.809200 -59.758801 6.055000] -0.683924 0.000000 0.000000 -0.729553 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7018608A, 83217237, 0x018601CF, 71.1165, -15.7673, 0.055, 0.990213, 0, 0, 0.139568, False, '2025-08-10 19:29:09'); /* Trophy Keeper of Honor */
/* @teleloc 0x018601CF [71.116501 -15.767300 0.055000] 0.990213 0.000000 0.000000 0.139568 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7018608B, 83217237, 0x018601E9, 90.3708, -19.9602, 0.055, 0.75901, 0, 0, -0.651079, False, '2025-08-10 19:29:20'); /* Trophy Keeper of Honor */
/* @teleloc 0x018601E9 [90.370796 -19.960199 0.055000] 0.759010 0.000000 0.000000 -0.651079 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7018608C, 83217237, 0x018601DD, 74.6284, -72.4709, 0.055, -0.151327, 0, 0, 0.988484, False, '2025-08-10 19:36:01'); /* Trophy Keeper of Honor */
/* @teleloc 0x018601DD [74.628403 -72.470901 0.055000] -0.151327 0.000000 0.000000 0.988484 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7018608D, 63212983, 0x018601DD, 69.8978, -69.8703, -0.063, 0.426737, 0, 0, 0.904376, False, '2025-08-10 19:36:19'); /* Simiran Portal */
/* @teleloc 0x018601DD [69.897797 -69.870300 -0.063000] 0.426737 0.000000 0.000000 0.904376 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7018608E, 90191900, 0x01860130, -3.56242, -129.31, -6.063, -0.097192, 0, 0, -0.995266, False, '2025-08-10 19:37:16'); /* Decimation Golems */
/* @teleloc 0x01860130 [-3.562420 -129.309998 -6.063000] -0.097192 0.000000 0.000000 -0.995266 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7018608F, 92172778, 0x01860167, 29.7696, -124.942, -5.995, 0.782877, 0, 0, -0.622177, False, '2025-08-10 19:37:27'); /* Decimation Golem */
/* @teleloc 0x01860167 [29.769600 -124.942001 -5.995000] 0.782877 0.000000 0.000000 -0.622177 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70186090, 83217237, 0x01860171, 35.9138, -124.237, -5.945, -0.835695, 0, 0, 0.549195, False, '2025-08-10 19:37:43'); /* Trophy Keeper of Honor */
/* @teleloc 0x01860171 [35.913799 -124.237000 -5.945000] -0.835695 0.000000 0.000000 0.549195 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70186091, 83217237, 0x0186014F, 24.5533, -109.905, -5.945, 0.991008, 0, 0, 0.133802, False, '2025-08-10 19:37:55'); /* Trophy Keeper of Honor */
/* @teleloc 0x0186014F [24.553301 -109.904999 -5.945000] 0.991008 0.000000 0.000000 0.133802 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70186092, 83217237, 0x018601AC, 18.9974, -103.903, 0.055, 0.39402, 0, 0, -0.919102, False, '2025-08-10 19:38:07'); /* Trophy Keeper of Honor */
/* @teleloc 0x018601AC [18.997400 -103.903000 0.055000] 0.394020 0.000000 0.000000 -0.919102 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70186093, 83217237, 0x01860117, 78.3215, -66.7759, -11.945, -0.078967, 0, 0, 0.996877, False, '2025-08-10 22:48:25'); /* Trophy Keeper of Honor */
/* @teleloc 0x01860117 [78.321503 -66.775902 -11.945000] -0.078967 0.000000 0.000000 0.996877 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70186094, 83217237, 0x01860125, 87.5879, -78.3811, -11.945, -0.767973, 0, 0, 0.640482, False, '2025-08-10 22:48:27'); /* Trophy Keeper of Honor */
/* @teleloc 0x01860125 [87.587898 -78.381104 -11.945000] -0.767973 0.000000 0.000000 0.640482 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70186095, 83217237, 0x01860110, 84.2126, -40.2259, -11.945, -0.904821, 0, 0, 0.425793, False, '2025-08-10 22:48:31'); /* Trophy Keeper of Honor */
/* @teleloc 0x01860110 [84.212601 -40.225899 -11.945000] -0.904821 0.000000 0.000000 0.425793 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70186096, 83217237, 0x01860112, 77.6657, -56.4221, -11.945, -0.059287, 0, 0, 0.998241, False, '2025-08-10 22:48:36'); /* Trophy Keeper of Honor */
/* @teleloc 0x01860112 [77.665703 -56.422100 -11.945000] -0.059287 0.000000 0.000000 0.998241 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70186097, 83217237, 0x01860128, 96.1832, -33.7551, -11.945, 0.836199, 0, 0, -0.548426, False, '2025-08-10 22:49:56'); /* Trophy Keeper of Honor */
/* @teleloc 0x01860128 [96.183197 -33.755100 -11.945000] 0.836199 0.000000 0.000000 -0.548426 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70186098, 50037551, 0x01860247, 69.711, -90.0197, 6.06, 1, 0, 0, 0.000126, False, '2025-08-20 15:30:43'); /* 151 gtfo trap */
/* @teleloc 0x01860247 [69.710999 -90.019699 6.060000] 1.000000 0.000000 0.000000 0.000126 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70186099, 50037551, 0x018601DA, 70.6626, -62.9593, 0.055, 0.996691, 0, 0, 0.081284, False, '2025-08-20 15:30:49'); /* 151 gtfo trap */
/* @teleloc 0x018601DA [70.662598 -62.959301 0.055000] 0.996691 0.000000 0.000000 0.081284 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7018609A, 50037551, 0x018601C6, 63.8645, -70.1756, 0.055, 0.247412, 0, 0, 0.96891, False, '2025-08-20 15:30:51'); /* 151 gtfo trap */
/* @teleloc 0x018601C6 [63.864498 -70.175598 0.055000] 0.247412 0.000000 0.000000 0.968910 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7018609B, 50037551, 0x018601C7, 61.696, -80.8595, 3.06966, -0.113203, 0, 0, 0.993572, False, '2025-08-20 15:30:53'); /* 151 gtfo trap */
/* @teleloc 0x018601C7 [61.695999 -80.859497 3.069660] -0.113203 0.000000 0.000000 0.993572 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7018609C, 50037551, 0x018601DE, 73.8797, -82.4876, 0.055, -0.862832, 0, 0, 0.505491, False, '2025-08-20 15:30:57'); /* 151 gtfo trap */
/* @teleloc 0x018601DE [73.879700 -82.487602 0.055000] -0.862832 0.000000 0.000000 0.505491 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7018609D, 50037551, 0x018601D6, 70.7528, -51.7091, 0.055, -0.998758, 0, 0, -0.049827, False, '2025-08-20 15:30:59'); /* 151 gtfo trap */
/* @teleloc 0x018601D6 [70.752800 -51.709099 0.055000] -0.998758 0.000000 0.000000 -0.049827 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7018609E, 50037551, 0x018601E6, 78.4345, -47.0071, 0.055, -0.915866, 0, 0, 0.401485, False, '2025-08-20 15:31:02'); /* 151 gtfo trap */
/* @teleloc 0x018601E6 [78.434502 -47.007099 0.055000] -0.915866 0.000000 0.000000 0.401485 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7018609F, 50037551, 0x018601E5, 81.0321, -36.1149, 0.055, -0.999861, 0, 0, -0.016665, False, '2025-08-20 15:31:04'); /* 151 gtfo trap */
/* @teleloc 0x018601E5 [81.032097 -36.114899 0.055000] -0.999861 0.000000 0.000000 -0.016665 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701860A0, 50037551, 0x018601EC, 90.6399, -29.2315, 0.055, -0.629368, 0, 0, 0.777107, False, '2025-08-20 15:31:06'); /* 151 gtfo trap */
/* @teleloc 0x018601EC [90.639900 -29.231501 0.055000] -0.629368 0.000000 0.000000 0.777107 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701860A1, 50037551, 0x018601EE, 101.395, -30.6043, 0.055, -0.697285, 0, 0, 0.716794, False, '2025-08-20 15:31:07'); /* 151 gtfo trap */
/* @teleloc 0x018601EE [101.394997 -30.604300 0.055000] -0.697285 0.000000 0.000000 0.716794 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701860A2, 50037551, 0x018601EF, 102.582, -44.819, 0.055, 0.220785, 0, 0, 0.975323, False, '2025-08-20 15:31:10'); /* 151 gtfo trap */
/* @teleloc 0x018601EF [102.582001 -44.819000 0.055000] 0.220785 0.000000 0.000000 0.975323 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701860A3, 50037551, 0x018601ED, 89.374, -42.1019, 0.055, 0.598295, 0, 0, 0.801276, False, '2025-08-20 15:31:12'); /* 151 gtfo trap */
/* @teleloc 0x018601ED [89.374001 -42.101898 0.055000] 0.598295 0.000000 0.000000 0.801276 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701860A4, 50037551, 0x018601F1, 99.6869, -63.0196, 0.055, 0.088094, 0, 0, 0.996112, False, '2025-08-20 15:31:16'); /* 151 gtfo trap */
/* @teleloc 0x018601F1 [99.686897 -63.019600 0.055000] 0.088094 0.000000 0.000000 0.996112 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701860A5, 50037551, 0x0186019B, 89.057, -69.3756, -5.945, 0.705689, 0, 0, 0.708522, False, '2025-08-20 15:31:18'); /* 151 gtfo trap */
/* @teleloc 0x0186019B [89.056999 -69.375603 -5.945000] 0.705689 0.000000 0.000000 0.708522 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701860A6, 50037551, 0x01860112, 79.4013, -61.8557, -11.945, 0.998413, 0, 0, -0.056317, False, '2025-08-20 15:31:24'); /* 151 gtfo trap */
/* @teleloc 0x01860112 [79.401299 -61.855701 -11.945000] 0.998413 0.000000 0.000000 -0.056317 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701860A7, 50037551, 0x01860111, 80.9759, -50.7809, -11.945, 0.999354, 0, 0, 0.035949, False, '2025-08-20 15:31:25'); /* 151 gtfo trap */
/* @teleloc 0x01860111 [80.975899 -50.780899 -11.945000] 0.999354 0.000000 0.000000 0.035949 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701860A8, 50037551, 0x01860110, 82.4674, -42.0709, -11.945, 0.969716, 0, 0, -0.244235, False, '2025-08-20 15:31:27'); /* 151 gtfo trap */
/* @teleloc 0x01860110 [82.467400 -42.070900 -11.945000] 0.969716 0.000000 0.000000 -0.244235 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701860A9, 50037551, 0x0186011C, 91.3319, -36.2312, -11.945, 0.880973, 0, 0, -0.473167, False, '2025-08-20 15:31:28'); /* 151 gtfo trap */
/* @teleloc 0x0186011C [91.331902 -36.231201 -11.945000] 0.880973 0.000000 0.000000 -0.473167 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701860AA, 50037551, 0x01860128, 100.27, -27.4377, -11.945, 0.991636, 0, 0, -0.129067, False, '2025-08-20 15:31:29'); /* 151 gtfo trap */
/* @teleloc 0x01860128 [100.269997 -27.437700 -11.945000] 0.991636 0.000000 0.000000 -0.129067 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701860AB, 50037551, 0x0186011D, 86.5881, -48.4711, -11.945, 0.381199, 0, 0, 0.924493, False, '2025-08-20 15:31:33'); /* 151 gtfo trap */
/* @teleloc 0x0186011D [86.588097 -48.471100 -11.945000] 0.381199 0.000000 0.000000 0.924493 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701860AC, 50037551, 0x01860112, 80.4603, -62.2772, -11.945, -0.083321, 0, 0, 0.996523, False, '2025-08-20 15:31:35'); /* 151 gtfo trap */
/* @teleloc 0x01860112 [80.460297 -62.277199 -11.945000] -0.083321 0.000000 0.000000 0.996523 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701860AD, 50037551, 0x01860116, 80.0646, -72.8841, -11.945, 0.047811, 0, 0, 0.998856, False, '2025-08-20 15:31:36'); /* 151 gtfo trap */
/* @teleloc 0x01860116 [80.064598 -72.884102 -11.945000] 0.047811 0.000000 0.000000 0.998856 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701860AE, 50037551, 0x0186010E, 74.9865, -83.1423, -11.945, 0.276391, 0, 0, 0.961045, False, '2025-08-20 15:31:37'); /* 151 gtfo trap */
/* @teleloc 0x0186010E [74.986504 -83.142303 -11.945000] 0.276391 0.000000 0.000000 0.961045 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701860AF, 50037551, 0x0186010E, 67.4371, -79.8865, -11.945, 0.943139, 0, 0, 0.332398, False, '2025-08-20 15:31:38'); /* 151 gtfo trap */
/* @teleloc 0x0186010E [67.437103 -79.886497 -11.945000] 0.943139 0.000000 0.000000 0.332398 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701860B0, 50037551, 0x0186010C, 70.8381, -67.951, -11.945, 0.977791, 0, 0, -0.209584, False, '2025-08-20 15:31:40'); /* 151 gtfo trap */
/* @teleloc 0x0186010C [70.838097 -67.950996 -11.945000] 0.977791 0.000000 0.000000 -0.209584 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701860B1, 50037551, 0x01860128, 102.109, -30.1994, -11.945, 0.986181, 0, 0, -0.16567, False, '2025-08-20 15:31:45'); /* 151 gtfo trap */
/* @teleloc 0x01860128 [102.109001 -30.199400 -11.945000] 0.986181 0.000000 0.000000 -0.165670 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701860B2, 50037551, 0x0186011A, 93.0607, -18.9712, -11.945, 0.700218, 0, 0, 0.713929, False, '2025-08-20 15:31:47'); /* 151 gtfo trap */
/* @teleloc 0x0186011A [93.060699 -18.971201 -11.945000] 0.700218 0.000000 0.000000 0.713929 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701860B3, 50037551, 0x0186010F, 79.603, -20.0491, -11.945, 0.608804, 0, 0, 0.793321, False, '2025-08-20 15:31:48'); /* 151 gtfo trap */
/* @teleloc 0x0186010F [79.602997 -20.049101 -11.945000] 0.608804 0.000000 0.000000 0.793321 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701860B4, 50037551, 0x01860106, 70.3878, -25.5542, -11.945, 0.287003, 0, 0, 0.95793, False, '2025-08-20 15:31:50'); /* 151 gtfo trap */
/* @teleloc 0x01860106 [70.387802 -25.554199 -11.945000] 0.287003 0.000000 0.000000 0.957930 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701860B5, 50037551, 0x01860100, 62.2021, -32.6478, -11.945, 0.386529, 0, 0, 0.922277, False, '2025-08-20 15:31:51'); /* 151 gtfo trap */
/* @teleloc 0x01860100 [62.202099 -32.647800 -11.945000] 0.386529 0.000000 0.000000 0.922277 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701860B6, 50037551, 0x01860101, 58.8694, -41.6695, -11.945, 0.073727, 0, 0, 0.997279, False, '2025-08-20 15:31:52'); /* 151 gtfo trap */
/* @teleloc 0x01860101 [58.869400 -41.669498 -11.945000] 0.073727 0.000000 0.000000 0.997279 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701860B7, 50037551, 0x01860102, 59.2396, -53.2042, -11.945, 0.033404, 0, 0, 0.999442, False, '2025-08-20 15:31:53'); /* 151 gtfo trap */
/* @teleloc 0x01860102 [59.239601 -53.204201 -11.945000] 0.033404 0.000000 0.000000 0.999442 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701860B8, 50037551, 0x01860103, 56.271, -59.4838, -11.945, 0.691594, 0, 0, 0.722287, False, '2025-08-20 15:31:54'); /* 151 gtfo trap */
/* @teleloc 0x01860103 [56.271000 -59.483799 -11.945000] 0.691594 0.000000 0.000000 0.722287 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701860B9, 50037551, 0x01860179, 49.4764, -65.3809, -5.945, -0.042537, 0, 0, 0.999095, False, '2025-08-20 15:31:57'); /* 151 gtfo trap */
/* @teleloc 0x01860179 [49.476398 -65.380898 -5.945000] -0.042537 0.000000 0.000000 0.999095 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701860BA, 50037551, 0x01860184, 60.7778, -70.3926, -5.945, -0.698162, 0, 0, 0.715939, False, '2025-08-20 15:31:59'); /* 151 gtfo trap */
/* @teleloc 0x01860184 [60.777802 -70.392601 -5.945000] -0.698162 0.000000 0.000000 0.715939 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701860BB, 50037551, 0x0186018A, 70.6199, -70.64, -5.945, -0.698162, 0, 0, 0.715939, False, '2025-08-20 15:32:00'); /* 151 gtfo trap */
/* @teleloc 0x0186018A [70.619904 -70.639999 -5.945000] -0.698162 0.000000 0.000000 0.715939 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701860BC, 50037551, 0x01860191, 81.8566, -70.0965, -5.945, -0.753649, 0, 0, 0.657278, False, '2025-08-20 15:32:02'); /* 151 gtfo trap */
/* @teleloc 0x01860191 [81.856598 -70.096497 -5.945000] -0.753649 0.000000 0.000000 0.657278 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701860BD, 50037551, 0x0186019B, 91.8871, -70.8178, -5.945, -0.723848, 0, 0, 0.68996, False, '2025-08-20 15:32:03'); /* 151 gtfo trap */
/* @teleloc 0x0186019B [91.887100 -70.817802 -5.945000] -0.723848 0.000000 0.000000 0.689960 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701860BE, 50037551, 0x018601F0, 100.839, -52.5099, 0.055, -0.999697, 0, 0, -0.024615, False, '2025-08-20 15:32:07'); /* 151 gtfo trap */
/* @teleloc 0x018601F0 [100.838997 -52.509899 0.055000] -0.999697 0.000000 0.000000 -0.024615 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701860BF, 50037551, 0x0186017F, 50.4164, -84.1222, -5.945, 0.010334, 0, 0, 0.999947, False, '2025-08-20 15:32:26'); /* 151 gtfo trap */
/* @teleloc 0x0186017F [50.416401 -84.122200 -5.945000] 0.010334 0.000000 0.000000 0.999947 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701860C0, 50037551, 0x01860181, 49.2711, -97.5525, -5.945, 0.060776, 0, 0, 0.998151, False, '2025-08-20 15:32:27'); /* 151 gtfo trap */
/* @teleloc 0x01860181 [49.271099 -97.552498 -5.945000] 0.060776 0.000000 0.000000 0.998151 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701860C1, 50037551, 0x0186016E, 37.8276, -100.346, -5.945, 0.684616, 0, 0, 0.728904, False, '2025-08-20 15:32:32'); /* 151 gtfo trap */
/* @teleloc 0x0186016E [37.827599 -100.346001 -5.945000] 0.684616 0.000000 0.000000 0.728904 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701860C2, 50037551, 0x0186015F, 29.6159, -100.586, -5.945, 0.713486, 0, 0, 0.70067, False, '2025-08-20 15:32:33'); /* 151 gtfo trap */
/* @teleloc 0x0186015F [29.615900 -100.585999 -5.945000] 0.713486 0.000000 0.000000 0.700670 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701860C3, 50037551, 0x0186014D, 20.0907, -102.465, -5.945, 0.489725, 0, 0, 0.871877, False, '2025-08-20 15:32:34'); /* 151 gtfo trap */
/* @teleloc 0x0186014D [20.090700 -102.464996 -5.945000] 0.489725 0.000000 0.000000 0.871877 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701860C4, 50037551, 0x0186013D, 9.5785, -110.061, -5.945, 0.417785, 0, 0, 0.908546, False, '2025-08-20 15:32:36'); /* 151 gtfo trap */
/* @teleloc 0x0186013D [9.578500 -110.060997 -5.945000] 0.417785 0.000000 0.000000 0.908546 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701860C5, 50037551, 0x0186012C, 1.27743, -108.623, -5.945, 0.805651, 0, 0, 0.59239, False, '2025-08-20 15:32:37'); /* 151 gtfo trap */
/* @teleloc 0x0186012C [1.277430 -108.623001 -5.945000] 0.805651 0.000000 0.000000 0.592390 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701860C6, 50037551, 0x01860137, 8.33709, -97.5617, -5.945, 0.999997, 0, 0, 0.002625, False, '2025-08-20 15:32:40'); /* 151 gtfo trap */
/* @teleloc 0x01860137 [8.337090 -97.561699 -5.945000] 0.999997 0.000000 0.000000 0.002625 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701860C7, 50037551, 0x01860134, 5.6608, -86.625, -5.945, 0.970155, 0, 0, 0.242487, False, '2025-08-20 15:32:41'); /* 151 gtfo trap */
/* @teleloc 0x01860134 [5.660800 -86.625000 -5.945000] 0.970155 0.000000 0.000000 0.242487 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701860C8, 50037551, 0x01860131, 12.8855, -78.9969, -5.945, 0.593931, 0, 0, -0.804516, False, '2025-08-20 15:32:43'); /* 151 gtfo trap */
/* @teleloc 0x01860131 [12.885500 -78.996902 -5.945000] 0.593931 0.000000 0.000000 -0.804516 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701860C9, 50037551, 0x01860148, 20.0287, -87.9005, -5.945, 0.494017, 0, 0, -0.869452, False, '2025-08-20 15:32:44'); /* 151 gtfo trap */
/* @teleloc 0x01860148 [20.028700 -87.900497 -5.945000] 0.494017 0.000000 0.000000 -0.869452 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701860CA, 50037551, 0x01860157, 32.0777, -84.898, -5.945, 0.846303, 0, 0, -0.532701, False, '2025-08-20 15:32:46'); /* 151 gtfo trap */
/* @teleloc 0x01860157 [32.077702 -84.898003 -5.945000] 0.846303 0.000000 0.000000 -0.532701 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701860CB, 50037551, 0x01860169, 42.6409, -83.7126, -5.945, 0.520534, 0, 0, -0.853841, False, '2025-08-20 15:32:47'); /* 151 gtfo trap */
/* @teleloc 0x01860169 [42.640900 -83.712601 -5.945000] 0.520534 0.000000 0.000000 -0.853841 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701860CC, 50037551, 0x0186016A, 37.6212, -93.7038, -5.945, -0.508775, 0, 0, -0.8609, False, '2025-08-20 15:32:49'); /* 151 gtfo trap */
/* @teleloc 0x0186016A [37.621201 -93.703796 -5.945000] -0.508775 0.000000 0.000000 -0.860900 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701860CD, 50037551, 0x01860163, 32.2266, -112.319, -5.945, 0.162142, 0, 0, -0.986768, False, '2025-08-20 15:32:51'); /* 151 gtfo trap */
/* @teleloc 0x01860163 [32.226601 -112.319000 -5.945000] 0.162142 0.000000 0.000000 -0.986768 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701860CE, 50037551, 0x01860168, 31.5632, -125.038, -5.945, 0.041697, 0, 0, -0.99913, False, '2025-08-20 15:32:52'); /* 151 gtfo trap */
/* @teleloc 0x01860168 [31.563200 -125.038002 -5.945000] 0.041697 0.000000 0.000000 -0.999130 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701860CF, 50037551, 0x01860156, 19.2131, -126.542, -5.945, -0.766071, 0, 0, -0.642756, False, '2025-08-20 15:32:54'); /* 151 gtfo trap */
/* @teleloc 0x01860156 [19.213100 -126.542000 -5.945000] -0.766071 0.000000 0.000000 -0.642756 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701860D0, 50037551, 0x01860142, 9.35173, -123.56, -5.945, -0.758606, 0, 0, -0.65155, False, '2025-08-20 15:32:55'); /* 151 gtfo trap */
/* @teleloc 0x01860142 [9.351730 -123.559998 -5.945000] -0.758606 0.000000 0.000000 -0.651550 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701860D1, 50037551, 0x01860162, 25.9844, -113.951, -5.945, -0.447604, 0, 0, 0.894232, False, '2025-08-20 15:33:02'); /* 151 gtfo trap */
/* @teleloc 0x01860162 [25.984400 -113.950996 -5.945000] -0.447604 0.000000 0.000000 0.894232 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701860D2, 50037551, 0x018601E3, 81.1125, -31.7847, 0.055, -0.251266, 0, 0, -0.967918, False, '2025-08-20 15:33:18'); /* 151 gtfo trap */
/* @teleloc 0x018601E3 [81.112503 -31.784700 0.055000] -0.251266 0.000000 0.000000 -0.967918 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701860D3, 50037551, 0x018601D4, 71.8401, -28.7106, 0.055, -0.956043, 0, 0, 0.293228, False, '2025-08-20 15:33:25'); /* 151 gtfo trap */
/* @teleloc 0x018601D4 [71.840103 -28.710600 0.055000] -0.956043 0.000000 0.000000 0.293228 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701860D4, 50037551, 0x018601D1, 71.4009, -19.1233, 0.055, -0.998195, 0, 0, -0.06005, False, '2025-08-20 15:33:26'); /* 151 gtfo trap */
/* @teleloc 0x018601D1 [71.400902 -19.123301 0.055000] -0.998195 0.000000 0.000000 -0.060050 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701860D5, 50037551, 0x018601CC, 69.7191, -10.8661, 0.055, 0.99759, 0, 0, 0.069392, False, '2025-08-20 15:33:34'); /* 151 gtfo trap */
/* @teleloc 0x018601CC [69.719101 -10.866100 0.055000] 0.997590 0.000000 0.000000 0.069392 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701860D6, 50037551, 0x018601C8, 70.5711, -2.17728, 0.055, 0.99815, 0, 0, -0.060802, False, '2025-08-20 15:33:36'); /* 151 gtfo trap */
/* @teleloc 0x018601C8 [70.571098 -2.177280 0.055000] 0.998150 0.000000 0.000000 -0.060802 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701860D7, 50037551, 0x018601BE, 62.4636, -9.62299, 0.055, -0.676083, 0, 0, -0.736826, False, '2025-08-20 15:33:39'); /* 151 gtfo trap */
/* @teleloc 0x018601BE [62.463600 -9.622990 0.055000] -0.676083 0.000000 0.000000 -0.736826 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701860D8, 50037551, 0x018601E1, 79.1956, -22.0025, 0.055, 0.741283, 0, 0, -0.671193, False, '2025-08-20 15:33:42'); /* 151 gtfo trap */
/* @teleloc 0x018601E1 [79.195602 -22.002501 0.055000] 0.741283 0.000000 0.000000 -0.671193 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701860D9, 50037551, 0x018601E9, 87.6384, -20.752, 0.055, 0.684715, 0, 0, -0.728811, False, '2025-08-20 15:33:43'); /* 151 gtfo trap */
/* @teleloc 0x018601E9 [87.638397 -20.752001 0.055000] 0.684715 0.000000 0.000000 -0.728811 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701860DA, 931271771, 0x01860247, 69.711, -90.0197, 6.06, 1, 0, 0, 0.000126, False, '2025-08-25 07:01:10');
/* @teleloc 0x01860247 [69.710999 -90.019699 6.060000] 1.000000 0.000000 0.000000 0.000126 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701860DB, 931271771, 0x01860250, 77.7304, -91.8504, 6.055, 0.867972, 0, 0, -0.496613, False, '2025-08-25 07:01:14');
/* @teleloc 0x01860250 [77.730400 -91.850403 6.055000] 0.867972 0.000000 0.000000 -0.496613 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701860DC, 931271771, 0x01860250, 82.3723, -89.136, 6.055, 0.988484, 0, 0, -0.151326, False, '2025-08-25 07:01:16');
/* @teleloc 0x01860250 [82.372299 -89.136002 6.055000] 0.988484 0.000000 0.000000 -0.151326 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701860DD, 931271771, 0x018601DA, 68.3517, -62.7252, 0.055, 0.969737, 0, 0, 0.244153, False, '2025-08-25 07:01:19');
/* @teleloc 0x018601DA [68.351700 -62.725201 0.055000] 0.969737 0.000000 0.000000 0.244153 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701860DE, 931271771, 0x018601D6, 69.9859, -51.9338, 0.055, 0.998499, 0, 0, -0.054766, False, '2025-08-25 07:01:20');
/* @teleloc 0x018601D6 [69.985901 -51.933800 0.055000] 0.998499 0.000000 0.000000 -0.054766 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701860DF, 931271771, 0x018601E6, 77.2855, -48.7476, 0.055, -0.944314, 0, 0, 0.329045, False, '2025-08-25 07:01:32');
/* @teleloc 0x018601E6 [77.285500 -48.747601 0.055000] -0.944314 0.000000 0.000000 0.329045 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701860E0, 931271771, 0x018601E5, 80.441, -41.528, 0.055, -0.99568, 0, 0, 0.092855, False, '2025-08-25 07:01:33');
/* @teleloc 0x018601E5 [80.441002 -41.528000 0.055000] -0.995680 0.000000 0.000000 0.092855 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701860E1, 931271771, 0x018601C5, 61.8892, -47.7674, 0.055, -0.88695, 0, 0, -0.461865, False, '2025-08-25 07:01:36');
/* @teleloc 0x018601C5 [61.889198 -47.767399 0.055000] -0.886950 0.000000 0.000000 -0.461865 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701860E2, 931271771, 0x018601C4, 58.9032, -40.3657, 0.055, -0.998987, 0, 0, -0.044991, False, '2025-08-25 07:01:38');
/* @teleloc 0x018601C4 [58.903198 -40.365700 0.055000] -0.998987 0.000000 0.000000 -0.044991 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701860E3, 931271771, 0x018601C2, 59.8937, -32.8632, 0.055, -0.983499, 0, 0, 0.180912, False, '2025-08-25 07:01:39');
/* @teleloc 0x018601C2 [59.893700 -32.863201 0.055000] -0.983499 0.000000 0.000000 0.180912 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701860E4, 931271771, 0x018601D5, 65.0419, -29.1061, 0.055, -0.822511, 0, 0, 0.568749, False, '2025-08-25 07:01:39');
/* @teleloc 0x018601D5 [65.041901 -29.106100 0.055000] -0.822511 0.000000 0.000000 0.568749 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701860E5, 931271771, 0x01860247, 74.7089, -85.8812, 6.055, 0.715377, 0, 0, 0.698739, False, '2025-08-25 07:01:46');
/* @teleloc 0x01860247 [74.708900 -85.881203 6.055000] 0.715377 0.000000 0.000000 0.698739 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701860E6, 931271771, 0x01860242, 64.2267, -88.9923, 6.055, 0.578098, 0, 0, 0.815968, False, '2025-08-25 07:01:48');
/* @teleloc 0x01860242 [64.226700 -88.992302 6.055000] 0.578098 0.000000 0.000000 0.815968 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701860E7, 931271771, 0x01860242, 59.7431, -88.4127, 6.055, 0.781261, 0, 0, 0.624205, False, '2025-08-25 07:01:49');
/* @teleloc 0x01860242 [59.743099 -88.412697 6.055000] 0.781261 0.000000 0.000000 0.624205 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701860E8, 931271771, 0x01860242, 57.17246, -93.65733, 6.055, -0.049923, 0, 0, 0.998753, False, '2025-08-25 07:01:51');
/* @teleloc 0x01860242 [57.172459 -93.657333 6.055000] -0.049923 0.000000 0.000000 0.998753 */
