DELETE FROM `landblock_instance` WHERE `landblock` = 0x019C;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7019C000,  1925, 0x019C0100, 76.4118, -42.8933, -42, -0.707107, 0, 0, -0.707107, False, '2005-02-09 10:00:00'); /* Chest */
/* @teleloc 0x019C0100 [76.411797 -42.893299 -42.000000] -0.707107 0.000000 0.000000 -0.707107 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7019C001,  1927, 0x019C0100, 76.3428, -41.0287, -42, -0.707107, 0, 0, -0.707107, False, '2005-02-09 10:00:00'); /* Chest */
/* @teleloc 0x019C0100 [76.342796 -41.028702 -42.000000] -0.707107 0.000000 0.000000 -0.707107 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7019C00D,  1917, 0x019C0106, 97.6871, -16.8257, -42, 1, 0, 0, 0, False, '2005-02-09 10:00:00'); /* Chest */
/* @teleloc 0x019C0106 [97.687103 -16.825701 -42.000000] 1.000000 0.000000 0.000000 0.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7019C012,  3991, 0x019C010E, 123.329, -37.9092, -42, 0.707107, 0, 0, -0.707107, False, '2005-02-09 10:00:00'); /* Chest */
/* @teleloc 0x019C010E [123.329002 -37.909199 -42.000000] 0.707107 0.000000 0.000000 -0.707107 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7019C015,  1946, 0x019C010E, 123.334, -40.0301, -42, 0.707107, 0, 0, -0.707107, False, '2005-02-09 10:00:00'); /* Chest */
/* @teleloc 0x019C010E [123.334000 -40.030102 -42.000000] 0.707107 0.000000 0.000000 -0.707107 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7019C016,  1931, 0x019C010E, 123.176, -42.0664, -42, 0.707107, 0, 0, -0.707107, False, '2005-02-09 10:00:00'); /* Chest */
/* @teleloc 0x019C010E [123.176003 -42.066399 -42.000000] 0.707107 0.000000 0.000000 -0.707107 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7019C017,  2557, 0x019C011D, 110, -80, -36, 0.707107, 0, 0, -0.707107, False, '2005-02-09 10:00:00'); /* Surface */
/* @teleloc 0x019C011D [110.000000 -80.000000 -36.000000] 0.707107 0.000000 0.000000 -0.707107 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7019C018,   568, 0x019C011F, 114.75, -80, -36, 0.707107, 0, 0, -0.707107, False, '2005-02-09 10:00:00'); /* Door */
/* @teleloc 0x019C011F [114.750000 -80.000000 -36.000000] 0.707107 0.000000 0.000000 -0.707107 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7019C019,   965, 0x019C0122, 130, -44.75, -36, 0, 0, 0, -1, False, '2005-02-09 10:00:00'); /* Zombie Generator */
/* @teleloc 0x019C0122 [130.000000 -44.750000 -36.000000] 0.000000 0.000000 0.000000 -1.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7019C01A,   912, 0x019C0125, 130, -90, -36, 0.707107, 0, 0, -0.707107, False, '2005-02-09 10:00:00'); /* Revenant Generator */
/* @teleloc 0x019C0125 [130.000000 -90.000000 -36.000000] 0.707107 0.000000 0.000000 -0.707107 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7019C01B,   911, 0x019C0125, 131.339, -89.1045, -36, 0.707107, 0, 0, -0.707107, False, '2005-02-09 10:00:00'); /* Lich Generator */
/* @teleloc 0x019C0125 [131.339005 -89.104500 -36.000000] 0.707107 0.000000 0.000000 -0.707107 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7019C01C,   911, 0x019C0125, 131.296, -91.2615, -36, 0.707107, 0, 0, -0.707107, False, '2005-02-09 10:00:00'); /* Lich Generator */
/* @teleloc 0x019C0125 [131.296005 -91.261497 -36.000000] 0.707107 0.000000 0.000000 -0.707107 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7019C01D,   965, 0x019C0126, 135.25, -50, -36, -0.707107, 0, 0, -0.707107, False, '2005-02-09 10:00:00'); /* Zombie Generator */
/* @teleloc 0x019C0126 [135.250000 -50.000000 -36.000000] -0.707107 0.000000 0.000000 -0.707107 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7019C01E,   911, 0x019C0127, 141.715, -61.0199, -36, 1, 0, 0, 0, False, '2005-02-09 10:00:00'); /* Lich Generator */
/* @teleloc 0x019C0127 [141.714996 -61.019901 -36.000000] 1.000000 0.000000 0.000000 0.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7019C020,   911, 0x019C012B, 141.482, -99.3668, -36, 1, 0, 0, 0, False, '2005-02-09 10:00:00'); /* Lich Generator */
/* @teleloc 0x019C012B [141.481995 -99.366798 -36.000000] 1.000000 0.000000 0.000000 0.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7019C021,   911, 0x019C012B, 139.269, -99.2804, -36, 1, 0, 0, 0, False, '2005-02-09 10:00:00'); /* Lich Generator */
/* @teleloc 0x019C012B [139.268997 -99.280403 -36.000000] 1.000000 0.000000 0.000000 0.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7019C022,   911, 0x019C012D, 150.354, -79.8362, -36, 1, 0, 0, 0, False, '2005-02-09 10:00:00'); /* Lich Generator */
/* @teleloc 0x019C012D [150.354004 -79.836197 -36.000000] 1.000000 0.000000 0.000000 0.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7019C023,   152, 0x019C012F, 160, -80, -36, 0.707107, 0, 0, -0.707107, False, '2005-02-09 10:00:00'); /* Font */
/* @teleloc 0x019C012F [160.000000 -80.000000 -36.000000] 0.707107 0.000000 0.000000 -0.707107 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7019C024,   911, 0x019C012F, 157.452, -79.9798, -36, 0.707107, 0, 0, -0.707107, False, '2005-02-09 10:00:00'); /* Lich Generator */
/* @teleloc 0x019C012F [157.451996 -79.979797 -36.000000] 0.707107 0.000000 0.000000 -0.707107 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7019C027,   553, 0x019C013A, 20, -90, -30, -0.707107, 0, 0, -0.707107, False, '2005-02-09 10:00:00'); /* Mushroom Circle Generator */
/* @teleloc 0x019C013A [20.000000 -90.000000 -30.000000] -0.707107 0.000000 0.000000 -0.707107 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7019C028,   553, 0x019C013A, 20, -90, -30, -0.707107, 0, 0, -0.707107, False, '2005-02-09 10:00:00'); /* Mushroom Circle Generator */
/* @teleloc 0x019C013A [20.000000 -90.000000 -30.000000] -0.707107 0.000000 0.000000 -0.707107 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7019C030,   152, 0x019C0148, 50, -30, -30, 0.707107, 0, 0, -0.707107, False, '2005-02-09 10:00:00'); /* Font */
/* @teleloc 0x019C0148 [50.000000 -30.000000 -30.000000] 0.707107 0.000000 0.000000 -0.707107 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7019C033,   278, 0x019C014C, 45.25, -40, -30, -0.707107, 0, 0, -0.707107, False, '2005-02-09 10:00:00'); /* Door */
/* @teleloc 0x019C014C [45.250000 -40.000000 -30.000000] -0.707107 0.000000 0.000000 -0.707107 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7019C03F,   394, 0x019C017E, 137.876, -39.2865, -36, -0.707107, 0, 0, -0.707107, False, '2005-02-09 10:00:00'); /* Undead Generator */
/* @teleloc 0x019C017E [137.876007 -39.286499 -36.000000] -0.707107 0.000000 0.000000 -0.707107 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7019C040,   394, 0x019C017E, 138.888, -41.7762, -36, 0.9995, 0, 0, -0.031629, False, '2005-02-09 10:00:00'); /* Undead Generator */
/* @teleloc 0x019C017E [138.888000 -41.776199 -36.000000] 0.999500 0.000000 0.000000 -0.031629 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7019C047,  1927, 0x019C01A0, 40, -50, -24, -0.707107, 0, 0, -0.707107, False, '2005-02-09 10:00:00'); /* Chest */
/* @teleloc 0x019C01A0 [40.000000 -50.000000 -24.000000] -0.707107 0.000000 0.000000 -0.707107 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7019C051,   568, 0x019C01E5, 25.25, -30, -18, -0.707107, 0, 0, -0.707107, False, '2005-02-09 10:00:00'); /* Door */
/* @teleloc 0x019C01E5 [25.250000 -30.000000 -18.000000] -0.707107 0.000000 0.000000 -0.707107 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7019C054,  1301, 0x019C01EA, 35.25, -20, -18, -0.707107, 0, 0, -0.707107, False, '2005-02-09 10:00:00'); /* Door */
/* @teleloc 0x019C01EA [35.250000 -20.000000 -18.000000] -0.707107 0.000000 0.000000 -0.707107 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7019C058,  2557, 0x019C01EF, 50, -20, -18, -0.707107, 0, 0, -0.707107, False, '2005-02-09 10:00:00'); /* Surface */
/* @teleloc 0x019C01EF [50.000000 -20.000000 -18.000000] -0.707107 0.000000 0.000000 -0.707107 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7019C05E,  1916, 0x019C0222, 29.752, -33.3703, -12, 0, 0, 0, -1, False, '2005-02-09 10:00:00'); /* Chest */
/* @teleloc 0x019C0222 [29.752001 -33.370300 -12.000000] 0.000000 0.000000 0.000000 -1.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7019C05F,  1930, 0x019C0222, 28.4733, -33.2622, -12, 0, 0, 0, -1, False, '2005-02-09 10:00:00'); /* Chest */
/* @teleloc 0x019C0222 [28.473301 -33.262199 -12.000000] 0.000000 0.000000 0.000000 -1.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7019C060,   568, 0x019C0224, 25.25, -30, -12, -0.707107, 0, 0, -0.707107, False, '2005-02-09 10:00:00'); /* Door */
/* @teleloc 0x019C0224 [25.250000 -30.000000 -12.000000] -0.707107 0.000000 0.000000 -0.707107 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7019C066,   278, 0x019C022C, 35.25, -20, -12, -0.707107, 0, 0, -0.707107, False, '2005-02-09 10:00:00'); /* Door */
/* @teleloc 0x019C022C [35.250000 -20.000000 -12.000000] -0.707107 0.000000 0.000000 -0.707107 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7019C071,   153, 0x019C025F, 140, -40, -12, 0, 0, 0, -1, False, '2005-02-09 10:00:00'); /* Fountain */
/* @teleloc 0x019C025F [140.000000 -40.000000 -12.000000] 0.000000 0.000000 0.000000 -1.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7019C083, 4200078, 0x019C02A5, 103.643, -22.5978, -0.063, 0.737555, 0, 0, -0.675288, False, '2025-07-04 21:17:17'); /* Desert March */
/* @teleloc 0x019C02A5 [103.642998 -22.597799 -0.063000] 0.737555 0.000000 0.000000 -0.675288 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7019C084, 4200079, 0x019C02A5, 103.643, -18.1687, -0.063, 0.706989, 0, 0, -0.707225, False, '2025-07-04 21:17:45'); /* Sir Bellas */
/* @teleloc 0x019C02A5 [103.642998 -18.168699 -0.063000] 0.706989 0.000000 0.000000 -0.707225 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7019C085, 4200080, 0x019C02A5, 99.532, -16.357, -0.063, 0.998391, 0, 0, -0.056707, False, '2025-07-04 21:18:09'); /* Bobo Waterfall */
/* @teleloc 0x019C02A5 [99.531998 -16.357000 -0.063000] 0.998391 0.000000 0.000000 -0.056707 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7019C086, 4200081, 0x019C02A5, 96.357, -18.4897, -0.063, 0.699475, 0, 0, 0.714657, False, '2025-07-04 21:18:30'); /* Heart of Innocence */
/* @teleloc 0x019C02A5 [96.357002 -18.489700 -0.063000] 0.699475 0.000000 0.000000 0.714657 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7019C087, 4200082, 0x019C02A5, 96.357, -22.3354, -0.063, 0.702223, 0, 0, 0.711957, False, '2025-07-04 21:18:56'); /* Son of Pooky */
/* @teleloc 0x019C02A5 [96.357002 -22.335400 -0.063000] 0.702223 0.000000 0.000000 0.711957 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7019C088, 4200076, 0x019C02AF, 116.707, -36.357, -0.063, 0.999842, 0, 0, 0.017808, False, '2025-07-04 21:19:50'); /* Ayan Baqur */
/* @teleloc 0x019C02AF [116.707001 -36.356998 -0.063000] 0.999842 0.000000 0.000000 0.017808 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7019C089, 4200077, 0x019C02AF, 120.426, -36.357, -0.063, -0.999489, 0, 0, -0.031952, False, '2025-07-04 21:20:47'); /* Candeth Tree */
/* @teleloc 0x019C02AF [120.426003 -36.356998 -0.063000] -0.999489 0.000000 0.000000 -0.031952 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7019C08A, 4200083, 0x019C02AF, 123.106, -43.643, -0.063, 0.01553, 0, 0, -0.999879, False, '2025-07-04 21:21:21'); /* Ithaenc Cathedral */
/* @teleloc 0x019C02AF [123.106003 -43.643002 -0.063000] 0.015530 0.000000 0.000000 -0.999879 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7019C08B, 4200084, 0x019C02AF, 117.42, -43.643, -0.063, 0.060685, 0, 0, -0.998157, False, '2025-07-04 21:22:00'); /* Crater Village */
/* @teleloc 0x019C02AF [117.419998 -43.643002 -0.063000] 0.060685 0.000000 0.000000 -0.998157 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7019C08C, 4200085, 0x019C02A9, 103.643, -56.5563, -0.063, -0.696162, 0, 0, 0.717885, False, '2025-07-04 21:22:28'); /* Lighthouse Hermit */
/* @teleloc 0x019C02A9 [103.642998 -56.556301 -0.063000] -0.696162 0.000000 0.000000 0.717885 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7019C093, 24433, 0x019C029F, 83.0121, -43.643, -0.063, -0.001375, 0, 0, -0.999999, False, '2025-07-04 21:26:50'); /* Matron Hive East */
/* @teleloc 0x019C029F [83.012100 -43.643002 -0.063000] -0.001375 0.000000 0.000000 -0.999999 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7019C094, 30960, 0x019C029F, 79.297, -43.643, -0.063, -0.004243, 0, 0, -0.999991, False, '2025-07-04 21:27:07'); /* Dark Design */
/* @teleloc 0x019C029F [79.296997 -43.643002 -0.063000] -0.004243 0.000000 0.000000 -0.999991 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7019C095, 30964, 0x019C029F, 77.2398, -36.357, -0.063, -0.999838, 0, 0, 0.018015, False, '2025-07-04 21:27:24');
/* @teleloc 0x019C029F [77.239799 -36.356998 -0.063000] -0.999838 0.000000 0.000000 0.018015 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7019C096, 30971, 0x019C029F, 82.3254, -36.357, -0.063, -0.999995, 0, 0, -0.003145, False, '2025-07-04 21:27:45'); /* Path of the Blind */
/* @teleloc 0x019C029F [82.325401 -36.356998 -0.063000] -0.999995 0.000000 0.000000 -0.003145 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7019C097, 2003659, 0x019C029F, 75.4863, -42.2969, 0.055, -0.69973, 0, 0, -0.714408, False, '2025-07-04 22:10:50'); /* Glory Ahead! */
/* @teleloc 0x019C029F [75.486298 -42.296902 0.055000] -0.699730 0.000000 0.000000 -0.714408 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7019C098,  8384, 0x019C02B3, 129.917, -36.2232, -0.063, -0.999792, 0, 0, -0.020414, False, '2025-07-04 22:15:34'); /* Withered Banderling Drop */
/* @teleloc 0x019C02B3 [129.917007 -36.223202 -0.063000] -0.999792 0.000000 0.000000 -0.020414 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7019C09C,  1269, 0x019C02AF, 123.768, -37.5345, 0.055, 0.722362, 0, 0, -0.691515, False, '2025-07-04 23:11:26'); /* NPC's Ahead */
/* @teleloc 0x019C02AF [123.767998 -37.534500 0.055000] 0.722362 0.000000 0.000000 -0.691515 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7019C09D, 13130, 0x019C0259, 128.345, -27.8438, -12.063, 0.894723, 0, 0, 0.446621, False, '2025-07-05 04:46:25'); /* Snowy Valley Portal */
/* @teleloc 0x019C0259 [128.345001 -27.843800 -12.063000] 0.894723 0.000000 0.000000 0.446621 */
