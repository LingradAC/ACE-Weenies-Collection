DELETE FROM `landblock_instance` WHERE `landblock` = 0x7309;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x77309001, 24487, 0x73090000, 22.5335, 174.595, -0.895, -0.440066, 0, 0, -0.897965, False, '2005-02-09 10:00:00'); /* Ulgrim Island Beach Gen */
/* @teleloc 0x73090000 [22.533501 174.595001 -0.895000] -0.440066 0.000000 0.000000 -0.897965 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x77309002, 73217237, 0x7309002D, 120.402, 96.124, -0.045, 0.994814, 0, 0, -0.101714, False, '2025-08-10 19:43:49'); /* Islandgolemgen */
/* @teleloc 0x7309002D [120.402000 96.124001 -0.045000] 0.994814 0.000000 0.000000 -0.101714 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x77309003, 73217237, 0x7309000B, 42.5869, 71.9378, -0.045, 0.567906, 0, 0, 0.823094, False, '2025-08-10 19:43:56'); /* Islandgolemgen */
/* @teleloc 0x7309000B [42.586899 71.937798 -0.045000] 0.567906 0.000000 0.000000 0.823094 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x77309004, 24487, 0x7309003A, 170.979, 29.4878, -0.845, -0.999322, 0, 0, 0.036824, False, '2025-08-10 19:52:37'); /* Ulgrim Island Beach Gen */
/* @teleloc 0x7309003A [170.979004 29.487801 -0.845000] -0.999322 0.000000 0.000000 0.036824 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x77309005, 73217237, 0x73090001, 1.98121, 23.9328, 0.066198, 0.448059, 0, 0, -0.894004, False, '2025-08-12 12:41:06'); /* Islandgolemgen */
/* @teleloc 0x73090001 [1.981210 23.932800 0.066198] 0.448059 0.000000 0.000000 -0.894004 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x77309006, 73217237, 0x73090013, 55.8766, 48.383, 0.055, 0.978516, 0, 0, -0.206174, False, '2025-08-12 12:41:11'); /* Islandgolemgen */
/* @teleloc 0x73090013 [55.876598 48.382999 0.055000] 0.978516 0.000000 0.000000 -0.206174 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x77309007, 73217237, 0x7309001C, 76.6087, 72.3438, -0.045, 0.91322, 0, 0, -0.407467, False, '2025-08-12 12:41:13'); /* Islandgolemgen */
/* @teleloc 0x7309001C [76.608704 72.343803 -0.045000] 0.913220 0.000000 0.000000 -0.407467 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x77309008, 73217237, 0x7309002B, 126.585, 60.7077, -0.045, 0.290167, 0, 0, -0.956976, False, '2025-08-12 12:41:17'); /* Islandgolemgen */
/* @teleloc 0x7309002B [126.584999 60.707699 -0.045000] 0.290167 0.000000 0.000000 -0.956976 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x77309009, 83217237, 0x73090026, 100.783, 120.345, -0.845, -0.970829, 0, 0, -0.239774, False, '2025-09-04 22:48:56'); /* Trophy Keeper of Honor */
/* @teleloc 0x73090026 [100.782997 120.345001 -0.845000] -0.970829 0.000000 0.000000 -0.239774 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7730900A, 83217237, 0x73090016, 71.6351, 131.681, -0.845, -0.698561, 0, 0, -0.71555, False, '2025-09-04 22:48:58'); /* Trophy Keeper of Honor */
/* @teleloc 0x73090016 [71.635101 131.681000 -0.845000] -0.698561 0.000000 0.000000 -0.715550 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7730900B, 83217237, 0x73090016, 59.2968, 131.889, -0.845, -0.827873, 0, 0, -0.560916, False, '2025-09-04 22:48:59'); /* Trophy Keeper of Honor */
/* @teleloc 0x73090016 [59.296799 131.889008 -0.845000] -0.827873 0.000000 0.000000 -0.560916 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7730900C, 83217237, 0x7309000E, 47.935, 136.809, -0.845, -0.865414, 0, 0, -0.501057, False, '2025-09-04 22:48:59'); /* Trophy Keeper of Honor */
/* @teleloc 0x7309000E [47.935001 136.809006 -0.845000] -0.865414 0.000000 0.000000 -0.501057 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7730900D, 83217237, 0x7309000E, 47.935, 136.809, -0.845, -0.865414, 0, 0, -0.501057, False, '2025-09-04 22:49:00'); /* Trophy Keeper of Honor */
/* @teleloc 0x7309000E [47.935001 136.809006 -0.845000] -0.865414 0.000000 0.000000 -0.501057 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7730900E, 83217237, 0x7309000F, 35.2137, 144.1125, -0.845, -0.865414, 0, 0, -0.501057, False, '2025-09-04 22:49:00'); /* Trophy Keeper of Honor */
/* @teleloc 0x7309000F [35.213699 144.112503 -0.845000] -0.865414 0.000000 0.000000 -0.501057 */
