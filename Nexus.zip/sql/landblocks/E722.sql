DELETE FROM `landblock_instance` WHERE `landblock` = 0xE722;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E722000, 28259, 0xE7220100, 180.042, 130.3, 0.405, -0.026399, 0, 0, -0.999651, False, '2005-02-09 10:00:00'); /* Dark Mosswart Halls */
/* @teleloc 0xE7220100 [180.042007 130.300003 0.405000] -0.026399 0.000000 0.000000 -0.999651 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E722001,  8430, 0xE7220000, 174.83, 134.163, 0.0066, 0.999355, 0, 0, -0.035903,  True, '2005-02-09 10:00:00'); /* Mosswart Soul Trapper */
/* @teleloc 0xE7220000 [174.830002 134.162994 0.006600] 0.999355 0.000000 0.000000 -0.035903 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E722002,  8430, 0xE7220000, 176.302, 133.275, 0.0066, 0.999355, 0, 0, -0.035903,  True, '2005-02-09 10:00:00'); /* Mosswart Soul Trapper */
/* @teleloc 0xE7220000 [176.302002 133.274994 0.006600] 0.999355 0.000000 0.000000 -0.035903 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E722003,  8428, 0xE7220000, 183.397, 136.364, 0.0066, 0.999844, 0, 0, 0.017675,  True, '2005-02-09 10:00:00'); /* Mosswart Idolator */
/* @teleloc 0xE7220000 [183.397003 136.363998 0.006600] 0.999844 0.000000 0.000000 0.017675 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E722004,  8428, 0xE7220000, 182.379, 134.847, 0.0066, 0.999844, 0, 0, 0.017675,  True, '2005-02-09 10:00:00'); /* Mosswart Idolator */
/* @teleloc 0xE7220000 [182.378998 134.847000 0.006600] 0.999844 0.000000 0.000000 0.017675 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E722005,  7924, 0xE7220000, 178.849, 138.365, 0.005, -0.001289, 0, 0, 0.999999, False, '2005-02-09 10:00:00'); /* Linkable Monster Generator ( 5 Min.) */
/* @teleloc 0xE7220000 [178.848999 138.365005 0.005000] -0.001289 0.000000 0.000000 0.999999 */

INSERT INTO `landblock_instance_link` (`parent_GUID`, `child_GUID`, `last_Modified`)
VALUES (0x7E722005, 0x7E722001, '2005-02-09 10:00:00') /* Mosswart Soul Trapper (8430) */
     , (0x7E722005, 0x7E722002, '2005-02-09 10:00:00') /* Mosswart Soul Trapper (8430) */
     , (0x7E722005, 0x7E722003, '2005-02-09 10:00:00') /* Mosswart Idolator (8428) */
     , (0x7E722005, 0x7E722004, '2005-02-09 10:00:00') /* Mosswart Idolator (8428) */;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E722006,  7924, 0xE7220012, 63.4641, 47.482, 0.055, 0.983795, 0, 0, 0.179298, False, '2025-08-14 11:19:02'); /* Linkable Monster Generator ( 5 Min.) */
/* @teleloc 0xE7220012 [63.464100 47.481998 0.055000] 0.983795 0.000000 0.000000 0.179298 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E722007, 24411, 0xE7220012, 63.2403, 46.5009, 0.055, 0.983795, 0, 0, 0.179298, False, '2025-08-14 11:19:16'); /* Asheron Invasion Extreme Generators */
/* @teleloc 0xE7220012 [63.240299 46.500900 0.055000] 0.983795 0.000000 0.000000 0.179298 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E722008, 24411, 0xE7220015, 65.7146, 96.2741, 0.055, 0.99476, 0, 0, -0.102235, False, '2025-08-14 11:19:22'); /* Asheron Invasion Extreme Generators */
/* @teleloc 0xE7220015 [65.714600 96.274101 0.055000] 0.994760 0.000000 0.000000 -0.102235 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E722009, 24411, 0xE722001F, 84.2656, 157.093, -0.045, 0.977302, 0, 0, -0.211852, False, '2025-08-14 11:19:26'); /* Asheron Invasion Extreme Generators */
/* @teleloc 0xE722001F [84.265602 157.093002 -0.045000] 0.977302 0.000000 0.000000 -0.211852 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E72200A, 24411, 0xE722003F, 180.75, 161.057, 0.055, -0.85263, 0, 0, 0.522515, False, '2025-08-14 11:22:36'); /* Asheron Invasion Extreme Generators */
/* @teleloc 0xE722003F [180.750000 161.057007 0.055000] -0.852630 0.000000 0.000000 0.522515 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E72200B, 24411, 0xE722002C, 136.2789, 88.36977, 0.055, 0.972171, 0, 0, -0.234272, False, '2025-08-16 18:44:33'); /* Asheron Invasion Extreme Generators */
/* @teleloc 0xE722002C [136.278900 88.369766 0.055000] 0.972171 0.000000 0.000000 -0.234272 */
