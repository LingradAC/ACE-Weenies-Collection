DELETE FROM `landblock_instance` WHERE `landblock` = 0xE5CE;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E5CE002, 4200152, 0xE5CE0040, 173.052, 176.713, 6.055, -0.483653, 0, 0, 0.87526, False, '2025-07-19 10:37:07'); /* Gate */
/* @teleloc 0xE5CE0040 [173.052002 176.712997 6.055000] -0.483653 0.000000 0.000000 0.875260 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E5CE003, 4200152, 0xE5CE0037, 160.063, 161.698, 9.03462, -0.394427, 0, 0, 0.918927, False, '2025-07-19 10:37:39'); /* Gate */
/* @teleloc 0xE5CE0037 [160.063004 161.697998 9.034620] -0.394427 0.000000 0.000000 0.918927 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E5CE004, 4200152, 0xE5CE0037, 147.598, 148.667, 10.4439, -0.443159, 0, 0, 0.896443, False, '2025-07-19 10:37:50'); /* Gate */
/* @teleloc 0xE5CE0037 [147.598007 148.667007 10.443900] -0.443159 0.000000 0.000000 0.896443 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E5CE005, 4200152, 0xE5CE002E, 139.883, 138.303, 6.99524, -0.45921, 0, 0, 0.888328, False, '2025-07-19 10:37:55'); /* Gate */
/* @teleloc 0xE5CE002E [139.882996 138.302994 6.995240] -0.459210 0.000000 0.000000 0.888328 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E5CE006, 4200152, 0xE5CE002E, 134.193, 128.73, 2.23748, -0.545666, 0, 0, 0.838003, False, '2025-07-19 10:37:58'); /* Gate */
/* @teleloc 0xE5CE002E [134.192993 128.729996 2.237480] -0.545666 0.000000 0.000000 0.838003 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E5CE007, 4200152, 0xE5CE002D, 127.307, 114.862, 0.055, -0.521505, 0, 0, 0.853248, False, '2025-07-19 10:38:02'); /* Gate */
/* @teleloc 0xE5CE002D [127.306999 114.862000 0.055000] -0.521505 0.000000 0.000000 0.853248 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E5CE008, 4200152, 0xE5CE0025, 116.289, 100.633, 0.055, -0.441023, 0, 0, 0.897496, False, '2025-07-19 10:38:12'); /* Gate */
/* @teleloc 0xE5CE0025 [116.289001 100.633003 0.055000] -0.441023 0.000000 0.000000 0.897496 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E5CE009, 4200152, 0xE5CE0024, 104.323, 83.3382, -0.395, -0.534514, 0, 0, 0.84516, False, '2025-07-19 10:38:16'); /* Gate */
/* @teleloc 0xE5CE0024 [104.322998 83.338203 -0.395000] -0.534514 0.000000 0.000000 0.845160 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E5CE00A, 4200152, 0xE5CE001B, 95.7158, 67.8819, -0.845, -0.46108, 0, 0, 0.887358, False, '2025-07-19 10:38:24'); /* Gate */
/* @teleloc 0xE5CE001B [95.715797 67.881897 -0.845000] -0.461080 0.000000 0.000000 0.887358 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E5CE00B, 4200152, 0xE5CE001B, 81.7441, 59.5387, -0.845, 0.155598, 0, 0, 0.98782, False, '2025-07-19 10:38:30'); /* Gate */
/* @teleloc 0xE5CE001B [81.744102 59.538700 -0.845000] 0.155598 0.000000 0.000000 0.987820 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E5CE00C, 4200152, 0xE5CE0013, 62.9169, 62.5131, -0.845, -0.117184, 0, 0, 0.99311, False, '2025-07-19 10:38:42'); /* Gate */
/* @teleloc 0xE5CE0013 [62.916901 62.513100 -0.845000] -0.117184 0.000000 0.000000 0.993110 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E5CE00D, 4200152, 0xE5CE000B, 45.5179, 57.3145, -0.845, -0.314002, 0, 0, 0.949422, False, '2025-07-19 10:38:46'); /* Gate */
/* @teleloc 0xE5CE000B [45.517899 57.314499 -0.845000] -0.314002 0.000000 0.000000 0.949422 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E5CE00E, 4200152, 0xE5CE000A, 28.7057, 45.8685, -0.845, -0.335694, 0, 0, 0.941971, False, '2025-07-19 10:38:52'); /* Gate */
/* @teleloc 0xE5CE000A [28.705700 45.868500 -0.845000] -0.335694 0.000000 0.000000 0.941971 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E5CE00F, 4200152, 0xE5CE0002, 14.534, 32.4715, -0.845, -0.420926, 0, 0, 0.907095, False, '2025-07-19 10:38:57'); /* Gate */
/* @teleloc 0xE5CE0002 [14.534000 32.471500 -0.845000] -0.420926 0.000000 0.000000 0.907095 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E5CE010, 4200152, 0xE5CE0001, 2.144121, 17.47408, -0.845, -0.514917, 0, 0, 0.85724, False, '2025-07-19 10:39:01'); /* Gate */
/* @teleloc 0xE5CE0001 [2.144121 17.474079 -0.845000] -0.514917 0.000000 0.000000 0.857240 */
