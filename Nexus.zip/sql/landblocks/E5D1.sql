DELETE FROM `landblock_instance` WHERE `landblock` = 0xE5D1;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E5D1000, 4200152, 0xE5D10005, 8.17714, 99.2605, 0.055, -0.823293, 0, 0, 0.567617, False, '2025-07-19 10:32:08'); /* Gate */
/* @teleloc 0xE5D10005 [8.177140 99.260498 0.055000] -0.823293 0.000000 0.000000 0.567617 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E5D1001, 4200152, 0xE5D10004, 16.0405, 81.6793, 0.055, -0.845228, 0, 0, 0.534406, False, '2025-07-19 10:32:33'); /* Gate */
/* @teleloc 0xE5D10004 [16.040501 81.679298 0.055000] -0.845228 0.000000 0.000000 0.534406 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E5D1002, 4200152, 0xE5D1000B, 24.3535, 65.3641, 0.055, -0.905013, 0, 0, 0.425385, False, '2025-07-19 10:32:38'); /* Gate */
/* @teleloc 0xE5D1000B [24.353500 65.364098 0.055000] -0.905013 0.000000 0.000000 0.425385 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E5D1003, 4200152, 0xE5D1000B, 34.9697, 51.1189, 0.055, -0.93071, 0, 0, 0.365757, False, '2025-07-19 10:32:42'); /* Gate */
/* @teleloc 0xE5D1000B [34.969700 51.118900 0.055000] -0.930710 0.000000 0.000000 0.365757 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E5D1004, 4200152, 0xE5D1000A, 45.4606, 37.9093, 0.055, -0.794151, 0, 0, 0.607721, False, '2025-07-19 10:32:47'); /* Gate */
/* @teleloc 0xE5D1000A [45.460602 37.909302 0.055000] -0.794151 0.000000 0.000000 0.607721 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E5D1005, 4200152, 0xE5D10011, 51.0149, 20.9494, 0.817653, -0.926812, 0, 0, 0.375526, False, '2025-07-19 10:32:52'); /* Gate */
/* @teleloc 0xE5D10011 [51.014900 20.949400 0.817653] -0.926812 0.000000 0.000000 0.375526 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E5D1006, 4200152, 0xE5D10011, 63.7219, 6.05348, 2.12452, -0.866771, 0, 0, 0.498707, False, '2025-07-19 10:33:00'); /* Gate */
/* @teleloc 0xE5D10011 [63.721901 6.053480 2.124520] -0.866771 0.000000 0.000000 0.498707 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E5D1007, 700043, 0xE5D10003, 12.96732, 59.32048, 2.81317, -0.945717, 0, 0, -0.324991, False, '2025-08-24 14:40:31'); /* BiglugianGen */
/* @teleloc 0xE5D10003 [12.967320 59.320480 2.813170] -0.945717 0.000000 0.000000 -0.324991 */
