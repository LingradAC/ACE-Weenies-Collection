DELETE FROM `landblock_instance` WHERE `landblock` = 0x1049;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x71049000, 92834236, 0x10490026, 115.566, 123.03, -0.845, 0.98585, 0, 0, -0.167629, False, '2025-07-23 05:53:11');
/* @teleloc 0x10490026 [115.566002 123.029999 -0.845000] 0.985850 0.000000 0.000000 -0.167629 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x71049001, 56843983, 0x10490012, 53.89504, 29.19639, 3.996779, 0.352207, 0, 0, -0.935922, False, '2025-07-23 07:10:59');
/* @teleloc 0x10490012 [53.895039 29.196390 3.996779] 0.352207 0.000000 0.000000 -0.935922 */
