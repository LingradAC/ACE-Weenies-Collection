DELETE FROM `landblock_instance` WHERE `landblock` = 0x0F48;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70F48000, 92834236, 0x0F48001C, 75.6745, 95.5844, -0.045, 0.170763, 0, 0, -0.985312, False, '2025-07-23 05:52:43'); /* Hopeslayer Warden + Ravener Generator */
/* @teleloc 0x0F48001C [75.674500 95.584396 -0.045000] 0.170763 0.000000 0.000000 -0.985312 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70F48001, 56843983, 0x0F48003B, 178.068, 69.5784, -0.045, 0.318245, 0, 0, -0.948009, False, '2025-07-23 07:11:11'); /* Oathblade Gen */
/* @teleloc 0x0F48003B [178.067993 69.578400 -0.045000] 0.318245 0.000000 0.000000 -0.948009 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70F48002, 490174, 0x0F480010, 45.9317, 184.039, 9.71028, 0.884168, 0, 0, -0.46717, False, '2025-07-29 17:07:47'); /* Drudge Maurader Generator */
/* @teleloc 0x0F480010 [45.931702 184.039001 9.710280] 0.884168 0.000000 0.000000 -0.467170 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70F48003, 5000765, 0x0F480036, 157.1073, 143.6694, 9.147273, 0.140375, 0, 0, -0.990099, False, '2025-07-30 04:22:04'); /* Mage Skellie gen */
/* @teleloc 0x0F480036 [157.107300 143.669403 9.147273] 0.140375 0.000000 0.000000 -0.990099 */
