DELETE FROM `landblock_instance` WHERE `landblock` = 0xF667;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F667000, 490118, 0xF6670020, 86.3355, 175.88, 2.7117, -0.754956, 0, 0, -0.655776, False, '2023-12-30 13:03:47'); /* Outpost Large Tree2 */
/* @teleloc 0xF6670020 [86.335503 175.880005 2.711700] -0.754956 0.000000 0.000000 -0.655776 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F667001, 490118, 0xF6670008, 19.1417, 176.672, 3.79995, -0.805199, 0, 0, 0.593005, False, '2023-12-30 13:03:55'); /* Outpost Large Tree2 */
/* @teleloc 0xF6670008 [19.141701 176.671997 3.799950] -0.805199 0.000000 0.000000 0.593005 */
