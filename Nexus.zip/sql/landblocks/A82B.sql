DELETE FROM `landblock_instance` WHERE `landblock` = 0xA82B;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7A82B000,  9401, 0xA82B0032, 155.382, 39.6783, 106.949, -0.995645, 0, 0, -0.093227, False, '2025-08-12 04:13:55'); /* Dread Mattekar */
/* @teleloc 0xA82B0032 [155.382004 39.678299 106.948997] -0.995645 0.000000 0.000000 -0.093227 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7A82B001,  9401, 0xA82B0002, 23.50896, 31.39284, 109.3839, 0.761858, 0, 0, 0.647745, False, '2025-08-12 04:14:59'); /* Dread Mattekar */
/* @teleloc 0xA82B0002 [23.508961 31.392839 109.383904] 0.761858 0.000000 0.000000 0.647745 */
