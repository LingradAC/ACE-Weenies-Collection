DELETE FROM `landblock_instance` WHERE `landblock` = 0x0E48;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70E48000, 490174, 0x0E48001F, 75.74651, 165.3443, -0.395, 0.395674, 0, 0, -0.918391, False, '2025-07-29 17:07:35'); /* Drudge Maurader Generator */
/* @teleloc 0x0E48001F [75.746513 165.344299 -0.395000] 0.395674 0.000000 0.000000 -0.918391 */
