DELETE FROM `landblock_instance` WHERE `landblock` = 0xE622;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E622000, 24411, 0xE6220014, 50.02148, 81.3521, 20.25999, -0.67454, 0, 0, -0.738238, False, '2025-08-16 18:20:55'); /* Asheron Invasion Extreme Generators */
/* @teleloc 0xE6220014 [50.021481 81.352097 20.259991] -0.674540 0.000000 0.000000 -0.738238 */
