DELETE FROM `landblock_instance` WHERE `landblock` = 0xF664;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F664000, 490116, 0xF6640032, 154.911, 42.2769, 17.829, 0.513134, 0, 0, 0.858308, False, '2023-12-31 09:41:24'); /* Outpost Small Tree */
/* @teleloc 0xF6640032 [154.910995 42.276901 17.829000] 0.513134 0.000000 0.000000 0.858308 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F664001, 490116, 0xF664001B, 77.9473, 69.9682, 2.5506, -0.052971, 0, 0, 0.998596, False, '2023-12-31 09:41:31'); /* Outpost Small Tree */
/* @teleloc 0xF664001B [77.947304 69.968201 2.550600] -0.052971 0.000000 0.000000 0.998596 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F664002, 490118, 0xF6640035, 148.028, 113.435, 9.82053, 0.798085, 0, 0, -0.602545, False, '2024-01-06 14:56:15'); /* Outpost Large Tree2 */
/* @teleloc 0xF6640035 [148.028000 113.434998 9.820530] 0.798085 0.000000 0.000000 -0.602545 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F664004, 490118, 0xF6640031, 156.862, 18.9794, 14.0153, -0.761554, 0, 0, 0.648102, False, '2024-02-10 11:22:36'); /* Outpost Large Tree2 */
/* @teleloc 0xF6640031 [156.862000 18.979401 14.015300] -0.761554 0.000000 0.000000 0.648102 */
