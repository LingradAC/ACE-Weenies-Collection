DELETE FROM `landblock_instance` WHERE `landblock` = 0xF6D7;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F6D7006, 5000662, 0xF6D70019, 86.7084, 16.4094, 0.055, -0.561256, 0, 0, 0.827642, False, '2020-01-13 01:44:13'); /* Plant */
/* @teleloc 0xF6D70019 [86.708397 16.409401 0.055000] -0.561256 0.000000 0.000000 0.827642 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F6D7007, 5000295, 0xF6D70019, 87.4367, 16.1095, 0.055, -0.083306, 0, 0, 0.996524, False, '2020-01-13 01:44:14'); /* Plant */
/* @teleloc 0xF6D70019 [87.436699 16.109501 0.055000] -0.083306 0.000000 0.000000 0.996524 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F6D7008, 5000295, 0xF6D70021, 99.4322, 20.2486, 0.055, -0.639497, 0, 0, 0.768793, False, '2020-01-13 01:44:21'); /* Plant */
/* @teleloc 0xF6D70021 [99.432198 20.248600 0.055000] -0.639497 0.000000 0.000000 0.768793 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F6D700A, 5000652, 0xF6D70021, 99.057, 12.6294, 0.005, 0.98993, 0, 0, -0.14156, False, '2019-07-27 14:14:00');
/* @teleloc 0xF6D70021 [99.056999 12.629400 0.005000] 0.989930 0.000000 0.000000 -0.141560 */
