DELETE FROM `landblock_instance` WHERE `landblock` = 0xE820;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E820000, 24411, 0xE820000A, 24.2392, 46.9202, 0.055, 0.777636, 0, 0, -0.628716, False, '2025-08-16 18:21:40'); /* Asheron Invasion Extreme Generators */
/* @teleloc 0xE820000A [24.239201 46.920200 0.055000] 0.777636 0.000000 0.000000 -0.628716 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E820001, 24411, 0xE8200025, 96.29889, 110.7912, -0.045, 0.902693, 0, 0, -0.430286, False, '2025-08-16 18:21:47'); /* Asheron Invasion Extreme Generators */
/* @teleloc 0xE8200025 [96.298889 110.791199 -0.045000] 0.902693 0.000000 0.000000 -0.430286 */
