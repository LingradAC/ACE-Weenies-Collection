DELETE FROM `landblock_instance` WHERE `landblock` = 0x720A;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7720A000, 24487, 0x720A0000, 182.785, 31.2192, -0.895, 0.975143, 0, 0, -0.221577, False, '2021-11-01 00:00:00'); /* Ulgrim Island Beach Gen */
/* @teleloc 0x720A0000 [182.785004 31.219200 -0.895000] 0.975143 0.000000 0.000000 -0.221577 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7720A001,  1154, 0x720A000A, 24.5015, 35.4266, 1.05029, -0.797676, 0, 0, -0.603086, False, '2021-11-01 00:00:00'); /* Linkable Monster Generator */
/* @teleloc 0x720A000A [24.501499 35.426601 1.050290] -0.797676 0.000000 0.000000 -0.603086 */

INSERT INTO `landblock_instance_link` (`parent_GUID`, `child_GUID`, `last_Modified`)
VALUES (0x7720A001, 0x7720A13F, '2021-11-01 00:00:00') /* The Black Breath (32804) */
     , (0x7720A001, 0x7720A1D5, '2021-11-01 00:00:00') /* The Black Breath (32804) */;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7720A003, 24487, 0x720A0000, 118.236, 78.9268, -0.9, -0.631259, 0, 0, -0.775572, False, '2021-11-01 00:00:00'); /* Ulgrim Island Beach Gen */
/* @teleloc 0x720A0000 [118.236000 78.926804 -0.900000] -0.631259 0.000000 0.000000 -0.775572 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7720A008, 24487, 0x720A0000, 104.439, 80.441, -0.895, 0.190244, 0, 0, -0.981737, False, '2021-11-01 00:00:00'); /* Ulgrim Island Beach Gen */
/* @teleloc 0x720A0000 [104.439003 80.441002 -0.895000] 0.190244 0.000000 0.000000 -0.981737 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7720A00B, 24487, 0x720A0000, 71.2775, 63.9689, 0.674257, 0.993683, 0, 0, -0.112223, False, '2021-11-01 00:00:00'); /* Ulgrim Island Beach Gen */
/* @teleloc 0x720A0000 [71.277496 63.968899 0.674257] 0.993683 0.000000 0.000000 -0.112223 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7720A00E, 24487, 0x720A0000, 0.364251, 78.6124, -0.095, -0.621669, 0, 0, 0.78328, False, '2021-11-01 00:00:00'); /* Ulgrim Island Beach Gen */
/* @teleloc 0x720A0000 [0.364251 78.612396 -0.095000] -0.621669 0.000000 0.000000 0.783280 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7720A00F, 24487, 0x720A0000, 31.4327, 132.685, -0.895, 0.965413, 0, 0, -0.260725, False, '2021-11-01 00:00:00'); /* Ulgrim Island Beach Gen */
/* @teleloc 0x720A0000 [31.432699 132.684998 -0.895000] 0.965413 0.000000 0.000000 -0.260725 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7720A011, 24487, 0x720A0000, 84.6419, 11.2851, 1.05957, -0.251826, 0, 0, -0.967772, False, '2021-11-01 00:00:00'); /* Ulgrim Island Beach Gen */
/* @teleloc 0x720A0000 [84.641899 11.285100 1.059570] -0.251826 0.000000 0.000000 -0.967772 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7720A013, 24490, 0x720A0000, 31.9428, 45.5088, 0.661904, -0.797676, 0, 0, -0.603086, False, '2021-11-01 00:00:00'); /* Ulgrim Island Tree-Line Gen */
/* @teleloc 0x720A0000 [31.942801 45.508801 0.661904] -0.797676 0.000000 0.000000 -0.603086 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7720A13F, 32804, 0x720A0002, 23.3195, 27.1861, 1.74449, -0.797676, 0, 0, -0.603086,  True, '2021-11-01 00:00:00'); /* The Black Breath */
/* @teleloc 0x720A0002 [23.319500 27.186100 1.744490] -0.797676 0.000000 0.000000 -0.603086 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7720A1D5, 32804, 0x720A000A, 26.3024, 36.1142, 1.00048, -0.797676, 0, 0, -0.603086,  True, '2021-11-01 00:00:00'); /* The Black Breath */
/* @teleloc 0x720A000A [26.302401 36.114201 1.000480] -0.797676 0.000000 0.000000 -0.603086 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7720A1D6, 73217237, 0x720A0003, 4.83942, 64.7109, 0.055, 0.633996, 0, 0, -0.773337, False, '2025-08-12 12:40:41'); /* Islandgolemgen */
/* @teleloc 0x720A0003 [4.839420 64.710899 0.055000] 0.633996 0.000000 0.000000 -0.773337 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7720A1D7, 73217237, 0x720A0013, 51.5614, 61.469, 0.932584, 0.776208, 0, 0, -0.630477, False, '2025-08-12 12:40:44'); /* Islandgolemgen */
/* @teleloc 0x720A0013 [51.561401 61.469002 0.932584] 0.776208 0.000000 0.000000 -0.630477 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7720A1D8, 73217237, 0x720A0021, 104.785, 23.3792, 0.106736, 0.180909, 0, 0, -0.9835, False, '2025-08-12 12:40:49'); /* Islandgolemgen */
/* @teleloc 0x720A0021 [104.785004 23.379200 0.106736] 0.180909 0.000000 0.000000 -0.983500 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7720A1D9, 83217237, 0x720A000C, 24.273, 77.0112, -0.045, -0.632231, 0, 0, 0.77478, False, '2025-09-04 22:35:19'); /* Trophy Keeper of Honor */
/* @teleloc 0x720A000C [24.273001 77.011200 -0.045000] -0.632231 0.000000 0.000000 0.774780 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7720A1DA, 83217237, 0x720A001B, 78.5803, 56.853, 0.668204, -0.364312, 0, 0, 0.931277, False, '2025-09-04 22:35:23'); /* Trophy Keeper of Honor */
/* @teleloc 0x720A001B [78.580299 56.853001 0.668204] -0.364312 0.000000 0.000000 0.931277 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7720A1DB, 83217237, 0x720A0022, 98.6066, 34.7147, -0.045, -0.354892, 0, 0, 0.934908, False, '2025-09-04 22:35:24'); /* Trophy Keeper of Honor */
/* @teleloc 0x720A0022 [98.606598 34.714699 -0.045000] -0.354892 0.000000 0.000000 0.934908 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7720A1DC, 83217237, 0x720A0019, 95.947, 9.23596, 1.28534, 0.374913, 0, 0, 0.92706, False, '2025-09-04 22:35:26'); /* Trophy Keeper of Honor */
/* @teleloc 0x720A0019 [95.946999 9.235960 1.285340] 0.374913 0.000000 0.000000 0.927060 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7720A1DD, 73217237, 0x720A0009, 24.0813, 9.957, 2.04822, -0.844969, 0, 0, 0.534815, False, '2025-09-06 02:52:04'); /* Islandgolemgen */
/* @teleloc 0x720A0009 [24.081301 9.957000 2.048220] -0.844969 0.000000 0.000000 0.534815 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7720A1DE, 73217237, 0x720A0003, 23.1009, 61.9567, 0.055, -0.474222, 0, 0, 0.880405, False, '2025-09-06 18:58:22'); /* Islandgolemgen */
/* @teleloc 0x720A0003 [23.100901 61.956699 0.055000] -0.474222 0.000000 0.000000 0.880405 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7720A1DF, 73217237, 0x720A001A, 83.1593, 43.0231, 1.02471, -0.307298, 0, 0, 0.951613, False, '2025-09-06 18:58:27'); /* Islandgolemgen */
/* @teleloc 0x720A001A [83.159302 43.023102 1.024710] -0.307298 0.000000 0.000000 0.951613 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7720A1E0, 73217237, 0x720A0021, 99.3319, 23.5375, 0.093539, -0.447343, 0, 0, 0.894363, False, '2025-09-06 18:58:29'); /* Islandgolemgen */
/* @teleloc 0x720A0021 [99.331902 23.537500 0.093539] -0.447343 0.000000 0.000000 0.894363 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7720A1E1, 73217237, 0x720A0029, 120.0683, 7.857509, -0.045, -0.278339, 0, 0, 0.960483, False, '2025-09-06 18:58:31'); /* Islandgolemgen */
/* @teleloc 0x720A0029 [120.068298 7.857509 -0.045000] -0.278339 0.000000 0.000000 0.960483 */
