DELETE FROM `landblock_instance` WHERE `landblock` = 0x01FC;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701FC00F,   907, 0x01FC0132, 69.064, -21.364, 0, 0.707107, 0, 0, -0.707107, False, '2005-02-09 10:00:00'); /* Reedshark Pup Generator */
/* @teleloc 0x01FC0132 [69.064003 -21.364000 0.000000] 0.707107 0.000000 0.000000 -0.707107 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701FC013,   420, 0x01FC014D, 97.3913, -28.6249, 0, 0.707107, 0, 0, -0.707107, False, '2005-02-09 10:00:00'); /* Item Food Generator */
/* @teleloc 0x01FC014D [97.391296 -28.624901 0.000000] 0.707107 0.000000 0.000000 -0.707107 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701FC015,  1915, 0x01FC014D, 96.2109, -27.6868, 0, -0.707107, 0, 0, -0.707107, False, '2005-02-09 10:00:00'); /* Chest */
/* @teleloc 0x01FC014D [96.210899 -27.686800 0.000000] -0.707107 0.000000 0.000000 -0.707107 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701FC016,  1921, 0x01FC014D, 96.0978, -33.2983, 0, -0.707107, 0, 0, -0.707107, False, '2005-02-09 10:00:00'); /* Chest */
/* @teleloc 0x01FC014D [96.097801 -33.298302 0.000000] -0.707107 0.000000 0.000000 -0.707107 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701FC020,  5056, 0x01FC0193, 69.1925, -53.7621, 6, 0, 0, 0, -1, False, '2005-02-09 10:00:00'); /* Chest */
/* @teleloc 0x01FC0193 [69.192497 -53.762100 6.000000] 0.000000 0.000000 0.000000 -1.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701FC021, 90172313, 0x01FC0120, 41.1113, -73.4041, 0.055, -0.838698, 0, 0, -0.544597, False, '2025-08-04 16:17:35'); /* pancakegene */
/* @teleloc 0x01FC0120 [41.111301 -73.404099 0.055000] -0.838698 0.000000 0.000000 -0.544597 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701FC022, 90172313, 0x01FC011C, 28.4128, -86.6624, 0.055, -0.551225, 0, 0, -0.834357, False, '2025-08-04 16:17:37'); /* pancakegene */
/* @teleloc 0x01FC011C [28.412800 -86.662399 0.055000] -0.551225 0.000000 0.000000 -0.834357 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701FC023, 90172313, 0x01FC0116, 20.141, -92.8574, 0.055, -0.551225, 0, 0, -0.834357, False, '2025-08-04 16:17:38'); /* pancakegene */
/* @teleloc 0x01FC0116 [20.141001 -92.857399 0.055000] -0.551225 0.000000 0.000000 -0.834357 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701FC024, 90172313, 0x01FC010E, 10.6495, -101.844, 0.055, -0.805045, 0, 0, -0.593214, False, '2025-08-04 16:17:39'); /* pancakegene */
/* @teleloc 0x01FC010E [10.649500 -101.844002 0.055000] -0.805045 0.000000 0.000000 -0.593214 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701FC025, 90172313, 0x01FC0108, 1.70785, -99.1902, 0.055, -0.978121, 0, 0, -0.208038, False, '2025-08-04 16:17:41'); /* pancakegene */
/* @teleloc 0x01FC0108 [1.707850 -99.190201 0.055000] -0.978121 0.000000 0.000000 -0.208038 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701FC026, 90172313, 0x01FC0107, -0.964401, -90.7895, 0.055, -0.984887, 0, 0, 0.173201, False, '2025-08-04 16:17:42'); /* pancakegene */
/* @teleloc 0x01FC0107 [-0.964401 -90.789497 0.055000] -0.984887 0.000000 0.000000 0.173201 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701FC027, 90172313, 0x01FC0106, 4.40115, -82.7222, 0.055, -0.984887, 0, 0, 0.173201, False, '2025-08-04 16:17:43'); /* pancakegene */
/* @teleloc 0x01FC0106 [4.401150 -82.722198 0.055000] -0.984887 0.000000 0.000000 0.173201 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701FC028, 90172313, 0x01FC0106, -1.85423, -75.1651, 0.055, -0.997771, 0, 0, -0.066727, False, '2025-08-04 16:17:44'); /* pancakegene */
/* @teleloc 0x01FC0106 [-1.854230 -75.165100 0.055000] -0.997771 0.000000 0.000000 -0.066727 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701FC029, 90172313, 0x01FC0100, 1.16433, -39.609, 0.055, -0.819897, 0, 0, -0.572511, False, '2025-08-04 16:17:48'); /* pancakegene */
/* @teleloc 0x01FC0100 [1.164330 -39.609001 0.055000] -0.819897 0.000000 0.000000 -0.572511 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701FC02A, 90172313, 0x01FC010F, 19.599, -31.3708, 0.055, -0.882929, 0, 0, 0.469506, False, '2025-08-04 16:17:51'); /* pancakegene */
/* @teleloc 0x01FC010F [19.599001 -31.370800 0.055000] -0.882929 0.000000 0.000000 0.469506 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701FC02B, 90172313, 0x01FC0131, 60.5044, -65.3922, 0.055, -0.159526, 0, 0, 0.987194, False, '2025-08-04 16:17:57'); /* pancakegene */
/* @teleloc 0x01FC0131 [60.504398 -65.392197 0.055000] -0.159526 0.000000 0.000000 0.987194 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701FC02C, 90172313, 0x01FC013A, 67.5391, -71.0788, 0.055, -0.382424, 0, 0, 0.923987, False, '2025-08-04 16:17:58'); /* pancakegene */
/* @teleloc 0x01FC013A [67.539101 -71.078796 0.055000] -0.382424 0.000000 0.000000 0.923987 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701FC02D, 90172313, 0x01FC0139, 70.1714, -61.6817, 0.055, -0.993017, 0, 0, -0.117975, False, '2025-08-04 16:18:00'); /* pancakegene */
/* @teleloc 0x01FC0139 [70.171402 -61.681702 0.055000] -0.993017 0.000000 0.000000 -0.117975 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701FC02F, 90172313, 0x01FC0135, 71.8756, -48.0748, 0.055, 0.638132, 0, 0, 0.769927, False, '2025-08-04 16:18:12'); /* pancakegene */
/* @teleloc 0x01FC0135 [71.875603 -48.074799 0.055000] 0.638132 0.000000 0.000000 0.769927 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701FC030, 90172313, 0x01FC012D, 57.8771, -49.0066, 0.055, -0.314065, 0, 0, 0.949402, False, '2025-08-04 16:18:18'); /* pancakegene */
/* @teleloc 0x01FC012D [57.877102 -49.006599 0.055000] -0.314065 0.000000 0.000000 0.949402 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701FC031, 90172313, 0x01FC0148, 89.5487, -38.987, 0.055, -0.892187, 0, 0, 0.451667, False, '2025-08-04 16:18:22'); /* pancakegene */
/* @teleloc 0x01FC0148 [89.548698 -38.987000 0.055000] -0.892187 0.000000 0.000000 0.451667 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701FC032, 90172313, 0x01FC0134, 71.5637, -36.375, 0.055, -0.809649, 0, 0, -0.586914, False, '2025-08-04 16:18:25'); /* pancakegene */
/* @teleloc 0x01FC0134 [71.563698 -36.375000 0.055000] -0.809649 0.000000 0.000000 -0.586914 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701FC033, 90172313, 0x01FC012C, 59.8282, -31.4295, 0.055, -0.675494, 0, 0, -0.737366, False, '2025-08-04 16:18:26'); /* pancakegene */
/* @teleloc 0x01FC012C [59.828201 -31.429501 0.055000] -0.675494 0.000000 0.000000 -0.737366 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701FC034, 90172313, 0x01FC0122, 48.2809, -29.3708, 0.055, 0.552651, 0, 0, -0.833413, False, '2025-08-04 16:18:28'); /* pancakegene */
/* @teleloc 0x01FC0122 [48.280899 -29.370800 0.055000] 0.552651 0.000000 0.000000 -0.833413 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701FC035, 90172313, 0x01FC0128, 59.1548, -18.7303, 0.055, -0.781444, 0, 0, -0.623976, False, '2025-08-04 16:18:41'); /* pancakegene */
/* @teleloc 0x01FC0128 [59.154800 -18.730301 0.055000] -0.781444 0.000000 0.000000 -0.623976 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701FC036, 90172313, 0x01FC014C, 101.597, 2.17222, 0.055, -0.319619, 0, 0, 0.947546, False, '2025-08-04 16:18:50'); /* pancakegene */
/* @teleloc 0x01FC014C [101.597000 2.172220 0.055000] -0.319619 0.000000 0.000000 0.947546 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701FC037, 90172313, 0x01FC0152, 112.164, -3.77821, 0.055, -0.246326, 0, 0, 0.969187, False, '2025-08-04 16:18:52'); /* pancakegene */
/* @teleloc 0x01FC0152 [112.164001 -3.778210 0.055000] -0.246326 0.000000 0.000000 0.969187 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701FC038, 90172313, 0x01FC015A, 120.775, -15.6888, 0.055, 0.463868, 0, 0, 0.885904, False, '2025-08-04 16:18:55'); /* pancakegene */
/* @teleloc 0x01FC015A [120.775002 -15.688800 0.055000] 0.463868 0.000000 0.000000 0.885904 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701FC039, 90172313, 0x01FC0155, 110.178, -31.5972, 0.055, 0.654194, 0, 0, 0.756327, False, '2025-08-04 16:18:57'); /* pancakegene */
/* @teleloc 0x01FC0155 [110.178001 -31.597200 0.055000] 0.654194 0.000000 0.000000 0.756327 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701FC03A, 90172313, 0x01FC0151, 100.424, -60.1927, 0.055, -0.937569, 0, 0, 0.347799, False, '2025-08-04 16:19:07'); /* pancakegene */
/* @teleloc 0x01FC0151 [100.424004 -60.192699 0.055000] -0.937569 0.000000 0.000000 0.347799 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701FC03B, 90172313, 0x01FC0156, 109.193, -53.1984, 0.055, -0.937569, 0, 0, 0.347799, False, '2025-08-04 16:19:08'); /* pancakegene */
/* @teleloc 0x01FC0156 [109.193001 -53.198399 0.055000] -0.937569 0.000000 0.000000 0.347799 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701FC03C, 63212983, 0x01FC0115, 18.4871, -72.0451, -0.063, 0.325476, 0, 0, 0.94555, False, '2025-08-04 16:19:49'); /* Simiran Portal */
/* @teleloc 0x01FC0115 [18.487101 -72.045097 -0.063000] 0.325476 0.000000 0.000000 0.945550 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701FC03D, 90172313, 0x01FC012D, 60.8646, -51.0883, 0.055, -0.705346, 0, 0, -0.708863, False, '2025-08-08 03:43:40'); /* pancakegene */
/* @teleloc 0x01FC012D [60.864601 -51.088299 0.055000] -0.705346 0.000000 0.000000 -0.708863 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701FC03E, 90172313, 0x01FC0135, 68.1508, -50.612, 0.055, -0.577785, 0, 0, 0.816189, False, '2025-08-08 03:43:42'); /* pancakegene */
/* @teleloc 0x01FC0135 [68.150803 -50.612000 0.055000] -0.577785 0.000000 0.000000 0.816189 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701FC040, 90172313, 0x01FC0144, 78.9178, -57.3834, 0.055, -0.977923, 0, 0, 0.208964, False, '2025-08-08 03:43:47'); /* pancakegene */
/* @teleloc 0x01FC0144 [78.917801 -57.383400 0.055000] -0.977923 0.000000 0.000000 0.208964 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701FC042, 90172313, 0x01FC0132, 71.8681, -19.8407, 0.055, -0.856594, 0, 0, -0.51599, False, '2025-08-08 03:44:02'); /* pancakegene */
/* @teleloc 0x01FC0132 [71.868103 -19.840700 0.055000] -0.856594 0.000000 0.000000 -0.515990 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701FC043, 90172313, 0x01FC0183, 61.915, -10.1869, 3.44424, -0.789071, 0, 0, 0.614302, False, '2025-08-08 03:44:05'); /* pancakegene */
/* @teleloc 0x01FC0183 [61.915001 -10.186900 3.444240] -0.789071 0.000000 0.000000 0.614302 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701FC044, 90172313, 0x01FC019C, 77.4224, -7.06023, 6.055, -0.900558, 0, 0, 0.434736, False, '2025-08-08 03:44:07'); /* pancakegene */
/* @teleloc 0x01FC019C [77.422401 -7.060230 6.055000] -0.900558 0.000000 0.000000 0.434736 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701FC045, 90172313, 0x01FC01A5, 86.5232, -0.244003, 6.055, -0.671735, 0, 0, 0.740792, False, '2025-08-08 03:44:09'); /* pancakegene */
/* @teleloc 0x01FC01A5 [86.523201 -0.244003 6.055000] -0.671735 0.000000 0.000000 0.740792 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701FC046, 90172313, 0x01FC01A5, 94.9181, -0.060251, 6.055, -0.395599, 0, 0, 0.918424, False, '2025-08-08 03:44:11'); /* pancakegene */
/* @teleloc 0x01FC01A5 [94.918098 -0.060251 6.055000] -0.395599 0.000000 0.000000 0.918424 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701FC047, 90172313, 0x01FC0154, 112.901, -23.5093, 0.055, 0.66003, 0, 0, 0.75124, False, '2025-08-08 03:44:18'); /* pancakegene */
/* @teleloc 0x01FC0154 [112.901001 -23.509300 0.055000] 0.660030 0.000000 0.000000 0.751240 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701FC048, 90172313, 0x01FC015A, 116.536, -19.4218, 0.055, 0.985154, 0, 0, -0.171674, False, '2025-08-08 03:44:20'); /* pancakegene */
/* @teleloc 0x01FC015A [116.536003 -19.421801 0.055000] 0.985154 0.000000 0.000000 -0.171674 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701FC049, 90172313, 0x01FC0159, 121.6, -11.7013, 0.055, 0.989491, 0, 0, 0.144597, False, '2025-08-08 03:44:21'); /* pancakegene */
/* @teleloc 0x01FC0159 [121.599998 -11.701300 0.055000] 0.989491 0.000000 0.000000 0.144597 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701FC04A, 90172313, 0x01FC0156, 110.076, -52.757, 0.055, 0.385985, 0, 0, 0.922505, False, '2025-08-08 03:44:32'); /* pancakegene */
/* @teleloc 0x01FC0156 [110.075996 -52.757000 0.055000] 0.385985 0.000000 0.000000 0.922505 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701FC04B, 90172313, 0x01FC0150, 104.055, -54.2413, 0.055, 0.538809, 0, 0, 0.842428, False, '2025-08-08 03:44:33'); /* pancakegene */
/* @teleloc 0x01FC0150 [104.055000 -54.241299 0.055000] 0.538809 0.000000 0.000000 0.842428 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701FC04C, 90172313, 0x01FC0170, 28.4135, -109.828, 6.055, -0.704952, 0, 0, 0.709255, False, '2025-08-08 04:22:06'); /* pancakegene */
/* @teleloc 0x01FC0170 [28.413500 -109.828003 6.055000] -0.704952 0.000000 0.000000 0.709255 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701FC04D, 90172313, 0x01FC0179, 35.4994, -105.7, 6.055, -0.928562, 0, 0, 0.371177, False, '2025-08-08 04:22:07'); /* pancakegene */
/* @teleloc 0x01FC0179 [35.499401 -105.699997 6.055000] -0.928562 0.000000 0.000000 0.371177 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701FC04E, 90172313, 0x01FC0178, 39.0224, -100.438, 6.055, -0.928562, 0, 0, 0.371177, False, '2025-08-08 04:22:08'); /* pancakegene */
/* @teleloc 0x01FC0178 [39.022400 -100.438004 6.055000] -0.928562 0.000000 0.000000 0.371177 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701FC04F, 90172313, 0x01FC0180, 45.5378, -100.087, 6.055, -0.739193, 0, 0, 0.673493, False, '2025-08-08 04:22:09'); /* pancakegene */
/* @teleloc 0x01FC0180 [45.537800 -100.086998 6.055000] -0.739193 0.000000 0.000000 0.673493 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701FC050, 90172313, 0x01FC017F, 53.0329, -91.1718, 6.055, -0.944381, 0, 0, 0.328854, False, '2025-08-08 04:22:11'); /* pancakegene */
/* @teleloc 0x01FC017F [53.032902 -91.171799 6.055000] -0.944381 0.000000 0.000000 0.328854 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701FC051, 90172313, 0x01FC018E, 59.0836, -88.1481, 6.055, -0.803309, 0, 0, 0.595563, False, '2025-08-08 04:22:11'); /* pancakegene */
/* @teleloc 0x01FC018E [59.083599 -88.148102 6.055000] -0.803309 0.000000 0.000000 0.595563 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701FC052, 90172313, 0x01FC018D, 64.6574, -83.4579, 6.055, -0.805023, 0, 0, 0.593244, False, '2025-08-08 04:22:12'); /* pancakegene */
/* @teleloc 0x01FC018D [64.657402 -83.457901 6.055000] -0.805023 0.000000 0.000000 0.593244 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701FC053, 90172313, 0x01FC019A, 69.8881, -85.2891, 6.055, -0.846447, 0, 0, 0.532474, False, '2025-08-08 04:22:13'); /* pancakegene */
/* @teleloc 0x01FC019A [69.888100 -85.289101 6.055000] -0.846447 0.000000 0.000000 0.532474 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701FC054, 90172313, 0x01FC01A4, 77.6963, -78.1473, 6.055, -0.908851, 0, 0, 0.41712, False, '2025-08-08 04:22:14'); /* pancakegene */
/* @teleloc 0x01FC01A4 [77.696297 -78.147301 6.055000] -0.908851 0.000000 0.000000 0.417120 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701FC055, 90172313, 0x01FC01A2, 82.354, -68.9023, 6.055, -0.81517, 0, 0, 0.579222, False, '2025-08-08 04:22:15'); /* pancakegene */
/* @teleloc 0x01FC01A2 [82.353996 -68.902298 6.055000] -0.815170 0.000000 0.000000 0.579222 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701FC056, 90172313, 0x01FC01A0, 80.5256, -48.8587, 6.055, -0.640273, 0, 0, -0.768148, False, '2025-08-08 04:22:18'); /* pancakegene */
/* @teleloc 0x01FC01A0 [80.525597 -48.858700 6.055000] -0.640273 0.000000 0.000000 -0.768148 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701FC057, 90172313, 0x01FC0193, 71.4138, -49.7049, 6.055, -0.840242, 0, 0, -0.542211, False, '2025-08-08 04:22:19'); /* pancakegene */
/* @teleloc 0x01FC0193 [71.413803 -49.704899 6.055000] -0.840242 0.000000 0.000000 -0.542211 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701FC058, 90172313, 0x01FC0187, 61.8222, -49.7032, 6.055, -0.815725, 0, 0, -0.57844, False, '2025-08-08 04:22:20'); /* pancakegene */
/* @teleloc 0x01FC0187 [61.822201 -49.703201 6.055000] -0.815725 0.000000 0.000000 -0.578440 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701FC059, 90172313, 0x01FC017E, 49.7425, -41.6294, 6.055, -0.987044, 0, 0, 0.160451, False, '2025-08-08 04:22:26'); /* pancakegene */
/* @teleloc 0x01FC017E [49.742500 -41.629398 6.055000] -0.987044 0.000000 0.000000 0.160451 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701FC05A, 90172313, 0x01FC017E, 46.0664, -37.643, 6.055, -0.923699, 0, 0, -0.38312, False, '2025-08-08 04:22:27'); /* pancakegene */
/* @teleloc 0x01FC017E [46.066399 -37.643002 6.055000] -0.923699 0.000000 0.000000 -0.383120 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701FC05B, 90172313, 0x01FC0173, 40.6825, -31.9421, 6.055, -0.997838, 0, 0, -0.065728, False, '2025-08-08 04:22:28'); /* pancakegene */
/* @teleloc 0x01FC0173 [40.682499 -31.942101 6.055000] -0.997838 0.000000 0.000000 -0.065728 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701FC05C, 90172313, 0x01FC01BD, 117.597, -50.1605, 6.055, 0.902847, 0, 0, 0.429962, False, '2025-08-08 04:26:03'); /* pancakegene */
/* @teleloc 0x01FC01BD [117.597000 -50.160500 6.055000] 0.902847 0.000000 0.000000 0.429962 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701FC05D, 90172313, 0x01FC01BE, 121.032, -45.0536, 6.055, 0.986082, 0, 0, 0.166263, False, '2025-08-08 04:26:05'); /* pancakegene */
/* @teleloc 0x01FC01BE [121.031998 -45.053600 6.055000] 0.986082 0.000000 0.000000 0.166263 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701FC05E, 90172313, 0x01FC01B4, 111.672, -39.8459, 3.22551, 0.772099, 0, 0, 0.635502, False, '2025-08-08 04:26:06'); /* pancakegene */
/* @teleloc 0x01FC01B4 [111.671997 -39.845901 3.225510] 0.772099 0.000000 0.000000 0.635502 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701FC05F, 90172313, 0x01FC0155, 109.274, -31.8793, 0.055, 0.999772, 0, 0, 0.021366, False, '2025-08-08 04:26:08'); /* pancakegene */
/* @teleloc 0x01FC0155 [109.274002 -31.879299 0.055000] 0.999772 0.000000 0.000000 0.021366 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701FC060, 90172313, 0x01FC0150, 104.503, -50.7433, 0.055, -0.254142, 0, 0, -0.967167, False, '2025-08-08 04:27:36'); /* pancakegene */
/* @teleloc 0x01FC0150 [104.502998 -50.743301 0.055000] -0.254142 0.000000 0.000000 -0.967167 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701FC061, 90172313, 0x01FC0151, 99.1619, -59.196, 0.055, -0.369165, 0, 0, -0.929364, False, '2025-08-08 04:27:37'); /* pancakegene */
/* @teleloc 0x01FC0151 [99.161903 -59.195999 0.055000] -0.369165 0.000000 0.000000 -0.929364 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701FC062, 90172313, 0x01FC014A, 91.0106, -65.3038, 0.055, -0.068456, 0, 0, -0.997654, False, '2025-08-08 04:27:38'); /* pancakegene */
/* @teleloc 0x01FC014A [91.010597 -65.303802 0.055000] -0.068456 0.000000 0.000000 -0.997654 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701FC063, 90172313, 0x01FC014B, 88.7487, -76.3066, 0.055, -0.543623, 0, 0, -0.839329, False, '2025-08-08 04:27:40'); /* pancakegene */
/* @teleloc 0x01FC014B [88.748703 -76.306602 0.055000] -0.543623 0.000000 0.000000 -0.839329 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701FC064, 90172313, 0x01FC0146, 82.564, -77.1036, 0.055, 0.985551, 0, 0, 0.169381, False, '2025-08-08 04:27:58'); /* pancakegene */
/* @teleloc 0x01FC0146 [82.564003 -77.103600 0.055000] 0.985551 0.000000 0.000000 0.169381 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701FC065, 90172313, 0x01FC0119, 32.7537, -60.3241, 0.055, -0.712042, 0, 0, -0.702137, False, '2025-08-08 04:35:19'); /* pancakegene */
/* @teleloc 0x01FC0119 [32.753700 -60.324100 0.055000] -0.712042 0.000000 0.000000 -0.702137 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701FC066, 931271771, 0x01FC0114, 18.9, -58.9, 0.055, 0.636078, 0, 0, -0.771625, False, '2025-08-25 07:15:39'); /* pvp trap */
/* @teleloc 0x01FC0114 [18.900000 -58.900002 0.055000] 0.636078 0.000000 0.000000 -0.771625 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701FC067, 931271771, 0x01FC0115, 19.4501, -67.0913, 0.055, 0.017772, 0, 0, -0.999842, False, '2025-08-25 07:15:43'); /* pvp trap */
/* @teleloc 0x01FC0115 [19.450100 -67.091301 0.055000] 0.017772 0.000000 0.000000 -0.999842 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701FC068, 931271771, 0x01FC011A, 27.6277, -69.5237, 0.055, 0.854452, 0, 0, -0.51953, False, '2025-08-25 07:15:45'); /* pvp trap */
/* @teleloc 0x01FC011A [27.627701 -69.523697 0.055000] 0.854452 0.000000 0.000000 -0.519530 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701FC069, 931271771, 0x01FC0119, 32.869, -62.653, 0.055, 0.964063, 0, 0, -0.265673, False, '2025-08-25 07:15:46'); /* pvp trap */
/* @teleloc 0x01FC0119 [32.868999 -62.653000 0.055000] 0.964063 0.000000 0.000000 -0.265673 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701FC06A, 931271771, 0x01FC011F, 37.2036, -59.9071, 0.055, 0.775177, 0, 0, -0.631744, False, '2025-08-25 07:15:46'); /* pvp trap */
/* @teleloc 0x01FC011F [37.203602 -59.907101 0.055000] 0.775177 0.000000 0.000000 -0.631744 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701FC06B, 931271771, 0x01FC0120, 41.7205, -66.7577, 0.055, 0.057645, 0, 0, -0.998337, False, '2025-08-25 07:15:48'); /* pvp trap */
/* @teleloc 0x01FC0120 [41.720501 -66.757698 0.055000] 0.057645 0.000000 0.000000 -0.998337 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701FC06C, 931271771, 0x01FC0120, 36.9832, -73.6414, 0.055, -0.263688, 0, 0, -0.964608, False, '2025-08-25 07:15:49'); /* pvp trap */
/* @teleloc 0x01FC0120 [36.983200 -73.641403 0.055000] -0.263688 0.000000 0.000000 -0.964608 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701FC06D, 931271771, 0x01FC011B, 33.2788, -83.0022, 0.055, -0.60404, 0, 0, -0.796954, False, '2025-08-25 07:15:51'); /* pvp trap */
/* @teleloc 0x01FC011B [33.278801 -83.002197 0.055000] -0.604040 0.000000 0.000000 -0.796954 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701FC06E, 931271771, 0x01FC0119, 26.3302, -58.1148, 0.055, -0.250144, 0, 0, -0.968209, False, '2025-08-25 07:15:55'); /* pvp trap */
/* @teleloc 0x01FC0119 [26.330200 -58.114799 0.055000] -0.250144 0.000000 0.000000 -0.968209 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701FC06F, 931271771, 0x01FC0114, 24.9957, -64.5121, 0.055, -0.102648, 0, 0, -0.994718, False, '2025-08-25 07:15:56'); /* pvp trap */
/* @teleloc 0x01FC0114 [24.995701 -64.512100 0.055000] -0.102648 0.000000 0.000000 -0.994718 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701FC070, 590336, 0x01FC0039, 187.9381, 16.2979, 0.043274, 0.234471, 0, 0, 0.972123, False, '2025-09-02 17:40:42'); /* Hera's Test Vault */
/* @teleloc 0x01FC0039 [187.938095 16.297899 0.043274] 0.234471 0.000000 0.000000 0.972123 */
