DELETE FROM `landblock_instance` WHERE `landblock` = 0xF5D6;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F5D6004, 5000295, 0xF5D60002, 2.15782, 42.8796, 0.055, -0.84344, 0, 0, 0.537223, False, '2020-01-13 01:43:39'); /* Plant */
/* @teleloc 0xF5D60002 [2.157820 42.879601 0.055000] -0.843440 0.000000 0.000000 0.537223 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F5D6005, 5000662, 0xF5D60003, 16.3644, 62.7126, 0.055, -0.884034, 0, 0, 0.467423, False, '2020-01-13 01:43:41'); /* Plant */
/* @teleloc 0xF5D60003 [16.364401 62.712601 0.055000] -0.884034 0.000000 0.000000 0.467423 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F5D6006, 5000294, 0xF5D6000A, 33.5892, 47.5842, 0.055, -0.164933, 0, 0, 0.986305, False, '2020-01-13 01:43:44'); /* Plant */
/* @teleloc 0xF5D6000A [33.589199 47.584202 0.055000] -0.164933 0.000000 0.000000 0.986305 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F5D6007, 5000294, 0xF5D6000A, 38.2847, 33.9374, 0.055, -0.164933, 0, 0, 0.986305, False, '2020-01-13 01:43:44'); /* Plant */
/* @teleloc 0xF5D6000A [38.284698 33.937401 0.055000] -0.164933 0.000000 0.000000 0.986305 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F5D6008, 5000294, 0xF5D6000A, 38.2847, 33.9374, 0.055, -0.164933, 0, 0, 0.986305, False, '2020-01-13 01:43:45'); /* Plant */
/* @teleloc 0xF5D6000A [38.284698 33.937401 0.055000] -0.164933 0.000000 0.000000 0.986305 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F5D6009, 5000294, 0xF5D60012, 48.0684, 30.4383, 0.055, -0.87927, 0, 0, 0.476324, False, '2020-01-13 01:43:45'); /* Plant */
/* @teleloc 0xF5D60012 [48.068401 30.438299 0.055000] -0.879270 0.000000 0.000000 0.476324 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F5D600A, 5000294, 0xF5D6000A, 43.0236, 35.3117, 0.055, -0.274765, 0, 0, -0.961511, False, '2020-01-13 01:43:47'); /* Plant */
/* @teleloc 0xF5D6000A [43.023602 35.311699 0.055000] -0.274765 0.000000 0.000000 -0.961511 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F5D600B, 5000296, 0xF5D60012, 66.6148, 44.4482, 0.055, 0.823093, 0, 0, -0.567906, False, '2020-01-13 01:43:50'); /* Plant */
/* @teleloc 0xF5D60012 [66.614799 44.448200 0.055000] 0.823093 0.000000 0.000000 -0.567906 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F5D600C, 5000661, 0xF5D6002C, 138.561, 82.8494, 0.055, 0.957962, 0, 0, -0.286896, False, '2020-01-13 01:43:55'); /* Plant */
/* @teleloc 0xF5D6002C [138.561005 82.849403 0.055000] 0.957962 0.000000 0.000000 -0.286896 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F5D600D, 5000661, 0xF5D60034, 153.075, 92.5934, -0.045, -0.591601, 0, 0, -0.806231, False, '2020-01-13 01:43:58'); /* Plant */
/* @teleloc 0xF5D60034 [153.074997 92.593399 -0.045000] -0.591601 0.000000 0.000000 -0.806231 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F5D600E, 5000295, 0xF5D6003E, 182.241, 126.065, 0.055, -0.818823, 0, 0, 0.574047, False, '2020-01-13 01:44:02'); /* Plant */
/* @teleloc 0xF5D6003E [182.240997 126.065002 0.055000] -0.818823 0.000000 0.000000 0.574047 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F5D600F, 5000662, 0xF5D6003F, 191.786, 160.8, 0.055, -0.974453, 0, 0, -0.224594, False, '2020-01-13 01:44:05'); /* Plant */
/* @teleloc 0xF5D6003F [191.785995 160.800003 0.055000] -0.974453 0.000000 0.000000 -0.224594 */
