DELETE FROM `landblock_instance` WHERE `landblock` = 0x104F;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7104F000, 1910466, 0x104F0021, 104.617, 0.159332, -0.045, 0.973956, 0, 0, 0.226738, False, '2025-07-16 15:07:56'); /* VRtree1 */
/* @teleloc 0x104F0021 [104.616997 0.159332 -0.045000] 0.973956 0.000000 0.000000 0.226738 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7104F001, 1910466, 0x104F0021, 101.672, 6.14051, -0.045, 0.973956, 0, 0, 0.226738, False, '2025-07-16 15:07:56'); /* VRtree1 */
/* @teleloc 0x104F0021 [101.671997 6.140510 -0.045000] 0.973956 0.000000 0.000000 0.226738 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7104F002, 1910466, 0x104F0021, 101.135, 7.06084, -0.045, 0.952475, 0, 0, 0.304617, False, '2025-07-16 15:07:57'); /* VRtree1 */
/* @teleloc 0x104F0021 [101.135002 7.060840 -0.045000] 0.952475 0.000000 0.000000 0.304617 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7104F003, 1910466, 0x104F0019, 95.8612, 14.4352, -0.395, 0.939393, 0, 0, 0.342841, False, '2025-07-16 15:07:57'); /* VRtree1 */
/* @teleloc 0x104F0019 [95.861198 14.435200 -0.395000] 0.939393 0.000000 0.000000 0.342841 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7104F004, 1910466, 0x104F0019, 95.8612, 14.4352, -0.395, 0.939393, 0, 0, 0.342841, False, '2025-07-16 15:07:58'); /* VRtree1 */
/* @teleloc 0x104F0019 [95.861198 14.435200 -0.395000] 0.939393 0.000000 0.000000 0.342841 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7104F005, 1910466, 0x104F001A, 87.5868, 24.2612, -0.395, 0.939393, 0, 0, 0.342841, False, '2025-07-16 15:07:58'); /* VRtree1 */
/* @teleloc 0x104F001A [87.586800 24.261200 -0.395000] 0.939393 0.000000 0.000000 0.342841 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7104F006, 1910466, 0x104F001A, 80.2958, 32.9194, -0.045, 0.939393, 0, 0, 0.342841, False, '2025-07-16 15:07:59'); /* VRtree1 */
/* @teleloc 0x104F001A [80.295799 32.919399 -0.045000] 0.939393 0.000000 0.000000 0.342841 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7104F007, 1910466, 0x104F001A, 74.5819, 36.5173, -0.395, 0.856751, 0, 0, 0.51573, False, '2025-07-16 15:07:59'); /* VRtree1 */
/* @teleloc 0x104F001A [74.581902 36.517300 -0.395000] 0.856751 0.000000 0.000000 0.515730 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7104F008, 1910466, 0x104F0012, 71.6818, 37.4873, -0.395, 0.794283, 0, 0, 0.607549, False, '2025-07-16 15:08:00'); /* VRtree1 */
/* @teleloc 0x104F0012 [71.681801 37.487301 -0.395000] 0.794283 0.000000 0.000000 0.607549 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7104F009, 1910466, 0x104F0012, 60.2306, 40.5348, -0.395, 0.749376, 0, 0, 0.662145, False, '2025-07-16 15:08:00'); /* VRtree1 */
/* @teleloc 0x104F0012 [60.230598 40.534801 -0.395000] 0.749376 0.000000 0.000000 0.662145 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7104F00A, 1910466, 0x104F0012, 53.4762, 41.0498, -0.395, 0.633062, 0, 0, 0.774101, False, '2025-07-16 15:08:01'); /* VRtree1 */
/* @teleloc 0x104F0012 [53.476200 41.049801 -0.395000] 0.633062 0.000000 0.000000 0.774101 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7104F00B, 1910466, 0x104F000A, 33.8298, 37.0714, -0.395, 0.633062, 0, 0, 0.774101, False, '2025-07-16 15:08:02'); /* VRtree1 */
/* @teleloc 0x104F000A [33.829800 37.071400 -0.395000] 0.633062 0.000000 0.000000 0.774101 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7104F00C, 1910466, 0x104F0002, 20.2687, 32.1247, -0.045, 0.464864, 0, 0, 0.885382, False, '2025-07-16 15:08:03'); /* VRtree1 */
/* @teleloc 0x104F0002 [20.268700 32.124699 -0.045000] 0.464864 0.000000 0.000000 0.885382 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7104F00D, 1910466, 0x104F0001, 9.7391, 23.994, -0.395, 0.401152, 0, 0, 0.916012, False, '2025-07-16 15:08:04'); /* VRtree1 */
/* @teleloc 0x104F0001 [9.739100 23.993999 -0.395000] 0.401152 0.000000 0.000000 0.916012 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7104F00E, 5000216, 0x104F0001, 0.014511, 11.6496, -0.045, 0.950741, 0, 0, 0.309985, False, '2025-07-16 15:09:55'); /* Gate */
/* @teleloc 0x104F0001 [0.014511 11.649600 -0.045000] 0.950741 0.000000 0.000000 0.309985 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7104F00F, 5000216, 0x104F0001, 0.014511, 11.6496, -0.045, 0.950741, 0, 0, 0.309985, False, '2025-07-16 15:09:56'); /* Gate */
/* @teleloc 0x104F0001 [0.014511 11.649600 -0.045000] 0.950741 0.000000 0.000000 0.309985 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7104F010, 5000216, 0x104F0001, 3.10635, 13.9056, -0.395, 0.950741, 0, 0, 0.309985, False, '2025-07-16 15:09:56'); /* Gate */
/* @teleloc 0x104F0001 [3.106350 13.905600 -0.395000] 0.950741 0.000000 0.000000 0.309985 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7104F011, 5000216, 0x104F0001, 3.10635, 13.9056, -0.395, 0.950741, 0, 0, 0.309985, False, '2025-07-16 15:09:57'); /* Gate */
/* @teleloc 0x104F0001 [3.106350 13.905600 -0.395000] 0.950741 0.000000 0.000000 0.309985 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7104F012, 5000216, 0x104F0001, 6.01336, 16.0267, -0.395, 0.950741, 0, 0, 0.309985, False, '2025-07-16 15:09:57'); /* Gate */
/* @teleloc 0x104F0001 [6.013360 16.026699 -0.395000] 0.950741 0.000000 0.000000 0.309985 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7104F013, 5000216, 0x104F0001, 6.01336, 16.0267, -0.395, 0.950741, 0, 0, 0.309985, False, '2025-07-16 15:09:58'); /* Gate */
/* @teleloc 0x104F0001 [6.013360 16.026699 -0.395000] 0.950741 0.000000 0.000000 0.309985 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7104F014, 5000216, 0x104F0001, 8.87192, 18.1125, -0.395, 0.950741, 0, 0, 0.309985, False, '2025-07-16 15:09:58'); /* Gate */
/* @teleloc 0x104F0001 [8.871920 18.112499 -0.395000] 0.950741 0.000000 0.000000 0.309985 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7104F015, 5000216, 0x104F0001, 8.87192, 18.1125, -0.395, 0.950741, 0, 0, 0.309985, False, '2025-07-16 15:09:59'); /* Gate */
/* @teleloc 0x104F0001 [8.871920 18.112499 -0.395000] 0.950741 0.000000 0.000000 0.309985 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7104F016, 5000216, 0x104F0001, 11.8526, 20.2873, -0.395, 0.950741, 0, 0, 0.309985, False, '2025-07-16 15:09:59'); /* Gate */
/* @teleloc 0x104F0001 [11.852600 20.287300 -0.395000] 0.950741 0.000000 0.000000 0.309985 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7104F017, 5000216, 0x104F0001, 11.8526, 20.2873, -0.395, 0.950741, 0, 0, 0.309985, False, '2025-07-16 15:10:00'); /* Gate */
/* @teleloc 0x104F0001 [11.852600 20.287300 -0.395000] 0.950741 0.000000 0.000000 0.309985 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7104F018, 5000216, 0x104F0001, 14.6665, 22.3405, -0.045, 0.950741, 0, 0, 0.309985, False, '2025-07-16 15:10:00'); /* Gate */
/* @teleloc 0x104F0001 [14.666500 22.340500 -0.045000] 0.950741 0.000000 0.000000 0.309985 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7104F019, 5000216, 0x104F0001, 14.6665, 22.3405, -0.045, 0.950741, 0, 0, 0.309985, False, '2025-07-16 15:10:01'); /* Gate */
/* @teleloc 0x104F0001 [14.666500 22.340500 -0.045000] 0.950741 0.000000 0.000000 0.309985 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7104F01A, 5000216, 0x104F0002, 17.0119, 24.0519, -0.045, 0.950741, 0, 0, 0.309985, False, '2025-07-16 15:10:01'); /* Gate */
/* @teleloc 0x104F0002 [17.011900 24.051901 -0.045000] 0.950741 0.000000 0.000000 0.309985 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7104F01B, 5000216, 0x104F0002, 17.0119, 24.0519, -0.045, 0.950741, 0, 0, 0.309985, False, '2025-07-16 15:10:02'); /* Gate */
/* @teleloc 0x104F0002 [17.011900 24.051901 -0.045000] 0.950741 0.000000 0.000000 0.309985 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7104F01C, 5000216, 0x104F0002, 20.0087, 26.2385, -0.045, 0.950741, 0, 0, 0.309985, False, '2025-07-16 15:10:02'); /* Gate */
/* @teleloc 0x104F0002 [20.008699 26.238501 -0.045000] 0.950741 0.000000 0.000000 0.309985 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7104F01D, 5000216, 0x104F0002, 22.8338, 28.2999, -0.045, 0.950741, 0, 0, 0.309985, False, '2025-07-16 15:10:03'); /* Gate */
/* @teleloc 0x104F0002 [22.833799 28.299900 -0.045000] 0.950741 0.000000 0.000000 0.309985 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7104F01E, 5000216, 0x104F000A, 24.0478, 29.1857, -0.045, 0.950741, 0, 0, 0.309985, False, '2025-07-16 15:10:03'); /* Gate */
/* @teleloc 0x104F000A [24.047800 29.185699 -0.045000] 0.950741 0.000000 0.000000 0.309985 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7104F01F, 5000216, 0x104F000A, 24.0478, 29.1857, -0.045, 0.950741, 0, 0, 0.309985, False, '2025-07-16 15:10:04'); /* Gate */
/* @teleloc 0x104F000A [24.047800 29.185699 -0.045000] 0.950741 0.000000 0.000000 0.309985 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7104F020, 5000216, 0x104F000A, 26.7837, 31.182, -0.045, 0.950741, 0, 0, 0.309985, False, '2025-07-16 15:10:04'); /* Gate */
/* @teleloc 0x104F000A [26.783701 31.181999 -0.045000] 0.950741 0.000000 0.000000 0.309985 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7104F021, 5000216, 0x104F000A, 28.8442, 32.6217, -0.045, 0.979531, 0, 0, 0.201293, False, '2025-07-16 15:10:05'); /* Gate */
/* @teleloc 0x104F000A [28.844200 32.621700 -0.045000] 0.979531 0.000000 0.000000 0.201293 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7104F022, 5000216, 0x104F000A, 30.0868, 33.1343, -0.045, 0.995937, 0, 0, 0.090055, False, '2025-07-16 15:10:05'); /* Gate */
/* @teleloc 0x104F000A [30.086800 33.134300 -0.045000] 0.995937 0.000000 0.000000 0.090055 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7104F023, 5000216, 0x104F000A, 30.0868, 33.1343, -0.045, 0.995937, 0, 0, 0.090055, False, '2025-07-16 15:10:06'); /* Gate */
/* @teleloc 0x104F000A [30.086800 33.134300 -0.045000] 0.995937 0.000000 0.000000 0.090055 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7104F024, 5000216, 0x104F000A, 33.7769, 33.8071, -0.045, 0.995937, 0, 0, 0.090055, False, '2025-07-16 15:10:06'); /* Gate */
/* @teleloc 0x104F000A [33.776901 33.807098 -0.045000] 0.995937 0.000000 0.000000 0.090055 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7104F025, 5000216, 0x104F000A, 33.7769, 33.8071, -0.045, 0.995937, 0, 0, 0.090055, False, '2025-07-16 15:10:07'); /* Gate */
/* @teleloc 0x104F000A [33.776901 33.807098 -0.045000] 0.995937 0.000000 0.000000 0.090055 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7104F026, 5000216, 0x104F000A, 37.2173, 34.4344, -0.045, 0.995937, 0, 0, 0.090055, False, '2025-07-16 15:10:07'); /* Gate */
/* @teleloc 0x104F000A [37.217300 34.434399 -0.045000] 0.995937 0.000000 0.000000 0.090055 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7104F027, 5000216, 0x104F000A, 37.2173, 34.4344, -0.045, 0.995937, 0, 0, 0.090055, False, '2025-07-16 15:10:08'); /* Gate */
/* @teleloc 0x104F000A [37.217300 34.434399 -0.045000] 0.995937 0.000000 0.000000 0.090055 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7104F028, 5000216, 0x104F000A, 37.2173, 34.4344, -0.045, 0.995937, 0, 0, 0.090055, False, '2025-07-16 15:10:08'); /* Gate */
/* @teleloc 0x104F000A [37.217300 34.434399 -0.045000] 0.995937 0.000000 0.000000 0.090055 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7104F029, 5000216, 0x104F000A, 40.8015, 35.0879, -0.045, 0.995937, 0, 0, 0.090055, False, '2025-07-16 15:10:09'); /* Gate */
/* @teleloc 0x104F000A [40.801498 35.087898 -0.045000] 0.995937 0.000000 0.000000 0.090055 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7104F02A, 5000216, 0x104F000A, 40.8015, 35.0879, -0.045, 0.995937, 0, 0, 0.090055, False, '2025-07-16 15:10:09'); /* Gate */
/* @teleloc 0x104F000A [40.801498 35.087898 -0.045000] 0.995937 0.000000 0.000000 0.090055 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7104F02B, 5000216, 0x104F000A, 44.3949, 35.7431, -0.045, 0.995937, 0, 0, 0.090055, False, '2025-07-16 15:10:10'); /* Gate */
/* @teleloc 0x104F000A [44.394901 35.743099 -0.045000] 0.995937 0.000000 0.000000 0.090055 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7104F02C, 5000216, 0x104F000A, 44.3949, 35.7431, -0.045, 0.995937, 0, 0, 0.090055, False, '2025-07-16 15:10:10'); /* Gate */
/* @teleloc 0x104F000A [44.394901 35.743099 -0.045000] 0.995937 0.000000 0.000000 0.090055 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7104F02D, 5000216, 0x104F0012, 48.1549, 36.4287, -0.395, 0.995937, 0, 0, 0.090055, False, '2025-07-16 15:10:10'); /* Gate */
/* @teleloc 0x104F0012 [48.154900 36.428699 -0.395000] 0.995937 0.000000 0.000000 0.090055 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7104F02E, 5000216, 0x104F0012, 48.1549, 36.4287, -0.395, 0.995937, 0, 0, 0.090055, False, '2025-07-16 15:10:11'); /* Gate */
/* @teleloc 0x104F0012 [48.154900 36.428699 -0.395000] 0.995937 0.000000 0.000000 0.090055 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7104F02F, 5000216, 0x104F0012, 52.1552, 37.0951, -0.395, 0.999394, 0, 0, -0.034815, False, '2025-07-16 15:10:11'); /* Gate */
/* @teleloc 0x104F0012 [52.155201 37.095100 -0.395000] 0.999394 0.000000 0.000000 -0.034815 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7104F030, 5000216, 0x104F0012, 52.1552, 37.0951, -0.395, 0.999394, 0, 0, -0.034815, False, '2025-07-16 15:10:12'); /* Gate */
/* @teleloc 0x104F0012 [52.155201 37.095100 -0.395000] 0.999394 0.000000 0.000000 -0.034815 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7104F031, 5000216, 0x104F0012, 55.6349, 36.8524, -0.395, 0.999394, 0, 0, -0.034815, False, '2025-07-16 15:10:12'); /* Gate */
/* @teleloc 0x104F0012 [55.634899 36.852402 -0.395000] 0.999394 0.000000 0.000000 -0.034815 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7104F032, 5000216, 0x104F0012, 55.6349, 36.8524, -0.395, 0.999394, 0, 0, -0.034815, False, '2025-07-16 15:10:13'); /* Gate */
/* @teleloc 0x104F0012 [55.634899 36.852402 -0.395000] 0.999394 0.000000 0.000000 -0.034815 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7104F033, 5000216, 0x104F0012, 55.6349, 36.8524, -0.395, 0.999394, 0, 0, -0.034815, False, '2025-07-16 15:10:13'); /* Gate */
/* @teleloc 0x104F0012 [55.634899 36.852402 -0.395000] 0.999394 0.000000 0.000000 -0.034815 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7104F034, 5000216, 0x104F0012, 59.4623, 36.5854, -0.395, 0.999394, 0, 0, -0.034815, False, '2025-07-16 15:10:14'); /* Gate */
/* @teleloc 0x104F0012 [59.462299 36.585400 -0.395000] 0.999394 0.000000 0.000000 -0.034815 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7104F035, 5000216, 0x104F0012, 59.4623, 36.5854, -0.395, 0.999394, 0, 0, -0.034815, False, '2025-07-16 15:10:14'); /* Gate */
/* @teleloc 0x104F0012 [59.462299 36.585400 -0.395000] 0.999394 0.000000 0.000000 -0.034815 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7104F036, 5000216, 0x104F0012, 63.9423, 36.2301, -0.395, 0.989168, 0, 0, -0.14679, False, '2025-07-16 15:10:15'); /* Gate */
/* @teleloc 0x104F0012 [63.942299 36.230099 -0.395000] 0.989168 0.000000 0.000000 -0.146790 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7104F037, 5000216, 0x104F0012, 63.9423, 36.2301, -0.395, 0.989168, 0, 0, -0.14679, False, '2025-07-16 15:10:15'); /* Gate */
/* @teleloc 0x104F0012 [63.942299 36.230099 -0.395000] 0.989168 0.000000 0.000000 -0.146790 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7104F038, 5000216, 0x104F0012, 67.3905, 35.1693, -0.045, 0.975388, 0, 0, -0.220496, False, '2025-07-16 15:10:16'); /* Gate */
/* @teleloc 0x104F0012 [67.390503 35.169300 -0.045000] 0.975388 0.000000 0.000000 -0.220496 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7104F039, 5000216, 0x104F0012, 67.3905, 35.1693, -0.045, 0.975388, 0, 0, -0.220496, False, '2025-07-16 15:10:16'); /* Gate */
/* @teleloc 0x104F0012 [67.390503 35.169300 -0.045000] 0.975388 0.000000 0.000000 -0.220496 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7104F03A, 5000216, 0x104F0012, 70.6132, 33.6338, -0.045, 0.975388, 0, 0, -0.220496, False, '2025-07-16 15:10:17'); /* Gate */
/* @teleloc 0x104F0012 [70.613197 33.633801 -0.045000] 0.975388 0.000000 0.000000 -0.220496 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7104F03B, 5000216, 0x104F001A, 72.0341, 32.9568, -0.045, 0.975388, 0, 0, -0.220496, False, '2025-07-16 15:10:17'); /* Gate */
/* @teleloc 0x104F001A [72.034103 32.956799 -0.045000] 0.975388 0.000000 0.000000 -0.220496 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7104F03C, 5000216, 0x104F001A, 72.0341, 32.9568, -0.045, 0.975388, 0, 0, -0.220496, False, '2025-07-16 15:10:18'); /* Gate */
/* @teleloc 0x104F001A [72.034103 32.956799 -0.045000] 0.975388 0.000000 0.000000 -0.220496 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7104F03D, 5000216, 0x104F001A, 74.6632, 31.7, -0.045, 0.956124, 0, 0, -0.292961, False, '2025-07-16 15:10:18'); /* Gate */
/* @teleloc 0x104F001A [74.663200 31.700001 -0.045000] 0.956124 0.000000 0.000000 -0.292961 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7104F03E, 5000216, 0x104F001A, 74.6632, 31.7, -0.045, 0.956124, 0, 0, -0.292961, False, '2025-07-16 15:10:19'); /* Gate */
/* @teleloc 0x104F001A [74.663200 31.700001 -0.045000] 0.956124 0.000000 0.000000 -0.292961 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7104F03F, 5000216, 0x104F001A, 77.8413, 29.5507, -0.045, 0.956124, 0, 0, -0.292961, False, '2025-07-16 15:10:19'); /* Gate */
/* @teleloc 0x104F001A [77.841301 29.550699 -0.045000] 0.956124 0.000000 0.000000 -0.292961 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7104F040, 5000216, 0x104F001A, 77.8413, 29.5507, -0.045, 0.956124, 0, 0, -0.292961, False, '2025-07-16 15:10:20'); /* Gate */
/* @teleloc 0x104F001A [77.841301 29.550699 -0.045000] 0.956124 0.000000 0.000000 -0.292961 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7104F041, 5000216, 0x104F001A, 80.4374, 27.7691, -0.045, 0.912139, 0, 0, -0.40988, False, '2025-07-16 15:10:20'); /* Gate */
/* @teleloc 0x104F001A [80.437401 27.769100 -0.045000] 0.912139 0.000000 0.000000 -0.409880 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7104F042, 5000216, 0x104F001A, 80.4374, 27.7691, -0.045, 0.912139, 0, 0, -0.40988, False, '2025-07-16 15:10:21'); /* Gate */
/* @teleloc 0x104F001A [80.437401 27.769100 -0.045000] 0.912139 0.000000 0.000000 -0.409880 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7104F043, 5000216, 0x104F001A, 82.9298, 24.9624, -0.045, 0.912139, 0, 0, -0.40988, False, '2025-07-16 15:10:21'); /* Gate */
/* @teleloc 0x104F001A [82.929802 24.962400 -0.045000] 0.912139 0.000000 0.000000 -0.409880 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7104F044, 5000216, 0x104F0019, 83.8233, 23.9562, -0.045, 0.912139, 0, 0, -0.40988, False, '2025-07-16 15:10:22'); /* Gate */
/* @teleloc 0x104F0019 [83.823303 23.956200 -0.045000] 0.912139 0.000000 0.000000 -0.409880 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7104F045, 5000216, 0x104F0019, 83.8233, 23.9562, -0.045, 0.912139, 0, 0, -0.40988, False, '2025-07-16 15:10:22'); /* Gate */
/* @teleloc 0x104F0019 [83.823303 23.956200 -0.045000] 0.912139 0.000000 0.000000 -0.409880 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7104F046, 5000216, 0x104F0019, 86.368, 21.0601, -0.395, 0.872831, 0, 0, -0.488022, False, '2025-07-16 15:10:23'); /* Gate */
/* @teleloc 0x104F0019 [86.367996 21.060101 -0.395000] 0.872831 0.000000 0.000000 -0.488022 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7104F047, 5000216, 0x104F0019, 86.368, 21.0601, -0.395, 0.872831, 0, 0, -0.488022, False, '2025-07-16 15:10:23'); /* Gate */
/* @teleloc 0x104F0019 [86.367996 21.060101 -0.395000] 0.872831 0.000000 0.000000 -0.488022 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7104F048, 5000216, 0x104F0019, 88.2686, 17.9682, -0.395, 0.872831, 0, 0, -0.488022, False, '2025-07-16 15:10:24'); /* Gate */
/* @teleloc 0x104F0019 [88.268600 17.968201 -0.395000] 0.872831 0.000000 0.000000 -0.488022 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7104F049, 5000216, 0x104F0019, 88.2686, 17.9682, -0.395, 0.872831, 0, 0, -0.488022, False, '2025-07-16 15:10:24'); /* Gate */
/* @teleloc 0x104F0019 [88.268600 17.968201 -0.395000] 0.872831 0.000000 0.000000 -0.488022 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7104F04A, 5000216, 0x104F0019, 90.064, 15.0473, -0.395, 0.872831, 0, 0, -0.488022, False, '2025-07-16 15:10:25'); /* Gate */
/* @teleloc 0x104F0019 [90.064003 15.047300 -0.395000] 0.872831 0.000000 0.000000 -0.488022 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7104F04B, 5000216, 0x104F0019, 90.064, 15.0473, -0.395, 0.872831, 0, 0, -0.488022, False, '2025-07-16 15:10:25'); /* Gate */
/* @teleloc 0x104F0019 [90.064003 15.047300 -0.395000] 0.872831 0.000000 0.000000 -0.488022 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7104F04C, 5000216, 0x104F0019, 92.0732, 11.7787, -0.045, 0.872831, 0, 0, -0.488022, False, '2025-07-16 15:10:26'); /* Gate */
/* @teleloc 0x104F0019 [92.073196 11.778700 -0.045000] 0.872831 0.000000 0.000000 -0.488022 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7104F04D, 5000216, 0x104F0019, 93.8467, 8.89344, -0.045, 0.872831, 0, 0, -0.488022, False, '2025-07-16 15:10:26'); /* Gate */
/* @teleloc 0x104F0019 [93.846703 8.893440 -0.045000] 0.872831 0.000000 0.000000 -0.488022 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7104F04E, 5000216, 0x104F0019, 93.8467, 8.89344, -0.045, 0.872831, 0, 0, -0.488022, False, '2025-07-16 15:10:27'); /* Gate */
/* @teleloc 0x104F0019 [93.846703 8.893440 -0.045000] 0.872831 0.000000 0.000000 -0.488022 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7104F04F, 5000216, 0x104F0021, 96.061, 5.29121, -0.045, 0.872831, 0, 0, -0.488022, False, '2025-07-16 15:10:28'); /* Gate */
/* @teleloc 0x104F0021 [96.060997 5.291210 -0.045000] 0.872831 0.000000 0.000000 -0.488022 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7104F050, 5000216, 0x104F0021, 96.061, 5.29121, -0.045, 0.872831, 0, 0, -0.488022, False, '2025-07-16 15:10:28'); /* Gate */
/* @teleloc 0x104F0021 [96.060997 5.291210 -0.045000] 0.872831 0.000000 0.000000 -0.488022 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7104F051, 5000216, 0x104F0021, 97.9095, 2.28394, -0.045, 0.872831, 0, 0, -0.488022, False, '2025-07-16 15:10:29'); /* Gate */
/* @teleloc 0x104F0021 [97.909500 2.283940 -0.045000] 0.872831 0.000000 0.000000 -0.488022 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7104F052, 5000216, 0x104F0021, 97.90952, 2.283943, -0.045, 0.872831, 0, 0, -0.488022, False, '2025-07-16 15:10:29'); /* Gate */
/* @teleloc 0x104F0021 [97.909523 2.283943 -0.045000] 0.872831 0.000000 0.000000 -0.488022 */
