DELETE FROM `landblock_instance` WHERE `landblock` = 0xC5D0;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7C5D0000, 24913, 0xC5D00029, 131.578, 19.64054, 111.9917, 0.988771, 0, 0, 0.149438, False, '2025-08-24 07:48:55'); /* Olthoi Brood Hive */
/* @teleloc 0xC5D00029 [131.578003 19.640539 111.991699] 0.988771 0.000000 0.000000 0.149438 */
