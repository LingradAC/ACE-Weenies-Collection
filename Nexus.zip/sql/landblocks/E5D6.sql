DELETE FROM `landblock_instance` WHERE `landblock` = 0xE5D6;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E5D6000, 12382137, 0xE5D60006, 23.39, 136.149, -0.845, -0.922635, 0, 0, -0.385674, False, '2025-07-19 07:07:18'); /* Mutated Tusker Generator */
/* @teleloc 0xE5D60006 [23.389999 136.149002 -0.845000] -0.922635 0.000000 0.000000 -0.385674 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E5D6001, 4200152, 0xE5D60029, 133.904, 4.88246, -0.845, 0.891311, 0, 0, -0.453392, False, '2025-07-19 10:25:25'); /* Gate */
/* @teleloc 0xE5D60029 [133.904007 4.882460 -0.845000] 0.891311 0.000000 0.000000 -0.453392 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E5D6002, 4200152, 0xE5D60029, 124.46, 18.5849, -0.845, 0.907439, 0, 0, -0.420185, False, '2025-07-19 10:25:54'); /* Gate */
/* @teleloc 0xE5D60029 [124.459999 18.584900 -0.845000] 0.907439 0.000000 0.000000 -0.420185 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E5D6003, 4200152, 0xE5D60022, 111.776, 33.1344, -0.845, 0.947482, 0, 0, -0.31981, False, '2025-07-19 10:26:03'); /* Gate */
/* @teleloc 0xE5D60022 [111.776001 33.134399 -0.845000] 0.947482 0.000000 0.000000 -0.319810 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E5D6004, 4200152, 0xE5D60022, 97.8792, 43.772, -0.845, 0.976817, 0, 0, -0.214078, False, '2025-07-19 10:26:08'); /* Gate */
/* @teleloc 0xE5D60022 [97.879204 43.771999 -0.845000] 0.976817 0.000000 0.000000 -0.214078 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E5D6005, 4200152, 0xE5D6001B, 81.0563, 52.4658, -0.845, 0.951159, 0, 0, -0.308703, False, '2025-07-19 10:26:13'); /* Gate */
/* @teleloc 0xE5D6001B [81.056297 52.465801 -0.845000] 0.951159 0.000000 0.000000 -0.308703 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E5D6006, 4200152, 0xE5D60013, 65.1718, 62.9284, -0.845, 0.960421, 0, 0, -0.278552, False, '2025-07-19 10:26:28'); /* Gate */
/* @teleloc 0xE5D60013 [65.171799 62.928398 -0.845000] 0.960421 0.000000 0.000000 -0.278552 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E5D6007, 4200152, 0xE5D60014, 50.4843, 76.9206, -0.845, 0.900539, 0, 0, -0.434776, False, '2025-07-19 10:26:43'); /* Gate */
/* @teleloc 0xE5D60014 [50.484299 76.920601 -0.845000] 0.900539 0.000000 0.000000 -0.434776 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E5D6008, 4200152, 0xE5D6000C, 41.4945, 94.3397, -0.845, 0.828198, 0, 0, -0.560436, False, '2025-07-19 10:26:55'); /* Gate */
/* @teleloc 0xE5D6000C [41.494499 94.339699 -0.845000] 0.828198 0.000000 0.000000 -0.560436 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E5D6009, 4200152, 0xE5D6000D, 38.9347, 111.586, -0.845, 0.665748, 0, 0, -0.746177, False, '2025-07-19 10:27:04'); /* Gate */
/* @teleloc 0xE5D6000D [38.934700 111.585999 -0.845000] 0.665748 0.000000 0.000000 -0.746177 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E5D600A, 4200152, 0xE5D6000E, 42.0553, 133.562, -0.845, 0.74076, 0, 0, -0.67177, False, '2025-07-19 10:27:12'); /* Gate */
/* @teleloc 0xE5D6000E [42.055302 133.561996 -0.845000] 0.740760 0.000000 0.000000 -0.671770 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E5D600B, 4200152, 0xE5D6000F, 38.1879, 151.992, -0.845, 0.842792, 0, 0, -0.53824, False, '2025-07-19 10:27:18'); /* Gate */
/* @teleloc 0xE5D6000F [38.187901 151.992004 -0.845000] 0.842792 0.000000 0.000000 -0.538240 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E5D600C, 4200152, 0xE5D6000F, 30.0549, 166.485, -0.845, -0.315923, 0, 0, -0.948785, False, '2025-07-19 10:27:23'); /* Gate */
/* @teleloc 0xE5D6000F [30.054899 166.485001 -0.845000] -0.315923 0.000000 0.000000 -0.948785 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E5D600D, 4200152, 0xE5D60008, 14.54274, 176.127, -0.845, -0.265322, 0, 0, -0.96416, False, '2025-07-19 10:27:31'); /* Gate */
/* @teleloc 0xE5D60008 [14.542740 176.126999 -0.845000] -0.265322 0.000000 0.000000 -0.964160 */
