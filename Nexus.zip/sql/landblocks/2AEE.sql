DELETE FROM `landblock_instance` WHERE `landblock` = 0x2AEE;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x72AEE000,  8377, 0x2AEE0100, 139.3, 91.5, 100.805, 1, 0, 0, 0, False, '2021-11-01 00:00:00'); /* Beer Keg */
/* @teleloc 0x2AEE0100 [139.300003 91.500000 100.805000] 1.000000 0.000000 0.000000 0.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x72AEE004, 32801, 0x2AEE003E, 170.289, 121.743, 66.005, 0.891154, 0, 0, -0.453701, False, '2021-11-01 00:00:00'); /* Iian di Alduressa */
/* @teleloc 0x2AEE003E [170.289001 121.742996 66.004997] 0.891154 0.000000 0.000000 -0.453701 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x72AEE6A5,  1154, 0x2AEE003D, 168.601, 97.6729, 64.1394, 0.152115, 0, 0, 0.988363, False, '2021-11-01 00:00:00'); /* Linkable Monster Generator */
/* @teleloc 0x2AEE003D [168.600998 97.672897 64.139397] 0.152115 0.000000 0.000000 0.988363 */

INSERT INTO `landblock_instance_link` (`parent_GUID`, `child_GUID`, `last_Modified`)
VALUES (0x72AEE6A5, 0x72AEE6A6, '2021-11-01 00:00:00') /* Exploration Marker (39838) */;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x72AEE6A6, 39838, 0x2AEE003D, 168.601, 97.6729, 64.1394, 0.152115, 0, 0, 0.988363,  True, '2021-11-01 00:00:00'); /* Exploration Marker */
/* @teleloc 0x2AEE003D [168.600998 97.672897 64.139397] 0.152115 0.000000 0.000000 0.988363 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x72AEE6A7, 666666666, 0x2AEE002D, 130.089, 109.949, 99.937, -0.999743, 0, 0, 0.022674, False, '2025-07-21 10:26:39'); /* Vault of the Nexus */
/* @teleloc 0x2AEE002D [130.089005 109.948997 99.936996] -0.999743 0.000000 0.000000 0.022674 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x72AEE6A9, 128192777, 0x2AEE002D, 132.904, 108.564, 100.055, 0.99993, 0, 0, 0.0118, False, '2025-07-21 10:32:24'); /* Treasure Pile */
/* @teleloc 0x2AEE002D [132.904007 108.564003 100.055000] 0.999930 0.000000 0.000000 0.011800 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x72AEE6AA, 128192777, 0x2AEE002D, 126.884, 108.562, 100.055, 0.999586, 0, 0, 0.028764, False, '2025-07-21 10:32:28'); /* Treasure Pile */
/* @teleloc 0x2AEE002D [126.884003 108.561996 100.055000] 0.999586 0.000000 0.000000 0.028764 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x72AEE6AB, 128192777, 0x2AEE002D, 127.045, 111.38, 100.055, 0.736538, 0, 0, -0.676396, False, '2025-07-21 10:32:37'); /* Treasure Pile */
/* @teleloc 0x2AEE002D [127.044998 111.379997 100.055000] 0.736538 0.000000 0.000000 -0.676396 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x72AEE6AC, 128192777, 0x2AEE002D, 128.472, 111.502, 100.055, 0.736538, 0, 0, -0.676396, False, '2025-07-21 10:32:38'); /* Treasure Pile */
/* @teleloc 0x2AEE002D [128.472000 111.501999 100.055000] 0.736538 0.000000 0.000000 -0.676396 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x72AEE6AD, 128192777, 0x2AEE002D, 133.127, 111.428, 100.055, -0.649672, 0, 0, -0.760214, False, '2025-07-21 10:33:00'); /* Treasure Pile */
/* @teleloc 0x2AEE002D [133.126999 111.428001 100.055000] -0.649672 0.000000 0.000000 -0.760214 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x72AEE6AE, 128192777, 0x2AEE002D, 131.523, 112.419, 100.055, -0.12891, 0, 0, -0.991656, False, '2025-07-21 10:33:12'); /* Treasure Pile */
/* @teleloc 0x2AEE002D [131.522995 112.418999 100.055000] -0.128910 0.000000 0.000000 -0.991656 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x72AEE6B1, 86659156, 0x2AEE002D, 126.318, 110.211, 104.305, 0.705329, 0, 0, -0.70888, False, '2025-07-21 10:39:35'); /* BLACK PILLAR WITH RED LIGHTNING */
/* @teleloc 0x2AEE002D [126.318001 110.210999 104.305000] 0.705329 0.000000 0.000000 -0.708880 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x72AEE6B2, 86659156, 0x2AEE002D, 133.115, 110.207, 104.305, -0.691036, 0, 0, -0.722821, False, '2025-07-21 10:40:12'); /* BLACK PILLAR WITH RED LIGHTNING */
/* @teleloc 0x2AEE002D [133.115005 110.207001 104.305000] -0.691036 0.000000 0.000000 -0.722821 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x72AEE6B3, 86659149, 0x2AEE002D, 129.895, 111.899, 100.055, -0.999989, 0, 0, 0.004625, False, '2025-07-21 10:41:52'); /* COOLASSLIGHT2 */
/* @teleloc 0x2AEE002D [129.895004 111.899002 100.055000] -0.999989 0.000000 0.000000 0.004625 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x72AEE6B4, 911914, 0x2AEE0025, 100.894, 109.565, 100.005, 0.666397, 0, 0, -0.745597, False, '2025-07-21 12:36:28'); /* Uber Stakes Gamemaster */
/* @teleloc 0x2AEE0025 [100.893997 109.565002 100.004997] 0.666397 0.000000 0.000000 -0.745597 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x72AEE6B5, 911916, 0x2AEE0025, 100.93, 108.257, 100.005, 0.666397, 0, 0, -0.745597, False, '2025-07-21 12:36:34'); /* 60MMD Gambler */
/* @teleloc 0x2AEE0025 [100.930000 108.257004 100.004997] 0.666397 0.000000 0.000000 -0.745597 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x72AEE6B6, 911917, 0x2AEE0025, 100.881, 107.032, 100.005, 0.666397, 0, 0, -0.745597, False, '2025-07-21 12:36:46'); /* 100MMD Gambler */
/* @teleloc 0x2AEE0025 [100.880997 107.031998 100.004997] 0.666397 0.000000 0.000000 -0.745597 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x72AEE6B7, 911911, 0x2AEE0025, 100.894, 103.468, 100.005, 0.676373, 0, 0, -0.736559, False, '2025-07-21 12:38:00'); /* 5 Uber-Gem Gambler */
/* @teleloc 0x2AEE0025 [100.893997 103.468002 100.004997] 0.676373 0.000000 0.000000 -0.736559 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x72AEE6B8, 911912, 0x2AEE0025, 100.91, 102.015, 100.005, 0.676373, 0, 0, -0.736559, False, '2025-07-21 12:38:08'); /* 10 Uber-Gem Gambler */
/* @teleloc 0x2AEE0025 [100.910004 102.014999 100.004997] 0.676373 0.000000 0.000000 -0.736559 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x72AEE6B9, 911913, 0x2AEE0025, 100.882, 100.822, 100.005, 0.676373, 0, 0, -0.736559, False, '2025-07-21 12:38:11'); /* 20 Uber-Gem Gambler */
/* @teleloc 0x2AEE0025 [100.882004 100.821999 100.004997] 0.676373 0.000000 0.000000 -0.736559 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x72AEE6BA, 34282, 0x2AEE0025, 101.314, 105.399, 100.001, 0.70333, 0, 0, 0.710864, False, '2025-07-21 12:40:29'); /* Wheel of Knowledge */
/* @teleloc 0x2AEE0025 [101.314003 105.399002 100.000999] 0.703330 0.000000 0.000000 0.710864 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x72AEE6BB, 34282, 0x2AEE0025, 101.357, 99.6028, 100.001, 0.708773, 0, 0, 0.705436, False, '2025-07-21 12:40:35'); /* Wheel of Knowledge */
/* @teleloc 0x2AEE0025 [101.357002 99.602798 100.000999] 0.708773 0.000000 0.000000 0.705436 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x72AEE6BC, 40463, 0x2AEE0101, 136.524, 82.1694, 99.995, 0.999992, 0, 0, 0.004131, False, '2025-07-21 12:42:04'); /* Rare Exchanger */
/* @teleloc 0x2AEE0101 [136.524002 82.169403 99.995003] 0.999992 0.000000 0.000000 0.004131 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x72AEE6BD,  9496, 0x2AEE0024, 117.753, 76.8924, 100.005, 0.999632, 0, 0, -0.027146, False, '2025-07-21 12:42:59'); /* Gharu'ndim High-Stakes Gamesmaster */
/* @teleloc 0x2AEE0024 [117.752998 76.892403 100.004997] 0.999632 0.000000 0.000000 -0.027146 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x72AEE6BE,  9502, 0x2AEE0024, 116.243, 76.8815, 100.005, 0.999993, 0, 0, 0.003751, False, '2025-07-21 12:43:36'); /* Gharu'ndim Mid-Stakes Gamesmaster */
/* @teleloc 0x2AEE0024 [116.242996 76.881500 100.004997] 0.999993 0.000000 0.000000 0.003751 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x72AEE6BF,  9499, 0x2AEE0024, 114.692, 76.9003, 100.005, 0.999431, 0, 0, -0.033743, False, '2025-07-21 12:43:51'); /* Gharu'ndim Low-Stakes Gamesmaster */
/* @teleloc 0x2AEE0024 [114.692001 76.900299 100.004997] 0.999431 0.000000 0.000000 -0.033743 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x72AEE6C0,  9460, 0x2AEE0024, 101.578, 81.8884, 100, 0.699871, 0, 0, 0.714269, False, '2025-07-21 12:44:27'); /* Monty's Golden Chest */
/* @teleloc 0x2AEE0024 [101.578003 81.888397 100.000000] 0.699871 0.000000 0.000000 0.714269 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x72AEE6C1,  9461, 0x2AEE0024, 101.573, 85.819, 100, 0.699871, 0, 0, 0.714269, False, '2025-07-21 12:44:33'); /* Arshid's Golden Chest */
/* @teleloc 0x2AEE0024 [101.572998 85.819000 100.000000] 0.699871 0.000000 0.000000 0.714269 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x72AEE6C2,  9462, 0x2AEE0024, 101.573, 89.8135, 100, 0.699871, 0, 0, 0.714269, False, '2025-07-21 12:44:37'); /* Gan-Zo's Golden Chest */
/* @teleloc 0x2AEE0024 [101.572998 89.813499 100.000000] 0.699871 0.000000 0.000000 0.714269 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x72AEE6C3, 52032, 0x2AEE0024, 101.584, 93.7744, 100, 0.686707, 0, 0, 0.726934, False, '2025-07-21 12:45:02'); /* Exquisite Casino Chest */
/* @teleloc 0x2AEE0024 [101.584000 93.774399 100.000000] 0.686707 0.000000 0.000000 0.726934 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x72AEE6C4, 490211, 0x2AEE0100, 133.497, 91.7341, 99.995, -0.032446, 0, 0, 0.999474, False, '2025-07-21 12:52:29'); /* Foolproof Exchanger */
/* @teleloc 0x2AEE0100 [133.496994 91.734100 99.995003] -0.032446 0.000000 0.000000 0.999474 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x72AEE6C5, 490198, 0x2AEE0101, 139.498, 86.5942, 99.995, 0.701585, 0, 0, 0.712586, False, '2025-07-21 12:52:50'); /* Shiyama the Currency Exchanger */
/* @teleloc 0x2AEE0101 [139.498001 86.594200 99.995003] 0.701585 0.000000 0.000000 0.712586 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x72AEE6C6,  3917, 0x2AEE0100, 137.798, 91.0864, 99.995, 0.011075, 0, 0, -0.999939, False, '2025-07-21 12:53:12'); /* Collector */
/* @teleloc 0x2AEE0100 [137.798004 91.086403 99.995003] 0.011075 0.000000 0.000000 -0.999939 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x72AEE6C7, 30443, 0x2AEE0100, 139.495, 89.6196, 99.995, -0.728964, 0, 0, -0.684552, False, '2025-07-21 12:53:22'); /* Ivory Crafter */
/* @teleloc 0x2AEE0100 [139.494995 89.619598 99.995003] -0.728964 0.000000 0.000000 -0.684552 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x72AEE6C8, 38460, 0x2AEE0024, 104.505, 76.8852, 100.005, 0.916065, 0, 0, -0.40103, False, '2025-07-21 12:54:55'); /* Arcanum Broker */
/* @teleloc 0x2AEE0024 [104.504997 76.885201 100.004997] 0.916065 0.000000 0.000000 -0.401030 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x72AEE6C9, 49642, 0x2AEE0025, 114.504, 98.0835, 100.005, 0.179687, 0, 0, -0.983724, False, '2025-07-21 12:56:06'); /* Town Crier */
/* @teleloc 0x2AEE0025 [114.503998 98.083504 100.004997] 0.179687 0.000000 0.000000 -0.983724 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x72AEE6CA, 38942, 0x2AEE0024, 107.3632, 77.68901, 100, 0.020228, 0, 0, -0.999795, False, '2025-07-22 12:04:42'); /* Grand Casino Chest */
/* @teleloc 0x2AEE0024 [107.363197 77.689011 100.000000] 0.020228 0.000000 0.000000 -0.999795 */
