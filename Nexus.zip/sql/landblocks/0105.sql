DELETE FROM `landblock_instance` WHERE `landblock` = 0x0105;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70105004,  1295, 0x01050104, 52, -50, -29.995, -0.707107, 0, 0, -0.707107, False, '2005-02-09 10:00:00'); /* Door */
/* @teleloc 0x01050104 [52.000000 -50.000000 -29.995001] -0.707107 0.000000 0.000000 -0.707107 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70105005,  1295, 0x01050104, 48, -50, -29.995, 0.707107, 0, 0, -0.707107, False, '2005-02-09 10:00:00'); /* Door */
/* @teleloc 0x01050104 [48.000000 -50.000000 -29.995001] 0.707107 0.000000 0.000000 -0.707107 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70105008,  3969, 0x01050109, 50, -80, -29.995, 1, 0, 0, 0, False, '2005-02-09 10:00:00'); /* Chest */
/* @teleloc 0x01050109 [50.000000 -80.000000 -29.995001] 1.000000 0.000000 0.000000 0.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70105069,  3985, 0x010502D6, 140, -184.5, -5.995, 0, 0, 0, -1, False, '2005-02-09 10:00:00'); /* Chest */
/* @teleloc 0x010502D6 [140.000000 -184.500000 -5.995000] 0.000000 0.000000 0.000000 -1.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70105077,  7243, 0x01050341, 80, -210, 0.005, 0.696707, 0, 0, -0.717356, False, '2005-02-09 10:00:00'); /* Surface Portal */
/* @teleloc 0x01050341 [80.000000 -210.000000 0.005000] 0.696707 0.000000 0.000000 -0.717356 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70105078, 12382137, 0x01050383, 115.156, -170.615, 0.055, 0.999907, 0, 0, 0.013632, False, '2025-08-20 12:47:02'); /* Mutated Tusker Generator */
/* @teleloc 0x01050383 [115.155998 -170.615005 0.055000] 0.999907 0.000000 0.000000 0.013632 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70105079, 12382137, 0x01050303, 61.6221, -100.009, 0.055, -0.83394, 0, 0, -0.551855, False, '2025-08-20 12:47:21'); /* Mutated Tusker Generator */
/* @teleloc 0x01050303 [61.622101 -100.009003 0.055000] -0.833940 0.000000 0.000000 -0.551855 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7010507A, 12382137, 0x0105024C, 55.9153, -141.354, -11.945, 0.145461, 0, 0, -0.989364, False, '2025-08-20 12:47:33'); /* Mutated Tusker Generator */
/* @teleloc 0x0105024C [55.915298 -141.354004 -11.945000] 0.145461 0.000000 0.000000 -0.989364 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7010507B, 12382137, 0x010501A5, 11.5664, -193.125, -17.945, 0.729838, 0, 0, -0.68362, False, '2025-08-20 12:47:45'); /* Mutated Tusker Generator */
/* @teleloc 0x010501A5 [11.566400 -193.125000 -17.945000] 0.729838 0.000000 0.000000 -0.683620 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7010507C, 12382137, 0x0105017A, 60.0678, -242.809, -23.945, 0.999703, 0, 0, -0.024375, False, '2025-08-20 12:47:56'); /* Mutated Tusker Generator */
/* @teleloc 0x0105017A [60.067799 -242.809006 -23.945000] 0.999703 0.000000 0.000000 -0.024375 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7010507D, 12382137, 0x0105014D, 51.2877, -193.134, -23.945, -0.781533, 0, 0, 0.623864, False, '2025-08-20 12:48:25'); /* Mutated Tusker Generator */
/* @teleloc 0x0105014D [51.287701 -193.134003 -23.945000] -0.781533 0.000000 0.000000 0.623864 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7010507E, 12382137, 0x0105010B, 49.558, -104.787, -29.945, -0.999992, 0, 0, 0.003964, False, '2025-08-20 12:48:36'); /* Mutated Tusker Generator */
/* @teleloc 0x0105010B [49.557999 -104.787003 -29.945000] -0.999992 0.000000 0.000000 0.003964 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7010507F, 12382137, 0x01050210, 90.3871, -242.609, -17.945, -0.99931, 0, 0, 0.037132, False, '2025-08-20 12:49:18'); /* Mutated Tusker Generator */
/* @teleloc 0x01050210 [90.387100 -242.608994 -17.945000] -0.999310 0.000000 0.000000 0.037132 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70105080, 12382137, 0x01050200, 91.3451, -193.215, -17.945, -0.936078, 0, 0, -0.351793, False, '2025-08-20 12:49:23'); /* Mutated Tusker Generator */
/* @teleloc 0x01050200 [91.345100 -193.214996 -17.945000] -0.936078 0.000000 0.000000 -0.351793 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70105081, 12382137, 0x01050365, 95.5123, -118.861, 0.055, 0.699696, 0, 0, 0.714441, False, '2025-08-20 12:51:12'); /* Mutated Tusker Generator */
/* @teleloc 0x01050365 [95.512299 -118.861000 0.055000] 0.699696 0.000000 0.000000 0.714441 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70105082, 12382137, 0x010502AF, 100.667, -129.107, -5.945, 0.017149, 0, 0, -0.999853, False, '2025-08-20 12:51:27'); /* Mutated Tusker Generator */
/* @teleloc 0x010502AF [100.667000 -129.106995 -5.945000] 0.017149 0.000000 0.000000 -0.999853 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70105083, 12382137, 0x010502D5, 140.022, -172.545, -5.945, -0.988778, 0, 0, -0.149395, False, '2025-08-20 12:51:35'); /* Mutated Tusker Generator */
/* @teleloc 0x010502D5 [140.022003 -172.544998 -5.945000] -0.988778 0.000000 0.000000 -0.149395 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70105084, 12382137, 0x010501B5, 11.3344, -241.48, -17.945, 0.046582, 0, 0, 0.998915, False, '2025-08-20 12:52:37'); /* Mutated Tusker Generator */
/* @teleloc 0x010501B5 [11.334400 -241.479996 -17.945000] 0.046582 0.000000 0.000000 0.998915 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70105085, 12382137, 0x01050192, 1.33102, -184.132, -17.945, -0.007701, 0, 0, 0.99997, False, '2025-08-20 12:58:30'); /* Mutated Tusker Generator */
/* @teleloc 0x01050192 [1.331020 -184.132004 -17.945000] -0.007701 0.000000 0.000000 0.999970 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70105086, 12382137, 0x01050262, 29.6861, -82.2003, -5.945, -0.99795, 0, 0, 0.064007, False, '2025-08-20 13:12:24'); /* Mutated Tusker Generator */
/* @teleloc 0x01050262 [29.686100 -82.200302 -5.945000] -0.997950 0.000000 0.000000 0.064007 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70105087, 12382137, 0x0105011F, 40.4177, -93.962, -23.945, -0.000062, 0, 0, 1, False, '2025-08-20 13:13:21'); /* Mutated Tusker Generator */
/* @teleloc 0x0105011F [40.417702 -93.961998 -23.945000] -0.000062 0.000000 0.000000 1.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70105088, 12382137, 0x0105029C, 102.238, -86.5084, -5.945, -0.036104, 0, 0, 0.999348, False, '2025-08-20 13:14:35'); /* Mutated Tusker Generator */
/* @teleloc 0x0105029C [102.237999 -86.508400 -5.945000] -0.036104 0.000000 0.000000 0.999348 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70105089, 23423818, 0x01050375, 100, -210, 0.055, 0.707107, 0, 0, -0.707107, False, '2025-08-20 15:22:13'); /* 200 gtfo trap */
/* @teleloc 0x01050375 [100.000000 -210.000000 0.055000] 0.707107 0.000000 0.000000 -0.707107 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7010508A, 23423818, 0x01050382, 110.103, -207.545, 0.055, 0.917726, 0, 0, -0.397214, False, '2025-08-20 15:22:19'); /* 200 gtfo trap */
/* @teleloc 0x01050382 [110.102997 -207.544998 0.055000] 0.917726 0.000000 0.000000 -0.397214 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7010508B, 23423818, 0x0105037F, 111.893, -184.538, 0.055, 0.999861, 0, 0, -0.016655, False, '2025-08-20 15:22:22'); /* 200 gtfo trap */
/* @teleloc 0x0105037F [111.892998 -184.537994 0.055000] 0.999861 0.000000 0.000000 -0.016655 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7010508C, 23423818, 0x0105037E, 114.217, -165.653, 0.055, 0.984166, 0, 0, -0.177249, False, '2025-08-20 15:22:23'); /* 200 gtfo trap */
/* @teleloc 0x0105037E [114.217003 -165.653000 0.055000] 0.984166 0.000000 0.000000 -0.177249 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7010508D, 23423818, 0x0105037B, 110.163, -152.806, 0.055, 0.999907, 0, 0, 0.013642, False, '2025-08-20 15:22:26'); /* 200 gtfo trap */
/* @teleloc 0x0105037B [110.163002 -152.806000 0.055000] 0.999907 0.000000 0.000000 0.013642 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7010508E, 23423818, 0x01050383, 123.448, -173.09, 0.055, 0.74481, 0, 0, -0.667276, False, '2025-08-20 15:22:29'); /* 200 gtfo trap */
/* @teleloc 0x01050383 [123.447998 -173.089996 0.055000] 0.744810 0.000000 0.000000 -0.667276 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7010508F, 23423818, 0x01050383, 122.843, -167.141, 0.055, 0.994192, 0, 0, -0.107621, False, '2025-08-20 15:22:31'); /* 200 gtfo trap */
/* @teleloc 0x01050383 [122.843002 -167.141006 0.055000] 0.994192 0.000000 0.000000 -0.107621 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70105090, 23423818, 0x01050377, 107.829, -140.486, 0.055, 0.951792, 0, 0, 0.306743, False, '2025-08-20 15:22:34'); /* 200 gtfo trap */
/* @teleloc 0x01050377 [107.829002 -140.485992 0.055000] 0.951792 0.000000 0.000000 0.306743 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70105091, 23423818, 0x01050353, 93.6178, -138.843, 0.055, 0.725937, 0, 0, 0.687761, False, '2025-08-20 15:22:36'); /* 200 gtfo trap */
/* @teleloc 0x01050353 [93.617798 -138.843002 0.055000] 0.725937 0.000000 0.000000 0.687761 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70105092, 23423818, 0x0105033A, 79.397, -136.938, 0.055, 0.87469, 0, 0, 0.484684, False, '2025-08-20 15:22:37'); /* 200 gtfo trap */
/* @teleloc 0x0105033A [79.397003 -136.938004 0.055000] 0.874690 0.000000 0.000000 0.484684 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70105093, 23423818, 0x01050334, 79.7824, -121.048, 0.055, 0.998092, 0, 0, -0.061742, False, '2025-08-20 15:22:39'); /* 200 gtfo trap */
/* @teleloc 0x01050334 [79.782402 -121.047997 0.055000] 0.998092 0.000000 0.000000 -0.061742 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70105094, 23423818, 0x0105032F, 77.9305, -109.675, 0.055, 0.895908, 0, 0, 0.444239, False, '2025-08-20 15:22:40'); /* 200 gtfo trap */
/* @teleloc 0x0105032F [77.930496 -109.675003 0.055000] 0.895908 0.000000 0.000000 0.444239 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70105095, 23423818, 0x01050318, 68.5032, -98.9279, 0.055, 0.979347, 0, 0, 0.202189, False, '2025-08-20 15:22:42'); /* 200 gtfo trap */
/* @teleloc 0x01050318 [68.503197 -98.927902 0.055000] 0.979347 0.000000 0.000000 0.202189 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70105096, 23423818, 0x0105030E, 69.8689, -84.2197, 0.055, 0.999489, 0, 0, 0.031955, False, '2025-08-20 15:22:44'); /* 200 gtfo trap */
/* @teleloc 0x0105030E [69.868896 -84.219704 0.055000] 0.999489 0.000000 0.000000 0.031955 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70105097, 23423818, 0x010502FA, 55.656, -77.782, 0.055, 0.785946, 0, 0, 0.618296, False, '2025-08-20 15:22:46'); /* 200 gtfo trap */
/* @teleloc 0x010502FA [55.655998 -77.781998 0.055000] 0.785946 0.000000 0.000000 0.618296 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70105098, 23423818, 0x010502E2, 50.4541, -64.6256, 0.055, 0.998879, 0, 0, -0.047345, False, '2025-08-20 15:22:48'); /* 200 gtfo trap */
/* @teleloc 0x010502E2 [50.454102 -64.625603 0.055000] 0.998879 0.000000 0.000000 -0.047345 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70105099, 23423818, 0x010502DB, 39.3295, -58.8962, 0.055, 0.707502, 0, 0, 0.706712, False, '2025-08-20 15:22:50'); /* 200 gtfo trap */
/* @teleloc 0x010502DB [39.329498 -58.896198 0.055000] 0.707502 0.000000 0.000000 0.706712 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7010509A, 23423818, 0x010502D8, 27.9765, -59.9932, 0.055, 0.53444, 0, 0, 0.845206, False, '2025-08-20 15:22:51'); /* 200 gtfo trap */
/* @teleloc 0x010502D8 [27.976500 -59.993198 0.055000] 0.534440 0.000000 0.000000 0.845206 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7010509B, 23423818, 0x01050262, 28.4731, -83.2038, -5.945, -0.044307, 0, 0, 0.999018, False, '2025-08-20 15:22:54'); /* 200 gtfo trap */
/* @teleloc 0x01050262 [28.473101 -83.203796 -5.945000] -0.044307 0.000000 0.000000 0.999018 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7010509C, 23423818, 0x01050264, 32.9418, -99.19, -5.945, -0.368587, 0, 0, 0.929593, False, '2025-08-20 15:22:55'); /* 200 gtfo trap */
/* @teleloc 0x01050264 [32.941799 -99.190002 -5.945000] -0.368587 0.000000 0.000000 0.929593 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7010509D, 23423818, 0x0105026D, 47.1324, -101.249, -5.945, -0.461254, 0, 0, 0.887268, False, '2025-08-20 15:22:57'); /* 200 gtfo trap */
/* @teleloc 0x0105026D [47.132401 -101.249001 -5.945000] -0.461254 0.000000 0.000000 0.887268 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7010509E, 23423818, 0x01050241, 49.8957, -115.747, -11.945, 0.105959, 0, 0, 0.994371, False, '2025-08-20 15:22:58'); /* 200 gtfo trap */
/* @teleloc 0x01050241 [49.895699 -115.747002 -11.945000] 0.105959 0.000000 0.000000 0.994371 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7010509F, 23423818, 0x01050242, 49.5993, -133.825, -11.945, -0.014993, 0, 0, 0.999888, False, '2025-08-20 15:23:00'); /* 200 gtfo trap */
/* @teleloc 0x01050242 [49.599300 -133.824997 -11.945000] -0.014993 0.000000 0.000000 0.999888 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701050A0, 23423818, 0x0105023D, 39.9729, -145.078, -11.945, 0.231916, 0, 0, 0.972736, False, '2025-08-20 15:23:01'); /* 200 gtfo trap */
/* @teleloc 0x0105023D [39.972900 -145.078003 -11.945000] 0.231916 0.000000 0.000000 0.972736 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701050A1, 23423818, 0x0105023A, 28.1775, -150.351, -11.945, 0.688223, 0, 0, 0.725499, False, '2025-08-20 15:23:03'); /* 200 gtfo trap */
/* @teleloc 0x0105023A [28.177500 -150.350998 -11.945000] 0.688223 0.000000 0.000000 0.725499 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701050A2, 23423818, 0x010501A3, 8.6211, -149.433, -17.945, 0.650739, 0, 0, 0.759302, False, '2025-08-20 15:23:05'); /* 200 gtfo trap */
/* @teleloc 0x010501A3 [8.621100 -149.432999 -17.945000] 0.650739 0.000000 0.000000 0.759302 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701050A3, 23423818, 0x01050190, -1.75494, -158.76, -17.945, 0.063806, 0, 0, 0.997962, False, '2025-08-20 15:23:07'); /* 200 gtfo trap */
/* @teleloc 0x01050190 [-1.754940 -158.759995 -17.945000] 0.063806 0.000000 0.000000 0.997962 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701050A4, 23423818, 0x01050192, -0.190643, -175.016, -17.945, -0.05727, 0, 0, 0.998359, False, '2025-08-20 15:23:08'); /* 200 gtfo trap */
/* @teleloc 0x01050192 [-0.190643 -175.016006 -17.945000] -0.057270 0.000000 0.000000 0.998359 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701050A5, 23423818, 0x01050193, 0.945557, -188.203, -17.945, -0.016917, 0, 0, 0.999857, False, '2025-08-20 15:23:10'); /* 200 gtfo trap */
/* @teleloc 0x01050193 [0.945557 -188.203003 -17.945000] -0.016917 0.000000 0.000000 0.999857 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701050A6, 23423818, 0x010501A6, 5.31459, -197.669, -17.945, -0.460402, 0, 0, 0.88771, False, '2025-08-20 15:23:11'); /* 200 gtfo trap */
/* @teleloc 0x010501A6 [5.314590 -197.669006 -17.945000] -0.460402 0.000000 0.000000 0.887710 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701050A7, 23423818, 0x010501A7, 9.55377, -212.995, -17.945, 0.051811, 0, 0, 0.998657, False, '2025-08-20 15:23:13'); /* 200 gtfo trap */
/* @teleloc 0x010501A7 [9.553770 -212.994995 -17.945000] 0.051811 0.000000 0.000000 0.998657 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701050A8, 23423818, 0x010501AE, 10.2164, -225.693, -17.945, 0.01145, 0, 0, 0.999934, False, '2025-08-20 15:23:15'); /* 200 gtfo trap */
/* @teleloc 0x010501AE [10.216400 -225.692993 -17.945000] 0.011450 0.000000 0.000000 0.999934 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701050A9, 23423818, 0x010501C1, 21.7021, -198.762, -17.945, 0.931117, 0, 0, -0.36472, False, '2025-08-20 15:23:18'); /* 200 gtfo trap */
/* @teleloc 0x010501C1 [21.702101 -198.761993 -17.945000] 0.931117 0.000000 0.000000 -0.364720 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701050AA, 23423818, 0x010501D5, 27.156, -189.199, -17.945, 0.886968, 0, 0, -0.461832, False, '2025-08-20 15:23:20'); /* 200 gtfo trap */
/* @teleloc 0x010501D5 [27.156000 -189.199005 -17.945000] 0.886968 0.000000 0.000000 -0.461832 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701050AB, 23423818, 0x0105023F, 35.6739, -179.007, -17.4609, 0.71794, 0, 0, -0.696105, False, '2025-08-20 15:23:21'); /* 200 gtfo trap */
/* @teleloc 0x0105023F [35.673901 -179.007004 -17.460899] 0.717940 0.000000 0.000000 -0.696105 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701050AC, 23423818, 0x01050249, 51.9702, -179.613, -11.945, 0.666994, 0, 0, -0.745064, False, '2025-08-20 15:23:23'); /* 200 gtfo trap */
/* @teleloc 0x01050249 [51.970200 -179.613007 -11.945000] 0.666994 0.000000 0.000000 -0.745064 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701050AD, 23423818, 0x010501E8, 68.9153, -180.477, -17.945, 0.731848, 0, 0, -0.681468, False, '2025-08-20 15:23:25'); /* 200 gtfo trap */
/* @teleloc 0x010501E8 [68.915298 -180.477005 -17.945000] 0.731848 0.000000 0.000000 -0.681468 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701050AE, 23423818, 0x010501ED, 75.5905, -192.086, -17.945, 0.595854, 0, 0, -0.803093, False, '2025-08-20 15:23:27'); /* 200 gtfo trap */
/* @teleloc 0x010501ED [75.590500 -192.085999 -17.945000] 0.595854 0.000000 0.000000 -0.803093 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701050AF, 23423818, 0x010501EE, 82.0259, -200.41, -17.945, 0.173038, 0, 0, -0.984915, False, '2025-08-20 15:23:28'); /* 200 gtfo trap */
/* @teleloc 0x010501EE [82.025902 -200.410004 -17.945000] 0.173038 0.000000 0.000000 -0.984915 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701050B0, 23423818, 0x010501EE, 76.463, -204.489, -17.945, -0.04715, 0, 0, -0.998888, False, '2025-08-20 15:23:30'); /* 200 gtfo trap */
/* @teleloc 0x010501EE [76.462997 -204.488998 -17.945000] -0.047150 0.000000 0.000000 -0.998888 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701050B1, 23423818, 0x01050201, 90.4367, -204.479, -17.945, 0.675238, 0, 0, -0.7376, False, '2025-08-20 15:23:32'); /* 200 gtfo trap */
/* @teleloc 0x01050201 [90.436699 -204.479004 -17.945000] 0.675238 0.000000 0.000000 -0.737600 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701050B2, 23423818, 0x01050222, 98.3455, -203.907, -17.945, 0.759431, 0, 0, -0.650588, False, '2025-08-20 15:23:33'); /* 200 gtfo trap */
/* @teleloc 0x01050222 [98.345497 -203.906998 -17.945000] 0.759431 0.000000 0.000000 -0.650588 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701050B3, 23423818, 0x01050222, 104.066, -201.348, -17.945, 0.92469, 0, 0, -0.38072, False, '2025-08-20 15:23:34'); /* 200 gtfo trap */
/* @teleloc 0x01050222 [104.066002 -201.348007 -17.945000] 0.924690 0.000000 0.000000 -0.380720 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701050B4, 23423818, 0x01050221, 104.235, -188.752, -17.945, 0.999837, 0, 0, 0.018071, False, '2025-08-20 15:23:35'); /* 200 gtfo trap */
/* @teleloc 0x01050221 [104.235001 -188.751999 -17.945000] 0.999837 0.000000 0.000000 0.018071 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701050B5, 23423818, 0x01050220, 103.279, -177.308, -17.945, 0.98206, 0, 0, 0.188568, False, '2025-08-20 15:23:37'); /* 200 gtfo trap */
/* @teleloc 0x01050220 [103.278999 -177.307999 -17.945000] 0.982060 0.000000 0.000000 0.188568 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701050B6, 23423818, 0x010501FF, 94.7526, -178.724, -17.945, 0.600845, 0, 0, 0.799366, False, '2025-08-20 15:23:38'); /* 200 gtfo trap */
/* @teleloc 0x010501FF [94.752602 -178.723999 -17.945000] 0.600845 0.000000 0.000000 0.799366 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701050B7, 23423818, 0x010501FF, 87.1594, -179.178, -17.945, 0.721588, 0, 0, 0.692323, False, '2025-08-20 15:23:39'); /* 200 gtfo trap */
/* @teleloc 0x010501FF [87.159401 -179.177994 -17.945000] 0.721588 0.000000 0.000000 0.692323 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701050B8, 23423818, 0x010501ED, 84.202, -189.322, -17.945, 0.183889, 0, 0, 0.982947, False, '2025-08-20 15:23:41'); /* 200 gtfo trap */
/* @teleloc 0x010501ED [84.202003 -189.322006 -17.945000] 0.183889 0.000000 0.000000 0.982947 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701050B9, 23423818, 0x010501EE, 77.4404, -198.86, -17.945, 0.092028, 0, 0, 0.995756, False, '2025-08-20 15:23:42'); /* 200 gtfo trap */
/* @teleloc 0x010501EE [77.440399 -198.860001 -17.945000] 0.092028 0.000000 0.000000 0.995756 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701050BA, 23423818, 0x0105021D, 100.912, -154.629, -17.945, -0.992552, 0, 0, -0.121823, False, '2025-08-20 15:23:47'); /* 200 gtfo trap */
/* @teleloc 0x0105021D [100.912003 -154.628998 -17.945000] -0.992552 0.000000 0.000000 -0.121823 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701050BB, 23423818, 0x0105024D, 59.0107, -149.05, -11.945, -0.767004, 0, 0, -0.641642, False, '2025-08-20 15:23:51'); /* 200 gtfo trap */
/* @teleloc 0x0105024D [59.010700 -149.050003 -11.945000] -0.767004 0.000000 0.000000 -0.641642 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701050BC, 23423818, 0x0105024C, 57.9175, -136.927, -11.945, -0.990094, 0, 0, -0.140404, False, '2025-08-20 15:23:53'); /* 200 gtfo trap */
/* @teleloc 0x0105024C [57.917500 -136.927002 -11.945000] -0.990094 0.000000 0.000000 -0.140404 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701050BD, 23423818, 0x01050242, 52.1797, -126.021, -11.945, -0.93838, 0, 0, -0.345606, False, '2025-08-20 15:23:56'); /* 200 gtfo trap */
/* @teleloc 0x01050242 [52.179699 -126.021004 -11.945000] -0.938380 0.000000 0.000000 -0.345606 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701050BE, 23423818, 0x010502EA, 50.112, -91.9569, 0.055, 0.006588, 0, 0, 0.999978, False, '2025-08-20 15:24:07'); /* 200 gtfo trap */
/* @teleloc 0x010502EA [50.112000 -91.956902 0.055000] 0.006588 0.000000 0.000000 0.999978 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701050BF, 23423818, 0x01050300, 63.4643, -99.8652, 0.055, -0.681035, 0, 0, 0.732251, False, '2025-08-20 15:24:09'); /* 200 gtfo trap */
/* @teleloc 0x01050300 [63.464298 -99.865196 0.055000] -0.681035 0.000000 0.000000 0.732251 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701050C0, 23423818, 0x0105031D, 72.0771, -109.863, 0.055, -0.042445, 0, 0, 0.999099, False, '2025-08-20 15:24:11'); /* 200 gtfo trap */
/* @teleloc 0x0105031D [72.077103 -109.862999 0.055000] -0.042445 0.000000 0.000000 0.999099 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701050C1, 23423818, 0x0105031F, 74.0396, -121.203, 0.055, -0.482922, 0, 0, 0.875664, False, '2025-08-20 15:24:12'); /* 200 gtfo trap */
/* @teleloc 0x0105031F [74.039597 -121.203003 0.055000] -0.482922 0.000000 0.000000 0.875664 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701050C2, 23423818, 0x0105033F, 80.8688, -150.314, 0.055, -0.451042, 0, 0, 0.892503, False, '2025-08-20 15:24:15'); /* 200 gtfo trap */
/* @teleloc 0x0105033F [80.868797 -150.313995 0.055000] -0.451042 0.000000 0.000000 0.892503 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701050C3, 23423818, 0x01050373, 97.4257, -151.95, 0.055, -0.725111, 0, 0, 0.688632, False, '2025-08-20 15:24:17'); /* 200 gtfo trap */
/* @teleloc 0x01050373 [97.425697 -151.949997 0.055000] -0.725111 0.000000 0.000000 0.688632 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701050C4, 23423818, 0x0105037E, 107.104, -173.309, 0.055, -0.999993, 0, 0, 0.003823, False, '2025-08-20 15:24:24'); /* 200 gtfo trap */
/* @teleloc 0x0105037E [107.103996 -173.309006 0.055000] -0.999993 0.000000 0.000000 0.003823 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701050C5, 23423818, 0x010501BA, 10.2254, -249.326, -17.945, 0.027277, 0, 0, -0.999628, False, '2025-08-20 15:24:55'); /* 200 gtfo trap */
/* @teleloc 0x010501BA [10.225400 -249.326004 -17.945000] 0.027277 0.000000 0.000000 -0.999628 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701050C6, 23423818, 0x010501A1, -0.081882, -250.244, -17.945, -0.712736, 0, 0, -0.701432, False, '2025-08-20 15:24:57'); /* 200 gtfo trap */
/* @teleloc 0x010501A1 [-0.081882 -250.244003 -17.945000] -0.712736 0.000000 0.000000 -0.701432 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701050C7, 23423818, 0x010501BC, 8.87908, -261.826, -17.945, 0.004548, 0, 0, -0.99999, False, '2025-08-20 15:25:00'); /* 200 gtfo trap */
/* @teleloc 0x010501BC [8.879080 -261.825989 -17.945000] 0.004548 0.000000 0.000000 -0.999990 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701050C8, 23423818, 0x01050118, 25.5577, -269.694, -23.945, 0.613738, 0, 0, -0.78951, False, '2025-08-20 15:25:02'); /* 200 gtfo trap */
/* @teleloc 0x01050118 [25.557699 -269.694000 -23.945000] 0.613738 0.000000 0.000000 -0.789510 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701050C9, 23423818, 0x01050136, 37.8703, -269.325, -23.945, 0.809602, 0, 0, -0.58698, False, '2025-08-20 15:25:04'); /* 200 gtfo trap */
/* @teleloc 0x01050136 [37.870300 -269.325012 -23.945000] 0.809602 0.000000 0.000000 -0.586980 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701050CA, 23423818, 0x01050166, 50.0716, -258.325, -23.945, 0.829965, 0, 0, -0.557816, False, '2025-08-20 15:25:06'); /* 200 gtfo trap */
/* @teleloc 0x01050166 [50.071602 -258.325012 -23.945000] 0.829965 0.000000 0.000000 -0.557816 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701050CB, 23423818, 0x0105015C, 51.6897, -244.981, -23.945, 0.999804, 0, 0, 0.019782, False, '2025-08-20 15:25:08'); /* 200 gtfo trap */
/* @teleloc 0x0105015C [51.689701 -244.981003 -23.945000] 0.999804 0.000000 0.000000 0.019782 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701050CC, 23423818, 0x0105017B, 61.4628, -236.059, -23.945, 0.999778, 0, 0, -0.021079, False, '2025-08-20 15:25:10'); /* 200 gtfo trap */
/* @teleloc 0x0105017B [61.462799 -236.059006 -23.945000] 0.999778 0.000000 0.000000 -0.021079 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701050CD, 23423818, 0x01050159, 51.1869, -228.721, -23.945, 0.714375, 0, 0, 0.699763, False, '2025-08-20 15:25:12'); /* 200 gtfo trap */
/* @teleloc 0x01050159 [51.186901 -228.720993 -23.945000] 0.714375 0.000000 0.000000 0.699763 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701050CE, 23423818, 0x01050154, 49.7398, -212.888, -23.945, 0.999814, 0, 0, 0.019297, False, '2025-08-20 15:25:14'); /* 200 gtfo trap */
/* @teleloc 0x01050154 [49.739799 -212.888000 -23.945000] 0.999814 0.000000 0.000000 0.019297 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701050CF, 23423818, 0x01050150, 49.3424, -197.721, -23.945, 0.999778, 0, 0, -0.021084, False, '2025-08-20 15:25:16'); /* 200 gtfo trap */
/* @teleloc 0x01050150 [49.342400 -197.720993 -23.945000] 0.999778 0.000000 0.000000 -0.021084 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701050D0, 23423818, 0x0105014A, 50.9096, -184.231, -23.945, 0.99933, 0, 0, 0.036598, False, '2025-08-20 15:25:18'); /* 200 gtfo trap */
/* @teleloc 0x0105014A [50.909599 -184.231003 -23.945000] 0.999330 0.000000 0.000000 0.036598 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701050D1, 23423818, 0x01050148, 52.271, -169.866, -23.945, 0.912255, 0, 0, -0.409623, False, '2025-08-20 15:25:19'); /* 200 gtfo trap */
/* @teleloc 0x01050148 [52.271000 -169.865997 -23.945000] 0.912255 0.000000 0.000000 -0.409623 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701050D2, 23423818, 0x01050144, 49.386, -157.285, -23.945, 1, 0, 0, -0.000419, False, '2025-08-20 15:25:24'); /* 200 gtfo trap */
/* @teleloc 0x01050144 [49.386002 -157.285004 -23.945000] 1.000000 0.000000 0.000000 -0.000419 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701050D3, 23423818, 0x0105010E, 50.415, -134.167, -29.945, 0.999554, 0, 0, 0.029864, False, '2025-08-20 15:25:26'); /* 200 gtfo trap */
/* @teleloc 0x0105010E [50.415001 -134.167007 -29.945000] 0.999554 0.000000 0.000000 0.029864 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701050D4, 23423818, 0x0105010C, 49.9991, -114.349, -29.945, 0.999945, 0, 0, -0.010515, False, '2025-08-20 15:25:28'); /* 200 gtfo trap */
/* @teleloc 0x0105010C [49.999100 -114.348999 -29.945000] 0.999945 0.000000 0.000000 -0.010515 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701050D5, 23423818, 0x0105010B, 50.1095, -101.321, -29.945, 0.998705, 0, 0, -0.050877, False, '2025-08-20 15:25:30'); /* 200 gtfo trap */
/* @teleloc 0x0105010B [50.109501 -101.320999 -29.945000] 0.998705 0.000000 0.000000 -0.050877 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701050D6, 23423818, 0x0105010A, 50.1654, -86.8714, -29.945, 0.999554, 0, 0, 0.029864, False, '2025-08-20 15:25:31'); /* 200 gtfo trap */
/* @teleloc 0x0105010A [50.165401 -86.871399 -29.945000] 0.999554 0.000000 0.000000 0.029864 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701050D7, 23423818, 0x01050108, 50.7696, -71.3266, -29.945, 0.991344, 0, 0, -0.131287, False, '2025-08-20 15:25:34'); /* 200 gtfo trap */
/* @teleloc 0x01050108 [50.769600 -71.326599 -29.945000] 0.991344 0.000000 0.000000 -0.131287 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701050D8, 23423818, 0x01050139, 54.8513, -72.4085, -19.7878, 0.442479, 0, 0, -0.896779, False, '2025-08-20 15:25:37'); /* 200 gtfo trap */
/* @teleloc 0x01050139 [54.851299 -72.408501 -19.787800] 0.442479 0.000000 0.000000 -0.896779 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701050D9, 23423818, 0x0105016D, 57.3752, -80.8609, -23.945, -0.029134, 0, 0, -0.999576, False, '2025-08-20 15:25:39'); /* 200 gtfo trap */
/* @teleloc 0x0105016D [57.375198 -80.860901 -23.945000] -0.029134 0.000000 0.000000 -0.999576 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701050DA, 23423818, 0x0105016E, 56.6722, -92.9089, -23.945, -0.029134, 0, 0, -0.999576, False, '2025-08-20 15:25:40'); /* 200 gtfo trap */
/* @teleloc 0x0105016E [56.672199 -92.908897 -23.945000] -0.029134 0.000000 0.000000 -0.999576 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701050DB, 23423818, 0x01050170, 56.2591, -109.101, -23.945, 0.011245, 0, 0, -0.999937, False, '2025-08-20 15:25:41'); /* 200 gtfo trap */
/* @teleloc 0x01050170 [56.259102 -109.100998 -23.945000] 0.011245 0.000000 0.000000 -0.999937 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701050DC, 23423818, 0x01050121, 42.5692, -108.189, -23.945, -0.886115, 0, 0, 0.463466, False, '2025-08-20 15:25:46'); /* 200 gtfo trap */
/* @teleloc 0x01050121 [42.569199 -108.189003 -23.945000] -0.886115 0.000000 0.000000 0.463466 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701050DD, 23423818, 0x01050120, 44.4025, -98.1193, -23.945, -0.994632, 0, 0, -0.103478, False, '2025-08-20 15:25:47'); /* 200 gtfo trap */
/* @teleloc 0x01050120 [44.402500 -98.119301 -23.945000] -0.994632 0.000000 0.000000 -0.103478 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701050DE, 23423818, 0x0105011F, 44.1292, -86.5992, -23.945, -0.99962, 0, 0, 0.027581, False, '2025-08-20 15:25:48'); /* 200 gtfo trap */
/* @teleloc 0x0105011F [44.129200 -86.599197 -23.945000] -0.999620 0.000000 0.000000 0.027581 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701050DF, 23423818, 0x0105011D, 43.7767, -74.5401, -23.945, -0.998586, 0, 0, -0.053158, False, '2025-08-20 15:25:49'); /* 200 gtfo trap */
/* @teleloc 0x0105011D [43.776699 -74.540100 -23.945000] -0.998586 0.000000 0.000000 -0.053158 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x701050E0, 23423818, 0x0105011D, 43.6023, -67.1484, -23.945, -0.99962, 0, 0, 0.027581, False, '2025-08-20 15:25:50'); /* 200 gtfo trap */
/* @teleloc 0x0105011D [43.602299 -67.148399 -23.945000] -0.999620 0.000000 0.000000 0.027581 */
