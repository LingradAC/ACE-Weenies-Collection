DELETE FROM `landblock_instance` WHERE `landblock` = 0xE3D6;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E3D6000, 12382137, 0xE3D60038, 153.994, 169.188, -0.845, 0.293294, 0, 0, 0.956022, False, '2025-07-19 07:05:29'); /* Rat Generator */
/* @teleloc 0xE3D60038 [153.994003 169.188004 -0.845000] 0.293294 0.000000 0.000000 0.956022 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E3D6001, 12382137, 0xE3D6001A, 77.2117, 41.3652, -0.395, 0.14571, 0, 0, 0.989327, False, '2025-07-19 07:05:41'); /* Rat Generator */
/* @teleloc 0xE3D6001A [77.211700 41.365200 -0.395000] 0.145710 0.000000 0.000000 0.989327 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E3D6002, 12382137, 0xE3D60019, 72.88335, 23.24502, -0.395, -0.567749, 0, 0, 0.823202, False, '2025-07-19 07:05:58'); /* Rat Generator */
/* @teleloc 0xE3D60019 [72.883347 23.245020 -0.395000] -0.567749 0.000000 0.000000 0.823202 */
