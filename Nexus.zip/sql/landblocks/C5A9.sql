DELETE FROM `landblock_instance` WHERE `landblock` = 0xC5A9;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7C5A9000,  6090, 0xC5A90101, 31.813, 77.701, 54.005, -0.707107, 0, 0, -0.707107, False, '2005-02-09 10:00:00'); /* Arwic Meeting Hall Portal */
/* @teleloc 0xC5A90101 [31.813000 77.700996 54.005001] -0.707107 0.000000 0.000000 -0.707107 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7C5A9004, 27547, 0xC5A90000, 38.5916, 88.6518, 52.005, -0.77686, 0, 0, -0.629674, False, '2005-02-09 10:00:00'); /* Bind Stone */
/* @teleloc 0xC5A90000 [38.591599 88.651802 52.005001] -0.776860 0.000000 0.000000 -0.629674 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7C5A9005, 42821, 0xC5A9003E, 184.4963, 140.8888, 45.06355, 0.957167, 0, 0, 0.289537, False, '2025-07-22 11:03:37'); /* Uziz Portal */
/* @teleloc 0xC5A9003E [184.496307 140.888794 45.063549] 0.957167 0.000000 0.000000 0.289537 */
