DELETE FROM `landblock_instance` WHERE `landblock` = 0xE4D1;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E4D1000, 12382138, 0xE4D10012, 62.6116, 33.9818, -0.045, -0.767442, 0, 0, 0.641119, False, '2025-07-19 10:02:22'); /* Picker Golem Generator */
/* @teleloc 0xE4D10012 [62.611599 33.981800 -0.045000] -0.767442 0.000000 0.000000 0.641119 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E4D1001, 4200152, 0xE4D10040, 185.592, 187.855, 0.055, -0.77236, 0, 0, 0.635185, False, '2025-07-19 10:31:44'); /* Gate */
/* @teleloc 0xE4D10040 [185.591995 187.854996 0.055000] -0.772360 0.000000 0.000000 0.635185 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E4D1002, 4200152, 0xE4D10040, 188.203, 170.517, 0.055, -0.736729, 0, 0, 0.676188, False, '2025-07-19 10:31:49'); /* Gate */
/* @teleloc 0xE4D10040 [188.203003 170.516998 0.055000] -0.736729 0.000000 0.000000 0.676188 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E4D1003, 4200152, 0xE4D1003F, 190.241, 151.381, 0.055, -0.723262, 0, 0, 0.690574, False, '2025-07-19 10:31:53'); /* Gate */
/* @teleloc 0xE4D1003F [190.240997 151.380997 0.055000] -0.723262 0.000000 0.000000 0.690574 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E4D1004, 4200152, 0xE4D1003E, 190.499, 133.463, -0.045, -0.679773, 0, 0, 0.733422, False, '2025-07-19 10:31:58'); /* Gate */
/* @teleloc 0xE4D1003E [190.498993 133.462997 -0.045000] -0.679773 0.000000 0.000000 0.733422 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E4D1005, 4200152, 0xE4D1003D, 191.805, 115.404, -0.045, -0.869703, 0, 0, 0.493576, False, '2025-07-19 10:32:04'); /* Gate */
/* @teleloc 0xE4D1003D [191.804993 115.403999 -0.045000] -0.869703 0.000000 0.000000 0.493576 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E4D1006, 213788146, 0xE4D10038, 166.273, 180.395, -0.045, 0.63964, 0, 0, -0.768675, False, '2025-07-20 14:07:57'); /* bzmobgen */
/* @teleloc 0xE4D10038 [166.272995 180.395004 -0.045000] 0.639640 0.000000 0.000000 -0.768675 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E4D1007, 91737171, 0xE4D10005, 16.1024, 100.765, -0.045, -0.98969, 0, 0, -0.14323, False, '2025-07-27 15:41:55'); /* cultistsoldiergen */
/* @teleloc 0xE4D10005 [16.102400 100.764999 -0.045000] -0.989690 0.000000 0.000000 -0.143230 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E4D1008, 700043, 0xE4D1002D, 128.7362, 110.4091, -0.845, 0.669488, 0, 0, 0.742823, False, '2025-08-24 14:40:46'); /* BiglugianGen */
/* @teleloc 0xE4D1002D [128.736206 110.409103 -0.845000] 0.669488 0.000000 0.000000 0.742823 */
