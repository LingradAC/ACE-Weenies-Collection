DELETE FROM `landblock_instance` WHERE `landblock` = 0x33DA;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x733DA013, 39477, 0x33DA001C, 94.0429, 94.0587, 60, -0.382683, 0, 0, -0.92388, False, '2021-11-01 00:00:00'); /* Betting Cage Door */
/* @teleloc 0x33DA001C [94.042900 94.058701 60.000000] -0.382683 0.000000 0.000000 -0.923880 */
