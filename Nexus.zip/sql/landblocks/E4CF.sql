DELETE FROM `landblock_instance` WHERE `landblock` = 0xE4CF;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E4CF000, 86659145, 0xE4CF0013, 61.3724, 55.0074, 46.639, -0.00229, 0, 0, 0.999997, False, '2025-07-27 15:08:26'); /* Vein of the Hopeslayer */
/* @teleloc 0xE4CF0013 [61.372398 55.007401 46.639000] -0.002290 0.000000 0.000000 0.999997 */
