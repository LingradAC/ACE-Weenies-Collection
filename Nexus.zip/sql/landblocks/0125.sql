DELETE FROM `landblock_instance` WHERE `landblock` = 0x0125;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70125000,   143, 0x01250100, -4.05, -27.1675, 0.0125, -0.707107, 0, 0, -0.707107, False, '2021-11-01 00:00:00'); /* Chest */
/* @teleloc 0x01250100 [-4.050000 -27.167500 0.012500] -0.707107 0.000000 0.000000 -0.707107 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70125001,   278, 0x01250102, 4.75, -30, 0, 0.707107, 0, 0, -0.707107, False, '2021-11-01 00:00:00'); /* Door */
/* @teleloc 0x01250102 [4.750000 -30.000000 0.000000] 0.707107 0.000000 0.000000 -0.707107 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70125002,  4980, 0x01250104, 10, -30, 0, -0.707107, 0, 0, -0.707107, False, '2021-11-01 00:00:00'); /* Refreshing Fountain */
/* @teleloc 0x01250104 [10.000000 -30.000000 0.000000] -0.707107 0.000000 0.000000 -0.707107 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70125003,   278, 0x0125010B, 30, -4.75, 0, 0, 0, 0, -1, False, '2021-11-01 00:00:00'); /* Door */
/* @teleloc 0x0125010B [30.000000 -4.750000 0.000000] 0.000000 0.000000 0.000000 -1.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70125004,  4979, 0x01250116, 62.1713, -29.7508, 0, 0.707107, 0, 0, -0.707107, False, '2021-11-01 00:00:00'); /* Sewer */
/* @teleloc 0x01250116 [62.171299 -29.750799 0.000000] 0.707107 0.000000 0.000000 -0.707107 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70125005,   278, 0x01250118, 55.25, -30, 0, -0.707107, 0, 0, -0.707107, False, '2021-11-01 00:00:00'); /* Door */
/* @teleloc 0x01250118 [55.250000 -30.000000 0.000000] -0.707107 0.000000 0.000000 -0.707107 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70125006, 42820, 0x01250126, 30, -63.132, 6.005, 0, 0, 0, -1, False, '2021-11-01 00:00:00'); /* Holtburg Portal */
/* @teleloc 0x01250126 [30.000000 -63.132000 6.005000] 0.000000 0.000000 0.000000 -1.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70125007,   568, 0x01250128, 25.25, -60, 6, -0.707107, 0, 0, -0.707107, False, '2021-11-01 00:00:00'); /* Door */
/* @teleloc 0x01250128 [25.250000 -60.000000 6.000000] -0.707107 0.000000 0.000000 -0.707107 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70125008,   568, 0x01250129, 34.75, -60, 6, 0.707107, 0, 0, -0.707107, False, '2021-11-01 00:00:00'); /* Door */
/* @teleloc 0x01250129 [34.750000 -60.000000 6.000000] 0.707107 0.000000 0.000000 -0.707107 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70125009, 32205, 0x01250104, 8.85783, -29.9211, -0.0272, 0.70958, 0, 0, -0.704625, False, '2025-07-04 20:37:57'); /* Pumpkin Buffer */
/* @teleloc 0x01250104 [8.857830 -29.921101 -0.027200] 0.709580 0.000000 0.000000 -0.704625 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7012500A, 80022, 0x01250104, 8.85783, -29.9211, 0.055, 0.70958, 0, 0, -0.704625, False, '2025-07-04 20:38:01'); /* Pumpkin Buffer Generator */
/* @teleloc 0x01250104 [8.857830 -29.921101 0.055000] 0.709580 0.000000 0.000000 -0.704625 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7012500B, 32205, 0x0125010C, 30.0261, -7.90949, -0.0272, 0.026922, 0, 0, 0.999638, False, '2025-08-13 17:07:58'); /* Pumpkin Buffer */
/* @teleloc 0x0125010C [30.026100 -7.909490 -0.027200] 0.026922 0.000000 0.000000 0.999638 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7012500C, 32205, 0x01250115, 51.462, -30.922, -0.0272, 0.791623, 0, 0, 0.61101, False, '2025-08-13 17:08:04'); /* Pumpkin Buffer */
/* @teleloc 0x01250115 [51.462002 -30.922001 -0.027200] 0.791623 0.000000 0.000000 0.611010 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7012500D, 32205, 0x01250125, 30.4468, -53.9504, 6.9791, -0.442738, 0, 0, 0.896651, False, '2025-08-13 17:08:25'); /* Pumpkin Buffer */
/* @teleloc 0x01250125 [30.446800 -53.950401 6.979100] -0.442738 0.000000 0.000000 0.896651 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7012500E, 32205, 0x01250116, 63.9897, -29.7794, 0.793988, -0.669942, 0, 0, 0.742414, False, '2025-08-13 17:08:41'); /* Pumpkin Buffer */
/* @teleloc 0x01250116 [63.989700 -29.779400 0.793988] -0.669942 0.000000 0.000000 0.742414 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7012500F, 32205, 0x01250109, 30.1534, 3.65339, 0.475297, -0.906115, 0, 0, -0.423031, False, '2025-08-13 17:08:51'); /* Pumpkin Buffer */
/* @teleloc 0x01250109 [30.153400 3.653390 0.475297] -0.906115 0.000000 0.000000 -0.423031 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70125010, 32205, 0x01250100, -3.42347, -30.3794, -0.0272, -0.743655, 0, 0, -0.668564, False, '2025-08-13 17:08:58'); /* Pumpkin Buffer */
/* @teleloc 0x01250100 [-3.423470 -30.379400 -0.027200] -0.743655 0.000000 0.000000 -0.668564 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70125011, 931271771, 0x01250126, 30, -60, 6.055, 1, 0, 0, 0, False, '2025-08-25 07:18:15');
/* @teleloc 0x01250126 [30.000000 -60.000000 6.055000] 1.000000 0.000000 0.000000 0.000000 */
