DELETE FROM `landblock_instance` WHERE `landblock` = 0xF1D7;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F1D7002, 5000768, 0xF1D70030, 120.265, 171.662, 0.055, -0.645503, 0, 0, 0.763758, False, '2020-05-07 18:50:16'); /* Stealth Remoran gen */
/* @teleloc 0xF1D70030 [120.264999 171.662003 0.055000] -0.645503 0.000000 0.000000 0.763758 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F1D7003, 5000767, 0xF1D7002F, 133.91, 156.501, 0.055, 0.645484, 0, 0, 0.763774, False, '2020-05-07 18:50:18'); /* Wasp gen */
/* @teleloc 0xF1D7002F [133.910004 156.501007 0.055000] 0.645484 0.000000 0.000000 0.763774 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F1D7004, 5000767, 0xF1D70026, 100.998, 143.377, 0.055, 0.225198, 0, 0, 0.974313, False, '2020-05-07 18:50:24'); /* Wasp gen */
/* @teleloc 0xF1D70026 [100.998001 143.376999 0.055000] 0.225198 0.000000 0.000000 0.974313 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F1D7007, 5000662, 0xF1D70008, 2.6813, 188.673, 0.055, 0.729601, 0, 0, 0.683873, False, '2020-01-13 01:39:48'); /* Plant */
/* @teleloc 0xF1D70008 [2.681300 188.673004 0.055000] 0.729601 0.000000 0.000000 0.683873 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F1D7008, 5000294, 0xF1D70008, 11.7876, 178.372, 0.055, -0.616705, 0, 0, -0.787194, False, '2020-01-13 01:39:58'); /* Plant */
/* @teleloc 0xF1D70008 [11.787600 178.371994 0.055000] -0.616705 0.000000 0.000000 -0.787194 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F1D7009, 5000295, 0xF1D70008, 4.12378, 187.231, 0.055, -0.977103, 0, 0, 0.212768, False, '2020-01-13 01:39:59'); /* Plant */
/* @teleloc 0xF1D70008 [4.123780 187.231003 0.055000] -0.977103 0.000000 0.000000 0.212768 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F1D700A, 5000662, 0xF1D7000D, 30.2596, 117.114, 0.055, 0.09933, 0, 0, 0.995055, False, '2020-01-13 01:40:20'); /* Plant */
/* @teleloc 0xF1D7000D [30.259600 117.113998 0.055000] 0.099330 0.000000 0.000000 0.995055 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F1D700B, 5000294, 0xF1D7000D, 39.3467, 114.395, 0.055, -0.633882, 0, 0, 0.77343, False, '2020-01-13 01:40:22'); /* Plant */
/* @teleloc 0xF1D7000D [39.346699 114.394997 0.055000] -0.633882 0.000000 0.000000 0.773430 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F1D700C, 5000295, 0xF1D7000D, 38.5345, 111.08, 0.055, 0.367587, 0, 0, 0.929989, False, '2020-01-13 01:40:24'); /* Plant */
/* @teleloc 0xF1D7000D [38.534500 111.080002 0.055000] 0.367587 0.000000 0.000000 0.929989 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F1D700D, 5000296, 0xF1D70019, 76.0351, 23.6358, 0.055, -0.333865, 0, 0, 0.942621, False, '2020-01-13 01:40:31'); /* Plant */
/* @teleloc 0xF1D70019 [76.035103 23.635799 0.055000] -0.333865 0.000000 0.000000 0.942621 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F1D700E, 5000296, 0xF1D70019, 87.8543, 9.04412, 0.055, -0.333865, 0, 0, 0.942621, False, '2020-01-13 01:40:32'); /* Plant */
/* @teleloc 0xF1D70019 [87.854301 9.044120 0.055000] -0.333865 0.000000 0.000000 0.942621 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F1D700F, 5000661, 0xF1D70019, 86.3661, 8.48163, 0.055, 0.776393, 0, 0, 0.630249, False, '2020-01-13 01:40:34'); /* Plant */
/* @teleloc 0xF1D70019 [86.366096 8.481630 0.055000] 0.776393 0.000000 0.000000 0.630249 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F1D7011, 5000767, 0xF1D70033, 144.249, 69.9315, 0.055, 0.838451, 0, 0, -0.544977, False, '2020-05-20 20:58:13'); /* Wasp gen */
/* @teleloc 0xF1D70033 [144.248993 69.931503 0.055000] 0.838451 0.000000 0.000000 -0.544977 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F1D7012, 5000767, 0xF1D7002C, 132.059, 90.2419, 0.055, 0.541473, 0, 0, 0.840718, False, '2020-05-20 20:58:16'); /* Wasp gen */
/* @teleloc 0xF1D7002C [132.059006 90.241898 0.055000] 0.541473 0.000000 0.000000 0.840718 */
