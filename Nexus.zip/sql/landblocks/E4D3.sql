DELETE FROM `landblock_instance` WHERE `landblock` = 0xE4D3;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E4D3000, 91737171, 0xE4D30010, 29.1468, 169.845, -0.395, 0.118247, 0, 0, -0.992984, False, '2025-07-27 14:43:25'); /* cultistsoldiergen */
/* @teleloc 0xE4D30010 [29.146799 169.845001 -0.395000] 0.118247 0.000000 0.000000 -0.992984 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E4D3001, 7002199, 0xE4D3003B, 188.271, 51.92356, -0.845, 0.019816, 0, 0, -0.999804, False, '2025-08-24 14:19:14');
/* @teleloc 0xE4D3003B [188.270996 51.923561 -0.845000] 0.019816 0.000000 0.000000 -0.999804 */
