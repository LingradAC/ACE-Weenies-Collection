DELETE FROM `landblock_instance` WHERE `landblock` = 0xC5A6;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7C5A6000,   412, 0xC5A60000, 134.52, 60, 39, -0.707107, 0, 0, -0.707107, False, '2005-02-09 10:00:00'); /* Door */
/* @teleloc 0xC5A60000 [134.520004 60.000000 39.000000] -0.707107 0.000000 0.000000 -0.707107 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7C5A6005,  4786, 0xC5A6010C, 153.959, 12.0098, 38.0585, -0.72955, 0, 0, -0.683927, False, '2005-02-09 10:00:00'); /* Olthoi Hunter Gen */
/* @teleloc 0xC5A6010C [153.959000 12.009800 38.058498] -0.729550 0.000000 0.000000 -0.683927 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7C5A6013, 16919, 0xC5A60000, 179.67, 34.8723, 38, -0.999988, 0, 0, -0.004908, False, '2005-02-09 10:00:00'); /* Pedestal Weak Spot */
/* @teleloc 0xC5A60000 [179.669998 34.872299 38.000000] -0.999988 0.000000 0.000000 -0.004908 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7C5A6016, 19457, 0xC5A60000, 179.714, 30.645, 45, -0.716466, 0, 0, -0.697622, False, '2005-02-09 10:00:00'); /* Fireworks Generator */
/* @teleloc 0xC5A60000 [179.714005 30.645000 45.000000] -0.716466 0.000000 0.000000 -0.697622 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7C5A601E, 19206, 0xC5A60000, 179.804, 30.7831, 44.82, -0.675557, 0, 0, -0.737308, False, '2005-02-09 10:00:00'); /* Nullified Statue of a Tumerok */
/* @teleloc 0xC5A60000 [179.804001 30.783100 44.820000] -0.675557 0.000000 0.000000 -0.737308 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7C5A601F, 19716, 0xC5A6011B, 179.698, 17.7833, 32.805, 0.029702, 0, 0, -0.999559, False, '2005-02-09 10:00:00'); /* Mammet Foundry Portal */
/* @teleloc 0xC5A6011B [179.697998 17.783300 32.805000] 0.029702 0.000000 0.000000 -0.999559 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7C5A6025,   412, 0xC5A60000, 176.149, 60.8515, 38, 0.707107, 0, 0, -0.707107, False, '2005-02-09 10:00:00'); /* Door */
/* @teleloc 0xC5A60000 [176.149002 60.851501 38.000000] 0.707107 0.000000 0.000000 -0.707107 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7C5A6026,   412, 0xC5A60000, 156.2, 77.59, 38.01, 1, 0, 0, 0, False, '2005-02-09 10:00:00'); /* Door */
/* @teleloc 0xC5A60000 [156.199997 77.589996 38.009998] 1.000000 0.000000 0.000000 0.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7C5A6027,   412, 0xC5A60000, 160.695, 82.545, 37.995, 0.707107, 0, 0, 0.707107, False, '2005-02-09 10:00:00'); /* Door */
/* @teleloc 0xC5A60000 [160.695007 82.544998 37.994999] 0.707107 0.000000 0.000000 0.707107 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7C5A6028,   412, 0xC5A60000, 159.245, 83.895, 40.995, 1, 0, 0, 0, False, '2005-02-09 10:00:00'); /* Door */
/* @teleloc 0xC5A60000 [159.244995 83.894997 40.994999] 1.000000 0.000000 0.000000 0.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7C5A6029,   412, 0xC5A60000, 158.212, 80.19, 41, 0.707107, 0, 0, 0.707107, False, '2005-02-09 10:00:00'); /* Door */
/* @teleloc 0xC5A60000 [158.212006 80.190002 41.000000] 0.707107 0.000000 0.000000 0.707107 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7C5A602A,   701, 0xC5A6011E, 159.067, 80.5821, 38.005, -0.907042, 0, 0, -0.421041, False, '2005-02-09 10:00:00'); /* Laqisha the Scribe */
/* @teleloc 0xC5A6011E [159.067001 80.582100 38.005001] -0.907042 0.000000 0.000000 -0.421041 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7C5A602B, 1942757, 0xC5A60032, 165.582, 36.5308, 37.9985, -0.858154, 0, 0, -0.513392, False, '2025-08-23 23:27:21'); /* Scuttling Grievver */
/* @teleloc 0xC5A60032 [165.582001 36.530800 37.998501] -0.858154 0.000000 0.000000 -0.513392 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7C5A602C, 1942757, 0xC5A6002B, 141.773, 64.0435, 38.1841, -0.822237, 0, 0, -0.569146, False, '2025-08-23 23:27:26'); /* Scuttling Grievver */
/* @teleloc 0xC5A6002B [141.772995 64.043503 38.184101] -0.822237 0.000000 0.000000 -0.569146 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7C5A602D, 1942757, 0xC5A6002A, 137.668, 39.1534, 38.5261, -0.070569, 0, 0, -0.997507, False, '2025-08-23 23:27:29'); /* Scuttling Grievver */
/* @teleloc 0xC5A6002A [137.667999 39.153400 38.526100] -0.070569 0.000000 0.000000 -0.997507 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7C5A602E, 1942757, 0xC5A60029, 140.553, 19.0529, 38.2857, 0.412794, 0, 0, -0.910825, False, '2025-08-23 23:27:30'); /* Scuttling Grievver */
/* @teleloc 0xC5A60029 [140.552994 19.052900 38.285702] 0.412794 0.000000 0.000000 -0.910825 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7C5A602F, 1942757, 0xC5A6003A, 191.363, 33.2458, 37.9985, 0.95566, 0, 0, 0.294473, False, '2025-08-23 23:28:57'); /* Scuttling Grievver */
/* @teleloc 0xC5A6003A [191.363007 33.245800 37.998501] 0.955660 0.000000 0.000000 0.294473 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7C5A6030, 19427577, 0xC5A60033, 154.456, 68.9512, 38.0075, 0.786162, 0, 0, 0.61802, False, '2025-08-23 23:33:49');
/* @teleloc 0xC5A60033 [154.455994 68.951202 38.007500] 0.786162 0.000000 0.000000 0.618020 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7C5A6031, 19427577, 0xC5A6002B, 129.276, 71.9739, 39.2345, 0.55769, 0, 0, 0.83005, False, '2025-08-23 23:33:51');
/* @teleloc 0xC5A6002B [129.276001 71.973900 39.234501] 0.557690 0.000000 0.000000 0.830050 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7C5A6032, 19427577, 0xC5A6002A, 123.592, 45.8379, 39.7082, -0.194635, 0, 0, 0.980876, False, '2025-08-23 23:33:53');
/* @teleloc 0xC5A6002A [123.592003 45.837898 39.708199] -0.194635 0.000000 0.000000 0.980876 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7C5A6033, 19427577, 0xC5A60031, 156.749, 0.969767, 38.0075, -0.732397, 0, 0, 0.680878, False, '2025-08-23 23:33:57');
/* @teleloc 0xC5A60031 [156.748993 0.969767 38.007500] -0.732397 0.000000 0.000000 0.680878 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7C5A6034, 194275777, 0xC5A60033, 157.528, 52.8257, 38.018, -0.985524, 0, 0, -0.169537, False, '2025-08-23 23:37:03');
/* @teleloc 0xC5A60033 [157.528000 52.825699 38.018002] -0.985524 0.000000 0.000000 -0.169537 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7C5A6035, 194275777, 0xC5A6002A, 139.657, 35.6171, 38.3799, -0.0979, 0, 0, -0.995196, False, '2025-08-23 23:37:06');
/* @teleloc 0xC5A6002A [139.656998 35.617100 38.379902] -0.097900 0.000000 0.000000 -0.995196 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7C5A6036, 194275777, 0xC5A60029, 142.782, 8.54979, 38.1195, 0.358217, 0, 0, -0.933638, False, '2025-08-23 23:37:08');
/* @teleloc 0xC5A60029 [142.781998 8.549790 38.119499] 0.358217 0.000000 0.000000 -0.933638 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7C5A6037, 194275777, 0xC5A60031, 161.327, 4.66466, 38.018, 0.828514, 0, 0, -0.559968, False, '2025-08-23 23:37:10');
/* @teleloc 0xC5A60031 [161.326996 4.664660 38.018002] 0.828514 0.000000 0.000000 -0.559968 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7C5A6038, 194275777, 0xC5A60039, 170.868, 10.0655, 38.018, 0.968644, 0, 0, -0.248455, False, '2025-08-23 23:37:11');
/* @teleloc 0xC5A60039 [170.867996 10.065500 38.018002] 0.968644 0.000000 0.000000 -0.248455 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7C5A6039, 194275777, 0xC5A6003A, 172.025, 26.2125, 38.018, 0.998659, 0, 0, 0.051771, False, '2025-08-23 23:37:12');
/* @teleloc 0xC5A6003A [172.024994 26.212500 38.018002] 0.998659 0.000000 0.000000 0.051771 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7C5A603A, 194275777, 0xC5A6003B, 169.824, 49.399, 38.018, 0.996845, 0, 0, -0.079369, False, '2025-08-23 23:37:14');
/* @teleloc 0xC5A6003B [169.824005 49.398998 38.018002] 0.996845 0.000000 0.000000 -0.079369 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7C5A603B, 194275777, 0xC5A6003C, 174.798, 80.4278, 38.018, 0.996845, 0, 0, -0.079369, False, '2025-08-23 23:37:16');
/* @teleloc 0xC5A6003C [174.798004 80.427803 38.018002] 0.996845 0.000000 0.000000 -0.079369 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7C5A603C, 194275777, 0xC5A6002B, 139.698, 60.0112, 38.3765, 0.677245, 0, 0, 0.735758, False, '2025-08-23 23:37:21');
/* @teleloc 0xC5A6002B [139.697998 60.011200 38.376499] 0.677245 0.000000 0.000000 0.735758 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7C5A603D, 194275777, 0xC5A6002B, 139.266, 50.9836, 38.4125, 0.203163, 0, 0, 0.979145, False, '2025-08-23 23:37:24');
/* @teleloc 0xC5A6002B [139.266006 50.983601 38.412498] 0.203163 0.000000 0.000000 0.979145 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7C5A603E, 13815757, 0xC5A60102, 131.187, 62.22, 38.205, 0.035639, 0, 0, -0.999365, False, '2025-08-23 23:45:23');
/* @teleloc 0xC5A60102 [131.186996 62.220001 38.205002] 0.035639 0.000000 0.000000 -0.999365 */
