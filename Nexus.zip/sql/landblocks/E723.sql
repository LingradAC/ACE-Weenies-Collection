DELETE FROM `landblock_instance` WHERE `landblock` = 0xE723;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E723000, 24411, 0xE723002A, 124.451, 24.3587, -0.045, 0.932603, 0, 0, -0.360904, False, '2025-08-14 11:19:31'); /* Asheron Invasion Extreme Generators */
/* @teleloc 0xE723002A [124.450996 24.358700 -0.045000] 0.932603 0.000000 0.000000 -0.360904 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E723001, 24411, 0xE723003C, 168.104, 72.86, -0.045, 0.971474, 0, 0, -0.237148, False, '2025-08-14 11:19:35'); /* Asheron Invasion Extreme Generators */
/* @teleloc 0xE723003C [168.104004 72.860001 -0.045000] 0.971474 0.000000 0.000000 -0.237148 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E723002, 24411, 0xE7230035, 164.774, 97.6095, -0.045, 0.974797, 0, 0, 0.223092, False, '2025-08-14 11:19:37'); /* Asheron Invasion Extreme Generators */
/* @teleloc 0xE7230035 [164.774002 97.609497 -0.045000] 0.974797 0.000000 0.000000 0.223092 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E723003, 24411, 0xE723002F, 126.6123, 144.2355, -0.045, 0.929985, 0, 0, 0.367598, False, '2025-08-14 11:19:41'); /* Asheron Invasion Extreme Generators */
/* @teleloc 0xE723002F [126.612297 144.235504 -0.045000] 0.929985 0.000000 0.000000 0.367598 */
