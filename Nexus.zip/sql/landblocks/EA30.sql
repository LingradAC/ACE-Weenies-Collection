DELETE FROM `landblock_instance` WHERE `landblock` = 0xEA30;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7EA30000,   720, 0xEA300000, 156, 28.45, 110, 1, 0, 0, 0, False, '2005-02-09 10:00:00'); /* Sliding Door */
/* @teleloc 0xEA300000 [156.000000 28.450001 110.000000] 1.000000 0.000000 0.000000 0.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7EA30001,   720, 0xEA300000, 156, 43.5247, 113, 1, 0, 0, 0, False, '2005-02-09 10:00:00'); /* Sliding Door */
/* @teleloc 0xEA300000 [156.000000 43.524700 113.000000] 1.000000 0.000000 0.000000 0.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7EA30002,   720, 0xEA300000, 156, 28.45, 113, 1, 0, 0, 0, False, '2005-02-09 10:00:00'); /* Sliding Door */
/* @teleloc 0xEA300000 [156.000000 28.450001 113.000000] 1.000000 0.000000 0.000000 0.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7EA30003,   720, 0xEA300000, 163.55, 36, 113, 0.707107, 0, 0, -0.707107, False, '2005-02-09 10:00:00'); /* Sliding Door */
/* @teleloc 0xEA300000 [163.550003 36.000000 113.000000] 0.707107 0.000000 0.000000 -0.707107 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7EA30004,   720, 0xEA300000, 148.45, 36, 113, 0.707107, 0, 0, 0.707107, False, '2005-02-09 10:00:00'); /* Sliding Door */
/* @teleloc 0xEA300000 [148.449997 36.000000 113.000000] 0.707107 0.000000 0.000000 0.707107 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7EA30005, 86653879, 0xEA300103, 150.669, 38.0079, 110.005, 0.724347, 0, 0, 0.689436, False, '2025-07-29 13:20:42'); /* BLUE BALL OF LIGHT */
/* @teleloc 0xEA300103 [150.669006 38.007900 110.004997] 0.724347 0.000000 0.000000 0.689436 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7EA30006, 99235757, 0xEA30002A, 122.216, 32.1113, 121.651, -0.97585, 0, 0, -0.218442, False, '2025-08-29 14:07:26');
/* @teleloc 0xEA30002A [122.216003 32.111301 121.651001] -0.975850 0.000000 0.000000 -0.218442 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7EA30007, 99235757, 0xEA300031, 151.621, 18.4884, 106.218, -0.979916, 0, 0, 0.199409, False, '2025-08-29 14:08:10');
/* @teleloc 0xEA300031 [151.621002 18.488400 106.218002] -0.979916 0.000000 0.000000 0.199409 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7EA30008, 99235757, 0xEA30001A, 72.5212, 35.9075, 138.886, -0.886796, 0, 0, -0.462161, False, '2025-08-29 14:08:17');
/* @teleloc 0xEA30001A [72.521202 35.907501 138.886002] -0.886796 0.000000 0.000000 -0.462161 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7EA30009, 99235757, 0xEA30001B, 83.93275, 60.09673, 145.1065, -0.921887, 0, 0, 0.38746, False, '2025-08-29 14:08:19');
/* @teleloc 0xEA30001B [83.932747 60.096729 145.106506] -0.921887 0.000000 0.000000 0.387460 */
