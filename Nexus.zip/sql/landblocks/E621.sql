DELETE FROM `landblock_instance` WHERE `landblock` = 0xE621;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E621000, 24411, 0xE621003D, 189.799, 111.339, 26.0429, -0.832766, 0, 0, -0.553626, False, '2025-08-16 18:20:40'); /* Asheron Invasion Extreme Generators */
/* @teleloc 0xE621003D [189.798996 111.338997 26.042900] -0.832766 0.000000 0.000000 -0.553626 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E621001, 24411, 0xE6210028, 115.502, 168.542, 18.5201, -0.952397, 0, 0, -0.304861, False, '2025-08-16 18:20:46'); /* Asheron Invasion Extreme Generators */
/* @teleloc 0xE6210028 [115.501999 168.542007 18.520100] -0.952397 0.000000 0.000000 -0.304861 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E621002, 24411, 0xE621000A, 39.1758, 47.83112, -0.045, 0.421531, 0, 0, -0.906814, False, '2025-08-16 18:21:13'); /* Asheron Invasion Extreme Generators */
/* @teleloc 0xE621000A [39.175800 47.831120 -0.045000] 0.421531 0.000000 0.000000 -0.906814 */
