DELETE FROM `landblock_instance` WHERE `landblock` = 0xF4D6;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F4D6005, 5000662, 0xF4D60022, 106.922, 36.3468, 0.055, -0.99993, 0, 0, 0.011863, False, '2020-01-13 01:43:33'); /* Plant */
/* @teleloc 0xF4D60022 [106.921997 36.346802 0.055000] -0.999930 0.000000 0.000000 0.011863 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F4D6006, 5000295, 0xF4D60033, 144.195, 57.9985, 0.055, -0.772332, 0, 0, 0.63522, False, '2020-01-13 01:43:36'); /* Plant */
/* @teleloc 0xF4D60033 [144.195007 57.998501 0.055000] -0.772332 0.000000 0.000000 0.635220 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F4D6007, 5000661, 0xF4D60033, 155.256, 58.6065, 0.055, -0.504795, 0, 0, 0.863239, False, '2020-01-13 01:43:37'); /* Plant */
/* @teleloc 0xF4D60033 [155.255997 58.606499 0.055000] -0.504795 0.000000 0.000000 0.863239 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F4D6008, 5000284, 0xF4D60005, 12.6818, 104.927, 0.1404, -0.423606, 0, 0, -0.905846, False, '2020-01-15 20:21:28'); /* Bone */
/* @teleloc 0xF4D60005 [12.681800 104.927002 0.140400] -0.423606 0.000000 0.000000 -0.905846 */
