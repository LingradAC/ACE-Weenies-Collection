DELETE FROM `landblock_instance` WHERE `landblock` = 0xB9F1;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7B9F1000, 52222, 0xB9F10040, 188.816, 189.978, 397.937, -0.99984, 0, 0, 0.017895, False, '2022-05-17 03:47:03'); /* Charged Niche */
/* @teleloc 0xB9F10040 [188.815994 189.977997 397.937012] -0.999840 0.000000 0.000000 0.017895 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7B9F1001, 3969221, 0xB9F10020, 80.2231, 169.019, 398.005, -0.001392, 0, 0, 0.999999, False, '2025-08-04 19:32:06'); /* Kaine FlatRock */
/* @teleloc 0xB9F10020 [80.223099 169.018997 398.005005] -0.001392 0.000000 0.000000 0.999999 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7B9F1002, 99996661, 0xB9F10020, 80.92913, 183.7173, 398.055, -0.012591, 0, 0, -0.999921, False, '2025-08-04 19:41:52'); /* ShadowGovernmentAttack */
/* @teleloc 0xB9F10020 [80.929131 183.717300 398.054993] -0.012591 0.000000 0.000000 -0.999921 */
