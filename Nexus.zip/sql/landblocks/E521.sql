DELETE FROM `landblock_instance` WHERE `landblock` = 0xE521;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E521000, 24411, 0xE521003F, 180.4297, 153.9142, -0.045, 0.167512, 0, 0, -0.98587, False, '2025-08-16 18:21:05'); /* Asheron Invasion Extreme Generators */
/* @teleloc 0xE521003F [180.429703 153.914200 -0.045000] 0.167512 0.000000 0.000000 -0.985870 */
