DELETE FROM `landblock_instance` WHERE `landblock` = 0xB54A;

