DELETE FROM `landblock_instance` WHERE `landblock` = 0xE523;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E523000, 24411, 0xE5230006, 12.213, 143.596, -0.045, 0.116077, 0, 0, -0.99324, False, '2025-08-14 11:20:51'); /* Asheron Invasion Extreme Generators */
/* @teleloc 0xE5230006 [12.213000 143.595993 -0.045000] 0.116077 0.000000 0.000000 -0.993240 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E523001, 24411, 0xE5230004, 10.4269, 84.6771, -0.045, 0.351003, 0, 0, -0.936374, False, '2025-08-14 11:20:55'); /* Asheron Invasion Extreme Generators */
/* @teleloc 0xE5230004 [10.426900 84.677101 -0.045000] 0.351003 0.000000 0.000000 -0.936374 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E523002, 24411, 0xE5230014, 63.3359, 84.2029, -0.045, 0.889885, 0, 0, -0.456186, False, '2025-08-14 11:20:59'); /* Asheron Invasion Extreme Generators */
/* @teleloc 0xE5230014 [63.335899 84.202904 -0.045000] 0.889885 0.000000 0.000000 -0.456186 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E523003, 24411, 0xE523002C, 120.126, 93.8461, -0.045, 0.34017, 0, 0, -0.940364, False, '2025-08-14 11:21:03'); /* Asheron Invasion Extreme Generators */
/* @teleloc 0xE523002C [120.125999 93.846100 -0.045000] 0.340170 0.000000 0.000000 -0.940364 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E523004, 24411, 0xE5230027, 108.5547, 152.5708, 7.197296, 0.999872, 0, 0, -0.016016, False, '2025-08-14 11:21:10'); /* Asheron Invasion Extreme Generators */
/* @teleloc 0xE5230027 [108.554703 152.570801 7.197296] 0.999872 0.000000 0.000000 -0.016016 */
