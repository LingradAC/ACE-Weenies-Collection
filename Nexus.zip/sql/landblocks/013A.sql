DELETE FROM `landblock_instance` WHERE `landblock` = 0x013A;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7013A000, 2432343298, 0x013A0108, 3.053164, -39.31079, 0.055, 0.694345, 0, 0, -0.719642, False, '2025-07-22 09:31:22');
/* @teleloc 0x013A0108 [3.053164 -39.310791 0.055000] 0.694345 0.000000 0.000000 -0.719642 */
