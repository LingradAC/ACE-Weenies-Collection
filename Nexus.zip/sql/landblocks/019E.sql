DELETE FROM `landblock_instance` WHERE `landblock` = 0x019E;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7019E001,   171, 0x019E0119, 23.0735, 0.355134, 0, -0.707107, 0, 0, -0.707107, False, '2005-02-09 10:00:00'); /* Vat */
/* @teleloc 0x019E0119 [23.073500 0.355134 0.000000] -0.707107 0.000000 0.000000 -0.707107 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7019E002,   171, 0x019E0101, -1.0621, -13.2144, 0, -0.707107, 0, 0, -0.707107, False, '2005-02-09 10:00:00'); /* Vat */
/* @teleloc 0x019E0101 [-1.062100 -13.214400 0.000000] -0.707107 0.000000 0.000000 -0.707107 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7019E00B,  2069, 0x019E0121, 23.1408, -39.6605, 0, -0.707107, 0, 0, -0.707107, False, '2005-02-09 10:00:00'); /* Surface */
/* @teleloc 0x019E0121 [23.140800 -39.660500 0.000000] -0.707107 0.000000 0.000000 -0.707107 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7019E022,  1946, 0x019E011E, 23.0134, -26.9728, 0.005, 0.867711, 0, 0, -0.497069, False, '2005-02-09 10:00:00'); /* Chest */
/* @teleloc 0x019E011E [23.013399 -26.972799 0.005000] 0.867711 0.000000 0.000000 -0.497069 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7019E030,  1915, 0x019E013F, 16.4566, -43.2035, 6.005, -0.395323, 0, 0, -0.918542, False, '2005-02-09 10:00:00'); /* Chest */
/* @teleloc 0x019E013F [16.456600 -43.203499 6.005000] -0.395323 0.000000 0.000000 -0.918542 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7019E031,  3961, 0x019E013F, 16.7586, -36.6009, 6.005, -0.887938, 0, 0, -0.459962, False, '2005-02-09 10:00:00'); /* Chest */
/* @teleloc 0x019E013F [16.758600 -36.600899 6.005000] -0.887938 0.000000 0.000000 -0.459962 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7019E03D, 22573, 0x019E0134, 37.6675, -51.272, 0.005, 0.34576, 0, 0, -0.938323, False, '2005-02-09 10:00:00'); /* Runed Chest */
/* @teleloc 0x019E0134 [37.667500 -51.271999 0.005000] 0.345760 0.000000 0.000000 -0.938323 */
