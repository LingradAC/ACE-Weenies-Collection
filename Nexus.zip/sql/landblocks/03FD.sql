DELETE FROM `landblock_instance` WHERE `landblock` = 0x03FD;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x703FD000,  9687, 0x03FD0100, 0.023, -43.404, -5.995, 0, 0, 0, -1,  True, '2005-02-09 10:00:00'); /* Storage */
/* @teleloc 0x03FD0100 [0.023000 -43.403999 -5.995000] 0.000000 0.000000 0.000000 -1.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x703FD001,  9687, 0x03FD0100, -3.608, -39.98, -5.995, -0.707107, 0, 0, -0.707107,  True, '2005-02-09 10:00:00'); /* Storage */
/* @teleloc 0x03FD0100 [-3.608000 -39.980000 -5.995000] -0.707107 0.000000 0.000000 -0.707107 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x703FD002,   278, 0x03FD0102, 4.75, -40, -6, 0.707107, 0, 0, -0.707107, False, '2005-02-09 10:00:00'); /* Door */
/* @teleloc 0x03FD0102 [4.750000 -40.000000 -6.000000] 0.707107 0.000000 0.000000 -0.707107 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x703FD003, 11697, 0x03FD0103, 14.0306, -20.114, -5.995, 0.696707, 0, 0, -0.717356,  True, '2005-02-09 10:00:00'); /* Floor Hook */
/* @teleloc 0x03FD0103 [14.030600 -20.114000 -5.995000] 0.696707 0.000000 0.000000 -0.717356 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x703FD004,  9686, 0x03FD0103, 10.1259, -15.604, -4.32, -0.999989, 0, 0, -0.004782,  True, '2005-02-09 10:00:00'); /* Wall Hook */
/* @teleloc 0x03FD0103 [10.125900 -15.604000 -4.320000] -0.999989 0.000000 0.000000 -0.004782 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x703FD005,   278, 0x03FD0105, 10, -24.75, -6, 0, 0, 0, -1, False, '2005-02-09 10:00:00'); /* Door */
/* @teleloc 0x03FD0105 [10.000000 -24.750000 -6.000000] 0.000000 0.000000 0.000000 -1.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x703FD006, 11697, 0x03FD0110, 20, 4.13086, -5.995, 1, 0, 0, 0,  True, '2005-02-09 10:00:00'); /* Floor Hook */
/* @teleloc 0x03FD0110 [20.000000 4.130860 -5.995000] 1.000000 0.000000 0.000000 0.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x703FD007,  9686, 0x03FD0110, 15.6054, -0.007371, -4.3, -0.707107, 0, 0, -0.707107,  True, '2005-02-09 10:00:00'); /* Wall Hook */
/* @teleloc 0x03FD0110 [15.605400 -0.007371 -4.300000] -0.707107 0.000000 0.000000 -0.707107 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x703FD008,   278, 0x03FD0112, 20, -4.75, -6, 0, 0, 0, -1, False, '2005-02-09 10:00:00'); /* Door */
/* @teleloc 0x03FD0112 [20.000000 -4.750000 -6.000000] 0.000000 0.000000 0.000000 -1.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x703FD009,  9686, 0x03FD0118, 19.9588, -15.1013, -4.3, 1, 0, 0, 0,  True, '2005-02-09 10:00:00'); /* Wall Hook */
/* @teleloc 0x03FD0118 [19.958799 -15.101300 -4.300000] 1.000000 0.000000 0.000000 0.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x703FD00A, 11697, 0x03FD0118, 20, -20, -5.995, 1, 0, 0, 0,  True, '2005-02-09 10:00:00'); /* Floor Hook */
/* @teleloc 0x03FD0118 [20.000000 -20.000000 -5.995000] 1.000000 0.000000 0.000000 0.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x703FD00B,  9686, 0x03FD0118, 15.1014, -19.9684, -4.3, -0.714424, 0, 0, -0.699713,  True, '2005-02-09 10:00:00'); /* Wall Hook */
/* @teleloc 0x03FD0118 [15.101400 -19.968399 -4.300000] -0.714424 0.000000 0.000000 -0.699713 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x703FD00C, 10662, 0x03FD0118, 20.0682, -18.5777, -5.995, 1, 0, 0, 0, False, '2005-02-09 10:00:00'); /* Villa */
/* @teleloc 0x03FD0118 [20.068199 -18.577700 -5.995000] 1.000000 0.000000 0.000000 0.000000 */

INSERT INTO `landblock_instance_link` (`parent_GUID`, `child_GUID`, `last_Modified`)
VALUES (0x703FD00C, 0x703FD000, '2005-02-09 10:00:00') /* Storage (9687) */
     , (0x703FD00C, 0x703FD001, '2005-02-09 10:00:00') /* Storage (9687) */
     , (0x703FD00C, 0x703FD003, '2005-02-09 10:00:00') /* Floor Hook (11697) */
     , (0x703FD00C, 0x703FD004, '2005-02-09 10:00:00') /* Wall Hook (9686) */
     , (0x703FD00C, 0x703FD006, '2005-02-09 10:00:00') /* Floor Hook (11697) */
     , (0x703FD00C, 0x703FD007, '2005-02-09 10:00:00') /* Wall Hook (9686) */
     , (0x703FD00C, 0x703FD009, '2005-02-09 10:00:00') /* Wall Hook (9686) */
     , (0x703FD00C, 0x703FD00A, '2005-02-09 10:00:00') /* Floor Hook (11697) */
     , (0x703FD00C, 0x703FD00B, '2005-02-09 10:00:00') /* Wall Hook (9686) */
     , (0x703FD00C, 0x703FD00D, '2005-02-09 10:00:00') /* Wall Hook (9686) */
     , (0x703FD00C, 0x703FD00E, '2005-02-09 10:00:00') /* Floor Hook (11697) */
     , (0x703FD00C, 0x703FD00F, '2005-02-09 10:00:00') /* Wall Hook (9686) */
     , (0x703FD00C, 0x703FD010, '2005-02-09 10:00:00') /* House Portal (11730) */
     , (0x703FD00C, 0x703FD012, '2005-02-09 10:00:00') /* Wall Hook (9686) */
     , (0x703FD00C, 0x703FD014, '2005-02-09 10:00:00') /* Floor Hook (11697) */
     , (0x703FD00C, 0x703FD015, '2005-02-09 10:00:00') /* Wall Hook (9686) */
     , (0x703FD00C, 0x703FD017, '2005-02-09 10:00:00') /* Wall Hook (9686) */
     , (0x703FD00C, 0x703FD018, '2005-02-09 10:00:00') /* Floor Hook (11697) */
     , (0x703FD00C, 0x703FD01A, '2005-02-09 10:00:00') /* Wall Hook (9686) */
     , (0x703FD00C, 0x703FD01B, '2005-02-09 10:00:00') /* Wall Hook (9686) */
     , (0x703FD00C, 0x703FD01C, '2005-02-09 10:00:00') /* Floor Hook (11697) */
     , (0x703FD00C, 0x703FD01D, '2005-02-09 10:00:00') /* Wall Hook (9686) */;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x703FD00D,  9686, 0x03FD0119, 19.9979, -34.8959, -4.3, 0.003683, 0, 0, -0.999993,  True, '2005-02-09 10:00:00'); /* Wall Hook */
/* @teleloc 0x03FD0119 [19.997900 -34.895901 -4.300000] 0.003683 0.000000 0.000000 -0.999993 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x703FD00E, 11697, 0x03FD0119, 20, -30, -5.995, 1, 0, 0, 0,  True, '2005-02-09 10:00:00'); /* Floor Hook */
/* @teleloc 0x03FD0119 [20.000000 -30.000000 -5.995000] 1.000000 0.000000 0.000000 0.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x703FD00F,  9686, 0x03FD0119, 24.8939, -29.9547, -4.3, 0.714424, 0, 0, -0.699713,  True, '2005-02-09 10:00:00'); /* Wall Hook */
/* @teleloc 0x03FD0119 [24.893900 -29.954700 -4.300000] 0.714424 0.000000 0.000000 -0.699713 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x703FD010, 11730, 0x03FD011F, 20, -50, -5.995, 1, 0, 0, 0,  True, '2005-02-09 10:00:00'); /* House Portal */
/* @teleloc 0x03FD011F [20.000000 -50.000000 -5.995000] 1.000000 0.000000 0.000000 0.000000 */

INSERT INTO `landblock_instance_link` (`parent_GUID`, `child_GUID`, `last_Modified`)
VALUES (0x703FD010, 0x703FD01F, '2005-02-09 10:00:00') /* Portal Linkspot (10762) */;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x703FD011,   568, 0x03FD0121, 20, -45.25, -6, 1, 0, 0, 0, False, '2005-02-09 10:00:00'); /* Door */
/* @teleloc 0x03FD0121 [20.000000 -45.250000 -6.000000] 1.000000 0.000000 0.000000 0.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x703FD012,  9686, 0x03FD012C, 29.8549, -34.3941, -4.3, -0.029195, 0, 0, -0.999574,  True, '2005-02-09 10:00:00'); /* Wall Hook */
/* @teleloc 0x03FD012C [29.854900 -34.394100 -4.300000] -0.029195 0.000000 0.000000 -0.999574 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x703FD013,   278, 0x03FD012E, 30, -25.25, -6, 1, 0, 0, 0, False, '2005-02-09 10:00:00'); /* Door */
/* @teleloc 0x03FD012E [30.000000 -25.250000 -6.000000] 1.000000 0.000000 0.000000 0.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x703FD014, 11697, 0x03FD012F, 40, -5.99258, -5.995, 1, 0, 0, 0,  True, '2005-02-09 10:00:00'); /* Floor Hook */
/* @teleloc 0x03FD012F [40.000000 -5.992580 -5.995000] 1.000000 0.000000 0.000000 0.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x703FD015,  9686, 0x03FD012F, 44.388, -10.2405, -4.3, 0.704517, 0, 0, -0.709687,  True, '2005-02-09 10:00:00'); /* Wall Hook */
/* @teleloc 0x03FD012F [44.388000 -10.240500 -4.300000] 0.704517 0.000000 0.000000 -0.709687 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x703FD016,   278, 0x03FD0131, 35.25, -10, -6, -0.707107, 0, 0, -0.707107, False, '2005-02-09 10:00:00'); /* Door */
/* @teleloc 0x03FD0131 [35.250000 -10.000000 -6.000000] -0.707107 0.000000 0.000000 -0.707107 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x703FD017,  9686, 0x03FD0132, -4.39398, -20.0622, 1.5, -0.696708, 0, 0, -0.717355,  True, '2005-02-09 10:00:00'); /* Wall Hook */
/* @teleloc 0x03FD0132 [-4.393980 -20.062201 1.500000] -0.696708 0.000000 0.000000 -0.717355 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x703FD018, 11697, 0x03FD0132, -0.752003, -24.0199, 0.005, -0.00525, 0, 0, 0.999986,  True, '2005-02-09 10:00:00'); /* Floor Hook */
/* @teleloc 0x03FD0132 [-0.752003 -24.019899 0.005000] -0.005250 0.000000 0.000000 0.999986 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x703FD019,   278, 0x03FD0134, 4.75, -20, 0, 0.707107, 0, 0, -0.707107, False, '2005-02-09 10:00:00'); /* Door */
/* @teleloc 0x03FD0134 [4.750000 -20.000000 0.000000] 0.707107 0.000000 0.000000 -0.707107 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x703FD01A,  9686, 0x03FD0139, 10.0959, -29.9483, 1.5, -0.354161, 0, 0, -0.935185,  True, '2005-02-09 10:00:00'); /* Wall Hook */
/* @teleloc 0x03FD0139 [10.095900 -29.948299 1.500000] -0.354161 0.000000 0.000000 -0.935185 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x703FD01B,  9686, 0x03FD013C, 29.9432, -20.0868, 1.5, 0.935786, 0, 0, -0.352568,  True, '2005-02-09 10:00:00'); /* Wall Hook */
/* @teleloc 0x03FD013C [29.943199 -20.086800 1.500000] 0.935786 0.000000 0.000000 -0.352568 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x703FD01C, 11697, 0x03FD0141, 44.1812, -30.4155, 0.005, 0.716417, 0, 0, -0.697672,  True, '2005-02-09 10:00:00'); /* Floor Hook */
/* @teleloc 0x03FD0141 [44.181198 -30.415501 0.005000] 0.716417 0.000000 0.000000 -0.697672 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x703FD01D,  9686, 0x03FD0141, 40.1348, -25.6021, 1.68725, 0.999755, 0, 0, -0.022137,  True, '2005-02-09 10:00:00'); /* Wall Hook */
/* @teleloc 0x03FD0141 [40.134800 -25.602100 1.687250] 0.999755 0.000000 0.000000 -0.022137 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x703FD01E,   278, 0x03FD0143, 35.25, -30, 0, -0.707107, 0, 0, -0.707107, False, '2005-02-09 10:00:00'); /* Door */
/* @teleloc 0x03FD0143 [35.250000 -30.000000 0.000000] -0.707107 0.000000 0.000000 -0.707107 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x703FD01F, 10762, 0x03FD011F, 117.519, 156.619, -2.795, -0.71455, 0, 0, 0.699585,  True, '2005-02-09 10:00:00'); /* Portal Linkspot */
/* @teleloc 0x03FD011F [117.518997 156.619003 -2.795000] -0.714550 0.000000 0.000000 0.699585 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x703FD020, 490356, 0x03FD0008, 10.43261, 189.023, 0.043274, 0.484293, 0, 0, -0.874906, False, '2025-09-05 23:29:34'); /* Hera's Vault */
/* @teleloc 0x03FD0008 [10.432610 189.022995 0.043274] 0.484293 0.000000 0.000000 -0.874906 */
