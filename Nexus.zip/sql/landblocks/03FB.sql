DELETE FROM `landblock_instance` WHERE `landblock` = 0x03FB;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x703FB000,  9687, 0x03FB0100, 0.023, -43.404, -5.995, 0, 0, 0, -1,  True, '2005-02-09 10:00:00'); /* Storage */
/* @teleloc 0x03FB0100 [0.023000 -43.403999 -5.995000] 0.000000 0.000000 0.000000 -1.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x703FB001,  9687, 0x03FB0100, -3.608, -39.98, -5.995, -0.707107, 0, 0, -0.707107,  True, '2005-02-09 10:00:00'); /* Storage */
/* @teleloc 0x03FB0100 [-3.608000 -39.980000 -5.995000] -0.707107 0.000000 0.000000 -0.707107 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x703FB002,   278, 0x03FB0102, 4.75, -40, -6, 0.707107, 0, 0, -0.707107, False, '2005-02-09 10:00:00'); /* Door */
/* @teleloc 0x03FB0102 [4.750000 -40.000000 -6.000000] 0.707107 0.000000 0.000000 -0.707107 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x703FB003, 11697, 0x03FB0103, 14.0306, -20.114, -5.995, 0.696707, 0, 0, -0.717356,  True, '2005-02-09 10:00:00'); /* Floor Hook */
/* @teleloc 0x03FB0103 [14.030600 -20.114000 -5.995000] 0.696707 0.000000 0.000000 -0.717356 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x703FB004,  9686, 0x03FB0103, 10.1259, -15.604, -4.32, -0.999989, 0, 0, -0.004782,  True, '2005-02-09 10:00:00'); /* Wall Hook */
/* @teleloc 0x03FB0103 [10.125900 -15.604000 -4.320000] -0.999989 0.000000 0.000000 -0.004782 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x703FB005,   278, 0x03FB0105, 10, -24.75, -6, 0, 0, 0, -1, False, '2005-02-09 10:00:00'); /* Door */
/* @teleloc 0x03FB0105 [10.000000 -24.750000 -6.000000] 0.000000 0.000000 0.000000 -1.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x703FB006, 11697, 0x03FB0110, 20, 4.13086, -5.995, 1, 0, 0, 0,  True, '2005-02-09 10:00:00'); /* Floor Hook */
/* @teleloc 0x03FB0110 [20.000000 4.130860 -5.995000] 1.000000 0.000000 0.000000 0.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x703FB007,  9686, 0x03FB0110, 15.6054, -0.007371, -4.3, -0.707107, 0, 0, -0.707107,  True, '2005-02-09 10:00:00'); /* Wall Hook */
/* @teleloc 0x03FB0110 [15.605400 -0.007371 -4.300000] -0.707107 0.000000 0.000000 -0.707107 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x703FB008,   278, 0x03FB0112, 20, -4.75, -6, 0, 0, 0, -1, False, '2005-02-09 10:00:00'); /* Door */
/* @teleloc 0x03FB0112 [20.000000 -4.750000 -6.000000] 0.000000 0.000000 0.000000 -1.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x703FB009,  9686, 0x03FB0118, 19.9588, -15.1013, -4.3, 1, 0, 0, 0,  True, '2005-02-09 10:00:00'); /* Wall Hook */
/* @teleloc 0x03FB0118 [19.958799 -15.101300 -4.300000] 1.000000 0.000000 0.000000 0.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x703FB00A, 11697, 0x03FB0118, 20, -20, -5.995, 1, 0, 0, 0,  True, '2005-02-09 10:00:00'); /* Floor Hook */
/* @teleloc 0x03FB0118 [20.000000 -20.000000 -5.995000] 1.000000 0.000000 0.000000 0.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x703FB00B,  9686, 0x03FB0118, 15.1014, -19.9684, -4.3, -0.714424, 0, 0, -0.699713,  True, '2005-02-09 10:00:00'); /* Wall Hook */
/* @teleloc 0x03FB0118 [15.101400 -19.968399 -4.300000] -0.714424 0.000000 0.000000 -0.699713 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x703FB00C, 10660, 0x03FB0118, 20.0682, -18.5777, -5.995, 1, 0, 0, 0, False, '2005-02-09 10:00:00'); /* Villa */
/* @teleloc 0x03FB0118 [20.068199 -18.577700 -5.995000] 1.000000 0.000000 0.000000 0.000000 */

INSERT INTO `landblock_instance_link` (`parent_GUID`, `child_GUID`, `last_Modified`)
VALUES (0x703FB00C, 0x703FB000, '2005-02-09 10:00:00') /* Storage (9687) */
     , (0x703FB00C, 0x703FB001, '2005-02-09 10:00:00') /* Storage (9687) */
     , (0x703FB00C, 0x703FB003, '2005-02-09 10:00:00') /* Floor Hook (11697) */
     , (0x703FB00C, 0x703FB004, '2005-02-09 10:00:00') /* Wall Hook (9686) */
     , (0x703FB00C, 0x703FB006, '2005-02-09 10:00:00') /* Floor Hook (11697) */
     , (0x703FB00C, 0x703FB007, '2005-02-09 10:00:00') /* Wall Hook (9686) */
     , (0x703FB00C, 0x703FB009, '2005-02-09 10:00:00') /* Wall Hook (9686) */
     , (0x703FB00C, 0x703FB00A, '2005-02-09 10:00:00') /* Floor Hook (11697) */
     , (0x703FB00C, 0x703FB00B, '2005-02-09 10:00:00') /* Wall Hook (9686) */
     , (0x703FB00C, 0x703FB00D, '2005-02-09 10:00:00') /* Wall Hook (9686) */
     , (0x703FB00C, 0x703FB00E, '2005-02-09 10:00:00') /* Floor Hook (11697) */
     , (0x703FB00C, 0x703FB00F, '2005-02-09 10:00:00') /* Wall Hook (9686) */
     , (0x703FB00C, 0x703FB010, '2005-02-09 10:00:00') /* House Portal (11730) */
     , (0x703FB00C, 0x703FB012, '2005-02-09 10:00:00') /* Wall Hook (9686) */
     , (0x703FB00C, 0x703FB014, '2005-02-09 10:00:00') /* Floor Hook (11697) */
     , (0x703FB00C, 0x703FB015, '2005-02-09 10:00:00') /* Wall Hook (9686) */
     , (0x703FB00C, 0x703FB017, '2005-02-09 10:00:00') /* Wall Hook (9686) */
     , (0x703FB00C, 0x703FB018, '2005-02-09 10:00:00') /* Floor Hook (11697) */
     , (0x703FB00C, 0x703FB01A, '2005-02-09 10:00:00') /* Wall Hook (9686) */
     , (0x703FB00C, 0x703FB01B, '2005-02-09 10:00:00') /* Wall Hook (9686) */
     , (0x703FB00C, 0x703FB01C, '2005-02-09 10:00:00') /* Floor Hook (11697) */
     , (0x703FB00C, 0x703FB01D, '2005-02-09 10:00:00') /* Wall Hook (9686) */;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x703FB00D,  9686, 0x03FB0119, 19.9979, -34.8959, -4.3, 0.003683, 0, 0, -0.999993,  True, '2005-02-09 10:00:00'); /* Wall Hook */
/* @teleloc 0x03FB0119 [19.997900 -34.895901 -4.300000] 0.003683 0.000000 0.000000 -0.999993 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x703FB00E, 11697, 0x03FB0119, 20, -30, -5.995, 1, 0, 0, 0,  True, '2005-02-09 10:00:00'); /* Floor Hook */
/* @teleloc 0x03FB0119 [20.000000 -30.000000 -5.995000] 1.000000 0.000000 0.000000 0.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x703FB00F,  9686, 0x03FB0119, 24.8939, -29.9547, -4.3, 0.714424, 0, 0, -0.699713,  True, '2005-02-09 10:00:00'); /* Wall Hook */
/* @teleloc 0x03FB0119 [24.893900 -29.954700 -4.300000] 0.714424 0.000000 0.000000 -0.699713 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x703FB010, 11730, 0x03FB011F, 20, -50, -5.995, 1, 0, 0, 0,  True, '2005-02-09 10:00:00'); /* House Portal */
/* @teleloc 0x03FB011F [20.000000 -50.000000 -5.995000] 1.000000 0.000000 0.000000 0.000000 */

INSERT INTO `landblock_instance_link` (`parent_GUID`, `child_GUID`, `last_Modified`)
VALUES (0x703FB010, 0x703FB01F, '2005-02-09 10:00:00') /* Portal Linkspot (10762) */;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x703FB011,   568, 0x03FB0121, 20, -45.25, -6, 1, 0, 0, 0, False, '2005-02-09 10:00:00'); /* Door */
/* @teleloc 0x03FB0121 [20.000000 -45.250000 -6.000000] 1.000000 0.000000 0.000000 0.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x703FB012,  9686, 0x03FB012C, 29.8549, -34.3941, -4.3, -0.029195, 0, 0, -0.999574,  True, '2005-02-09 10:00:00'); /* Wall Hook */
/* @teleloc 0x03FB012C [29.854900 -34.394100 -4.300000] -0.029195 0.000000 0.000000 -0.999574 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x703FB013,   278, 0x03FB012E, 30, -25.25, -6, 1, 0, 0, 0, False, '2005-02-09 10:00:00'); /* Door */
/* @teleloc 0x03FB012E [30.000000 -25.250000 -6.000000] 1.000000 0.000000 0.000000 0.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x703FB014, 11697, 0x03FB012F, 40, -5.99258, -5.995, 1, 0, 0, 0,  True, '2005-02-09 10:00:00'); /* Floor Hook */
/* @teleloc 0x03FB012F [40.000000 -5.992580 -5.995000] 1.000000 0.000000 0.000000 0.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x703FB015,  9686, 0x03FB012F, 44.388, -10.2405, -4.3, 0.704517, 0, 0, -0.709687,  True, '2005-02-09 10:00:00'); /* Wall Hook */
/* @teleloc 0x03FB012F [44.388000 -10.240500 -4.300000] 0.704517 0.000000 0.000000 -0.709687 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x703FB016,   278, 0x03FB0131, 35.25, -10, -6, -0.707107, 0, 0, -0.707107, False, '2005-02-09 10:00:00'); /* Door */
/* @teleloc 0x03FB0131 [35.250000 -10.000000 -6.000000] -0.707107 0.000000 0.000000 -0.707107 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x703FB017,  9686, 0x03FB0132, -4.39398, -20.0622, 1.5, -0.696708, 0, 0, -0.717355,  True, '2005-02-09 10:00:00'); /* Wall Hook */
/* @teleloc 0x03FB0132 [-4.393980 -20.062201 1.500000] -0.696708 0.000000 0.000000 -0.717355 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x703FB018, 11697, 0x03FB0132, -0.752003, -24.0199, 0.005, -0.00525, 0, 0, 0.999986,  True, '2005-02-09 10:00:00'); /* Floor Hook */
/* @teleloc 0x03FB0132 [-0.752003 -24.019899 0.005000] -0.005250 0.000000 0.000000 0.999986 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x703FB019,   278, 0x03FB0134, 4.75, -20, 0, 0.707107, 0, 0, -0.707107, False, '2005-02-09 10:00:00'); /* Door */
/* @teleloc 0x03FB0134 [4.750000 -20.000000 0.000000] 0.707107 0.000000 0.000000 -0.707107 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x703FB01A,  9686, 0x03FB0139, 10.0959, -29.9483, 1.5, -0.354161, 0, 0, -0.935185,  True, '2005-02-09 10:00:00'); /* Wall Hook */
/* @teleloc 0x03FB0139 [10.095900 -29.948299 1.500000] -0.354161 0.000000 0.000000 -0.935185 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x703FB01B,  9686, 0x03FB013C, 29.9432, -20.0868, 1.5, 0.935786, 0, 0, -0.352568,  True, '2005-02-09 10:00:00'); /* Wall Hook */
/* @teleloc 0x03FB013C [29.943199 -20.086800 1.500000] 0.935786 0.000000 0.000000 -0.352568 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x703FB01C, 11697, 0x03FB0141, 44.1812, -30.4155, 0.005, 0.716417, 0, 0, -0.697672,  True, '2005-02-09 10:00:00'); /* Floor Hook */
/* @teleloc 0x03FB0141 [44.181198 -30.415501 0.005000] 0.716417 0.000000 0.000000 -0.697672 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x703FB01D,  9686, 0x03FB0141, 40.1348, -25.6021, 1.68725, 0.999755, 0, 0, -0.022137,  True, '2005-02-09 10:00:00'); /* Wall Hook */
/* @teleloc 0x03FB0141 [40.134800 -25.602100 1.687250] 0.999755 0.000000 0.000000 -0.022137 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x703FB01E,   278, 0x03FB0143, 35.25, -30, 0, -0.707107, 0, 0, -0.707107, False, '2005-02-09 10:00:00'); /* Door */
/* @teleloc 0x03FB0143 [35.250000 -30.000000 0.000000] -0.707107 0.000000 0.000000 -0.707107 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x703FB01F, 10762, 0x03FB011F, 141.526, 155.774, 99.205, -0.704614, 0, 0, 0.709591,  True, '2005-02-09 10:00:00'); /* Portal Linkspot */
/* @teleloc 0x03FB011F [141.526001 155.774002 99.205002] -0.704614 0.000000 0.000000 0.709591 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x703FB020, 4200152, 0x03FB0040, 178.559, 176.495, 0.055, 0.34217, 0, 0, -0.939638, False, '2025-07-07 04:01:14'); /* Gate */
/* @teleloc 0x03FB0040 [178.559006 176.494995 0.055000] 0.342170 0.000000 0.000000 -0.939638 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x703FB021, 4200152, 0x03FB0040, 169.145, 170.258, 0.055, -0.192749, 0, 0, -0.981248, False, '2025-07-07 04:01:19'); /* Gate */
/* @teleloc 0x03FB0040 [169.145004 170.257996 0.055000] -0.192749 0.000000 0.000000 -0.981248 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x703FB022, 4200152, 0x03FB0038, 156.888, 177.365, 0.055, -0.521505, 0, 0, -0.853248, False, '2025-07-07 04:01:23'); /* Gate */
/* @teleloc 0x03FB0038 [156.888000 177.365005 0.055000] -0.521505 0.000000 0.000000 -0.853248 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x703FB023, 4200152, 0x03FB0038, 152.294, 189.227, 0.055, -0.710364, 0, 0, -0.703834, False, '2025-07-07 04:01:26'); /* Gate */
/* @teleloc 0x03FB0038 [152.294006 189.227005 0.055000] -0.710364 0.000000 0.000000 -0.703834 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x703FB024, 4200152, 0x03FB0040, 187.917, 187.025, 0.055, -0.451405, 0, 0, 0.892319, False, '2025-07-07 04:01:34'); /* Gate */
/* @teleloc 0x03FB0040 [187.917007 187.024994 0.055000] -0.451405 0.000000 0.000000 0.892319 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x703FB025, 86656970, 0x03FB0040, 170.281, 172.493, 0, -0.312027, 0, 0, -0.950073, False, '2025-07-07 04:08:04');
/* @teleloc 0x03FB0040 [170.281006 172.492996 0.000000] -0.312027 0.000000 0.000000 -0.950073 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x703FB026, 86653140, 0x03FB0040, 180.134, 180.789, 0.055, -0.907131, 0, 0, -0.420847, False, '2025-07-07 04:10:59'); /* Big Rock */
/* @teleloc 0x03FB0040 [180.134003 180.789001 0.055000] -0.907131 0.000000 0.000000 -0.420847 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x703FB027, 86653140, 0x03FB0038, 154.834, 186.225, 0.055, -0.784648, 0, 0, 0.619942, False, '2025-07-07 04:11:06'); /* Big Rock */
/* @teleloc 0x03FB0038 [154.834000 186.225006 0.055000] -0.784648 0.000000 0.000000 0.619942 */
