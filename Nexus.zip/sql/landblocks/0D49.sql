DELETE FROM `landblock_instance` WHERE `landblock` = 0x0D49;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70D49000, 490174, 0x0D490035, 145.464, 105.5486, -0.845, -0.033017, 0, 0, -0.999455, False, '2025-07-29 17:07:21'); /* Drudge Maurader Generator */
/* @teleloc 0x0D490035 [145.464005 105.548599 -0.845000] -0.033017 0.000000 0.000000 -0.999455 */
