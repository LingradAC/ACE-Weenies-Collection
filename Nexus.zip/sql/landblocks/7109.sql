DELETE FROM `landblock_instance` WHERE `landblock` = 0x7109;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x77109000, 24491, 0x71090000, 23.918, 186, 31.0068, 0.999886, 0, 0, -0.015097, False, '2021-11-01 00:00:00'); /* Ulgrim Island Volcano Caldera Gen */
/* @teleloc 0x71090000 [23.917999 186.000000 31.006800] 0.999886 0.000000 0.000000 -0.015097 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x77109002, 24492, 0x71090000, 0.413126, 175.952, 24.2167, -0.392736, 0, 0, -0.919651, False, '2021-11-01 00:00:00'); /* Ulgrim Island Volcano-Mix Gen */
/* @teleloc 0x71090000 [0.413126 175.951996 24.216700] -0.392736 0.000000 0.000000 -0.919651 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x77109005, 24489, 0x71090000, 81.8635, 177.447, 3.57453, 0.055697, 0, 0, 0.998448, False, '2021-11-01 00:00:00'); /* Ulgrim Island Rock-Mix Gen */
/* @teleloc 0x71090000 [81.863503 177.447006 3.574530] 0.055697 0.000000 0.000000 0.998448 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x77109006, 24489, 0x71090000, 62.5622, 139.515, 2.74749, 0.87991, 0, 0, 0.475141, False, '2021-11-01 00:00:00'); /* Ulgrim Island Rock-Mix Gen */
/* @teleloc 0x71090000 [62.562199 139.514999 2.747490] 0.879910 0.000000 0.000000 0.475141 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x77109007, 24489, 0x71090000, 166.818, 185.043, 4.84552, -0.99477, 0, 0, 0.102142, False, '2021-11-01 00:00:00'); /* Ulgrim Island Rock-Mix Gen */
/* @teleloc 0x71090000 [166.817993 185.042999 4.845520] -0.994770 0.000000 0.000000 0.102142 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x77109008, 24487, 0x71090000, 5.23279, 19.4331, -0.095, -0.544086, 0, 0, 0.83903, False, '2021-11-01 00:00:00'); /* Ulgrim Island Beach Gen */
/* @teleloc 0x71090000 [5.232790 19.433100 -0.095000] -0.544086 0.000000 0.000000 0.839030 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x77109009, 24487, 0x71090000, 85.5233, 24.1951, -0.095, -0.659472, 0, 0, 0.751729, False, '2021-11-01 00:00:00'); /* Ulgrim Island Beach Gen */
/* @teleloc 0x71090000 [85.523300 24.195101 -0.095000] -0.659472 0.000000 0.000000 0.751729 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7710900A, 24487, 0x71090000, 40.7488, 39.2092, 1.27243, 0.467938, 0, 0, -0.883761, False, '2021-11-01 00:00:00'); /* Ulgrim Island Beach Gen */
/* @teleloc 0x71090000 [40.748798 39.209202 1.272430] 0.467938 0.000000 0.000000 -0.883761 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7710900C, 24487, 0x71090000, 118.178, 71.7924, -0.095, -0.061987, 0, 0, -0.998077, False, '2021-11-01 00:00:00'); /* Ulgrim Island Beach Gen */
/* @teleloc 0x71090000 [118.178001 71.792397 -0.095000] -0.061987 0.000000 0.000000 -0.998077 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7710900D, 24487, 0x71090000, 168.014, 79.4495, -0.095, 0.998414, 0, 0, 0.056297, False, '2021-11-01 00:00:00'); /* Ulgrim Island Beach Gen */
/* @teleloc 0x71090000 [168.014008 79.449501 -0.095000] 0.998414 0.000000 0.000000 0.056297 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7710900E, 24487, 0x71090000, 191.504, 50.9138, -0.095, -0.317107, 0, 0, -0.94839, False, '2021-11-01 00:00:00'); /* Ulgrim Island Beach Gen */
/* @teleloc 0x71090000 [191.503998 50.913799 -0.095000] -0.317107 0.000000 0.000000 -0.948390 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7710900F, 24487, 0x71090000, 100.353, 21.7625, -0.095, -0.926473, 0, 0, -0.37636, False, '2021-11-01 00:00:00'); /* Ulgrim Island Beach Gen */
/* @teleloc 0x71090000 [100.352997 21.762501 -0.095000] -0.926473 0.000000 0.000000 -0.376360 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x77109013, 24490, 0x71090000, 86.3231, 96.9252, 2.88351, 0.798506, 0, 0, -0.601987, False, '2021-11-01 00:00:00'); /* Ulgrim Island Tree-Line Gen */
/* @teleloc 0x71090000 [86.323097 96.925201 2.883510] 0.798506 0.000000 0.000000 -0.601987 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x77109015, 24490, 0x71090000, 137.891, 114.168, 5.02793, 0.799881, 0, 0, -0.600159, False, '2021-11-01 00:00:00'); /* Ulgrim Island Tree-Line Gen */
/* @teleloc 0x71090000 [137.891006 114.167999 5.027930] 0.799881 0.000000 0.000000 -0.600159 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x77109016, 24490, 0x71090000, 180.619, 126.607, 5.05657, -0.985202, 0, 0, -0.171395, False, '2021-11-01 00:00:00'); /* Ulgrim Island Tree-Line Gen */
/* @teleloc 0x71090000 [180.619003 126.607002 5.056570] -0.985202 0.000000 0.000000 -0.171395 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x77109018, 24488, 0x71090000, 124.748, 147.93, 3.67753, 0.513486, 0, 0, 0.858098, False, '2021-11-01 00:00:00'); /* Ulgrim Island Jungle-Mix Gen */
/* @teleloc 0x71090000 [124.748001 147.929993 3.677530] 0.513486 0.000000 0.000000 0.858098 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7710901A, 24488, 0x71090000, 24.3908, 142.216, 7.75866, 0.712963, 0, 0, 0.701202, False, '2021-11-01 00:00:00'); /* Ulgrim Island Jungle-Mix Gen */
/* @teleloc 0x71090000 [24.390800 142.216003 7.758660] 0.712963 0.000000 0.000000 0.701202 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7710901B,  1154, 0x7109002C, 123.078, 87.5718, 1.30015, -0.061987, 0, 0, -0.998077, False, '2021-11-01 00:00:00'); /* Linkable Monster Generator */
/* @teleloc 0x7109002C [123.078003 87.571800 1.300150] -0.061987 0.000000 0.000000 -0.998077 */

INSERT INTO `landblock_instance_link` (`parent_GUID`, `child_GUID`, `last_Modified`)
VALUES (0x7710901B, 0x7710901D, '2021-11-01 00:00:00') /* Mysterious Hatch (32807) */
     , (0x7710901B, 0x7710901E, '2021-11-01 00:00:00') /* The Black Breath (32804) */;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7710901D, 32807, 0x7109001F, 91.3769, 148.065, 2, -0.863652, 0, 0, -0.504088,  True, '2021-11-01 00:00:00'); /* Mysterious Hatch */
/* @teleloc 0x7109001F [91.376900 148.065002 2.000000] -0.863652 0.000000 0.000000 -0.504088 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7710901E, 32804, 0x71090026, 117.412, 143.212, 3.85996, 0.513486, 0, 0, 0.858098,  True, '2021-11-01 00:00:00'); /* The Black Breath */
/* @teleloc 0x71090026 [117.412003 143.212006 3.859960] 0.513486 0.000000 0.000000 0.858098 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x771096A5,  1154, 0x7109001F, 94.0415, 165.899, 2, -0.038349, 0, 0, -0.999264, False, '2021-11-01 00:00:00'); /* Linkable Monster Generator */
/* @teleloc 0x7109001F [94.041496 165.899002 2.000000] -0.038349 0.000000 0.000000 -0.999264 */

INSERT INTO `landblock_instance_link` (`parent_GUID`, `child_GUID`, `last_Modified`)
VALUES (0x771096A5, 0x771096A6, '2021-11-01 00:00:00') /* Exploration Marker (39795) */;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x771096A6, 39795, 0x7109001F, 94.0415, 165.899, 2, -0.038349, 0, 0, -0.999264,  True, '2021-11-01 00:00:00'); /* Exploration Marker */
/* @teleloc 0x7109001F [94.041496 165.899002 2.000000] -0.038349 0.000000 0.000000 -0.999264 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x771096A7, 73217237, 0x7109003C, 171.884, 84.9909, -0.045, -0.975918, 0, 0, -0.21814, False, '2025-08-10 19:45:04'); /* Islandgolemgen */
/* @teleloc 0x7109003C [171.884003 84.990898 -0.045000] -0.975918 0.000000 0.000000 -0.218140 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x771096A8, 73217237, 0x7109001A, 77.1711, 47.8226, -0.045, -0.231014, 0, 0, -0.97295, False, '2025-08-10 19:45:13'); /* Islandgolemgen */
/* @teleloc 0x7109001A [77.171097 47.822601 -0.045000] -0.231014 0.000000 0.000000 -0.972950 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x771096A9, 73217237, 0x71090006, 15.4869, 140.552, 9.03403, 0.798096, 0, 0, 0.60253, False, '2025-08-12 08:50:21'); /* Islandgolemgen */
/* @teleloc 0x71090006 [15.486900 140.552002 9.034030] 0.798096 0.000000 0.000000 0.602530 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x771096AA, 73217237, 0x7109003C, 185.925, 72.32, -0.395, 0.954473, 0, 0, 0.298297, False, '2025-08-12 12:39:44'); /* Islandgolemgen */
/* @teleloc 0x7109003C [185.925003 72.320000 -0.395000] 0.954473 0.000000 0.000000 0.298297 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x771096AB, 73217237, 0x7109002B, 137.83, 70.3968, -0.045, 0.549163, 0, 0, 0.835715, False, '2025-08-12 12:39:48'); /* Islandgolemgen */
/* @teleloc 0x7109002B [137.830002 70.396797 -0.045000] 0.549163 0.000000 0.000000 0.835715 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x771096AC, 73217237, 0x7109001A, 95.5436, 47.9034, -0.395, 0.479947, 0, 0, 0.877297, False, '2025-08-12 12:39:51'); /* Islandgolemgen */
/* @teleloc 0x7109001A [95.543602 47.903400 -0.395000] 0.479947 0.000000 0.000000 0.877297 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x771096AD, 73217237, 0x71090012, 65.9144, 29.9167, 0.548058, 0.6384, 0, 0, 0.769705, False, '2025-08-12 12:39:54'); /* Islandgolemgen */
/* @teleloc 0x71090012 [65.914398 29.916700 0.548058] 0.638400 0.000000 0.000000 0.769705 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x771096AE, 73217237, 0x71090002, 23.8106, 24.566, 0.102169, 0.747212, 0, 0, 0.664585, False, '2025-08-12 12:39:56'); /* Islandgolemgen */
/* @teleloc 0x71090002 [23.810600 24.566000 0.102169] 0.747212 0.000000 0.000000 0.664585 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x771096AF, 83217237, 0x7109003A, 191.947, 38.3852, -0.045, -0.919306, 0, 0, -0.393543, False, '2025-09-04 22:34:19'); /* Trophy Keeper of Honor */
/* @teleloc 0x7109003A [191.947006 38.385201 -0.045000] -0.919306 0.000000 0.000000 -0.393543 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x771096B0, 83217237, 0x7109003B, 184.554, 48.5955, -0.045, -0.999561, 0, 0, 0.02964, False, '2025-09-04 22:34:21'); /* Trophy Keeper of Honor */
/* @teleloc 0x7109003B [184.554001 48.595501 -0.045000] -0.999561 0.000000 0.000000 0.029640 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x771096B1, 83217237, 0x7109003C, 176.021, 72.0838, -0.045, -0.821704, 0, 0, -0.569914, False, '2025-09-04 22:34:22'); /* Trophy Keeper of Honor */
/* @teleloc 0x7109003C [176.020996 72.083801 -0.045000] -0.821704 0.000000 0.000000 -0.569914 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x771096B2, 83217237, 0x7109002B, 136.873, 67.3163, -0.045, -0.690714, 0, 0, -0.723128, False, '2025-09-04 22:34:25'); /* Trophy Keeper of Honor */
/* @teleloc 0x7109002B [136.873001 67.316299 -0.045000] -0.690714 0.000000 0.000000 -0.723128 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x771096B3, 83217237, 0x71090023, 113.091, 65.5549, -0.045, -0.505765, 0, 0, -0.862671, False, '2025-09-04 22:34:27'); /* Trophy Keeper of Honor */
/* @teleloc 0x71090023 [113.091003 65.554901 -0.045000] -0.505765 0.000000 0.000000 -0.862671 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x771096B4, 83217237, 0x7109001A, 86.909, 38.2115, -0.395, -0.303303, 0, 0, -0.952894, False, '2025-09-04 22:34:29'); /* Trophy Keeper of Honor */
/* @teleloc 0x7109001A [86.908997 38.211498 -0.395000] -0.303303 0.000000 0.000000 -0.952894 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x771096B5, 83217237, 0x71090001, 23.5139, 18.8442, -0.045, -0.722345, 0, 0, -0.691533, False, '2025-09-04 22:34:34'); /* Trophy Keeper of Honor */
/* @teleloc 0x71090001 [23.513901 18.844200 -0.045000] -0.722345 0.000000 0.000000 -0.691533 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x771096B6, 73217237, 0x7109002C, 140.827, 94.4724, 1.9277, 0.998714, 0, 0, 0.050698, False, '2025-09-06 02:51:03'); /* Islandgolemgen */
/* @teleloc 0x7109002C [140.826996 94.472397 1.927700] 0.998714 0.000000 0.000000 0.050698 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x771096B7, 73217237, 0x71090036, 146.713, 129.004, 5.3047, 0.985266, 0, 0, 0.171026, False, '2025-09-06 02:51:06'); /* Islandgolemgen */
/* @teleloc 0x71090036 [146.712997 129.003998 5.304700] 0.985266 0.000000 0.000000 0.171026 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x771096B8, 73217237, 0x71090037, 160.744, 160.536, 2.67699, 0.779963, 0, 0, -0.625826, False, '2025-09-06 02:51:09'); /* Islandgolemgen */
/* @teleloc 0x71090037 [160.744003 160.535995 2.676990] 0.779963 0.000000 0.000000 -0.625826 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x771096B9, 73217237, 0x7109003F, 189.631, 165.201, 0.952214, 0.517675, 0, 0, -0.855577, False, '2025-09-06 02:51:12'); /* Islandgolemgen */
/* @teleloc 0x7109003F [189.630997 165.201004 0.952214] 0.517675 0.000000 0.000000 -0.855577 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x771096BA, 73217237, 0x7109003E, 185.461, 143.942, 5.51007, 0.369122, 0, 0, 0.929381, False, '2025-09-06 02:51:21'); /* Islandgolemgen */
/* @teleloc 0x7109003E [185.460999 143.942001 5.510070] 0.369122 0.000000 0.000000 0.929381 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x771096BB, 73217237, 0x7109002E, 136.761, 135.427, 4.7694, 0.702582, 0, 0, 0.711603, False, '2025-09-06 02:51:25'); /* Islandgolemgen */
/* @teleloc 0x7109002E [136.761002 135.427002 4.769400] 0.702582 0.000000 0.000000 0.711603 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x771096BC, 73217237, 0x71090026, 102.124, 133.895, 3.40749, 0.65058, 0, 0, 0.759438, False, '2025-09-06 02:51:28'); /* Islandgolemgen */
/* @teleloc 0x71090026 [102.124001 133.895004 3.407490] 0.650580 0.000000 0.000000 0.759438 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x771096BD, 73217237, 0x7109001F, 90.8133, 149.914, 2.055, 0.980265, 0, 0, 0.197688, False, '2025-09-06 02:51:30'); /* Islandgolemgen */
/* @teleloc 0x7109001F [90.813301 149.914001 2.055000] 0.980265 0.000000 0.000000 0.197688 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x771096BE, 73217237, 0x71090020, 95.0718, 181.207, 4.25613, 0.999449, 0, 0, -0.033202, False, '2025-09-06 02:51:32'); /* Islandgolemgen */
/* @teleloc 0x71090020 [95.071800 181.207001 4.256130] 0.999449 0.000000 0.000000 -0.033202 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x771096BF, 73217237, 0x71090007, 22.9769, 160.017, 25.6628, 0.9866, 0, 0, 0.16316, False, '2025-09-06 02:51:44'); /* Islandgolemgen */
/* @teleloc 0x71090007 [22.976900 160.016998 25.662800] 0.986600 0.000000 0.000000 0.163160 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x771096C0, 73217237, 0x71090008, 20.4948, 175.498, 33.5376, 0.960964, 0, 0, -0.276672, False, '2025-09-06 02:51:46'); /* Islandgolemgen */
/* @teleloc 0x71090008 [20.494801 175.498001 33.537601] 0.960964 0.000000 0.000000 -0.276672 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x771096C1, 73217237, 0x7109002C, 137.361, 72.1219, 0.065156, -0.746472, 0, 0, -0.665417, False, '2025-09-06 18:57:28'); /* Islandgolemgen */
/* @teleloc 0x7109002C [137.360992 72.121902 0.065156] -0.746472 0.000000 0.000000 -0.665417 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x771096C2, 73217237, 0x71090023, 101.995, 64.0773, -0.045, -0.629732, 0, 0, -0.776812, False, '2025-09-06 18:57:30'); /* Islandgolemgen */
/* @teleloc 0x71090023 [101.995003 64.077301 -0.045000] -0.629732 0.000000 0.000000 -0.776812 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x771096C3, 73217237, 0x7109001A, 85.9541, 45.9861, -0.395, -0.195338, 0, 0, -0.980736, False, '2025-09-06 18:57:32'); /* Islandgolemgen */
/* @teleloc 0x7109001A [85.954102 45.986099 -0.395000] -0.195338 0.000000 0.000000 -0.980736 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x771096C4, 73217237, 0x71090012, 52.0087, 37.6851, 1.19542, -0.682312, 0, 0, -0.731061, False, '2025-09-06 18:57:35'); /* Islandgolemgen */
/* @teleloc 0x71090012 [52.008701 37.685101 1.195420] -0.682312 0.000000 0.000000 -0.731061 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x771096C5, 73217237, 0x71090003, 6.5937, 54.16497, 0.604475, -0.937486, 0, 0, -0.348023, False, '2025-09-06 18:57:39'); /* Islandgolemgen */
/* @teleloc 0x71090003 [6.593700 54.164970 0.604475] -0.937486 0.000000 0.000000 -0.348023 */
