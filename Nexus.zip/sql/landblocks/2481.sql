DELETE FROM `landblock_instance` WHERE `landblock` = 0x2481;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x72481000,   412, 0x24810000, 84, 129.48, 220, 1, 0, 0, 0, False, '2005-02-09 10:00:00'); /* Door */
/* @teleloc 0x24810000 [84.000000 129.479996 220.000000] 1.000000 0.000000 0.000000 0.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x72481002,   171, 0x24810000, 88.5596, 127.871, 220.005, 0.673382, 0, 0, 0.739294, False, '2005-02-09 10:00:00'); /* Vat */
/* @teleloc 0x24810000 [88.559601 127.871002 220.005005] 0.673382 0.000000 0.000000 0.739294 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x72481003, 86653879, 0x24810102, 85.27932, 132.7731, 219.205, -0.861921, 0, 0, 0.507043, False, '2025-07-29 13:33:44'); /* BLUE BALL OF LIGHT */
/* @teleloc 0x24810102 [85.279320 132.773102 219.205002] -0.861921 0.000000 0.000000 0.507043 */
