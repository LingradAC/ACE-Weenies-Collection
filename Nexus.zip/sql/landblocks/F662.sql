DELETE FROM `landblock_instance` WHERE `landblock` = 0xF662;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F662000, 490118, 0xF6620010, 47.8593, 177.297, 8.3771, 0.254758, 0, 0, -0.967005, False, '2023-12-31 09:40:48'); /* Outpost Large Tree2 */
/* @teleloc 0xF6620010 [47.859299 177.296997 8.377100] 0.254758 0.000000 0.000000 -0.967005 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F662001, 490118, 0xF6620027, 109.733, 151.36, 17.8353, 0.600506, 0, 0, -0.799621, False, '2023-12-31 09:40:54'); /* Outpost Large Tree2 */
/* @teleloc 0xF6620027 [109.733002 151.360001 17.835300] 0.600506 0.000000 0.000000 -0.799621 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F662002, 490116, 0xF662002E, 143.37, 143.75, 16.0134, 0.977762, 0, 0, -0.209716, False, '2023-12-31 09:40:59'); /* Outpost Small Tree */
/* @teleloc 0xF662002E [143.369995 143.750000 16.013399] 0.977762 0.000000 0.000000 -0.209716 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F662004, 490118, 0xF6620034, 151.487, 94.9974, 7.80434, -0.956973, 0, 0, -0.290177, False, '2024-02-10 11:22:11'); /* Outpost Large Tree2 */
/* @teleloc 0xF6620034 [151.487000 94.997398 7.804340] -0.956973 0.000000 0.000000 -0.290177 */
