DELETE FROM `landblock_instance` WHERE `landblock` = 0xE9EC;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E9EC000, 73217237, 0xE9EC000B, 42.3139, 52.7013, 0.055, -0.009966, 0, 0, -0.99995, False, '2025-09-08 17:01:20'); /* Islandgolemgen */
/* @teleloc 0xE9EC000B [42.313900 52.701302 0.055000] -0.009966 0.000000 0.000000 -0.999950 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E9EC001, 73217237, 0xE9EC000A, 46.8439, 46.7573, 0.055, 0.176602, 0, 0, -0.984282, False, '2025-09-08 17:01:21'); /* Islandgolemgen */
/* @teleloc 0xE9EC000A [46.843899 46.757301 0.055000] 0.176602 0.000000 0.000000 -0.984282 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E9EC002, 73217237, 0xE9EC0012, 51.3247, 40.619, 0.055, 0.176602, 0, 0, -0.984282, False, '2025-09-08 17:01:22'); /* Islandgolemgen */
/* @teleloc 0xE9EC0012 [51.324699 40.618999 0.055000] 0.176602 0.000000 0.000000 -0.984282 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E9EC003, 73217237, 0xE9EC0012, 58.6968, 30.9171, 0.883971, 0.176602, 0, 0, -0.984282, False, '2025-09-08 17:01:23'); /* Islandgolemgen */
/* @teleloc 0xE9EC0012 [58.696800 30.917101 0.883971] 0.176602 0.000000 0.000000 -0.984282 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E9EC004, 73217237, 0xE9EC0012, 58.6968, 30.9171, 0.883971, 0.176602, 0, 0, -0.984282, False, '2025-09-08 17:01:24'); /* Islandgolemgen */
/* @teleloc 0xE9EC0012 [58.696800 30.917101 0.883971] 0.176602 0.000000 0.000000 -0.984282 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E9EC005, 73217237, 0xE9EC0012, 58.6968, 30.9171, 0.883971, 0.176602, 0, 0, -0.984282, False, '2025-09-08 17:01:24'); /* Islandgolemgen */
/* @teleloc 0xE9EC0012 [58.696800 30.917101 0.883971] 0.176602 0.000000 0.000000 -0.984282 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E9EC006, 73217237, 0xE9EC0011, 66.6803, 19.305, 1.66666, 0.176602, 0, 0, -0.984282, False, '2025-09-08 17:01:24'); /* Islandgolemgen */
/* @teleloc 0xE9EC0011 [66.680298 19.305000 1.666660] 0.176602 0.000000 0.000000 -0.984282 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E9EC007, 73217237, 0xE9EC0011, 70.115, 14.3093, 0.067092, 0.176602, 0, 0, -0.984282, False, '2025-09-08 17:01:25'); /* Islandgolemgen */
/* @teleloc 0xE9EC0011 [70.114998 14.309300 0.067092] 0.176602 0.000000 0.000000 -0.984282 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E9EC008, 73217237, 0xE9EC0019, 72.0018, 11.5649, 0.055, 0.176602, 0, 0, -0.984282, False, '2025-09-08 17:01:25'); /* Islandgolemgen */
/* @teleloc 0xE9EC0019 [72.001801 11.564900 0.055000] 0.176602 0.000000 0.000000 -0.984282 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E9EC009, 73217237, 0xE9EC0011, 55.2565, 8.33022, 1.36389, -0.989577, 0, 0, -0.144008, False, '2025-09-08 17:01:31'); /* Islandgolemgen */
/* @teleloc 0xE9EC0011 [55.256500 8.330220 1.363890] -0.989577 0.000000 0.000000 -0.144008 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E9EC00A, 73217237, 0xE9EC0011, 55.2565, 8.33022, 1.36389, -0.989577, 0, 0, -0.144008, False, '2025-09-08 17:01:31'); /* Islandgolemgen */
/* @teleloc 0xE9EC0011 [55.256500 8.330220 1.363890] -0.989577 0.000000 0.000000 -0.144008 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E9EC00B, 73217237, 0xE9EC000A, 45.9146, 24.0479, 0.055, -0.989577, 0, 0, -0.144008, False, '2025-09-08 17:01:33'); /* Islandgolemgen */
/* @teleloc 0xE9EC000A [45.914600 24.047899 0.055000] -0.989577 0.000000 0.000000 -0.144008 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E9EC00C, 73217237, 0xE9EC000A, 38.7661, 35.8039, 1.83702, -0.989577, 0, 0, -0.144008, False, '2025-09-08 17:01:34'); /* Islandgolemgen */
/* @teleloc 0xE9EC000A [38.766102 35.803902 1.837020] -0.989577 0.000000 0.000000 -0.144008 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E9EC00D, 73217237, 0xE9EC000A, 38.7661, 35.8039, 1.83702, -0.989577, 0, 0, -0.144008, False, '2025-09-08 17:01:34'); /* Islandgolemgen */
/* @teleloc 0xE9EC000A [38.766102 35.803902 1.837020] -0.989577 0.000000 0.000000 -0.144008 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E9EC00E, 73217237, 0xE9EC000A, 38.7661, 35.8039, 1.83702, -0.989577, 0, 0, -0.144008, False, '2025-09-08 17:01:35'); /* Islandgolemgen */
/* @teleloc 0xE9EC000A [38.766102 35.803902 1.837020] -0.989577 0.000000 0.000000 -0.144008 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E9EC00F, 73217237, 0xE9EC000A, 38.7661, 35.8039, 1.83702, -0.989577, 0, 0, -0.144008, False, '2025-09-08 17:01:35'); /* Islandgolemgen */
/* @teleloc 0xE9EC000A [38.766102 35.803902 1.837020] -0.989577 0.000000 0.000000 -0.144008 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E9EC010, 73217237, 0xE9EC000B, 30.1041, 71.7487, 0.636674, -0.856671, 0, 0, 0.515863, False, '2025-09-08 17:01:36'); /* Islandgolemgen */
/* @teleloc 0xE9EC000B [30.104099 71.748703 0.636674] -0.856671 0.000000 0.000000 0.515863 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E9EC011, 73217237, 0xE9EC000B, 30.1041, 71.7487, 0.636674, -0.856671, 0, 0, 0.515863, False, '2025-09-08 17:01:37'); /* Islandgolemgen */
/* @teleloc 0xE9EC000B [30.104099 71.748703 0.636674] -0.856671 0.000000 0.000000 0.515863 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E9EC012, 73217237, 0xE9EC000C, 39.9363, 76.9523, 1.82111, -0.856671, 0, 0, 0.515863, False, '2025-09-08 17:01:37'); /* Islandgolemgen */
/* @teleloc 0xE9EC000C [39.936298 76.952301 1.821110] -0.856671 0.000000 0.000000 0.515863 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E9EC013, 73217237, 0xE9EC0014, 56.9815, 76.4682, 2.46496, -0.315145, 0, 0, 0.949044, False, '2025-09-08 17:01:39'); /* Islandgolemgen */
/* @teleloc 0xE9EC0014 [56.981499 76.468201 2.464960] -0.315145 0.000000 0.000000 0.949044 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E9EC014, 73217237, 0xE9EC0014, 56.9815, 76.4682, 2.46496, -0.315145, 0, 0, 0.949044, False, '2025-09-08 17:01:39'); /* Islandgolemgen */
/* @teleloc 0xE9EC0014 [56.981499 76.468201 2.464960] -0.315145 0.000000 0.000000 0.949044 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E9EC015, 73217237, 0xE9EC0013, 64.8392, 65.9414, 8.20588, -0.315145, 0, 0, 0.949044, False, '2025-09-08 17:01:40'); /* Islandgolemgen */
/* @teleloc 0xE9EC0013 [64.839203 65.941399 8.205880] -0.315145 0.000000 0.000000 0.949044 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E9EC016, 73217237, 0xE9EC0013, 71.2606, 57.3386, 7.20912, -0.315145, 0, 0, 0.949044, False, '2025-09-08 17:01:41'); /* Islandgolemgen */
/* @teleloc 0xE9EC0013 [71.260597 57.338600 7.209120] -0.315145 0.000000 0.000000 0.949044 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E9EC017, 73217237, 0xE9EC001A, 78.5268, 47.604, 0.055, -0.315145, 0, 0, 0.949044, False, '2025-09-08 17:01:41'); /* Islandgolemgen */
/* @teleloc 0xE9EC001A [78.526802 47.604000 0.055000] -0.315145 0.000000 0.000000 0.949044 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E9EC018, 73217237, 0xE9EC001A, 78.5268, 47.604, 0.055, -0.315145, 0, 0, 0.949044, False, '2025-09-08 17:01:42'); /* Islandgolemgen */
/* @teleloc 0xE9EC001A [78.526802 47.604000 0.055000] -0.315145 0.000000 0.000000 0.949044 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E9EC019, 73217237, 0xE9EC001A, 88.6518, 34.9228, 0.055, -0.128431, 0, 0, 0.991719, False, '2025-09-08 17:01:43'); /* Islandgolemgen */
/* @teleloc 0xE9EC001A [88.651802 34.922798 0.055000] -0.128431 0.000000 0.000000 0.991719 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E9EC01A, 73217237, 0xE9EC0019, 90.0847, 23.7347, 0.055, 0.212836, 0, 0, 0.977088, False, '2025-09-08 17:01:44'); /* Islandgolemgen */
/* @teleloc 0xE9EC0019 [90.084702 23.734699 0.055000] 0.212836 0.000000 0.000000 0.977088 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E9EC01B, 73217237, 0xE9EC0013, 48.5356, 50.7489, 0.055, 0.354853, 0, 0, -0.934922, False, '2025-09-08 17:05:01'); /* Islandgolemgen */
/* @teleloc 0xE9EC0013 [48.535599 50.748901 0.055000] 0.354853 0.000000 0.000000 -0.934922 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E9EC01C, 73217237, 0xE9EC0012, 51.6501, 47.9986, 0.055, 0.491835, 0, 0, -0.870688, False, '2025-09-08 17:05:02'); /* Islandgolemgen */
/* @teleloc 0xE9EC0012 [51.650101 47.998600 0.055000] 0.491835 0.000000 0.000000 -0.870688 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E9EC01D, 73217237, 0xE9EC0012, 54.9849, 45.9888, 0.055, 0.491835, 0, 0, -0.870688, False, '2025-09-08 17:05:03'); /* Islandgolemgen */
/* @teleloc 0xE9EC0012 [54.984901 45.988800 0.055000] 0.491835 0.000000 0.000000 -0.870688 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E9EC01E, 73217237, 0xE9EC0012, 59.3071, 43.3838, 0.055, 0.491835, 0, 0, -0.870688, False, '2025-09-08 17:05:03'); /* Islandgolemgen */
/* @teleloc 0xE9EC0012 [59.307098 43.383801 0.055000] 0.491835 0.000000 0.000000 -0.870688 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E9EC01F, 73217237, 0xE9EC0012, 64.4287, 40.297, 0.055, 0.491835, 0, 0, -0.870688, False, '2025-09-08 17:05:04'); /* Islandgolemgen */
/* @teleloc 0xE9EC0012 [64.428703 40.297001 0.055000] 0.491835 0.000000 0.000000 -0.870688 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E9EC020, 73217237, 0xE9EC0012, 67.3805, 38.518, 0.055, 0.491835, 0, 0, -0.870688, False, '2025-09-08 17:05:05'); /* Islandgolemgen */
/* @teleloc 0xE9EC0012 [67.380501 38.518002 0.055000] 0.491835 0.000000 0.000000 -0.870688 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E9EC021, 73217237, 0xE9EC0012, 70.5234, 34.8937, 0.055, 0.199866, 0, 0, -0.979823, False, '2025-09-08 17:05:05'); /* Islandgolemgen */
/* @teleloc 0xE9EC0012 [70.523399 34.893700 0.055000] 0.199866 0.000000 0.000000 -0.979823 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E9EC022, 73217237, 0xE9EC0012, 70.3145, 30.1339, 0.055, -0.155828, 0, 0, -0.987784, False, '2025-09-08 17:05:06'); /* Islandgolemgen */
/* @teleloc 0xE9EC0012 [70.314499 30.133900 0.055000] -0.155828 0.000000 0.000000 -0.987784 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E9EC023, 73217237, 0xE9EC0012, 66.9033, 26.7061, 0.055, -0.591099, 0, 0, -0.806599, False, '2025-09-08 17:05:07'); /* Islandgolemgen */
/* @teleloc 0xE9EC0012 [66.903297 26.706100 0.055000] -0.591099 0.000000 0.000000 -0.806599 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E9EC024, 73217237, 0xE9EC0012, 62.2577, 27.3361, 0.055, -0.819088, 0, 0, -0.573668, False, '2025-09-08 17:05:08'); /* Islandgolemgen */
/* @teleloc 0xE9EC0012 [62.257702 27.336100 0.055000] -0.819088 0.000000 0.000000 -0.573668 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E9EC025, 73217237, 0xE9EC0012, 55.109, 29.0768, 0.055, -0.819088, 0, 0, -0.573668, False, '2025-09-08 17:05:08'); /* Islandgolemgen */
/* @teleloc 0xE9EC0012 [55.109001 29.076799 0.055000] -0.819088 0.000000 0.000000 -0.573668 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E9EC026, 73217237, 0xE9EC000A, 47.9218, 29.4042, 0.055, -0.819088, 0, 0, -0.573668, False, '2025-09-08 17:05:09'); /* Islandgolemgen */
/* @teleloc 0xE9EC000A [47.921799 29.404200 0.055000] -0.819088 0.000000 0.000000 -0.573668 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E9EC027, 73217237, 0xE9EC000A, 41.4162, 35.0394, 0.055, -0.998976, 0, 0, 0.045246, False, '2025-09-08 17:05:10'); /* Islandgolemgen */
/* @teleloc 0xE9EC000A [41.416199 35.039398 0.055000] -0.998976 0.000000 0.000000 0.045246 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E9EC028, 73217237, 0xE9EC000A, 41.5936, 43.2537, 0.055, -0.972027, 0, 0, 0.23487, False, '2025-09-08 17:05:11'); /* Islandgolemgen */
/* @teleloc 0xE9EC000A [41.593601 43.253700 0.055000] -0.972027 0.000000 0.000000 0.234870 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E9EC029, 73217237, 0xE9EC0013, 49.9122, 53.2643, 0.055, -0.836272, 0, 0, 0.548314, False, '2025-09-08 17:05:13'); /* Islandgolemgen */
/* @teleloc 0xE9EC0013 [49.912201 53.264301 0.055000] -0.836272 0.000000 0.000000 0.548314 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E9EC02A, 73217237, 0xE9EC0013, 63.0619, 50.5122, 0.055, -0.430699, 0, 0, 0.902496, False, '2025-09-08 17:05:14'); /* Islandgolemgen */
/* @teleloc 0xE9EC0013 [63.061901 50.512199 0.055000] -0.430699 0.000000 0.000000 0.902496 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E9EC02B, 73217237, 0xE9EC0012, 70.1154, 42.0377, 0.055, -0.061581, 0, 0, 0.998102, False, '2025-09-08 17:05:15'); /* Islandgolemgen */
/* @teleloc 0xE9EC0012 [70.115402 42.037701 0.055000] -0.061581 0.000000 0.000000 0.998102 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E9EC02C, 73217237, 0xE9EC001A, 73.0181, 32.5517, 0.055, 0.311013, 0, 0, 0.950406, False, '2025-09-08 17:05:16'); /* Islandgolemgen */
/* @teleloc 0xE9EC001A [73.018097 32.551701 0.055000] 0.311013 0.000000 0.000000 0.950406 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E9EC02D, 73217237, 0xE9EC0012, 66.9174, 24.3435, 0.055, 0.761594, 0, 0, 0.648055, False, '2025-09-08 17:05:17'); /* Islandgolemgen */
/* @teleloc 0xE9EC0012 [66.917397 24.343500 0.055000] 0.761594 0.000000 0.000000 0.648055 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E9EC02E, 73217237, 0xE9EC0012, 57.369, 27.5492, 0.055, 0.973548, 0, 0, 0.228481, False, '2025-09-08 17:05:18'); /* Islandgolemgen */
/* @teleloc 0xE9EC0012 [57.368999 27.549200 0.055000] 0.973548 0.000000 0.000000 0.228481 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E9EC02F, 73217237, 0xE9EC0012, 51.1397, 36.0143, 0.055, 0.979633, 0, 0, -0.200796, False, '2025-09-08 17:05:19'); /* Islandgolemgen */
/* @teleloc 0xE9EC0012 [51.139702 36.014301 0.055000] 0.979633 0.000000 0.000000 -0.200796 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E9EC030, 73217237, 0xE9EC0012, 52.5986, 44.7834, 0.055, 0.716602, 0, 0, -0.697482, False, '2025-09-08 17:05:20'); /* Islandgolemgen */
/* @teleloc 0xE9EC0012 [52.598598 44.783401 0.055000] 0.716602 0.000000 0.000000 -0.697482 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E9EC031, 73217237, 0xE9EC0012, 60.5275, 43.0319, 0.055, 0.076259, 0, 0, -0.997088, False, '2025-09-08 17:05:21'); /* Islandgolemgen */
/* @teleloc 0xE9EC0012 [60.527500 43.031898 0.055000] 0.076259 0.000000 0.000000 -0.997088 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E9EC032, 73217237, 0xE9EC0012, 64.29049, 36.08077, 0.055, -0.477408, 0, 0, -0.878682, False, '2025-09-08 17:05:23'); /* Islandgolemgen */
/* @teleloc 0xE9EC0012 [64.290489 36.080769 0.055000] -0.477408 0.000000 0.000000 -0.878682 */
