DELETE FROM `landblock_instance` WHERE `landblock` = 0xE3CF;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E3CF000, 213788146, 0xE3CF0031, 166.535, 16.24459, -0.845, -0.140105, 0, 0, -0.990137, False, '2025-07-20 14:08:46');
/* @teleloc 0xE3CF0031 [166.535004 16.244591 -0.845000] -0.140105 0.000000 0.000000 -0.990137 */
