DELETE FROM `landblock_instance` WHERE `landblock` = 0x104E;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7104E000, 1910466, 0x104E0005, 9.52852, 113.67, -0.395, 0.487077, 0, 0, -0.873359, False, '2025-07-16 15:07:33'); /* VRtree1 */
/* @teleloc 0x104E0005 [9.528520 113.669998 -0.395000] 0.487077 0.000000 0.000000 -0.873359 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7104E001, 1910466, 0x104E000D, 24.0107, 106.075, -0.395, 0.686999, 0, 0, -0.726659, False, '2025-07-16 15:07:36'); /* VRtree1 */
/* @teleloc 0x104E000D [24.010700 106.074997 -0.395000] 0.686999 0.000000 0.000000 -0.726659 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7104E002, 1910466, 0x104E000D, 41.4745, 103.69, -0.395, 0.726115, 0, 0, -0.687574, False, '2025-07-16 15:07:40'); /* VRtree1 */
/* @teleloc 0x104E000D [41.474499 103.690002 -0.395000] 0.726115 0.000000 0.000000 -0.687574 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7104E003, 1910466, 0x104E0015, 58.7055, 103.738, -0.395, 0.7695, 0, 0, -0.638647, False, '2025-07-16 15:07:42'); /* VRtree1 */
/* @teleloc 0x104E0015 [58.705502 103.737999 -0.395000] 0.769500 0.000000 0.000000 -0.638647 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7104E004, 1910466, 0x104E001D, 77.4627, 106.803, -0.395, 0.889091, 0, 0, -0.45773, False, '2025-07-16 15:07:48'); /* VRtree1 */
/* @teleloc 0x104E001D [77.462700 106.803001 -0.395000] 0.889091 0.000000 0.000000 -0.457730 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7104E005, 1910466, 0x104E001E, 95.7982, 124.859, -0.395, 0.906855, 0, 0, -0.421443, False, '2025-07-16 15:07:51'); /* VRtree1 */
/* @teleloc 0x104E001E [95.798203 124.859001 -0.395000] 0.906855 0.000000 0.000000 -0.421443 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7104E006, 1910466, 0x104E0026, 103.89, 135.123, -0.045, 0.976823, 0, 0, -0.214049, False, '2025-07-16 15:07:52'); /* VRtree1 */
/* @teleloc 0x104E0026 [103.889999 135.123001 -0.045000] 0.976823 0.000000 0.000000 -0.214049 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7104E007, 1910466, 0x104E0027, 107.905, 144.269, -0.045, 0.995538, 0, 0, -0.094365, False, '2025-07-16 15:07:53'); /* VRtree1 */
/* @teleloc 0x104E0027 [107.904999 144.268997 -0.045000] 0.995538 0.000000 0.000000 -0.094365 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7104E008, 1910466, 0x104E0027, 109.783, 155.027, -0.395, 0.999643, 0, 0, 0.026704, False, '2025-07-16 15:07:54'); /* VRtree1 */
/* @teleloc 0x104E0027 [109.782997 155.026993 -0.395000] 0.999643 0.000000 0.000000 0.026704 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7104E009, 1910466, 0x104E0028, 109.071, 168.349, -0.395, 0.999643, 0, 0, 0.026704, False, '2025-07-16 15:07:54'); /* VRtree1 */
/* @teleloc 0x104E0028 [109.070999 168.348999 -0.395000] 0.999643 0.000000 0.000000 0.026704 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7104E00A, 1910466, 0x104E0028, 108.72, 174.606, -0.395, 0.997749, 0, 0, 0.067061, False, '2025-07-16 15:07:55'); /* VRtree1 */
/* @teleloc 0x104E0028 [108.720001 174.606003 -0.395000] 0.997749 0.000000 0.000000 0.067061 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7104E00B, 1910466, 0x104E0028, 107.812, 181.21, -0.045, 0.994226, 0, 0, 0.107308, False, '2025-07-16 15:07:55'); /* VRtree1 */
/* @teleloc 0x104E0028 [107.811996 181.210007 -0.045000] 0.994226 0.000000 0.000000 0.107308 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7104E00C, 5000216, 0x104E0028, 99.3258, 191.98, -0.045, 0.872831, 0, 0, -0.488022, False, '2025-07-16 15:10:30'); /* Gate */
/* @teleloc 0x104E0028 [99.325798 191.979996 -0.045000] 0.872831 0.000000 0.000000 -0.488022 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7104E00D, 5000216, 0x104E0028, 99.3258, 191.98, -0.045, 0.872831, 0, 0, -0.488022, False, '2025-07-16 15:10:30'); /* Gate */
/* @teleloc 0x104E0028 [99.325798 191.979996 -0.045000] 0.872831 0.000000 0.000000 -0.488022 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7104E00E, 5000216, 0x104E0028, 101.087, 189.114, -0.045, 0.872831, 0, 0, -0.488022, False, '2025-07-16 15:10:31'); /* Gate */
/* @teleloc 0x104E0028 [101.086998 189.113998 -0.045000] 0.872831 0.000000 0.000000 -0.488022 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7104E00F, 5000216, 0x104E0028, 102.612, 186.616, -0.045, 0.83381, 0, 0, -0.552051, False, '2025-07-16 15:10:31'); /* Gate */
/* @teleloc 0x104E0028 [102.612000 186.615997 -0.045000] 0.833810 0.000000 0.000000 -0.552051 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7104E010, 5000216, 0x104E0028, 102.612, 186.616, -0.045, 0.83381, 0, 0, -0.552051, False, '2025-07-16 15:10:32'); /* Gate */
/* @teleloc 0x104E0028 [102.612000 186.615997 -0.045000] 0.833810 0.000000 0.000000 -0.552051 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7104E011, 5000216, 0x104E0028, 103.776, 183.851, -0.045, 0.790101, 0, 0, -0.612977, False, '2025-07-16 15:10:32'); /* Gate */
/* @teleloc 0x104E0028 [103.776001 183.850998 -0.045000] 0.790101 0.000000 0.000000 -0.612977 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7104E012, 5000216, 0x104E0028, 103.776, 183.851, -0.045, 0.790101, 0, 0, -0.612977, False, '2025-07-16 15:10:33'); /* Gate */
/* @teleloc 0x104E0028 [103.776001 183.850998 -0.045000] 0.790101 0.000000 0.000000 -0.612977 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7104E013, 5000216, 0x104E0028, 104.654, 180.428, -0.045, 0.790101, 0, 0, -0.612977, False, '2025-07-16 15:10:33'); /* Gate */
/* @teleloc 0x104E0028 [104.653999 180.427994 -0.045000] 0.790101 0.000000 0.000000 -0.612977 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7104E014, 5000216, 0x104E0028, 104.654, 180.428, -0.045, 0.790101, 0, 0, -0.612977, False, '2025-07-16 15:10:33'); /* Gate */
/* @teleloc 0x104E0028 [104.653999 180.427994 -0.045000] 0.790101 0.000000 0.000000 -0.612977 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7104E015, 5000216, 0x104E0028, 105.533, 177, -0.045, 0.790101, 0, 0, -0.612977, False, '2025-07-16 15:10:34'); /* Gate */
/* @teleloc 0x104E0028 [105.532997 177.000000 -0.045000] 0.790101 0.000000 0.000000 -0.612977 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7104E016, 5000216, 0x104E0028, 105.533, 177, -0.045, 0.790101, 0, 0, -0.612977, False, '2025-07-16 15:10:34'); /* Gate */
/* @teleloc 0x104E0028 [105.532997 177.000000 -0.045000] 0.790101 0.000000 0.000000 -0.612977 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7104E017, 5000216, 0x104E0028, 106.493, 173.259, -0.045, 0.790101, 0, 0, -0.612977, False, '2025-07-16 15:10:35'); /* Gate */
/* @teleloc 0x104E0028 [106.492996 173.259003 -0.045000] 0.790101 0.000000 0.000000 -0.612977 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7104E018, 5000216, 0x104E0028, 106.815, 171.934, -0.045, 0.74195, 0, 0, -0.670456, False, '2025-07-16 15:10:35'); /* Gate */
/* @teleloc 0x104E0028 [106.815002 171.934006 -0.045000] 0.741950 0.000000 0.000000 -0.670456 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7104E019, 5000216, 0x104E0028, 106.815, 171.934, -0.045, 0.74195, 0, 0, -0.670456, False, '2025-07-16 15:10:36'); /* Gate */
/* @teleloc 0x104E0028 [106.815002 171.934006 -0.045000] 0.741950 0.000000 0.000000 -0.670456 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7104E01A, 5000216, 0x104E0027, 107.224, 167.898, -0.045, 0.74195, 0, 0, -0.670456, False, '2025-07-16 15:10:36'); /* Gate */
/* @teleloc 0x104E0027 [107.223999 167.897995 -0.045000] 0.741950 0.000000 0.000000 -0.670456 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7104E01B, 5000216, 0x104E0027, 107.396, 166.067, -0.045, 0.689627, 0, 0, -0.724165, False, '2025-07-16 15:10:37'); /* Gate */
/* @teleloc 0x104E0027 [107.396004 166.067001 -0.045000] 0.689627 0.000000 0.000000 -0.724165 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7104E01C, 5000216, 0x104E0027, 107.396, 166.067, -0.045, 0.689627, 0, 0, -0.724165, False, '2025-07-16 15:10:38'); /* Gate */
/* @teleloc 0x104E0027 [107.396004 166.067001 -0.045000] 0.689627 0.000000 0.000000 -0.724165 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7104E01D, 5000216, 0x104E0027, 107.21, 162.281, -0.045, 0.689627, 0, 0, -0.724165, False, '2025-07-16 15:10:38'); /* Gate */
/* @teleloc 0x104E0027 [107.209999 162.281006 -0.045000] 0.689627 0.000000 0.000000 -0.724165 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7104E01E, 5000216, 0x104E0027, 107.21, 162.281, -0.045, 0.689627, 0, 0, -0.724165, False, '2025-07-16 15:10:39'); /* Gate */
/* @teleloc 0x104E0027 [107.209999 162.281006 -0.045000] 0.689627 0.000000 0.000000 -0.724165 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7104E01F, 5000216, 0x104E0027, 107.034, 158.678, -0.045, 0.689627, 0, 0, -0.724165, False, '2025-07-16 15:10:39'); /* Gate */
/* @teleloc 0x104E0027 [107.033997 158.677994 -0.045000] 0.689627 0.000000 0.000000 -0.724165 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7104E020, 5000216, 0x104E0027, 107.034, 158.678, -0.045, 0.689627, 0, 0, -0.724165, False, '2025-07-16 15:10:40'); /* Gate */
/* @teleloc 0x104E0027 [107.033997 158.677994 -0.045000] 0.689627 0.000000 0.000000 -0.724165 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7104E021, 5000216, 0x104E0027, 106.867, 155.253, -0.045, 0.689627, 0, 0, -0.724165, False, '2025-07-16 15:10:40'); /* Gate */
/* @teleloc 0x104E0027 [106.866997 155.253006 -0.045000] 0.689627 0.000000 0.000000 -0.724165 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7104E022, 5000216, 0x104E0027, 106.803, 154.031, -0.045, 0.661992, 0, 0, -0.749511, False, '2025-07-16 15:10:41'); /* Gate */
/* @teleloc 0x104E0027 [106.803001 154.031006 -0.045000] 0.661992 0.000000 0.000000 -0.749511 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7104E023, 5000216, 0x104E0027, 106.803, 154.031, -0.045, 0.661992, 0, 0, -0.749511, False, '2025-07-16 15:10:41'); /* Gate */
/* @teleloc 0x104E0027 [106.803001 154.031006 -0.045000] 0.661992 0.000000 0.000000 -0.749511 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7104E024, 5000216, 0x104E0027, 106.19, 149.319, -0.045, 0.573665, 0, 0, -0.81909, False, '2025-07-16 15:10:42'); /* Gate */
/* @teleloc 0x104E0027 [106.190002 149.319000 -0.045000] 0.573665 0.000000 0.000000 -0.819090 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7104E025, 5000216, 0x104E0027, 106.19, 149.319, -0.045, 0.573665, 0, 0, -0.81909, False, '2025-07-16 15:10:42'); /* Gate */
/* @teleloc 0x104E0027 [106.190002 149.319000 -0.045000] 0.573665 0.000000 0.000000 -0.819090 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7104E026, 5000216, 0x104E0027, 105.002, 146.054, -0.045, 0.573665, 0, 0, -0.81909, False, '2025-07-16 15:10:43'); /* Gate */
/* @teleloc 0x104E0027 [105.001999 146.054001 -0.045000] 0.573665 0.000000 0.000000 -0.819090 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7104E027, 5000216, 0x104E0026, 104.187, 143.812, -0.045, 0.573665, 0, 0, -0.81909, False, '2025-07-16 15:10:43'); /* Gate */
/* @teleloc 0x104E0026 [104.186996 143.811996 -0.045000] 0.573665 0.000000 0.000000 -0.819090 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7104E028, 5000216, 0x104E0026, 104.187, 143.812, -0.045, 0.573665, 0, 0, -0.81909, False, '2025-07-16 15:10:44'); /* Gate */
/* @teleloc 0x104E0026 [104.186996 143.811996 -0.045000] 0.573665 0.000000 0.000000 -0.819090 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7104E029, 5000216, 0x104E0026, 103.03, 140.63, -0.045, 0.573665, 0, 0, -0.81909, False, '2025-07-16 15:10:44'); /* Gate */
/* @teleloc 0x104E0026 [103.029999 140.630005 -0.045000] 0.573665 0.000000 0.000000 -0.819090 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7104E02A, 5000216, 0x104E0026, 102.119, 138.136, -0.045, 0.542553, 0, 0, -0.840021, False, '2025-07-16 15:10:45'); /* Gate */
/* @teleloc 0x104E0026 [102.119003 138.136002 -0.045000] 0.542553 0.000000 0.000000 -0.840021 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7104E02B, 5000216, 0x104E0026, 101.492, 136.758, -0.045, 0.510679, 0, 0, -0.859772, False, '2025-07-16 15:10:45'); /* Gate */
/* @teleloc 0x104E0026 [101.491997 136.757996 -0.045000] 0.510679 0.000000 0.000000 -0.859772 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7104E02C, 5000216, 0x104E0026, 100.602, 135.158, -0.045, 0.44482, 0, 0, -0.89562, False, '2025-07-16 15:10:46'); /* Gate */
/* @teleloc 0x104E0026 [100.601997 135.158005 -0.045000] 0.444820 0.000000 0.000000 -0.895620 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7104E02D, 5000216, 0x104E0026, 100.602, 135.158, -0.045, 0.44482, 0, 0, -0.89562, False, '2025-07-16 15:10:47'); /* Gate */
/* @teleloc 0x104E0026 [100.601997 135.158005 -0.045000] 0.444820 0.000000 0.000000 -0.895620 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7104E02E, 5000216, 0x104E0026, 98.3422, 132.178, -0.045, 0.44482, 0, 0, -0.89562, False, '2025-07-16 15:10:47'); /* Gate */
/* @teleloc 0x104E0026 [98.342201 132.177994 -0.045000] 0.444820 0.000000 0.000000 -0.895620 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7104E02F, 5000216, 0x104E0026, 98.3422, 132.178, -0.045, 0.44482, 0, 0, -0.89562, False, '2025-07-16 15:10:48'); /* Gate */
/* @teleloc 0x104E0026 [98.342201 132.177994 -0.045000] 0.444820 0.000000 0.000000 -0.895620 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7104E030, 5000216, 0x104E001E, 95.6811, 128.713, -0.395, 0.364852, 0, 0, -0.931066, False, '2025-07-16 15:10:48'); /* Gate */
/* @teleloc 0x104E001E [95.681099 128.712997 -0.395000] 0.364852 0.000000 0.000000 -0.931066 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7104E031, 5000216, 0x104E001E, 95.6811, 128.713, -0.395, 0.364852, 0, 0, -0.931066, False, '2025-07-16 15:10:49'); /* Gate */
/* @teleloc 0x104E001E [95.681099 128.712997 -0.395000] 0.364852 0.000000 0.000000 -0.931066 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7104E032, 5000216, 0x104E001E, 93.0177, 126.247, -0.395, 0.364852, 0, 0, -0.931066, False, '2025-07-16 15:10:49'); /* Gate */
/* @teleloc 0x104E001E [93.017700 126.247002 -0.395000] 0.364852 0.000000 0.000000 -0.931066 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7104E033, 5000216, 0x104E001E, 93.0177, 126.247, -0.395, 0.364852, 0, 0, -0.931066, False, '2025-07-16 15:10:50'); /* Gate */
/* @teleloc 0x104E001E [93.017700 126.247002 -0.395000] 0.364852 0.000000 0.000000 -0.931066 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7104E034, 5000216, 0x104E001E, 89.1817, 122.574, -0.395, 0.399502, 0, 0, -0.916732, False, '2025-07-16 15:10:51'); /* Gate */
/* @teleloc 0x104E001E [89.181702 122.573997 -0.395000] 0.399502 0.000000 0.000000 -0.916732 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7104E035, 5000216, 0x104E001E, 88.1162, 121.244, -0.395, 0.499892, 0, 0, -0.866088, False, '2025-07-16 15:10:51'); /* Gate */
/* @teleloc 0x104E001E [88.116203 121.244003 -0.395000] 0.499892 0.000000 0.000000 -0.866088 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7104E036, 5000216, 0x104E001D, 87.3509, 119.919, -0.395, 0.499892, 0, 0, -0.866088, False, '2025-07-16 15:10:52'); /* Gate */
/* @teleloc 0x104E001D [87.350899 119.918999 -0.395000] 0.499892 0.000000 0.000000 -0.866088 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7104E037, 5000216, 0x104E001D, 87.3509, 119.919, -0.395, 0.499892, 0, 0, -0.866088, False, '2025-07-16 15:10:52'); /* Gate */
/* @teleloc 0x104E001D [87.350899 119.918999 -0.395000] 0.499892 0.000000 0.000000 -0.866088 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7104E038, 5000216, 0x104E001D, 85.9617, 117.594, -0.395, 0.388012, 0, 0, -0.921654, False, '2025-07-16 15:10:53'); /* Gate */
/* @teleloc 0x104E001D [85.961700 117.594002 -0.395000] 0.388012 0.000000 0.000000 -0.921654 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7104E039, 5000216, 0x104E001D, 84.3653, 116.045, -0.395, 0.270078, 0, 0, -0.962839, False, '2025-07-16 15:10:53'); /* Gate */
/* @teleloc 0x104E001D [84.365303 116.044998 -0.395000] 0.270078 0.000000 0.000000 -0.962839 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7104E03A, 5000216, 0x104E001D, 84.3653, 116.045, -0.395, 0.270078, 0, 0, -0.962839, False, '2025-07-16 15:10:54'); /* Gate */
/* @teleloc 0x104E001D [84.365303 116.044998 -0.395000] 0.270078 0.000000 0.000000 -0.962839 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7104E03B, 5000216, 0x104E001D, 80.9609, 113.947, -0.045, 0.341464, 0, 0, -0.939895, False, '2025-07-16 15:10:54'); /* Gate */
/* @teleloc 0x104E001D [80.960899 113.946999 -0.045000] 0.341464 0.000000 0.000000 -0.939895 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7104E03C, 5000216, 0x104E001D, 80.9609, 113.947, -0.045, 0.341464, 0, 0, -0.939895, False, '2025-07-16 15:10:55'); /* Gate */
/* @teleloc 0x104E001D [80.960899 113.946999 -0.045000] 0.341464 0.000000 0.000000 -0.939895 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7104E03D, 5000216, 0x104E001D, 78.2505, 111.678, -0.045, 0.341464, 0, 0, -0.939895, False, '2025-07-16 15:10:55'); /* Gate */
/* @teleloc 0x104E001D [78.250504 111.678001 -0.045000] 0.341464 0.000000 0.000000 -0.939895 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7104E03E, 5000216, 0x104E001D, 76.7077, 110.407, -0.045, 0.23379, 0, 0, -0.972287, False, '2025-07-16 15:10:56'); /* Gate */
/* @teleloc 0x104E001D [76.707703 110.406998 -0.045000] 0.233790 0.000000 0.000000 -0.972287 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7104E03F, 5000216, 0x104E001D, 74.7023, 109.421, -0.045, 0.12316, 0, 0, -0.992387, False, '2025-07-16 15:10:56'); /* Gate */
/* @teleloc 0x104E001D [74.702301 109.420998 -0.045000] 0.123160 0.000000 0.000000 -0.992387 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7104E040, 5000216, 0x104E001D, 73.1772, 109.066, -0.045, 0.035966, 0, 0, -0.999353, False, '2025-07-16 15:10:57'); /* Gate */
/* @teleloc 0x104E001D [73.177200 109.066002 -0.045000] 0.035966 0.000000 0.000000 -0.999353 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7104E041, 5000216, 0x104E0015, 71.9937, 108.981, -0.045, 0.035966, 0, 0, -0.999353, False, '2025-07-16 15:10:57'); /* Gate */
/* @teleloc 0x104E0015 [71.993698 108.981003 -0.045000] 0.035966 0.000000 0.000000 -0.999353 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7104E042, 5000216, 0x104E0015, 71.9937, 108.981, -0.045, 0.035966, 0, 0, -0.999353, False, '2025-07-16 15:10:58'); /* Gate */
/* @teleloc 0x104E0015 [71.993698 108.981003 -0.045000] 0.035966 0.000000 0.000000 -0.999353 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7104E043, 5000216, 0x104E0015, 68.4681, 108.727, -0.045, 0.035966, 0, 0, -0.999353, False, '2025-07-16 15:10:58'); /* Gate */
/* @teleloc 0x104E0015 [68.468102 108.726997 -0.045000] 0.035966 0.000000 0.000000 -0.999353 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7104E044, 5000216, 0x104E0015, 68.4681, 108.727, -0.045, 0.035966, 0, 0, -0.999353, False, '2025-07-16 15:10:59'); /* Gate */
/* @teleloc 0x104E0015 [68.468102 108.726997 -0.045000] 0.035966 0.000000 0.000000 -0.999353 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7104E045, 5000216, 0x104E0015, 64.9387, 108.473, -0.045, 0.035966, 0, 0, -0.999353, False, '2025-07-16 15:10:59'); /* Gate */
/* @teleloc 0x104E0015 [64.938698 108.473000 -0.045000] 0.035966 0.000000 0.000000 -0.999353 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7104E046, 5000216, 0x104E0015, 61.1622, 108.201, -0.045, 0.035966, 0, 0, -0.999353, False, '2025-07-16 15:11:00'); /* Gate */
/* @teleloc 0x104E0015 [61.162201 108.200996 -0.045000] 0.035966 0.000000 0.000000 -0.999353 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7104E047, 5000216, 0x104E0015, 61.1622, 108.201, -0.045, 0.035966, 0, 0, -0.999353, False, '2025-07-16 15:11:00'); /* Gate */
/* @teleloc 0x104E0015 [61.162201 108.200996 -0.045000] 0.035966 0.000000 0.000000 -0.999353 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7104E048, 5000216, 0x104E0015, 57.8342, 107.964, -0.395, -0.001526, 0, 0, -0.999999, False, '2025-07-16 15:11:01'); /* Gate */
/* @teleloc 0x104E0015 [57.834202 107.963997 -0.395000] -0.001526 0.000000 0.000000 -0.999999 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7104E049, 5000216, 0x104E0015, 57.8342, 107.964, -0.395, -0.001526, 0, 0, -0.999999, False, '2025-07-16 15:11:02'); /* Gate */
/* @teleloc 0x104E0015 [57.834202 107.963997 -0.395000] -0.001526 0.000000 0.000000 -0.999999 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7104E04A, 5000216, 0x104E0015, 54.0437, 107.976, -0.395, -0.001526, 0, 0, -0.999999, False, '2025-07-16 15:11:02'); /* Gate */
/* @teleloc 0x104E0015 [54.043701 107.975998 -0.395000] -0.001526 0.000000 0.000000 -0.999999 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7104E04B, 5000216, 0x104E0015, 54.0437, 107.976, -0.395, -0.001526, 0, 0, -0.999999, False, '2025-07-16 15:11:03'); /* Gate */
/* @teleloc 0x104E0015 [54.043701 107.975998 -0.395000] -0.001526 0.000000 0.000000 -0.999999 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7104E04C, 5000216, 0x104E0015, 50.6151, 107.986, -0.395, -0.001526, 0, 0, -0.999999, False, '2025-07-16 15:11:03'); /* Gate */
/* @teleloc 0x104E0015 [50.615101 107.986000 -0.395000] -0.001526 0.000000 0.000000 -0.999999 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7104E04D, 5000216, 0x104E000D, 47.9216, 107.994, -0.395, -0.001526, 0, 0, -0.999999, False, '2025-07-16 15:11:04'); /* Gate */
/* @teleloc 0x104E000D [47.921600 107.994003 -0.395000] -0.001526 0.000000 0.000000 -0.999999 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7104E04E, 5000216, 0x104E000D, 47.9216, 107.994, -0.395, -0.001526, 0, 0, -0.999999, False, '2025-07-16 15:11:04'); /* Gate */
/* @teleloc 0x104E000D [47.921600 107.994003 -0.395000] -0.001526 0.000000 0.000000 -0.999999 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7104E04F, 5000216, 0x104E000D, 44.2169, 108.006, -0.045, -0.001526, 0, 0, -0.999999, False, '2025-07-16 15:11:05'); /* Gate */
/* @teleloc 0x104E000D [44.216900 108.005997 -0.045000] -0.001526 0.000000 0.000000 -0.999999 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7104E050, 5000216, 0x104E000D, 44.2169, 108.006, -0.045, -0.001526, 0, 0, -0.999999, False, '2025-07-16 15:11:05'); /* Gate */
/* @teleloc 0x104E000D [44.216900 108.005997 -0.045000] -0.001526 0.000000 0.000000 -0.999999 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7104E051, 5000216, 0x104E000D, 40.784, 108.016, -0.045, -0.001526, 0, 0, -0.999999, False, '2025-07-16 15:11:06'); /* Gate */
/* @teleloc 0x104E000D [40.784000 108.015999 -0.045000] -0.001526 0.000000 0.000000 -0.999999 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7104E052, 5000216, 0x104E000D, 40.784, 108.016, -0.045, -0.001526, 0, 0, -0.999999, False, '2025-07-16 15:11:06'); /* Gate */
/* @teleloc 0x104E000D [40.784000 108.015999 -0.045000] -0.001526 0.000000 0.000000 -0.999999 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7104E053, 5000216, 0x104E000D, 37.0303, 108.028, -0.045, -0.001526, 0, 0, -0.999999, False, '2025-07-16 15:11:07'); /* Gate */
/* @teleloc 0x104E000D [37.030300 108.028000 -0.045000] -0.001526 0.000000 0.000000 -0.999999 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7104E054, 5000216, 0x104E000D, 33.3777, 108.039, -0.045, -0.001526, 0, 0, -0.999999, False, '2025-07-16 15:11:08'); /* Gate */
/* @teleloc 0x104E000D [33.377701 108.039001 -0.045000] -0.001526 0.000000 0.000000 -0.999999 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7104E055, 5000216, 0x104E000D, 33.3777, 108.039, -0.045, -0.001526, 0, 0, -0.999999, False, '2025-07-16 15:11:08'); /* Gate */
/* @teleloc 0x104E000D [33.377701 108.039001 -0.045000] -0.001526 0.000000 0.000000 -0.999999 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7104E056, 5000216, 0x104E000D, 29.9571, 108.049, -0.045, -0.001526, 0, 0, -0.999999, False, '2025-07-16 15:11:09'); /* Gate */
/* @teleloc 0x104E000D [29.957100 108.049004 -0.045000] -0.001526 0.000000 0.000000 -0.999999 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7104E057, 5000216, 0x104E000D, 29.9571, 108.049, -0.045, -0.001526, 0, 0, -0.999999, False, '2025-07-16 15:11:09'); /* Gate */
/* @teleloc 0x104E000D [29.957100 108.049004 -0.045000] -0.001526 0.000000 0.000000 -0.999999 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7104E058, 5000216, 0x104E0006, 0.480152, 127.184, -0.395, -0.347152, 0, 0, -0.937809, False, '2025-07-16 15:14:45'); /* Gate */
/* @teleloc 0x104E0006 [0.480152 127.183998 -0.395000] -0.347152 0.000000 0.000000 -0.937809 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7104E059, 5000216, 0x104E0006, 1.71092, 126.108, -0.395, -0.416446, 0, 0, -0.909161, False, '2025-07-16 15:14:45'); /* Gate */
/* @teleloc 0x104E0006 [1.710920 126.108002 -0.395000] -0.416446 0.000000 0.000000 -0.909161 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7104E05A, 5000216, 0x104E0006, 1.71092, 126.108, -0.395, -0.416446, 0, 0, -0.909161, False, '2025-07-16 15:14:45'); /* Gate */
/* @teleloc 0x104E0006 [1.710920 126.108002 -0.395000] -0.416446 0.000000 0.000000 -0.909161 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7104E05B, 5000216, 0x104E0006, 1.71092, 126.108, -0.395, -0.416446, 0, 0, -0.909161, False, '2025-07-16 15:14:46'); /* Gate */
/* @teleloc 0x104E0006 [1.710920 126.108002 -0.395000] -0.416446 0.000000 0.000000 -0.909161 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7104E05C, 5000216, 0x104E0006, 3.94507, 123.518, -0.395, -0.416446, 0, 0, -0.909161, False, '2025-07-16 15:14:46'); /* Gate */
/* @teleloc 0x104E0006 [3.945070 123.517998 -0.395000] -0.416446 0.000000 0.000000 -0.909161 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7104E05D, 5000216, 0x104E0006, 3.94507, 123.518, -0.395, -0.416446, 0, 0, -0.909161, False, '2025-07-16 15:14:46'); /* Gate */
/* @teleloc 0x104E0006 [3.945070 123.517998 -0.395000] -0.416446 0.000000 0.000000 -0.909161 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7104E05E, 5000216, 0x104E0006, 6.3537, 120.725, -0.395, -0.416446, 0, 0, -0.909161, False, '2025-07-16 15:14:47'); /* Gate */
/* @teleloc 0x104E0006 [6.353700 120.724998 -0.395000] -0.416446 0.000000 0.000000 -0.909161 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7104E05F, 5000216, 0x104E0005, 7.01184, 119.973, -0.395, -0.335403, 0, 0, -0.942075, False, '2025-07-16 15:14:47'); /* Gate */
/* @teleloc 0x104E0005 [7.011840 119.973000 -0.395000] -0.335403 0.000000 0.000000 -0.942075 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7104E060, 5000216, 0x104E0005, 8.5346, 118.739, -0.395, -0.26387, 0, 0, -0.964558, False, '2025-07-16 15:14:48'); /* Gate */
/* @teleloc 0x104E0005 [8.534600 118.738998 -0.395000] -0.263870 0.000000 0.000000 -0.964558 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7104E061, 5000216, 0x104E0005, 8.5346, 118.739, -0.395, -0.26387, 0, 0, -0.964558, False, '2025-07-16 15:14:48'); /* Gate */
/* @teleloc 0x104E0005 [8.534600 118.738998 -0.395000] -0.263870 0.000000 0.000000 -0.964558 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7104E062, 5000216, 0x104E0005, 10.99, 117.282, -0.395, -0.299847, 0, 0, -0.953987, False, '2025-07-16 15:14:49'); /* Gate */
/* @teleloc 0x104E0005 [10.990000 117.281998 -0.395000] -0.299847 0.000000 0.000000 -0.953987 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7104E063, 5000216, 0x104E0005, 10.99, 117.282, -0.395, -0.299847, 0, 0, -0.953987, False, '2025-07-16 15:14:49'); /* Gate */
/* @teleloc 0x104E0005 [10.990000 117.281998 -0.395000] -0.299847 0.000000 0.000000 -0.953987 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7104E064, 5000216, 0x104E0005, 13.8583, 115.282, -0.045, -0.299847, 0, 0, -0.953987, False, '2025-07-16 15:14:50'); /* Gate */
/* @teleloc 0x104E0005 [13.858300 115.281998 -0.045000] -0.299847 0.000000 0.000000 -0.953987 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7104E065, 5000216, 0x104E0005, 13.8583, 115.282, -0.045, -0.299847, 0, 0, -0.953987, False, '2025-07-16 15:14:50'); /* Gate */
/* @teleloc 0x104E0005 [13.858300 115.281998 -0.045000] -0.299847 0.000000 0.000000 -0.953987 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7104E066, 5000216, 0x104E0005, 16.9023, 113.15, -0.045, -0.370486, 0, 0, -0.928838, False, '2025-07-16 15:14:51'); /* Gate */
/* @teleloc 0x104E0005 [16.902300 113.150002 -0.045000] -0.370486 0.000000 0.000000 -0.928838 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7104E067, 5000216, 0x104E0005, 16.9023, 113.15, -0.045, -0.370486, 0, 0, -0.928838, False, '2025-07-16 15:14:51'); /* Gate */
/* @teleloc 0x104E0005 [16.902300 113.150002 -0.045000] -0.370486 0.000000 0.000000 -0.928838 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7104E068, 5000216, 0x104E0005, 16.9023, 113.15, -0.045, -0.370486, 0, 0, -0.928838, False, '2025-07-16 15:14:51'); /* Gate */
/* @teleloc 0x104E0005 [16.902300 113.150002 -0.045000] -0.370486 0.000000 0.000000 -0.928838 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7104E069, 86653841, 0x104E0020, 83.2715, 173.038, 1.11571, 0.06966, 0, 0, -0.997571, False, '2025-07-16 15:37:48'); /* stairs44 */
/* @teleloc 0x104E0020 [83.271500 173.037994 1.115710] 0.069660 0.000000 0.000000 -0.997571 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7104E06A, 86653122, 0x104E0018, 57.1176, 170.071, 16.5749, -0.662192, 0, 0, -0.749334, False, '2025-07-16 16:04:54'); /* 1platform */
/* @teleloc 0x104E0018 [57.117599 170.070999 16.574900] -0.662192 0.000000 0.000000 -0.749334 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7104E06B, 86653122, 0x104E0018, 54.9871, 185.313, 16.6649, -0.99699, 0, 0, -0.077533, False, '2025-07-16 16:05:20'); /* 1platform */
/* @teleloc 0x104E0018 [54.987099 185.313004 16.664900] -0.996990 0.000000 0.000000 -0.077533 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7104E06C, 86653122, 0x104E0017, 58.3458, 153.979, 16.6649, -0.044605, 0, 0, 0.999005, False, '2025-07-16 16:05:36'); /* 1platform */
/* @teleloc 0x104E0017 [58.345798 153.979004 16.664900] -0.044605 0.000000 0.000000 0.999005 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7104E06D, 86653111, 0x104E003A, 185.349, 25.6167, 87.3678, -0.444644, 0, 0, 0.895707, False, '2025-07-19 00:04:27'); /* WOOD111 */
/* @teleloc 0x104E003A [185.348999 25.616699 87.367798] -0.444644 0.000000 0.000000 0.895707 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7104E06E, 86653111, 0x104E003B, 181.447, 54.8631, 87.8228, -0.952328, 0, 0, 0.305077, False, '2025-07-19 00:04:39'); /* WOOD111 */
/* @teleloc 0x104E003B [181.447006 54.863098 87.822800] -0.952328 0.000000 0.000000 0.305077 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7104E06F, 86653111, 0x104E003B, 191.636, 65.0792, 88.2778, -0.93824, 0, 0, 0.345985, False, '2025-07-19 00:05:15'); /* WOOD111 */
/* @teleloc 0x104E003B [191.636002 65.079201 88.277802] -0.938240 0.000000 0.000000 0.345985 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7104E070, 86653111, 0x104E003A, 185.615, 33.8251, 87.8238, 0.999115, 0, 0, 0.042058, False, '2025-07-22 18:43:01'); /* WOOD111 */
/* @teleloc 0x104E003A [185.615005 33.825100 87.823799] 0.999115 0.000000 0.000000 0.042058 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7104E071, 86653111, 0x104E003A, 185.411, 42.0566, 88.2798, 0.993155, 0, 0, 0.116804, False, '2025-07-22 18:43:28'); /* WOOD111 */
/* @teleloc 0x104E003A [185.410995 42.056599 88.279800] 0.993155 0.000000 0.000000 0.116804 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7104E072, 5167232, 0x104E003A, 186.849, 29.9135, -0.963, 0.995487, 0, 0, 0.094901, False, '2025-07-28 14:02:00'); /* Parkour Challenge */
/* @teleloc 0x104E003A [186.848999 29.913500 -0.963000] 0.995487 0.000000 0.000000 0.094901 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7104E073, 5167232, 0x104E003B, 182.69, 51.5279, -0.963, 0.995487, 0, 0, 0.094901, False, '2025-07-28 14:02:02'); /* Parkour Challenge */
/* @teleloc 0x104E003B [182.690002 51.527901 -0.963000] 0.995487 0.000000 0.000000 0.094901 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7104E074, 5167232, 0x104E003B, 185.429, 68.2009, -0.963, 0.961471, 0, 0, -0.274908, False, '2025-07-28 14:02:04'); /* Parkour Challenge */
/* @teleloc 0x104E003B [185.429001 68.200897 -0.963000] 0.961471 0.000000 0.000000 -0.274908 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7104E075, 23472387, 0x104E0017, 52.71412, 166.0204, 16.6649, -0.599702, 0, 0, -0.800224, False, '2025-08-08 05:42:42'); /* ApprenticeGen */
/* @teleloc 0x104E0017 [52.714119 166.020401 16.664900] -0.599702 0.000000 0.000000 -0.800224 */
