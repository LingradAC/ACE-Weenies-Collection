DELETE FROM `landblock_instance` WHERE `landblock` = 0xE5D0;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E5D0001, 43554, 0xE5D00040, 181.467, 175.285, 41.937, 1, 0, 0, 0, False, '2021-11-01 00:00:00'); /* Olthoi Tunnel */
/* @teleloc 0xE5D00040 [181.466995 175.285004 41.937000] 1.000000 0.000000 0.000000 0.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E5D0002, 4200152, 0xE5D00020, 72.7348, 186.097, 1.53068, -0.970232, 0, 0, 0.242177, False, '2025-07-19 10:33:39'); /* Gate */
/* @teleloc 0xE5D00020 [72.734802 186.097000 1.530680] -0.970232 0.000000 0.000000 0.242177 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E5D0003, 4200152, 0xE5D00020, 88.6218, 175.932, 1.89956, -0.970926, 0, 0, 0.239378, False, '2025-07-19 10:33:44'); /* Gate */
/* @teleloc 0xE5D00020 [88.621803 175.932007 1.899560] -0.970926 0.000000 0.000000 0.239378 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E5D0004, 4200152, 0xE5D00027, 102.129, 165.613, 0.055, -0.967866, 0, 0, 0.251465, False, '2025-07-19 10:33:50'); /* Gate */
/* @teleloc 0xE5D00027 [102.128998 165.613007 0.055000] -0.967866 0.000000 0.000000 0.251465 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E5D0005, 4200152, 0xE5D00027, 116.743, 155.889, 0.055, -0.931827, 0, 0, 0.362902, False, '2025-07-19 10:34:05'); /* Gate */
/* @teleloc 0xE5D00027 [116.742996 155.889008 0.055000] -0.931827 0.000000 0.000000 0.362902 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E5D0006, 4200152, 0xE5D0002E, 127.321, 142.383, -0.045, -0.79817, 0, 0, 0.602432, False, '2025-07-19 10:34:12'); /* Gate */
/* @teleloc 0xE5D0002E [127.320999 142.382996 -0.045000] -0.798170 0.000000 0.000000 0.602432 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E5D0007, 4200152, 0xE5D0002E, 129.091, 124.411, -0.045, -0.587548, 0, 0, 0.809189, False, '2025-07-19 10:34:16'); /* Gate */
/* @teleloc 0xE5D0002E [129.091003 124.411003 -0.045000] -0.587548 0.000000 0.000000 0.809189 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E5D0008, 4200152, 0xE5D0002D, 122.78, 104.886, -0.395, -0.595088, 0, 0, 0.803661, False, '2025-07-19 10:34:21'); /* Gate */
/* @teleloc 0xE5D0002D [122.779999 104.886002 -0.395000] -0.595088 0.000000 0.000000 0.803661 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E5D0009, 4200152, 0xE5D00024, 116.722, 86.1985, -0.395, -0.603834, 0, 0, 0.79711, False, '2025-07-19 10:34:27'); /* Gate */
/* @teleloc 0xE5D00024 [116.722000 86.198502 -0.395000] -0.603834 0.000000 0.000000 0.797110 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E5D000A, 4200152, 0xE5D00023, 112.25, 68.858, -0.845, -0.663691, 0, 0, 0.748007, False, '2025-07-19 10:34:33'); /* Gate */
/* @teleloc 0xE5D00023 [112.250000 68.858002 -0.845000] -0.663691 0.000000 0.000000 0.748007 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E5D000B, 4200152, 0xE5D0002B, 120.607, 49.3942, -0.845, -0.961603, 0, 0, 0.274444, False, '2025-07-19 10:34:56'); /* Gate */
/* @teleloc 0xE5D0002B [120.607002 49.394199 -0.845000] -0.961603 0.000000 0.000000 0.274444 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E5D000C, 4200152, 0xE5D0002A, 137.542, 43.259, -0.395, -0.998866, 0, 0, 0.047616, False, '2025-07-19 10:35:17'); /* Gate */
/* @teleloc 0xE5D0002A [137.542007 43.258999 -0.395000] -0.998866 0.000000 0.000000 0.047616 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E5D000D, 4200152, 0xE5D00032, 160.314, 42.0756, -0.845, -0.999872, 0, 0, -0.015992, False, '2025-07-19 10:35:23'); /* Gate */
/* @teleloc 0xE5D00032 [160.313995 42.075600 -0.845000] -0.999872 0.000000 0.000000 -0.015992 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E5D000E, 4200152, 0xE5D0003A, 181.76, 40.1818, -0.845, -0.998634, 0, 0, 0.052252, False, '2025-07-19 10:35:27'); /* Gate */
/* @teleloc 0xE5D0003A [181.759995 40.181801 -0.845000] -0.998634 0.000000 0.000000 0.052252 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E5D0014, 700255, 0xE5D0002A, 139.356, 39.0836, -0.395, -0.666889, 0, 0, 0.745157, False, '2025-08-04 17:40:42'); /* OathliegeGen */
/* @teleloc 0xE5D0002A [139.356003 39.083599 -0.395000] -0.666889 0.000000 0.000000 0.745157 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E5D0016, 700255, 0xE5D00029, 141.322, 14.1232, -0.173425, 0.603071, 0, 0, 0.797687, False, '2025-08-04 17:40:47'); /* OathliegeGen */
/* @teleloc 0xE5D00029 [141.322006 14.123200 -0.173425] 0.603071 0.000000 0.000000 0.797687 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E5D0017, 700043, 0xE5D00026, 99.8482, 135.441, 0.055, -0.024151, 0, 0, 0.999708, False, '2025-08-24 14:41:09'); /* BiglugianGen */
/* @teleloc 0xE5D00026 [99.848198 135.440994 0.055000] -0.024151 0.000000 0.000000 0.999708 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E5D0018, 700043, 0xE5D0001B, 92.59102, 64.79872, -0.395, -0.176104, 0, 0, 0.984372, False, '2025-08-24 14:41:15'); /* BiglugianGen */
/* @teleloc 0xE5D0001B [92.591019 64.798721 -0.395000] -0.176104 0.000000 0.000000 0.984372 */
