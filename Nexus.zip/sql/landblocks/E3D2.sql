DELETE FROM `landblock_instance` WHERE `landblock` = 0xE3D2;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E3D2000, 213788146, 0xE3D2000A, 41.4373, 46.1122, -0.045, 0.145436, 0, 0, -0.989368, False, '2025-07-20 14:07:35'); /* bzmobgen */
/* @teleloc 0xE3D2000A [41.437302 46.112202 -0.045000] 0.145436 0.000000 0.000000 -0.989368 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E3D2001, 12382138, 0xE3D2002B, 143.603, 63.031, 6.055, -0.53672, 0, 0, 0.843761, False, '2025-07-20 14:13:04'); /* Picker Golem Generator */
/* @teleloc 0xE3D2002B [143.602997 63.030998 6.055000] -0.536720 0.000000 0.000000 0.843761 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E3D2002, 91737171, 0xE3D20031, 153.8857, 23.20295, 6.055, -0.039142, 0, 0, -0.999234, False, '2025-07-27 14:44:01');
/* @teleloc 0xE3D20031 [153.885696 23.202950 6.055000] -0.039142 0.000000 0.000000 -0.999234 */
