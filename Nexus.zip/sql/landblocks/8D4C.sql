DELETE FROM `landblock_instance` WHERE `landblock` = 0x8D4C;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x78D4C000, 89235757, 0x8D4C0018, 58.2828, 191.965, 12.3471, -0.154893, 0, 0, 0.987931, False, '2025-08-29 13:58:35');
/* @teleloc 0x8D4C0018 [58.282799 191.964996 12.347100] -0.154893 0.000000 0.000000 0.987931 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x78D4C001, 89235757, 0x8D4C0017, 66.3865, 167.936, 14.055, -0.154893, 0, 0, 0.987931, False, '2025-08-29 13:58:37');
/* @teleloc 0x8D4C0017 [66.386497 167.936005 14.055000] -0.154893 0.000000 0.000000 0.987931 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x78D4C002, 89235757, 0x8D4C001F, 79.2965, 151.253, 14.0623, -0.515647, 0, 0, 0.856801, False, '2025-08-29 13:58:39');
/* @teleloc 0x8D4C001F [79.296501 151.253006 14.062300] -0.515647 0.000000 0.000000 0.856801 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x78D4C003, 89235757, 0x8D4C0026, 96.7478, 143.262, 18.1773, -0.64707, 0, 0, 0.76243, False, '2025-08-29 13:58:41');
/* @teleloc 0x8D4C0026 [96.747803 143.261993 18.177299] -0.647070 0.000000 0.000000 0.762430 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x78D4C004, 89235757, 0x8D4C002E, 120.0679, 141.6357, 16.64041, -0.736804, 0, 0, 0.676107, False, '2025-08-29 13:58:43');
/* @teleloc 0x8D4C002E [120.067902 141.635696 16.640409] -0.736804 0.000000 0.000000 0.676107 */
