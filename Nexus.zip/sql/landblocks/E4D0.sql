DELETE FROM `landblock_instance` WHERE `landblock` = 0xE4D0;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E4D0000, 213788146, 0xE4D00036, 164.07, 129.433, 6.055, 0.768028, 0, 0, -0.640416, False, '2025-07-20 14:08:18'); /* bzmobgen */
/* @teleloc 0xE4D00036 [164.070007 129.432999 6.055000] 0.768028 0.000000 0.000000 -0.640416 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E4D0001, 91737171, 0xE4D00008, 4.76279, 186.436, -0.395065, 0.233218, 0, 0, -0.972425, False, '2025-07-27 14:44:24'); /* cultistsoldiergen */
/* @teleloc 0xE4D00008 [4.762790 186.436005 -0.395065] 0.233218 0.000000 0.000000 -0.972425 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E4D0002, 91737171, 0xE4D00017, 57.8158, 164.321, 6.055, -0.986603, 0, 0, -0.163139, False, '2025-07-27 15:41:42'); /* cultistsoldiergen */
/* @teleloc 0xE4D00017 [57.815800 164.320999 6.055000] -0.986603 0.000000 0.000000 -0.163139 */
