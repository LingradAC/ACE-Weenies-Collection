DELETE FROM `landblock_instance` WHERE `landblock` = 0xC6B0;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7C6B0000, 3969001, 0xC6B00009, 29.4831, 13.372, 130.8906, 0.382684, 0, 0, -0.92388, False, '2025-08-04 19:30:16'); /* Kaine's Injured Friend */
/* @teleloc 0xC6B00009 [29.483101 13.372000 130.890594] 0.382684 0.000000 0.000000 -0.923880 */
