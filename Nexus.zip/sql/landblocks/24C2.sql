DELETE FROM `landblock_instance` WHERE `landblock` = 0x24C2;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x724C2000, 709823, 0x24C20023, 100.493, 56.46786, 85.68089, 0.948369, 0, 0, 0.317168, False, '2025-07-21 21:25:46'); /* enlargedgoblingen */
/* @teleloc 0x24C20023 [100.492996 56.467861 85.680893] 0.948369 0.000000 0.000000 0.317168 */
