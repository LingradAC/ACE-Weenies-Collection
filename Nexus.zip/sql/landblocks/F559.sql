DELETE FROM `landblock_instance` WHERE `landblock` = 0xF559;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F559000,  5148, 0xF5590101, 184.107, 80.093, 20.305, 0.5373, 0, 0, -0.843391, False, '2021-11-01 00:00:00'); /* Flames */
/* @teleloc 0xF5590101 [184.106995 80.093002 20.305000] 0.537300 0.000000 0.000000 -0.843391 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F559001,  5148, 0xF5590109, 152.002, 111.455, 20.205, -0.707107, 0, 0, -0.707107, False, '2021-11-01 00:00:00'); /* Flames */
/* @teleloc 0xF5590109 [152.001999 111.455002 20.205000] -0.707107 0.000000 0.000000 -0.707107 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F559002,   153, 0xF5590101, 184.245, 86.2221, 19.9925, -0.999932, 0, 0, -0.011672, False, '2021-11-01 00:00:00'); /* Fountain */
/* @teleloc 0xF5590101 [184.244995 86.222099 19.992500] -0.999932 0.000000 0.000000 -0.011672 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F559003,   165, 0xF5590101, 183.517, 83.1264, 20.05, -0.698806, 0, 0, -0.715311, False, '2021-11-01 00:00:00'); /* Pool */
/* @teleloc 0xF5590101 [183.516998 83.126404 20.049999] -0.698806 0.000000 0.000000 -0.715311 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F559004,   165, 0xF5590101, 181.248, 80.5406, 20.05, -0.999727, 0, 0, -0.023342, False, '2021-11-01 00:00:00'); /* Pool */
/* @teleloc 0xF5590101 [181.248001 80.540604 20.049999] -0.999727 0.000000 0.000000 -0.023342 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F559005,  6441, 0xF5590035, 157.873, 113.209, 20, 0.707107, 0, 0, -0.707107, False, '2021-11-01 00:00:00'); /* Well */
/* @teleloc 0xF5590035 [157.873001 113.209000 20.000000] 0.707107 0.000000 0.000000 -0.707107 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F559006, 21464, 0xF559003B, 177.311, 63.2039, 19.937, 0.482206, 0, 0, -0.876058, False, '2021-11-01 00:00:00'); /* Haven Residential Halls Portal */
/* @teleloc 0xF559003B [177.311005 63.203899 19.937000] 0.482206 0.000000 0.000000 -0.876058 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F559007,   720, 0xF559003C, 180.792, 90.7643, 20, -0.698806, 0, 0, -0.715312, False, '2021-11-01 00:00:00'); /* Sliding Door */
/* @teleloc 0xF559003C [180.792007 90.764297 20.000000] -0.698806 0.000000 0.000000 -0.715312 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F559008,   720, 0xF5590035, 160.931, 107.42, 20.025, 1, 0, 0, 0, False, '2021-11-01 00:00:00'); /* Sliding Door */
/* @teleloc 0xF5590035 [160.931000 107.419998 20.025000] 1.000000 0.000000 0.000000 0.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F559009,   720, 0xF5590035, 160.921, 112.47, 20.025, 1, 0, 0, 0, False, '2021-11-01 00:00:00'); /* Sliding Door */
/* @teleloc 0xF5590035 [160.921005 112.470001 20.025000] 1.000000 0.000000 0.000000 0.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F55900A,   720, 0xF5590035, 153.396, 98.77, 20.025, 1, 0, 0, 0, False, '2021-11-01 00:00:00'); /* Sliding Door */
/* @teleloc 0xF5590035 [153.395996 98.769997 20.025000] 1.000000 0.000000 0.000000 0.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F55900B,   509, 0xF5590035, 163.24, 101.351, 20, 0.974016, 0, 0, -0.226481, False, '2021-11-01 00:00:00'); /* Life Stone */
/* @teleloc 0xF5590035 [163.240005 101.350998 20.000000] 0.974016 0.000000 0.000000 -0.226481 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F55900D, 27547, 0xF559003D, 181.569, 98.2403, 20, -0.69609, 0, 0, -0.717955, False, '2021-11-01 00:00:00'); /* Bind Stone */
/* @teleloc 0xF559003D [181.569000 98.240303 20.000000] -0.696090 0.000000 0.000000 -0.717955 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F55900E, 21476, 0xF559003B, 175.443, 64.5452, 20, 0.482206, 0, 0, -0.876058, False, '2021-11-01 00:00:00'); /* Haven Residential Halls */
/* @teleloc 0xF559003B [175.442993 64.545197 20.000000] 0.482206 0.000000 0.000000 -0.876058 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F55900F,  4214, 0xF559010B, 152.843, 106.225, 20.005, -0.32099, 0, 0, 0.947083, False, '2021-11-01 00:00:00'); /* Leather Crafter */
/* @teleloc 0xF559010B [152.843002 106.224998 20.004999] -0.320990 0.000000 0.000000 0.947083 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F559011, 43067, 0xF559003D, 171.6, 113.397, 20.198, 0.997971, 0, 0, 0.063666, False, '2021-11-01 00:00:00'); /* Portal to Town Network */
/* @teleloc 0xF559003D [171.600006 113.397003 20.198000] 0.997971 0.000000 0.000000 0.063666 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F559017, 12774, 0xF5590023, 116.437, 67.7491, 20, -0.948616, 0, 0, 0.31643, False, '2021-11-01 00:00:00'); /* Settlement Portals */
/* @teleloc 0xF5590023 [116.436996 67.749100 20.000000] -0.948616 0.000000 0.000000 0.316430 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F559018, 14655, 0xF559002C, 121.832, 72.6583, 19.937, 0.906289, 0, 0, -0.422659, False, '2021-11-01 00:00:00'); /* Ong-Hau Village Portal */
/* @teleloc 0xF559002C [121.832001 72.658302 19.937000] 0.906289 0.000000 0.000000 -0.422659 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F559019, 12487, 0xF559002B, 122.549, 63.4265, 19.937, -0.925789, 0, 0, -0.37804, False, '2021-11-01 00:00:00'); /* Dryreach Beach Cottages Portal */
/* @teleloc 0xF559002B [122.549004 63.426498 19.937000] -0.925789 0.000000 0.000000 -0.378040 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F55901A, 13130, 0xF559002B, 123.619, 68.1929, 19.937, -0.748842, 0, 0, -0.662749, False, '2021-11-01 00:00:00'); /* Snowy Valley Portal */
/* @teleloc 0xF559002B [123.619003 68.192902 19.937000] -0.748842 0.000000 0.000000 -0.662749 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F55901B, 19140, 0xF5590024, 117.372, 75.2706, 19.937, -0.073747, 0, 0, -0.997277, False, '2021-11-01 00:00:00'); /* Dame Tolani Villas Portal */
/* @teleloc 0xF5590024 [117.372002 75.270599 19.937000] -0.073747 0.000000 0.000000 -0.997277 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F55901C, 14676, 0xF5590024, 112.659, 74.2251, 19.937, 0.240577, 0, 0, -0.97063, False, '2021-11-01 00:00:00'); /* Westshore Cottages Portal */
/* @teleloc 0xF5590024 [112.658997 74.225098 19.937000] 0.240577 0.000000 0.000000 -0.970630 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F55901D, 13112, 0xF5590023, 109.902, 70.39, 19.937, 0.620978, 0, 0, -0.783828, False, '2021-11-01 00:00:00'); /* Nan-Zari Portal */
/* @teleloc 0xF5590023 [109.902000 70.389999 19.937000] 0.620978 0.000000 0.000000 -0.783828 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F55901E, 12561, 0xF5590023, 110.224, 65.5946, 19.937, 0.824169, 0, 0, -0.566344, False, '2021-11-01 00:00:00'); /* Tou-Tou Penninsula Cottages Portal */
/* @teleloc 0xF5590023 [110.223999 65.594597 19.937000] 0.824169 0.000000 0.000000 -0.566344 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F55901F, 13137, 0xF5590023, 113.343, 61.9311, 19.937, 0.955382, 0, 0, -0.295372, False, '2021-11-01 00:00:00'); /* Tou-Tou Road Villas Portal */
/* @teleloc 0xF5590023 [113.343002 61.931099 19.937000] 0.955382 0.000000 0.000000 -0.295372 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F559020, 12472, 0xF5590023, 118.085, 61.1065, 19.937, -0.999675, 0, 0, -0.025498, False, '2021-11-01 00:00:00'); /* Ariake Portal */
/* @teleloc 0xF5590023 [118.084999 61.106499 19.937000] -0.999675 0.000000 0.000000 -0.025498 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F5590A5,  1154, 0xF559003D, 187.044, 98.758, 20.005, -0.968323, 0, 0, 0.249699, False, '2021-11-01 00:00:00'); /* Linkable Monster Generator */
/* @teleloc 0xF559003D [187.044006 98.758003 20.004999] -0.968323 0.000000 0.000000 0.249699 */
