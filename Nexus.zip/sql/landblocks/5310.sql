DELETE FROM `landblock_instance` WHERE `landblock` = 0x5310;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x75310001, 4200152, 0x5310003A, 175.174, 27.854, 120.055, -0.897776, 0, 0, 0.440453, False, '2025-07-07 01:47:29'); /* Gate */
/* @teleloc 0x5310003A [175.173996 27.854000 120.055000] -0.897776 0.000000 0.000000 0.440453 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x75310002, 4200152, 0x53100039, 184.769, 12.8031, 120.055, -0.779697, 0, 0, 0.626157, False, '2025-07-07 01:47:38'); /* Gate */
/* @teleloc 0x53100039 [184.768997 12.803100 120.055000] -0.779697 0.000000 0.000000 0.626157 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x75310003, 4200152, 0x53100039, 181.861, 0.425877, 120.055, -0.012319, 0, 0, 0.999924, False, '2025-07-07 01:47:42'); /* Gate */
/* @teleloc 0x53100039 [181.860992 0.425877 120.055000] -0.012319 0.000000 0.000000 0.999924 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x75310004, 4200152, 0x53100031, 164.487, 1.32668, 120.055, 0.026794, 0, 0, 0.999641, False, '2025-07-07 01:47:47'); /* Gate */
/* @teleloc 0x53100031 [164.487000 1.326680 120.055000] 0.026794 0.000000 0.000000 0.999641 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x75310005, 4200152, 0x53100031, 152.597, 6.1069, 120.055, 0.715639, 0, 0, 0.69847, False, '2025-07-07 01:48:18'); /* Gate */
/* @teleloc 0x53100031 [152.597000 6.106900 120.055000] 0.715639 0.000000 0.000000 0.698470 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x75310006, 4200152, 0x53100031, 153.374, 22.7917, 120.055, 0.764917, 0, 0, 0.64413, False, '2025-07-07 01:48:25'); /* Gate */
/* @teleloc 0x53100031 [153.373993 22.791700 120.055000] 0.764917 0.000000 0.000000 0.644130 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x75310007, 4200152, 0x53100032, 161.583, 35.5783, 120.055, 0.999188, 0, 0, 0.04029, False, '2025-07-07 01:48:31'); /* Gate */
/* @teleloc 0x53100032 [161.582993 35.578300 120.055000] 0.999188 0.000000 0.000000 0.040290 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7531000A, 42852, 0x53100031, 158.446, 9.74748, 119.937, -0.262378, 0, 0, -0.964965, False, '2025-07-07 02:05:27'); /* Portal to Town Network */
/* @teleloc 0x53100031 [158.445999 9.747480 119.936996] -0.262378 0.000000 0.000000 -0.964965 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7531000B, 288819, 0x53100039, 169.643, 11.2854, 120.055, -0.163476, 0, 0, 0.986547, False, '2025-07-07 09:47:55'); /* williegen */
/* @teleloc 0x53100039 [169.643005 11.285400 120.055000] -0.163476 0.000000 0.000000 0.986547 */
