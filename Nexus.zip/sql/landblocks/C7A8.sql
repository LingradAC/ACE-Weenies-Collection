DELETE FROM `landblock_instance` WHERE `landblock` = 0xC7A8;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7C7A8000,   509, 0xC7A80006, 14.41281, 123.4305, 50, -0.921798, 0, 0, -0.38767, False, '2025-07-10 14:01:13'); /* Life Stone */
/* @teleloc 0xC7A80006 [14.412810 123.430496 50.000000] -0.921798 0.000000 0.000000 -0.387670 */
