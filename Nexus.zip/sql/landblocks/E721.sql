DELETE FROM `landblock_instance` WHERE `landblock` = 0xE721;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E721000, 24411, 0xE721001A, 81.8799, 24.1264, 22.0339, -0.95753, 0, 0, -0.288332, False, '2025-08-16 18:20:32'); /* Asheron Invasion Extreme Generators */
/* @teleloc 0xE721001A [81.879898 24.126400 22.033899] -0.957530 0.000000 0.000000 -0.288332 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E721001, 24411, 0xE721003E, 182.2158, 133.5629, 33.23965, 0.997184, 0, 0, 0.074995, False, '2025-08-16 18:44:20'); /* Asheron Invasion Extreme Generators */
/* @teleloc 0xE721003E [182.215805 133.562897 33.239651] 0.997184 0.000000 0.000000 0.074995 */
