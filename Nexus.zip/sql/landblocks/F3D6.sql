DELETE FROM `landblock_instance` WHERE `landblock` = 0xF3D6;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3D6000, 5000764, 0xF3D6001F, 84.7082, 157.817, 0.055, 0.996747, 0, 0, 0.080598, False, '2020-05-07 18:53:02'); /* Melee Skellie gen */
/* @teleloc 0xF3D6001F [84.708199 157.817001 0.055000] 0.996747 0.000000 0.000000 0.080598 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3D6001, 5000765, 0xF3D6001F, 84.7082, 157.817, 0.055, 0.996747, 0, 0, 0.080598, False, '2020-05-07 18:53:02'); /* Mage Skellie gen */
/* @teleloc 0xF3D6001F [84.708199 157.817001 0.055000] 0.996747 0.000000 0.000000 0.080598 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3D6007, 5000766, 0xF3D60037, 167.969, 154.749, 0.055, 0.998364, 0, 0, 0.05718, False, '2020-05-07 19:30:13'); /* Shreth gen */
/* @teleloc 0xF3D60037 [167.968994 154.748993 0.055000] 0.998364 0.000000 0.000000 0.057180 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3D6008, 5000296, 0xF3D60021, 113.037, 0.360931, 0.055, -0.918808, 0, 0, 0.394705, False, '2020-01-13 01:43:07'); /* Plant */
/* @teleloc 0xF3D60021 [113.037003 0.360931 0.055000] -0.918808 0.000000 0.000000 0.394705 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3D6009, 5000662, 0xF3D60029, 120.216, 5.05339, 0.055, -0.725452, 0, 0, 0.688273, False, '2020-01-13 01:43:07'); /* Plant */
/* @teleloc 0xF3D60029 [120.216003 5.053390 0.055000] -0.725452 0.000000 0.000000 0.688273 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3D600A, 5000295, 0xF3D60031, 161.09, 8.6984, 0.055, -0.959775, 0, 0, 0.280769, False, '2020-01-13 01:43:12'); /* Plant */
/* @teleloc 0xF3D60031 [161.089996 8.698400 0.055000] -0.959775 0.000000 0.000000 0.280769 */
