DELETE FROM `landblock_instance` WHERE `landblock` = 0x94E7;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x794E7000, 575721190, 0x94E7001F, 85.4693, 146.772, 31.39, 0.486587, 0, 0, -0.873632, False, '2025-07-26 21:37:18'); /* Prismatic Crystal */
/* @teleloc 0x94E7001F [85.469299 146.772003 31.389999] 0.486587 0.000000 0.000000 -0.873632 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x794E7001, 5721190, 0x94E70020, 95.6027, 178.087, 31.19, -0.592086, 0, 0, -0.805875, False, '2025-07-26 21:37:58'); /* Prismatic Crystal */
/* @teleloc 0x94E70020 [95.602699 178.087006 31.190001] -0.592086 0.000000 0.000000 -0.805875 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x794E7002, 5721190, 0x94E70018, 70.0896, 171.839, 31.19, 0.402024, 0, 0, 0.915629, False, '2025-07-26 21:38:14'); /* Prismatic Crystal */
/* @teleloc 0x94E70018 [70.089600 171.839005 31.190001] 0.402024 0.000000 0.000000 0.915629 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x794E7004, 5721194, 0x94E70016, 65.3177, 129.052, 31.24, -0.352106, 0, 0, 0.93596, False, '2025-07-26 21:38:45'); /* Prismatic Crystal */
/* @teleloc 0x94E70016 [65.317703 129.052002 31.240000] -0.352106 0.000000 0.000000 0.935960 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x794E7005, 5721194, 0x94E70027, 119.968, 158.732, 31.24, -0.596782, 0, 0, -0.802404, False, '2025-07-26 21:39:11'); /* Prismatic Crystal */
/* @teleloc 0x94E70027 [119.968002 158.731995 31.240000] -0.596782 0.000000 0.000000 -0.802404 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x794E7006, 5721188, 0x94E70026, 112.922, 127.274, 31.14, -0.970077, 0, 0, -0.242796, False, '2025-07-26 21:39:34'); /* Prismatic Crystal */
/* @teleloc 0x94E70026 [112.921997 127.274002 31.139999] -0.970077 0.000000 0.000000 -0.242796 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x794E7007, 5721188, 0x94E7001E, 91.7066, 124.886, 31.14, -0.625697, 0, 0, -0.780067, False, '2025-07-26 21:39:45'); /* Prismatic Crystal */
/* @teleloc 0x94E7001E [91.706596 124.886002 31.139999] -0.625697 0.000000 0.000000 -0.780067 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x794E7008, 5721190, 0x94E70017, 51.8079, 153.851, 31.19, -0.693307, 0, 0, 0.720642, False, '2025-07-26 21:40:09'); /* Prismatic Crystal */
/* @teleloc 0x94E70017 [51.807899 153.850998 31.190001] -0.693307 0.000000 0.000000 0.720642 */
