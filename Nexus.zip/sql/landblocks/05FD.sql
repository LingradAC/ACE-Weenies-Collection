DELETE FROM `landblock_instance` WHERE `landblock` = 0x05FD;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x705FD000, 86659180, 0x05FD0022, 104.617, 29.1972, 10, 0.721442, 0, 0, -0.692475, False, '2025-07-20 16:23:44'); /* RED BRICK ARCHWAY SQUARE2 */
/* @teleloc 0x05FD0022 [104.616997 29.197201 10.000000] 0.721442 0.000000 0.000000 -0.692475 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x705FD004, 86659180, 0x05FD001B, 83.3301, 48.24, 10.055, -0.725024, 0, 0, 0.688724, False, '2025-07-20 16:26:09'); /* RED BRICK ARCHWAY SQUARE2 */
/* @teleloc 0x05FD001B [83.330101 48.240002 10.055000] -0.725024 0.000000 0.000000 0.688724 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x705FD005, 86659180, 0x05FD0012, 63.3733, 47.2607, 10.055, -0.725024, 0, 0, 0.688724, False, '2025-07-20 16:26:14'); /* RED BRICK ARCHWAY SQUARE2 */
/* @teleloc 0x05FD0012 [63.373299 47.260700 10.055000] -0.725024 0.000000 0.000000 0.688724 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x705FD006, 86659180, 0x05FD0012, 64.3299, 27.3137, 10.055, -0.725024, 0, 0, 0.688724, False, '2025-07-20 16:27:04'); /* RED BRICK ARCHWAY SQUARE2 */
/* @teleloc 0x05FD0012 [64.329903 27.313700 10.055000] -0.725024 0.000000 0.000000 0.688724 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x705FD008, 86659180, 0x05FD001C, 74.7324, 75.0252, 10.055, 0.01995, 0, 0, -0.999801, False, '2025-07-20 16:29:43'); /* RED BRICK ARCHWAY SQUARE2 */
/* @teleloc 0x05FD001C [74.732399 75.025200 10.055000] 0.019950 0.000000 0.000000 -0.999801 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x705FD009, 86659180, 0x05FD0014, 54.905, 74.0892, 10.055, 0.01995, 0, 0, -0.999801, False, '2025-07-20 16:30:10'); /* RED BRICK ARCHWAY SQUARE2 */
/* @teleloc 0x05FD0014 [54.904999 74.089203 10.055000] 0.019950 0.000000 0.000000 -0.999801 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x705FD00A, 86659180, 0x05FD001A, 76.8317, 34.9916, 10.055, 0.01995, 0, 0, -0.999801, False, '2025-07-20 16:30:56'); /* RED BRICK ARCHWAY SQUARE2 */
/* @teleloc 0x05FD001A [76.831703 34.991600 10.055000] 0.019950 0.000000 0.000000 -0.999801 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x705FD00B, 86659178, 0x05FD0022, 101.223, 28.0169, 10.055, 0.013694, 0, 0, -0.999906, False, '2025-07-20 16:32:16'); /* RED BRICK WALL1 */
/* @teleloc 0x05FD0022 [101.223000 28.016899 10.055000] 0.013694 0.000000 0.000000 -0.999906 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x705FD00C, 86659178, 0x05FD0022, 105.907, 32.6586, 10.055, 0.72619, 0, 0, -0.687494, False, '2025-07-20 16:35:19'); /* RED BRICK WALL1 */
/* @teleloc 0x05FD0022 [105.906998 32.658600 10.055000] 0.726190 0.000000 0.000000 -0.687494 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x705FD00D, 86659178, 0x05FD0022, 105.652, 42.7685, 10.055, 0.713251, 0, 0, -0.700909, False, '2025-07-20 16:35:24'); /* RED BRICK WALL1 */
/* @teleloc 0x05FD0022 [105.652000 42.768501 10.055000] 0.713251 0.000000 0.000000 -0.700909 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x705FD013, 86659178, 0x05FD001C, 76.9566, 85.0724, 10.055, 0.017288, 0, 0, -0.999851, False, '2025-07-20 16:35:56'); /* RED BRICK WALL1 */
/* @teleloc 0x05FD001C [76.956596 85.072403 10.055000] 0.017288 0.000000 0.000000 -0.999851 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x705FD014, 86659178, 0x05FD0023, 105.513, 53.9257, 10.055, 0.71466, 0, 0, -0.699473, False, '2025-07-20 16:43:07'); /* RED BRICK WALL1 */
/* @teleloc 0x05FD0023 [105.513000 53.925701 10.055000] 0.714660 0.000000 0.000000 -0.699473 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x705FD015, 86659178, 0x05FD0023, 105.382, 65.014, 10.055, 0.71418, 0, 0, -0.699962, False, '2025-07-20 16:43:59'); /* RED BRICK WALL1 */
/* @teleloc 0x05FD0023 [105.382004 65.014000 10.055000] 0.714180 0.000000 0.000000 -0.699962 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x705FD016, 86659178, 0x05FD0024, 105.086, 76.5201, 10.055, 0.72519, 0, 0, -0.688549, False, '2025-07-20 16:44:32'); /* RED BRICK WALL1 */
/* @teleloc 0x05FD0024 [105.085999 76.520103 10.055000] 0.725190 0.000000 0.000000 -0.688549 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x705FD017, 86659178, 0x05FD001C, 87.1283, 85.4292, 10.055, -0.999573, 0, 0, -0.029219, False, '2025-07-20 16:45:05'); /* RED BRICK WALL1 */
/* @teleloc 0x05FD001C [87.128304 85.429199 10.055000] -0.999573 0.000000 0.000000 -0.029219 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x705FD018, 86659178, 0x05FD001C, 95.2734, 86.0824, 10.055, -0.99853, 0, 0, -0.054196, False, '2025-07-20 16:45:10'); /* RED BRICK WALL1 */
/* @teleloc 0x05FD001C [95.273399 86.082397 10.055000] -0.998530 0.000000 0.000000 -0.054196 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x705FD019, 86659178, 0x05FD0024, 102.082, 83.4335, 10.055, -0.952858, 0, 0, 0.303418, False, '2025-07-20 16:45:18'); /* RED BRICK WALL1 */
/* @teleloc 0x05FD0024 [102.082001 83.433502 10.055000] -0.952858 0.000000 0.000000 0.303418 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x705FD01A, 86659178, 0x05FD001A, 90.0864, 27.7296, 10.055, -0.017379, 0, 0, 0.999849, False, '2025-07-20 16:46:10'); /* RED BRICK WALL1 */
/* @teleloc 0x05FD001A [90.086403 27.729601 10.055000] -0.017379 0.000000 0.000000 0.999849 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x705FD01B, 86659178, 0x05FD001A, 79.1483, 27.2205, 10.055, 0.042128, 0, 0, -0.999112, False, '2025-07-20 16:46:33'); /* RED BRICK WALL1 */
/* @teleloc 0x05FD001A [79.148300 27.220501 10.055000] 0.042128 0.000000 0.000000 -0.999112 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x705FD01C, 86659178, 0x05FD0012, 67.712, 26.0156, 10.055, 0.059861, 0, 0, -0.998207, False, '2025-07-20 16:47:15'); /* RED BRICK WALL1 */
/* @teleloc 0x05FD0012 [67.711998 26.015600 10.055000] 0.059861 0.000000 0.000000 -0.998207 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x705FD01D, 86659178, 0x05FD0012, 60.0291, 25.3131, 10.055, 0.054578, 0, 0, -0.99851, False, '2025-07-20 16:47:56'); /* RED BRICK WALL1 */
/* @teleloc 0x05FD0012 [60.029099 25.313101 10.055000] 0.054578 0.000000 0.000000 -0.998510 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x705FD01E, 86659178, 0x05FD0012, 54.2994, 32.52, 10.055, -0.698676, 0, 0, -0.715438, False, '2025-07-20 16:48:06'); /* RED BRICK WALL1 */
/* @teleloc 0x05FD0012 [54.299400 32.520000 10.055000] -0.698676 0.000000 0.000000 -0.715438 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x705FD01F, 86659178, 0x05FD0012, 54.454, 41.1522, 10.055, -0.718998, 0, 0, -0.695012, False, '2025-07-20 16:48:44'); /* RED BRICK WALL1 */
/* @teleloc 0x05FD0012 [54.453999 41.152199 10.055000] -0.718998 0.000000 0.000000 -0.695012 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x705FD020, 86659178, 0x05FD0013, 54.8468, 51.4621, 10.055, -0.715976, 0, 0, -0.698125, False, '2025-07-20 16:49:00'); /* RED BRICK WALL1 */
/* @teleloc 0x05FD0013 [54.846802 51.462101 10.055000] -0.715976 0.000000 0.000000 -0.698125 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x705FD021, 86659178, 0x05FD0013, 55.1451, 59.3145, 10.055, -0.715976, 0, 0, -0.698125, False, '2025-07-20 16:49:03'); /* RED BRICK WALL1 */
/* @teleloc 0x05FD0013 [55.145100 59.314499 10.055000] -0.715976 0.000000 0.000000 -0.698125 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x705FD022, 86659178, 0x05FD0013, 55.1579, 70.8242, 10.055, -0.692768, 0, 0, -0.721161, False, '2025-07-20 16:49:19'); /* RED BRICK WALL1 */
/* @teleloc 0x05FD0013 [55.157902 70.824203 10.055000] -0.692768 0.000000 0.000000 -0.721161 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x705FD023, 86659178, 0x05FD0014, 54.9291, 79.0089, 10.055, -0.692768, 0, 0, -0.721161, False, '2025-07-20 16:49:22'); /* RED BRICK WALL1 */
/* @teleloc 0x05FD0014 [54.929100 79.008904 10.055000] -0.692768 0.000000 0.000000 -0.721161 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x705FD024, 86659178, 0x05FD0014, 67.2123, 84.9762, 10.055, -0.999968, 0, 0, 0.008026, False, '2025-07-20 16:49:28'); /* RED BRICK WALL1 */
/* @teleloc 0x05FD0014 [67.212303 84.976196 10.055000] -0.999968 0.000000 0.000000 0.008026 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x705FD025, 86659178, 0x05FD0014, 57.5795, 85.1944, 10.055, -0.999998, 0, 0, -0.001964, False, '2025-07-20 16:49:33'); /* RED BRICK WALL1 */
/* @teleloc 0x05FD0014 [57.579498 85.194397 10.055000] -0.999998 0.000000 0.000000 -0.001964 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x705FD026, 86659180, 0x05FD0024, 100.154, 78.0607, 10.055, 0.745205, 0, 0, -0.666836, False, '2025-07-20 17:44:41'); /* RED BRICK ARCHWAY SQUARE2 */
/* @teleloc 0x05FD0024 [100.153999 78.060699 10.055000] 0.745205 0.000000 0.000000 -0.666836 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x705FD027, 86659180, 0x05FD0023, 100.962, 63.9164, 10.055, -0.655324, 0, 0, -0.755348, False, '2025-07-20 17:44:49'); /* RED BRICK ARCHWAY SQUARE2 */
/* @teleloc 0x05FD0023 [100.961998 63.916401 10.055000] -0.655324 0.000000 0.000000 -0.755348 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x705FD028, 86659180, 0x05FD0023, 100.146, 71.8699, 10.055, -0.660049, 0, 0, -0.751223, False, '2025-07-20 17:44:57'); /* RED BRICK ARCHWAY SQUARE2 */
/* @teleloc 0x05FD0023 [100.146004 71.869904 10.055000] -0.660049 0.000000 0.000000 -0.751223 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x705FD029, 86659180, 0x05FD0024, 99.6319, 75.8366, 10.055, -0.660049, 0, 0, -0.751223, False, '2025-07-20 17:44:59'); /* RED BRICK ARCHWAY SQUARE2 */
/* @teleloc 0x05FD0024 [99.631897 75.836601 10.055000] -0.660049 0.000000 0.000000 -0.751223 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x705FD02A, 86659180, 0x05FD0014, 56.5084, 83.836, 10.055, -0.998753, 0, 0, 0.049934, False, '2025-07-20 17:45:23'); /* RED BRICK ARCHWAY SQUARE2 */
/* @teleloc 0x05FD0014 [56.508400 83.835999 10.055000] -0.998753 0.000000 0.000000 0.049934 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x705FD02B, 86659180, 0x05FD0014, 63.6317, 83.7585, 10.055, -0.999979, 0, 0, -0.006432, False, '2025-07-20 17:45:31'); /* RED BRICK ARCHWAY SQUARE2 */
/* @teleloc 0x05FD0014 [63.631699 83.758499 10.055000] -0.999979 0.000000 0.000000 -0.006432 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x705FD02C, 86659180, 0x05FD0014, 71.1734, 77.4532, 10.055, -0.999972, 0, 0, -0.007489, False, '2025-07-20 17:45:35'); /* RED BRICK ARCHWAY SQUARE2 */
/* @teleloc 0x05FD0014 [71.173401 77.453201 10.055000] -0.999972 0.000000 0.000000 -0.007489 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x705FD02D, 86659178, 0x05FD0014, 60.7534, 74.3657, 10.055, -0.000449, 0, 0, -1, False, '2025-07-20 17:46:02'); /* RED BRICK WALL1 */
/* @teleloc 0x05FD0014 [60.753399 74.365700 10.055000] -0.000449 0.000000 0.000000 -1.000000 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x705FD02E, 911917, 0x05FD0013, 56.4892, 59.8909, 10.005, -0.700701, 0, 0, 0.713456, False, '2025-07-20 21:33:31'); /* 100MMD Gambler */
/* @teleloc 0x05FD0013 [56.489201 59.890900 10.005000] -0.700701 0.000000 0.000000 0.713456 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x705FD02F, 911916, 0x05FD0013, 56.4552, 58.0048, 10.005, -0.700701, 0, 0, 0.713456, False, '2025-07-20 21:33:37'); /* 60MMD Gambler */
/* @teleloc 0x05FD0013 [56.455200 58.004799 10.005000] -0.700701 0.000000 0.000000 0.713456 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x705FD031, 911911, 0x05FD0023, 104.179, 56.1143, 10.005, -0.718233, 0, 0, -0.695803, False, '2025-07-20 21:34:12'); /* 5 Uber-Gem Gambler */
/* @teleloc 0x05FD0023 [104.179001 56.114300 10.005000] -0.718233 0.000000 0.000000 -0.695803 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x705FD032, 911912, 0x05FD0023, 104.149, 58.5114, 10.005, -0.718233, 0, 0, -0.695803, False, '2025-07-20 21:34:17'); /* 10 Uber-Gem Gambler */
/* @teleloc 0x05FD0023 [104.149002 58.511398 10.005000] -0.718233 0.000000 0.000000 -0.695803 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x705FD033, 911913, 0x05FD0023, 104.127, 60.549, 10.005, -0.718233, 0, 0, -0.695803, False, '2025-07-20 21:34:20'); /* 20 Uber-Gem Gambler */
/* @teleloc 0x05FD0023 [104.126999 60.549000 10.005000] -0.718233 0.000000 0.000000 -0.695803 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x705FD034, 86659171, 0x05FD0023, 104.159, 57.2432, 10, 0.745386, 0, 0, -0.666633, False, '2025-07-20 21:34:45'); /* DISCO LIGHT11 */
/* @teleloc 0x05FD0023 [104.158997 57.243198 10.000000] 0.745386 0.000000 0.000000 -0.666633 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x705FD035, 86659171, 0x05FD0013, 56.6217, 57.2179, 10, 0.732914, 0, 0, 0.680322, False, '2025-07-20 21:34:53'); /* DISCO LIGHT11 */
/* @teleloc 0x05FD0013 [56.621700 57.217899 10.000000] 0.732914 0.000000 0.000000 0.680322 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x705FD036, 86659171, 0x05FD001B, 82.5054, 57.643, 10, 0.654078, 0, 0, 0.756427, False, '2025-07-20 21:35:02'); /* DISCO LIGHT11 */
/* @teleloc 0x05FD001B [82.505402 57.643002 10.000000] 0.654078 0.000000 0.000000 0.756427 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x705FD03B, 34282, 0x05FD0023, 103.484, 54.3384, 10.0006, 0.689659, 0, 0, -0.724134, False, '2025-07-20 21:37:08'); /* Wheel of Knowledge */
/* @teleloc 0x05FD0023 [103.484001 54.338402 10.000600] 0.689659 0.000000 0.000000 -0.724134 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x705FD03C, 34282, 0x05FD0023, 104.104, 62.2102, 10.0006, 0.689659, 0, 0, -0.724134, False, '2025-07-20 21:37:15'); /* Wheel of Knowledge */
/* @teleloc 0x05FD0023 [104.103996 62.210201 10.000600] 0.689659 0.000000 0.000000 -0.724134 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x705FD03D, 34282, 0x05FD0013, 56.2948, 53.7716, 10.0006, -0.70617, 0, 0, -0.708042, False, '2025-07-20 21:37:22'); /* Wheel of Knowledge */
/* @teleloc 0x05FD0013 [56.294800 53.771599 10.000600] -0.706170 0.000000 0.000000 -0.708042 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x705FD03E, 34282, 0x05FD0013, 56.8437, 62.5857, 10.0006, -0.731689, 0, 0, -0.681639, False, '2025-07-20 21:37:25'); /* Wheel of Knowledge */
/* @teleloc 0x05FD0013 [56.843700 62.585701 10.000600] -0.731689 0.000000 0.000000 -0.681639 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x705FD046, 10706, 0x05FD001B, 92.7871, 49.1571, 10.0015, 0.034927, 0, 0, -0.99939, False, '2025-07-20 21:40:54'); /* Wheel of Fortune */
/* @teleloc 0x05FD001B [92.787102 49.157101 10.001500] 0.034927 0.000000 0.000000 -0.999390 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x705FD047, 10706, 0x05FD001B, 73.2664, 48.1895, 10.0015, 0.003467, 0, 0, -0.999994, False, '2025-07-20 21:40:59'); /* Wheel of Fortune */
/* @teleloc 0x05FD001B [73.266403 48.189499 10.001500] 0.003467 0.000000 0.000000 -0.999994 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x705FD048, 10706, 0x05FD001B, 73.9686, 64.5021, 10.0015, 0.997951, 0, 0, 0.063984, False, '2025-07-20 21:41:03'); /* Wheel of Fortune */
/* @teleloc 0x05FD001B [73.968597 64.502098 10.001500] 0.997951 0.000000 0.000000 0.063984 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x705FD049, 10706, 0x05FD001B, 91.7021, 62.1747, 10.0015, 0.994655, 0, 0, 0.103259, False, '2025-07-20 21:41:07'); /* Wheel of Fortune */
/* @teleloc 0x05FD001B [91.702103 62.174702 10.001500] 0.994655 0.000000 0.000000 0.103259 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x705FD04A, 86659159, 0x05FD001C, 78.5444, 79.5687, 10.012, 0.999619, 0, 0, 0.027601, False, '2025-07-20 21:42:08'); /* ASHERON DIAMOND WITH BLUE LIGHT */
/* @teleloc 0x05FD001C [78.544403 79.568703 10.012000] 0.999619 0.000000 0.000000 0.027601 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x705FD04B, 86653868, 0x05FD001A, 77.8941, 30.4621, 10.0075, -0.999996, 0, 0, 0.00284, False, '2025-07-20 21:42:58'); /* Bael'Zharon */
/* @teleloc 0x05FD001A [77.894096 30.462099 10.007500] -0.999996 0.000000 0.000000 0.002840 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x705FD04C, 911914, 0x05FD0013, 56.3335, 55.5629, 10.005, 0.710459, 0, 0, -0.703739, False, '2025-07-20 23:22:21'); /* 20MMD Gambler */
/* @teleloc 0x05FD0013 [56.333500 55.562901 10.005000] 0.710459 0.000000 0.000000 -0.703739 */
