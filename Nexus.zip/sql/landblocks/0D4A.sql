DELETE FROM `landblock_instance` WHERE `landblock` = 0x0D4A;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70D4A00A, 86659156, 0x0D4A010D, 115.468, 28.6187, 18.2, 0.982013, 0, 0, 0.188813, False, '2025-07-16 16:19:18'); /* BLACK PILLAR WITH RED LIGHTNING */
/* @teleloc 0x0D4A010D [115.468002 28.618700 18.200001] 0.982013 0.000000 0.000000 0.188813 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70D4A00B, 86659156, 0x0D4A010D, 96.6083, 27.4553, 18.2, -0.027331, 0, 0, 0.999627, False, '2025-07-16 16:19:24'); /* BLACK PILLAR WITH RED LIGHTNING */
/* @teleloc 0x0D4A010D [96.608299 27.455299 18.200001] -0.027331 0.000000 0.000000 0.999627 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70D4A013, 49100001, 0x0D4A010D, 101.598, 27.12, 18.2075, 0.99531, 0, 0, -0.096739, False, '2025-07-16 21:02:09'); /* Lady Boy */
/* @teleloc 0x0D4A010D [101.598000 27.120001 18.207500] 0.995310 0.000000 0.000000 -0.096739 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70D4A02A, 716004, 0x0D4A010D, 112.969, 27.36, 18.21, -0.999853, 0, 0, -0.017121, False, '2025-07-16 21:16:47'); /* Dread Og */
/* @teleloc 0x0D4A010D [112.969002 27.360001 18.209999] -0.999853 0.000000 0.000000 -0.017121 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70D4A02C, 716164, 0x0D4A012D, 107.941, 84.2743, 19.8102, 0.007157, 0, 0, -0.999974, False, '2025-07-16 21:28:31'); /* Surface Portal */
/* @teleloc 0x0D4A012D [107.941002 84.274300 19.810200] 0.007157 0.000000 0.000000 -0.999974 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70D4A02E, 4210005, 0x0D4A0107, 87.3283, 27.5074, 18.21, 0.999053, 0, 0, -0.04351, False, '2025-07-16 21:32:14'); /* Anti Parazi */
/* @teleloc 0x0D4A0107 [87.328300 27.507401 18.209999] 0.999053 0.000000 0.000000 -0.043510 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70D4A02F, 86659156, 0x0D4A0105, 164.715, 49.2057, 18.2, 0.709805, 0, 0, -0.704398, False, '2025-07-16 21:33:24'); /* BLACK PILLAR WITH RED LIGHTNING */
/* @teleloc 0x0D4A0105 [164.714996 49.205700 18.200001] 0.709805 0.000000 0.000000 -0.704398 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70D4A030, 86659156, 0x0D4A0105, 165.1, 62.5678, 18.2, 0.718857, 0, 0, -0.695158, False, '2025-07-16 21:34:44'); /* BLACK PILLAR WITH RED LIGHTNING */
/* @teleloc 0x0D4A0105 [165.100006 62.567799 18.200001] 0.718857 0.000000 0.000000 -0.695158 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70D4A031,  2556, 0x0D4A0107, 93.7733, 27.7625, 18.137, 0.999559, 0, 0, 0.029691, False, '2025-07-16 21:37:19'); /* PVP Portal Temple */
/* @teleloc 0x0D4A0107 [93.773300 27.762501 18.136999] 0.999559 0.000000 0.000000 0.029691 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70D4A033, 898731, 0x0D4A012D, 98.7386, 74.6509, 18.2085, 0.945214, 0, 0, -0.326452, False, '2025-07-17 08:11:57'); /* Quintessence */
/* @teleloc 0x0D4A012D [98.738602 74.650902 18.208500] 0.945214 0.000000 0.000000 -0.326452 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70D4A042,  5772, 0x0D4A0106, 123.713, 26.8844, 18.205, 0.999044, 0, 0, 0.043723, False, '2025-07-17 09:19:43'); /* Town Crier */
/* @teleloc 0x0D4A0106 [123.712997 26.884399 18.205000] 0.999044 0.000000 0.000000 0.043723 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70D4A043, 490085, 0x0D4A0121, 99.3419, 51.1979, 18.2, 0.393935, 0, 0, 0.919138, False, '2025-07-17 09:20:03'); /* Gate */
/* @teleloc 0x0D4A0121 [99.341904 51.197899 18.200001] 0.393935 0.000000 0.000000 0.919138 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70D4A044, 42852, 0x0D4A0121, 99.6964, 51.3486, 18.137, 0.49463, 0, 0, 0.869104, False, '2025-07-17 09:20:16'); /* Portal to Town Network */
/* @teleloc 0x0D4A0121 [99.696404 51.348598 18.136999] 0.494630 0.000000 0.000000 0.869104 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70D4A04D, 666291444, 0x0D4A002B, 140.788, 50.4408, 41.9813, 0.507334, 0, 0, -0.86175, False, '2025-07-23 06:56:44'); /* Gaerlan The Mad Archmage */
/* @teleloc 0x0D4A002B [140.787994 50.440800 41.981300] 0.507334 0.000000 0.000000 -0.861750 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70D4A04E, 86659156, 0x0D4A002B, 141.065, 54.0754, 42, 0.13598, 0, 0, -0.990712, False, '2025-07-23 06:57:30'); /* BLACK PILLAR WITH RED LIGHTNING */
/* @teleloc 0x0D4A002B [141.065002 54.075401 42.000000] 0.135980 0.000000 0.000000 -0.990712 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70D4A04F, 86659156, 0x0D4A002B, 135.979, 50.0364, 42, 0.376859, 0, 0, -0.926271, False, '2025-07-23 06:57:34'); /* BLACK PILLAR WITH RED LIGHTNING */
/* @teleloc 0x0D4A002B [135.979004 50.036400 42.000000] 0.376859 0.000000 0.000000 -0.926271 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70D4A050, 23482398, 0x0D4A0129, 118.36, 92.718, 18.205, 0.454682, 0, 0, 0.890654, False, '2025-07-23 07:14:29'); /* Geraine Warden of the Reach */
/* @teleloc 0x0D4A0129 [118.360001 92.718002 18.205000] 0.454682 0.000000 0.000000 0.890654 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70D4A052, 62819828, 0x0D4A0023, 118.783, 49.0575, 18.255, -0.923178, 0, 0, -0.384372, False, '2025-07-25 14:16:18'); /* Threxil, the Mind Aperture */
/* @teleloc 0x0D4A0023 [118.782997 49.057499 18.254999] -0.923178 0.000000 0.000000 -0.384372 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70D4A053, 62819828, 0x0D4A0121, 116.624, 51.6383, 18.2667, -0.950303, 0, 0, -0.311325, False, '2025-07-25 14:16:59'); /* Threxil, the Mind Aperture */
/* @teleloc 0x0D4A0121 [116.624001 51.638302 18.266701] -0.950303 0.000000 0.000000 -0.311325 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70D4A05A, 490325, 0x0D4A0101, 51.806, 27.36, 18.21, 0.933071, 0, 0, -0.359693, False, '2025-07-29 03:26:35'); /* Baldur */
/* @teleloc 0x0D4A0101 [51.806000 27.360001 18.209999] 0.933071 0.000000 0.000000 -0.359693 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70D4A05C, 86659156, 0x0D4A0102, 52.8834, 141.076, 18.2, 0.944791, 0, 0, 0.327674, False, '2025-07-29 03:27:09'); /* BLACK PILLAR WITH RED LIGHTNING */
/* @teleloc 0x0D4A0102 [52.883400 141.076004 18.200001] 0.944791 0.000000 0.000000 0.327674 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70D4A05D, 86659156, 0x0D4A0102, 51.2656, 139.191, 18.2, 0.944791, 0, 0, 0.327674, False, '2025-07-29 03:27:11'); /* BLACK PILLAR WITH RED LIGHTNING */
/* @teleloc 0x0D4A0102 [51.265598 139.190994 18.200001] 0.944791 0.000000 0.000000 0.327674 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70D4A05E, 86659156, 0x0D4A0101, 51.1862, 28.4358, 18.2, 0.328852, 0, 0, 0.944381, False, '2025-07-29 03:27:26'); /* BLACK PILLAR WITH RED LIGHTNING */
/* @teleloc 0x0D4A0101 [51.186199 28.435801 18.200001] 0.328852 0.000000 0.000000 0.944381 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70D4A05F, 86659156, 0x0D4A0101, 53.099, 26.9, 18.2, 0.328852, 0, 0, 0.944381, False, '2025-07-29 03:27:28'); /* BLACK PILLAR WITH RED LIGHTNING */
/* @teleloc 0x0D4A0101 [53.098999 26.900000 18.200001] 0.328852 0.000000 0.000000 0.944381 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70D4A060, 45501, 0x0D4A0103, 164.976, 139.651, 18.2065, 0.54641, 0, 0, 0.837518, False, '2025-07-29 03:28:03'); /* Business Cow  */
/* @teleloc 0x0D4A0103 [164.975998 139.651001 18.206499] 0.546410 0.000000 0.000000 0.837518 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70D4A061, 716001, 0x0D4A0103, 164.202, 140.976, 18.2065, 0.399437, 0, 0, 0.916761, False, '2025-07-29 03:28:11'); /* Business Mite */
/* @teleloc 0x0D4A0103 [164.201996 140.975998 18.206499] 0.399437 0.000000 0.000000 0.916761 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70D4A062, 86659156, 0x0D4A0103, 165.1, 138.441, 18.2, -0.831622, 0, 0, 0.555343, False, '2025-07-29 03:28:17'); /* BLACK PILLAR WITH RED LIGHTNING */
/* @teleloc 0x0D4A0103 [165.100006 138.440994 18.200001] -0.831622 0.000000 0.000000 0.555343 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70D4A063, 86659156, 0x0D4A0103, 162.91, 141.1, 18.2, -0.940377, 0, 0, 0.340133, False, '2025-07-29 03:28:21'); /* BLACK PILLAR WITH RED LIGHTNING */
/* @teleloc 0x0D4A0103 [162.910004 141.100006 18.200001] -0.940377 0.000000 0.000000 0.340133 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70D4A064, 86659156, 0x0D4A010D, 107.714, 27.9, 18.2, -0.008205, 0, 0, 0.999966, False, '2025-07-29 03:28:50'); /* BLACK PILLAR WITH RED LIGHTNING */
/* @teleloc 0x0D4A010D [107.713997 27.900000 18.200001] -0.008205 0.000000 0.000000 0.999966 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70D4A065, 86659156, 0x0D4A0107, 90.7489, 27.7502, 18.2, -0.030828, 0, 0, 0.999525, False, '2025-07-29 03:29:28'); /* BLACK PILLAR WITH RED LIGHTNING */
/* @teleloc 0x0D4A0107 [90.748901 27.750200 18.200001] -0.030828 0.000000 0.000000 0.999525 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70D4A066, 86659156, 0x0D4A0107, 85.1319, 27.1701, 18.2, 0.007381, 0, 0, 0.999973, False, '2025-07-29 03:29:44'); /* BLACK PILLAR WITH RED LIGHTNING */
/* @teleloc 0x0D4A0107 [85.131897 27.170099 18.200001] 0.007381 0.000000 0.000000 0.999973 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70D4A067, 700012, 0x0D4A0129, 97.5753, 92.4573, 18.2065, 0.480814, 0, 0, -0.876823, False, '2025-07-29 19:22:31'); /* Nexus Buffer Mage */
/* @teleloc 0x0D4A0129 [97.575302 92.457298 18.206499] 0.480814 0.000000 0.000000 -0.876823 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70D4A069, 63212983, 0x0D4A001B, 78.8873, 52.8858, 41.937, -0.442569, 0, 0, -0.896735, False, '2025-07-30 05:26:40'); /* Simiran Portal */
/* @teleloc 0x0D4A001B [78.887299 52.885799 41.937000] -0.442569 0.000000 0.000000 -0.896735 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70D4A06D, 888522, 0x0D4A0104, 164.64, 113.512, 18.21, -0.615638, 0, 0, -0.788029, False, '2025-07-30 06:03:33'); /* Rookie */
/* @teleloc 0x0D4A0104 [164.639999 113.512001 18.209999] -0.615638 0.000000 0.000000 -0.788029 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70D4A06E, 716006, 0x0D4A0104, 164.803, 107.415, 18.2088, 0.858428, 0, 0, 0.512934, False, '2025-07-30 06:03:50'); /* Spacemonkey */
/* @teleloc 0x0D4A0104 [164.802994 107.415001 18.208799] 0.858428 0.000000 0.000000 0.512934 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70D4A070, 63212985, 0x0D4A0032, 164.221, 28.0341, 29.937, 0.642527, 0, 0, -0.766263, False, '2025-08-19 08:25:55'); /* The Red Vaults */
/* @teleloc 0x0D4A0032 [164.220993 28.034100 29.937000] 0.642527 0.000000 0.000000 -0.766263 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70D4A071, 42389238, 0x0D4A0032, 165.92, 42.949, 30.537, -0.755896, 0, 0, -0.654692, False, '2025-08-19 08:26:07'); /* Blood Pit */
/* @teleloc 0x0D4A0032 [165.919998 42.949001 30.537001] -0.755896 0.000000 0.000000 -0.654692 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70D4A073, 931271771, 0x0D4A0024, 108.126, 72.203, 54.655, 0.999986, 0, 0, 0.005349, False, '2025-08-25 07:03:32'); /* pvp trap */
/* @teleloc 0x0D4A0024 [108.125999 72.203003 54.654999] 0.999986 0.000000 0.000000 0.005349 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70D4A074, 716007, 0x0D4A0104, 164.495, 110.63, 18.2, 0.715125, 0, 0, -0.698997, False, '2025-08-28 00:51:25');
/* @teleloc 0x0D4A0104 [164.494995 110.629997 18.200001] 0.715125 0.000000 0.000000 -0.698997 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70D4A076, 39496921, 0x0D4A012D, 117.623, 75.0124, 18.2085, -0.821092, 0, 0, -0.570796, False, '2025-08-30 13:11:06'); /* Igris The Nexus Knight */
/* @teleloc 0x0D4A012D [117.623001 75.012398 18.208500] -0.821092 0.000000 0.000000 -0.570796 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x70D4A077, 36969211, 0x0D4A0032, 154.964, 25.8855, 30.537, -0.037399, 0, 0, 0.9993, False, '2025-09-04 22:09:41'); /* Portal to Dark Fiun Halls */
/* @teleloc 0x0D4A0032 [154.964005 25.885500 30.537001] -0.037399 0.000000 0.000000 0.999300 */
