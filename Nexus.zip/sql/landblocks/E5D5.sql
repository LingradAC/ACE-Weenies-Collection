DELETE FROM `landblock_instance` WHERE `landblock` = 0xE5D5;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E5D5000, 4200152, 0xE5D50030, 143.795, 179.487, -0.845, -0.531356, 0, 0, -0.847148, False, '2025-07-19 10:22:46'); /* Gate */
/* @teleloc 0xE5D50030 [143.794998 179.487000 -0.845000] -0.531356 0.000000 0.000000 -0.847148 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E5D5001, 4200152, 0xE5D50037, 151.216, 161.278, -0.845, 0.817677, 0, 0, -0.575677, False, '2025-07-19 10:22:54'); /* Gate */
/* @teleloc 0xE5D50037 [151.216003 161.278000 -0.845000] 0.817677 0.000000 0.000000 -0.575677 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E5D5002, 4200152, 0xE5D50036, 158.156, 140.865, -0.845, 0.819606, 0, 0, -0.572927, False, '2025-07-19 10:23:03'); /* Gate */
/* @teleloc 0xE5D50036 [158.156006 140.865005 -0.845000] 0.819606 0.000000 0.000000 -0.572927 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E5D5003, 4200152, 0xE5D50035, 166.553, 119.784, -0.845, 0.833556, 0, 0, -0.552435, False, '2025-07-19 10:23:08'); /* Gate */
/* @teleloc 0xE5D50035 [166.552994 119.783997 -0.845000] 0.833556 0.000000 0.000000 -0.552435 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E5D5004, 4200152, 0xE5D5003D, 174.223, 98.0894, -0.845, 0.793947, 0, 0, -0.607987, False, '2025-07-19 10:23:13'); /* Gate */
/* @teleloc 0xE5D5003D [174.223007 98.089401 -0.845000] 0.793947 0.000000 0.000000 -0.607987 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E5D5006, 4200152, 0xE5D5003B, 170.663, 56.6546, -0.845, 0.519274, 0, 0, -0.854608, False, '2025-07-19 10:23:51'); /* Gate */
/* @teleloc 0xE5D5003B [170.662994 56.654598 -0.845000] 0.519274 0.000000 0.000000 -0.854608 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E5D5007, 4200152, 0xE5D50032, 161.3, 37.0406, -0.845, 0.52668, 0, 0, -0.850063, False, '2025-07-19 10:23:56'); /* Gate */
/* @teleloc 0xE5D50032 [161.300003 37.040600 -0.845000] 0.526680 0.000000 0.000000 -0.850063 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E5D5008, 4200152, 0xE5D5003C, 176.285, 77.2696, -0.845, 0.667361, 0, 0, -0.744734, False, '2025-07-19 10:24:17'); /* Gate */
/* @teleloc 0xE5D5003C [176.285004 77.269600 -0.845000] 0.667361 0.000000 0.000000 -0.744734 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E5D5009, 4200152, 0xE5D50031, 157.942, 16.2355, -0.395, 0.725079, 0, 0, -0.688666, False, '2025-07-19 10:24:31'); /* Gate */
/* @teleloc 0xE5D50031 [157.942001 16.235500 -0.395000] 0.725079 0.000000 0.000000 -0.688666 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E5D500A, 4200152, 0xE5D50039, 169.493, 5.40389, -0.045, -0.999999, 0, 0, -0.001679, False, '2025-07-27 19:47:39'); /* Gate */
/* @teleloc 0xE5D50039 [169.492996 5.403890 -0.045000] -0.999999 0.000000 0.000000 -0.001679 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E5D500B, 4200152, 0xE5D50039, 183.36, 2.23692, -0.395, -0.967158, 0, 0, 0.254177, False, '2025-07-27 19:47:44'); /* Gate */
/* @teleloc 0xE5D50039 [183.360001 2.236920 -0.395000] -0.967158 0.000000 0.000000 0.254177 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E5D500C, 86653838, 0xE5D50031, 155.362, 8.79606, -0.045, 0.026514, 0, 0, -0.999649, False, '2025-07-27 19:54:03'); /* palmtree1 */
/* @teleloc 0xE5D50031 [155.362000 8.796060 -0.045000] 0.026514 0.000000 0.000000 -0.999649 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E5D500D, 86653838, 0xE5D50031, 165.138, 2.84372, -0.045, 0.742825, 0, 0, -0.669486, False, '2025-07-27 19:54:15'); /* palmtree1 */
/* @teleloc 0xE5D50031 [165.138000 2.843720 -0.045000] 0.742825 0.000000 0.000000 -0.669486 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E5D500E, 5000204, 0xE5D50031, 154.679, 18.2368, -0.395, -0.037229, 0, 0, 0.999307, False, '2025-07-27 19:55:51'); /* Tall Tree */
/* @teleloc 0xE5D50031 [154.679001 18.236799 -0.395000] -0.037229 0.000000 0.000000 0.999307 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7E5D500F, 5000204, 0xE5D50031, 157.825, 0.38312, -0.045, -0.72237, 0, 0, 0.691507, False, '2025-07-27 19:56:00'); /* Tall Tree */
/* @teleloc 0xE5D50031 [157.824997 0.383120 -0.045000] -0.722370 0.000000 0.000000 0.691507 */
